# Reproduce the additional result figures

Run from this directory:

    python plot_new_results.py --output outputs

The default raster export is 1000 dpi. The program reads the three CSV files in
source_data and writes PDF, editable SVG, PNG, and 300 dpi reading previews.
PDF is the layout reference. SVG text uses Arial, with DejaVu Sans as the stated
fallback; font substitution may change text widths. Required packages are
matplotlib, numpy, and pandas.

Figure 9 contains every primary contrast from the three additional independent
searches (36 estimates). Each search has its own prespecified 12-contrast
simultaneous interval family. There are three independent searches, not 150
independent searches. The four empirical zero contrasts in Otter searches 2 and 3
have no estimated interval and are shown with open symbols. They do not establish
equivalence.

Figure 10 contains eight complete-model local deletion effects and all 12 primary
between-background contrasts from the crossed module intervention. The local
intervals are nominal pointwise intervals; the background contrasts have
simultaneous intervals. Figure S6 contains all 24 local effects, including the
module interaction. The graphical abstract repeats an explicitly selected subset
of these results. Repeated display does not create additional observations.

All estimates and interval endpoints are read from the supplied analysis tables.
The plotting program does not refit, recompute, widen, smooth, or alter them.
Different panels have different linear axis ranges to keep small effects readable.
Very narrow intervals may be smaller than a marker; exact values remain in the CSV
files and outputs/plotted_values.json. Numerical qualification and its limited
two-seed scope remain attached to each source-data row.

The additional analyses preserve three RISE production-step numerical limitations
in their wider experimental record. These are not removed by a figure audit.
The current figures do not claim hardware validation or a universally superior
controller.

Final physical sizes:
- Figure 9: 160 × 169 mm.
- Figure 10: 160 × 174 mm.
- Figure S6: 160 × 120 mm.
- Graphical abstract: 180 × 85 mm.

For the manuscript figures, labels are 7.5–9 pt at the stated size. Import Figures
9 and 10 at 160 mm width to retain that typography. The abstract is a standalone
graphic and has a larger 12 pt headline.

