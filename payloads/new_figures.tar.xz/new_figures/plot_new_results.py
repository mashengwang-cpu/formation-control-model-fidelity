"""Reproduce Figures 9, 10 and S6 from the supplied, unmodified analysis tables.

Run: python plot_new_results.py --output outputs
Python 3.12; matplotlib, numpy and pandas. PDF is the layout reference.
No estimates or confidence intervals are recomputed by this plotting program.
"""
from pathlib import Path
import argparse
import hashlib
import json
import datetime
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator, FuncFormatter

HERE = Path(__file__).resolve().parent
INK = "#293844"
COLORS = {"minimal": "#087D91", "family": "#AC701A",
          "schedule_deletion": "#008577", "powers_deletion": "#AC701A",
          "module_interaction": "#775A9E"}
LABELS = {"schedule_deletion": "Schedule", "powers_deletion": "Signed powers",
          "module_interaction": "Interaction"}
SHAPES = {"schedule_deletion": "D", "powers_deletion": "v", "module_interaction": "^"}
BACKGROUNDS = ["point_selected_full", "rigid_retuned_full"]
mpl.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
    "xtick.labelsize": 7.5, "ytick.labelsize": 8, "legend.fontsize": 8,
    "legend.frameon": False,
    "axes.linewidth": 0.65, "axes.spines.right": False,
    "axes.spines.top": False, "axes.spines.left": False,
    "text.color": INK, "axes.labelcolor": INK, "axes.edgecolor": INK,
    "xtick.color": INK, "ytick.color": INK,
    "xtick.major.size": 3, "xtick.major.width": .65,
    "ytick.major.size": 0, "pdf.fonttype": 42, "ps.fonttype": 42,
    "svg.fonttype": "none", "svg.hashsalt": "formation-control-final-figures-v1",
    "savefig.facecolor": "white", "figure.facecolor": "white"
})
PLOTTED = []
def read_table(name, n):
    frame = pd.read_csv(HERE / "source_data" / name)
    assert len(frame) == n, (name, len(frame), n)
    assert np.isfinite(frame.mean_m).all()
    for _, row in frame.iterrows():
        lo, hi = row.lower_m, row.upper_m
        if np.isfinite(lo) and np.isfinite(hi):
            assert lo <= row.mean_m <= hi
        else:
            assert row.get("interval_status") == "empirical_degenerate_no_equivalence_claim"
    return frame

def style(ax, letter, title, ylevels, ylabels):
    ax.set_title(title, loc="left", pad=8, fontweight="normal")
    ax.text(-.03, 1.14, letter, transform=ax.transAxes, fontweight="bold",
            fontsize=9, va="center", ha="right")
    ax.axvline(0, color="#9AA4AA", linestyle=(0, (3, 3)), lw=.7, zorder=0)
    ax.set_yticks(ylevels, ylabels)
    ax.set_ylim(min(ylevels)-.52, max(ylevels)+.52)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4, min_n_ticks=3))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:g}"))
    for middle in (np.array(ylevels[:-1])+np.array(ylevels[1:]))/2:
        ax.axhline(middle, color="#E6EAED", lw=.55, zorder=-1)

def draw(ax, row, y, color, marker="o", filled=True, figure="", panel=""):
    mean, lo, hi = row.mean_m, row.lower_m, row.upper_m
    estimated = bool(np.isfinite(lo) and np.isfinite(hi))
    if estimated:
        ax.errorbar(mean, y, xerr=np.array([[mean-lo], [hi-mean]]),
                    fmt="none", color=color, elinewidth=1.0,
                    capsize=3.0, capthick=.9, zorder=3)
    ax.plot(mean, y, marker=marker, markersize=4.2,
            markerfacecolor=color if filled and estimated else "white",
            markeredgecolor=color, markeredgewidth=.9,
            linestyle="none", zorder=4)
    PLOTTED.append({"figure":figure,"panel":panel,"mean_m":float(mean),
                    "lower_m":float(lo) if estimated else None,
                    "upper_m":float(hi) if estimated else None,
                    "source_key": {k:str(row[k]) for k in
                       ["repetition","platform","strategy","comparator","background",
                        "model","effect","contrast_id"] if k in row.index}})

def limits(ax, rows, padding=.1):
    lo = min(0, float(rows.lower_m.min()), float(rows.mean_m.min()))
    hi = max(0, float(rows.upper_m.max()), float(rows.mean_m.max()))
    span = hi-lo
    assert span > 0
    ax.set_xlim(lo-padding*span, hi+padding*span)

def save(fig, stem, out, dpi):
    fig.canvas.draw()
    fig.savefig(out / (stem+".pdf"), metadata={"CreationDate": None, "ModDate": None,
                                             "Creator": "Matplotlib",
                                             "Title": stem})
    fig.savefig(out / (stem+".svg"), metadata={"Date":None,"Creator":"Matplotlib"})
    if dpi:
        fig.savefig(out / (stem+".png"), dpi=dpi)
    fig.savefig(out / (stem+"_preview.png"), dpi=300)
    plt.close(fig)

def figure9(data):
    fig, axes = plt.subplots(3, 2, figsize=(160/25.4, 169/25.4))
    fig.subplots_adjust(left=.145, right=.98, top=.94, bottom=.12,
                        hspace=.78, wspace=.54)
    names={"transfer":"Transfer", "retuned":"Retuned",
           "retuned_minus_transfer":"Retuned − transfer"}
    markers=["o","s","^"]
    for j, strategy in enumerate(names):
        for k, platform in enumerate(["native","otter"]):
            ax=axes[j,k]; letter="abcdef"[j*2+k]
            sub=data[(data.platform==platform)&(data.strategy==strategy)]
            assert len(sub)==6
            style(ax,letter,("Native" if k==0 else "Otter")+" · "+names[strategy],
                  [1,0],["Minimal","Family"])
            for c, cmp in enumerate(["minimal","family"]):
                for rep in [1,2,3]:
                    row=sub[(sub.comparator==cmp)&(sub.repetition==rep)].iloc[0]
                    draw(ax,row,1-c+(2-rep)*.23,COLORS[cmp],markers[rep-1],
                         figure="Figure_9",panel=letter)
            limits(ax,sub)
            ax.set_xlabel("Model interaction (m)" if j<2 else "Change in interaction (m)",labelpad=4)
    handles=[Line2D([],[],marker=m,color=INK,linestyle="none",markersize=4.2,
                   label="Search "+str(i+1)) for i,m in enumerate(markers)]
    fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(.57,.015),
               ncol=3,handletextpad=.45,columnspacing=1.5)
    return fig

def background_panel(ax, sub, letter, title):
    effects=list(LABELS)
    style(ax,letter,title,[2,1,0],[LABELS[e] for e in effects])
    for y,e in zip([2,1,0],effects):
        row=sub[sub.effect==e].iloc[0]
        draw(ax,row,y,COLORS[e],SHAPES[e],figure="Figure_10",panel=letter)
    limits(ax,sub)
    ax.set_xlabel("Background difference (m)",labelpad=4)

def local_panel(ax, sub, letter, title, effects, fig_name):
    levels=list(reversed(range(len(effects))))
    style(ax,letter,title,levels,[LABELS[e] for e in effects])
    for y,e in zip(levels,effects):
        for b,bg in enumerate(BACKGROUNDS):
            row=sub[(sub.effect==e)&(sub.background==bg)].iloc[0]
            draw(ax,row,y+(.16 if b==0 else -.16),COLORS[e],SHAPES[e],b==1,
                 figure=fig_name,panel=letter)
    limits(ax,sub)
    ax.set_xlabel("Deletion effect (m)" if len(effects)==2 else "Local effect (m)",labelpad=4)

def figure10(local, background):
    fig, axes=plt.subplots(3,2,figsize=(160/25.4,174/25.4),
                           gridspec_kw={"height_ratios":[1,1.1,1.1]})
    fig.subplots_adjust(left=.18,right=.98,top=.94,bottom=.10,wspace=.73,hspace=.83)
    for k,platform in enumerate(["native","otter"]):
        sub=local[(local.platform==platform)&(local.model=="rigid")&
                  (local.effect.isin(["schedule_deletion","powers_deletion"]))]
        local_panel(axes[0,k],sub,"ab"[k],
                    ("Native" if k==0 else "Otter")+" · complete model",
                    ["schedule_deletion","powers_deletion"],"Figure_10")
        for j,model in enumerate(["point","rigid"]):
            sub=background[(background.platform==platform)&(background.model==model)]
            background_panel(axes[j+1,k],sub,"cdef"[j*2+k],
                             ("Native" if k==0 else "Otter")+" · "+
                             ("point mass" if j==0 else "complete model"))
    handles=[Line2D([],[],marker="o",color=INK,markerfacecolor="white",
                    linestyle="none",markersize=4.2,label="Point-selected background"),
             Line2D([],[],marker="o",color=INK,linestyle="none",markersize=4.2,
                    label="Rigid-retuned background")]
    fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(.55,-.006),
               ncol=2,handletextpad=.5,columnspacing=1,
               title="Parameter background in panels a and b",title_fontsize=7.5)
    return fig

def figureS6(local):
    fig,axes=plt.subplots(2,2,figsize=(160/25.4,120/25.4))
    fig.subplots_adjust(left=.18,right=.98,top=.90,bottom=.15,wspace=.73,hspace=.85)
    for j,model in enumerate(["point","rigid"]):
        for k,platform in enumerate(["native","otter"]):
            sub=local[(local.platform==platform)&(local.model==model)]
            local_panel(axes[j,k],sub,"abcd"[2*j+k],
                        ("Native" if k==0 else "Otter")+" · "+
                        ("point mass" if j==0 else "complete model"),list(LABELS),"Figure_S6")
    handles=[Line2D([],[],marker="o",color=INK,markerfacecolor="white",
                    linestyle="none",markersize=4.2,label="Point-selected background"),
             Line2D([],[],marker="o",color=INK,linestyle="none",markersize=4.2,
                    label="Rigid-retuned background")]
    fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(.55,.002),
               ncol=2,handletextpad=.5,columnspacing=1)
    return fig

def graphical_abstract(search, local):
    fig,axes=plt.subplots(1,3,figsize=(180/25.4,85/25.4))
    fig.subplots_adjust(left=.11,right=.985,top=.71,bottom=.37,wspace=.75)
    fig.text(.04,.94,"Controller comparisons depend on model and tuning",
             fontsize=12,fontweight="bold",va="top")
    titles=["Native: model interaction", "Otter: retuned interaction", "Native: schedule deletion"]
    markers=["o","s","^"]
    for k,ax in enumerate(axes):
        ax.tick_params(labelsize=7.5)
        ax.axvline(0,color="#9AA4AA",linestyle=(0,(3,3)),lw=.7,zorder=0)
        ax.set_title(titles[k],loc="left",pad=12,fontsize=8.5)
        ax.xaxis.set_major_locator(MaxNLocator(3))
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x,_:f"{x:g}"))
    sub=search[(search.platform=="native")&(search.comparator=="minimal")&
               search.strategy.isin(["transfer","retuned"])]
    for j,strategy in enumerate(["transfer","retuned"]):
        for r in [1,2,3]:
            row=sub[(sub.strategy==strategy)&(sub.repetition==r)].iloc[0]
            draw(axes[0],row,1-j+(2-r)*.2,COLORS["minimal"],markers[r-1],
                 figure="Graphical_abstract",panel="a")
    axes[0].set_yticks([1,0],["Transfer","Retuned"])
    axes[0].set_ylim(-.55,1.55); limits(axes[0],sub)
    axes[0].set_xlabel("Full − Minimal interaction (m)",fontsize=7.5)
    sub=search[(search.platform=="otter")&(search.comparator=="minimal")&
               (search.strategy=="retuned")]
    for r in [1,2,3]:
        row=sub[sub.repetition==r].iloc[0]
        draw(axes[1],row,3-r,COLORS["minimal"],markers[r-1],
             figure="Graphical_abstract",panel="b")
    axes[1].set_yticks([2,1,0],["Search 1","Search 2","Search 3"])
    axes[1].set_ylim(-.5,2.5); limits(axes[1],sub)
    axes[1].set_xlabel("Full − Minimal interaction (m)",fontsize=7.5)
    sub=local[(local.platform=="native")&(local.model=="rigid")&
              (local.effect=="schedule_deletion")]
    for j,bg in enumerate(BACKGROUNDS):
        row=sub[sub.background==bg].iloc[0]
        draw(axes[2],row,1-j,COLORS["schedule_deletion"],"D",j==1,
             figure="Graphical_abstract",panel="c")
        axes[2].annotate(f"{row.mean_m:+.5f}",(row.mean_m,1-j),
                         xytext=(0,9),textcoords="offset points",ha="center",fontsize=7.5)
    axes[2].set_yticks([1,0],["Point\nbackground","Rigid\nbackground"])
    axes[2].set_ylim(-.55,1.7); limits(axes[2],sub,.24)
    axes[2].set_xlabel("Deleted − Full (m)",fontsize=7.5)
    fig.text(.04,.17,"Model interaction: (Full − Minimal error) in the complete model minus that in the point-mass model.",fontsize=8)
    fig.text(.04,.11,"Three independent searches (left, center). Means from 50 paired seed blocks in every panel.",fontsize=8)
    fig.text(.04,.05,"95% intervals: simultaneous within each search (left, center); pointwise for deletion (right).",fontsize=8)
    return fig

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,default=HERE/"outputs")
    parser.add_argument("--dpi",type=int,default=1000)
    args=parser.parse_args(); args.output.mkdir(parents=True,exist_ok=True)
    search=read_table("search_contrasts.csv",36)
    background=read_table("background_contrasts.csv",12)
    local=read_table("local_effects.csv",24)
    assert set(local.background)==set(BACKGROUNDS)
    for stem,fig in [("Figure_9",figure9(search)),
                     ("Figure_10",figure10(local,background)),
                     ("Figure_S6",figureS6(local)),
                     ("Graphical_abstract",graphical_abstract(search,local))]:
        save(fig,stem,args.output,args.dpi)
    (args.output/"plotted_values.json").write_text(json.dumps(PLOTTED,indent=2),encoding="utf-8")
    source_manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted((HERE/"source_data").glob("*.csv"))}
    (args.output/"source_sha256.json").write_text(json.dumps(source_manifest,indent=2),encoding="utf-8")
    print(json.dumps({"figures":4,"plotted_estimates":len(PLOTTED),"output":str(args.output)}))

if __name__=="__main__":
    main()
