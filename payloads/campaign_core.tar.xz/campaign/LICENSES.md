# License scope
Original code and software documentation: MIT; see LICENSE_CODE.txt.
Original research data: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/legalcode.en).
Attribution: Fuliang Ma, Yuzhen Dang, Yuping Ma, Ying Jiang and Hongbin Ma (2026).
The unmodified Python Vehicle Simulator and derived Otter kernel retain upstream attribution and the MIT license at code/vendor/PythonVehicleSimulator/LICENSE.
The source ledger and original SOFTWARE_SOURCES.md preserve the baseline provenance. In that baseline document, Reproduction/vendor refers here to code/vendor.
External Python dependencies retain their own licenses. The manuscript and submission correspondence are outside this data-license scope.
