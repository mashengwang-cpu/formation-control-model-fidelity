"""Frozen independent searches and full factorial intervention; resumable.

Does not import test outcomes into parameter selection. Run from this directory.
"""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name]='1'
from pathlib import Path
import sys, json, hashlib, tarfile, gzip, csv, time, shutil, traceback, argparse
from dataclasses import asdict, replace
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from scipy.stats import qmc

HERE=Path(__file__).resolve().parent
CODE=HERE/'code'
BASE=HERE.parent/'2026-09-08_GitHub精简复现交付/formation-control-repro'
sys.path.insert(0,str(CODE))
from enhancement.experiment import Job, run
from enhancement.controllers import DEFAULT, METHODS, parameter_indices
from enhancement.protocol import job_for, MODELS, DEVELOPMENT, TEST_TRAJECTORIES
from enhancement.campaign import rank_candidates
from enhancement.numerical_campaign import sources, digest, run_case

FACTOR_METHODS=('full','no_schedule','no_powers','no_schedule_no_powers')
DEV_KEYS=('time','error_norm','actual_force_squared_integral',
          'actual_moment_squared_integral','saturation_duration','physical_events',
          'physical_state','final_weights','final_error_filter','final_rise_integral')

def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.writing')
    tmp.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8')
    tmp.replace(path)

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def freeze():
    path=HERE/'design/protocol.json'
    if path.exists():
        p=read(path);check(p);return p
    with gzip.open(BASE/'provenance/INPUT_MEMBERS.csv.gz','rt',encoding='utf-8') as f:
        ledger={r['path']:r for r in csv.DictReader(f)}
    original={}
    with tarfile.open(BASE/'payloads/controlled.tar.xz') as a:
        for m in a:
            if '/campaign/' in m.name and m.name.endswith(('/protocol.json','/selection.json')):
                raw=a.extractfile(m).read()
                assert hashlib.sha256(raw).hexdigest()==ledger[m.name]['sha256']
                original[Path(m.name).name]=json.loads(raw)
    assert set(original)=={'protocol.json','selection.json'}
    save(HERE/'design/original_selection.json',original['selection.json'])
    save(HERE/'design/original_protocol.json',original['protocol.json'])
    repetitions=[]
    used=[]
    for r in range(1,4):
        seeds={};candidates={};scrambles={}
        for pi,platform in enumerate(('native','otter')):
            first=100000+r*10000+pi*1000
            seeds[platform]={'train':list(range(first,first+6)),
                'validation':list(range(first+100,first+112)),
                'test':list(range(first+200,first+250)),
                'numerical':list(range(first+400,first+402))}
            used.extend(set(v) for v in seeds[platform].values())
            candidates[platform]={};scrambles[platform]={}
            for mi,method in enumerate(METHODS):
                ids=parameter_indices(method)
                scramble=910000+r*100+pi*10+mi
                scrambles[platform][method]=scramble
                points=qmc.Sobol(len(ids),scramble=True,seed=scramble).random_base2(6)[:63]
                lo,hi=(np.array([.51,.51,.1,.01]),np.array([20.,20.,50.,100.])) if method=='rise' else (DEFAULT[ids]/8,DEFAULT[ids]*8)
                pars=[DEFAULT.copy()]
                for u in points:
                    v=DEFAULT.copy();v[ids]=np.exp(np.log(lo)+u*(np.log(hi)-np.log(lo)));pars.append(v)
                assert len({tuple(v) for v in pars})==64
                candidates[platform][method]=[dict(candidate=i,parameters=v.tolist()) for i,v in enumerate(pars)]
        repetitions.append(dict(repetition=r,seeds=seeds,scrambles=scrambles,candidates=candidates))
    factorial_seeds={p:list(range(first,first+50)) for p,first in [('native',150000),('otter',151000)]}
    factorial_numeric={p:list(range(first,first+2)) for p,first in [('native',150400),('otter',151400)]}
    used.extend(set(v) for v in factorial_seeds.values());used.extend(set(v) for v in factorial_numeric.values())
    old=original['protocol.json']
    for groups in old['seed_groups'].values():used.extend(set(v) for v in groups.values())
    used.extend([set(old['numerical_seeds']),set(old['source_fixture_seeds']),{890001}])
    for i,g in enumerate(used):
        for h in used[i+1:]:assert not g&h
    p=dict(version='independent-search-factorial-1',dynamics_sources=sources(),
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        repetitions=repetitions,selection_resolution_m=old['selection_resolution_m'],
        factorial_seeds=factorial_seeds,factorial_numerical_seeds=factorial_numeric,
        original_selection_hash=digest(original['selection.json']),
        development_evaluations_per_repetition=23040,
        factorial_design_references=9600,
        factorial_backgrounds=['point_selected_full','rigid_retuned_full'],
        factorial_methods=FACTOR_METHODS,
        storage={'development':'float64 endpoint-recomputation arrays, initial/final physical states and final controller states; no complete internal trajectory',
                 'test':'all arrays from run(detailed=True), lossless float64 NPZ',
                 'numerical':'all reference/fixed-step arrays'},
        inference={'search_repetitions':3,'test_blocks_per_platform_repetition':50,
          'search_report':'Each search separately; three-search effect range and SD descriptive only, no pseudoreplication of test blocks as searches.',
          'search_family':'8 Full-versus-Minimal/Family model interactions across platform and transfer/retuned, plus 4 direct strategy differences, separate simultaneous family per search',
          'factorial_primary':'For each platform: two model layers x (schedule conditional deletion, powers conditional deletion, factorial interaction) background differences = 12 simultaneous contrasts',
          'factorial_secondary':'All four cell means and paired local effects at each background/model; nominal intervals labelled secondary',
          'bootstrap_resamples':20000,'bootstrap_seed':990081,
          'missing':'Withhold affected complete inferential family if required J missing/nonfinite; report all failures and denominators',
          'numeric':'New two-seed grid per platform for every selected configuration and every factorial cell; DOP853 plus frozen fixed-step grid; unresolved cases retained and corresponding directions qualified.'})
    p['protocol_hash']=digest(p);save(path,p);return p

def check(p):
    assert p['dynamics_sources']==sources(),'Frozen controller/dynamics changed'
    assert p['runner_sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'Frozen runner changed'
    q=dict(p);h=q.pop('protocol_hash');assert digest(q)==h

def execution_id(row,p):
    j=dict(row['job']);j.pop('candidate');j.pop('stage')
    return digest(dict(job=j,parameters=row['parameters'],protocol=p['protocol_hash']))[:28]

def worker(payload):
    row,p,folder=payload;folder=Path(folder);key=execution_id(row,p)
    target=folder/'jobs'/f'{key}.json';trace=folder/'traces'/f'{key}.npz'
    if target.exists():
        r=read(target)
        assert r['protocol_hash']==p['protocol_hash']
        assert hashlib.sha256(trace.read_bytes()).hexdigest()==r['trace_sha256']
        return r
    if shutil.disk_usage(HERE).free<12*1024**3:raise OSError('Less than 12 GiB free; no record deleted')
    j=Job(**row['job']);rec=dict(job_id=key,protocol_hash=p['protocol_hash'],job=row['job'],parameters=row['parameters'])
    try:
        metrics,arrays=run(j,row['parameters'],detailed=j.stage=='test')
        rec.update(metrics=metrics,status='complete' if metrics['complete'] else 'failed_simulation')
    except (FloatingPointError,OverflowError,ValueError,ZeroDivisionError):
        rec.update(metrics=dict(complete=False,J_m=None,force_effort_N2s=None,failure='numerical_exception',cpu_seconds=None),status='failed_simulation',error=traceback.format_exc())
        arrays={'failed':np.ones(1,dtype=np.int8)}
    if j.stage in ('train','validation') and 'failed' not in arrays:
        arrays={k:arrays[k] for k in DEV_KEYS}
    with trace.with_suffix('.writing').open('wb') as f:np.savez_compressed(f,**arrays)
    trace.with_suffix('.writing').replace(trace)
    rec.update(trace='traces/'+trace.name,trace_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),stored_arrays=list(arrays))
    save(target,rec);return rec

def evaluate(rows,p,folder,workers):
    check(p);folder=Path(folder)
    for name in ('jobs','traces'):(folder/name).mkdir(parents=True,exist_ok=True)
    unique={};refs=[]
    for row in rows:
        key=execution_id(row,p);unique[key]=row
        refs.append(dict(design_id=digest(row)[:28],job_id=key,**row))
    design=dict(protocol_hash=p['protocol_hash'],rows=refs)
    path=folder/'design.json'
    if path.exists():assert read(path)==design
    else:save(path,design)
    records=[];start=time.perf_counter()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        worker_protocol={'protocol_hash':p['protocol_hash']}
        futures=[pool.submit(worker,(row,worker_protocol,str(folder))) for row in unique.values()]
        for f in as_completed(futures):
            records.append(f.result())
            if len(records)%96==0 or len(records)==len(unique):
                state=dict(stage=str(folder.relative_to(HERE)),completed=len(records),total=len(unique),design_references=len(refs),statuses=dict(Counter(x['status'] for x in records)),elapsed_seconds=round(time.perf_counter()-start))
                save(folder/'progress.json',state);save(HERE/'progress.json',state);print(json.dumps(state),flush=True)
    # Deterministic input order prevents completion order changing a near tie.
    records.sort(key=lambda x:(x['job']['platform'],x['job']['method'],x['job']['model'],x['job']['candidate'],x['job']['seed'],x['job']['trajectory'],x['job']['current']))
    save(folder/'summary.json',dict(executions=len(records),design_references=len(refs),statuses=dict(Counter(x['status'] for x in records)),cpu_seconds=sum(x['metrics'].get('cpu_seconds') or 0 for x in records),wall_seconds=time.perf_counter()-start))
    return records

def develop_rows(rep,short=None):
    stage='train' if short is None else 'validation'
    for platform in ('native','otter'):
        for method in METHODS:
            for model in MODELS:
                candidates=rep['candidates'][platform][method] if short is None else short[platform][method][model]
                for c in candidates:
                    for seed in rep['seeds'][platform][stage]:
                        for scenario in DEVELOPMENT:
                            yield dict(job=asdict(job_for(platform,model,method,seed,scenario,stage,c['candidate'])),parameters=c['parameters'])

def select(records,p,shortlist):
    out={platform:{method:{} for method in METHODS} for platform in ('native','otter')}
    for platform in out:
        for method in METHODS:
            for model in MODELS:
                rr=[x for x in records if (x['job']['platform'],x['job']['method'],x['job']['model'])==(platform,method,model)]
                assert len(rr)==(768 if shortlist else 192)
                ordered=rank_candidates(rr,p['selection_resolution_m'][platform][model])
                out[platform][method][model]=ordered[:8] if shortlist else ordered[0]
    return out

def test_rows(selection,seeds):
    for platform in ('native','otter'):
        for seed in seeds[platform]:
            for scene in TEST_TRAJECTORIES:
                for current in ([0.] if platform=='native' else [0.,.1,.2]):
                    for method in METHODS:
                        for strategy in ('transfer','retuned'):
                            for model in MODELS:
                                c=selection['choices'][platform][method]['point' if strategy=='transfer' else model]
                                yield dict(job=asdict(job_for(platform,model,method,seed,scene,'test',c['candidate'],current)),parameters=c['parameters'],strategy=strategy)
                    c=selection['choices'][platform]['full']['point']
                    for method in ('no_schedule','no_powers'):
                        for model in ('point','rigid'):
                            yield dict(job=asdict(job_for(platform,model,method,seed,scene,'test',c['candidate'],current)),parameters=c['parameters'],strategy='fixed_full_background')

def factorial_rows(selection,seeds):
    for platform in ('native','otter'):
        for seed in seeds[platform]:
            for scene in TEST_TRAJECTORIES:
                for current in ([0.] if platform=='native' else [0.,.1,.2]):
                    for background,key in [('point_selected_full','point'),('rigid_retuned_full','rigid')]:
                        c=selection['choices'][platform]['full'][key]
                        for model in ('point','rigid'):
                            for method in FACTOR_METHODS:
                                yield dict(job=asdict(job_for(platform,model,method,seed,scene,'test',c['candidate'],current)),parameters=c['parameters'],background=background)

def numerical(rows,p,folder,workers):
    check(p);folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    unique={}
    for row in rows:
        j=dict(row['job']);j.update(stage='numerical',candidate=0)
        key=digest(dict(job=j,parameters=row['parameters']))
        unique[key]=(j,row['parameters'])
    design=dict(source_hash=digest(sources()),cases=[dict(job=j,parameters=pars) for j,pars in unique.values()])
    if (folder/'design.json').exists():assert read(folder/'design.json')==design
    else:save(folder/'design.json',design)
    records=[];start=time.perf_counter()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        tasks=[pool.submit(run_case,(j,pars,str(folder),design['source_hash'],False)) for j,pars in unique.values()]
        for f in as_completed(tasks):
            records.append(f.result())
            if len(records)%6==0 or len(records)==len(unique):
                state=dict(stage=str(folder.relative_to(HERE)),completed=len(records),total=len(unique),elapsed_seconds=round(time.perf_counter()-start))
                save(folder/'progress.json',state);save(HERE/'progress.json',state);print(json.dumps(state),flush=True)
    summary=dict(cases=len(unique),evaluated=sum(x['status']=='evaluated' for x in records),implementation_errors=[x['case_id'] for x in records if x['status']!='evaluated'],
        unresolved_production=[x['case_id'] for x in records if x['status']=='evaluated' and not next(c for c in x['comparisons'] if c['physics_dt']==(.00125 if x['job']['platform']=='native' else .0025))['pass']],
        unresolved_finest=[x['case_id'] for x in records if x['status']=='evaluated' and not x['comparisons'][-1]['pass']],source_hash=design['source_hash'])
    save(folder/'summary.json',summary)
    if summary['implementation_errors']:raise RuntimeError('Numerical implementation errors; test not launched')
    return summary

def execute(args):
    p=freeze()
    if args.stage=='freeze':return
    gate=read(HERE/'compatibility.json');assert gate['status']=='pass'
    if args.stage in ('all','factorial'):
        original=read(HERE/'design/original_selection.json')
        rows=list(factorial_rows(original,p['factorial_seeds']));assert len(rows)==9600
        save(HERE/'design/factorial_test_frozen.json',dict(selection_hash=digest(original),rows=rows))
        numerical(factorial_rows(original,p['factorial_numerical_seeds']),p,HERE/'data/factorial/numerical',args.workers)
        evaluate(rows,p,HERE/'data/factorial/test',args.workers)
    if args.stage in ('all','search'):
        for rep in p['repetitions']:
            if args.repetition and rep['repetition']!=args.repetition:continue
            folder=HERE/f"data/search_{rep['repetition']}"
            training=evaluate(list(develop_rows(rep)),p,folder/'train',args.workers)
            short=select(training,p,True);save(folder/'shortlist.json',short)
            validation=evaluate(list(develop_rows(rep,short)),p,folder/'validation',args.workers)
            selected=dict(protocol_hash=p['protocol_hash'],repetition=rep['repetition'],choices=select(validation,p,False))
            selected['selection_hash']=digest(selected);save(folder/'selection.json',selected)
            counts=Counter((r['job']['platform'],r['job']['method']) for r in training+validation)
            assert len(counts)==8 and set(counts.values())=={2880}
            save(folder/'budget.json',dict(equal=True,counts=[dict(platform=x[0],method=x[1],evaluations=n) for x,n in sorted(counts.items())]))
            rows=list(test_rows(selected,{k:v['test'] for k,v in rep['seeds'].items()}))
            save(folder/'test_design_frozen.json',dict(selection_hash=selected['selection_hash'],rows=rows))
            numerical(test_rows(selected,{k:v['numerical'] for k,v in rep['seeds'].items()}),p,folder/'numerical',args.workers)
            evaluate(rows,p,folder/'test',args.workers)
    save(HERE/f'completed_{args.stage}_{args.repetition or "all"}.json',dict(status='executed',note='Scientific analysis and manuscript synchronization require separate verification.'))

if __name__=='__main__':
    if not __debug__:raise RuntimeError('Do not disable assertions')
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['freeze','all','factorial','search']);parser.add_argument('--workers',type=int,default=12);parser.add_argument('--repetition',type=int,choices=[1,2,3]);args=parser.parse_args()
    try:execute(args)
    except Exception:
        save(HERE/'execution_error.json',dict(error=traceback.format_exc()));raise
