"""Paired analysis, with search repetitions kept separate from test blocks."""
from pathlib import Path
import sys,json,hashlib,csv,argparse
from collections import Counter
import numpy as np
import pandas as pd
from campaign_runner import HERE,read,save,freeze,execution_id

def records(folder,verify_traces=False):
    design=read(folder/'design.json');rows=[];unique={}
    for row in design['rows']:
        key=row['job_id']
        if key not in unique:
            r=read(folder/'jobs'/f'{key}.json')
            assert r['job_id']==key and r['protocol_hash']==design['protocol_hash']
            if verify_traces:
                raw=(folder/r['trace']).read_bytes()
                assert hashlib.sha256(raw).hexdigest()==r['trace_sha256']
                with np.load(folder/r['trace'],allow_pickle=False) as a:
                    if r['metrics']['complete']:
                        observed=float(np.trapezoid(a['error_norm'].mean(1),a['time'])/r['job']['duration'])
                        np.testing.assert_allclose(observed,r['metrics']['J_m'],atol=1e-12,rtol=1e-12)
                        np.testing.assert_allclose(a['actual_force_squared_integral'].sum(),r['metrics']['force_effort_N2s'],atol=1e-9,rtol=1e-12)
            unique[key]=r
        r=unique[key]
        assert row['parameters']==r['parameters']
        for k in row['job']:
            if k not in ('candidate','stage'):assert row['job'][k]==r['job'][k]
        rows.append(dict(**row['job'],**r['metrics'],job_id=key,design_id=row['design_id'],
                         strategy=row.get('strategy',''),background=row.get('background','')))
    data=pd.DataFrame(rows)
    return data,dict(design_references=len(rows),unique_executions=len(unique),
                     statuses=dict(Counter(r['status'] for r in unique.values())),
                     complete=all(r['metrics']['complete'] and np.isfinite(r['metrics']['J_m']) for r in unique.values()))

def paired_values(data,platform,seeds,filters):
    a=data[data.platform.eq(platform)]
    for k,v in filters.items():a=a[a[k].eq(v)]
    keys=['seed','trajectory','current']
    assert not a.duplicated(keys).any()
    a=a.set_index(keys).sort_index()
    currents=[0.] if platform=='native' else [0.,.1,.2]
    expected=pd.MultiIndex.from_product([seeds,['double_sine','ellipse','speed_line'],currents],names=keys).sort_values()
    assert a.index.equals(expected),f'Incomplete pairing {platform} {filters}'
    assert a.complete.all() and np.isfinite(a.J_m).all()
    return a.J_m

def blocks(x,seeds):return x.groupby('seed').mean().reindex(seeds).to_numpy()

def numerical_qualification(folder,meta):
    """Observed two-seed discrepancies, never a rigorous error bound."""
    from campaign_runner import digest
    design=read(folder/'test/design.json')['rows'];lookup={}
    def key(job,pars):return (job['platform'],job['model'],job['method'],digest(pars))
    for file in (folder/'numerical').glob('*.json'):
        r=read(file)
        if 'case_id' not in r:continue
        k=key(r['job'],r['parameters']);lookup.setdefault(k,[]).append(r)
    for item in meta:
        coefficients={}
        for filters,coefficient in item.pop('_terms'):
            matches=[r for r in design if all((r['job'].get(k,r.get(k))==v) for k,v in filters.items())]
            configs={key(r['job'],r['parameters']) for r in matches}
            assert len(configs)==1,filters
            k=next(iter(configs));coefficients[k]=coefficients.get(k,0.)+coefficient
        observed=0.;qualified=True;details=[]
        for k,c in coefficients.items():
            if c==0:continue
            cases=lookup.get(k,[]);expected=6 if k[0]=='native' else 18
            values=[];good=len(cases)==expected
            for r in cases:
                comparisons=[x for x in r.get('comparisons',[]) if x['physics_dt']==(.00125 if k[0]=='native' else .0025)]
                if r['status']!='evaluated' or len(comparisons)!=1:
                    good=False;continue
                comparison=comparisons[0];v=comparison.get('J_difference_m')
                good=good and comparison['pass'] and v is not None and np.isfinite(v)
                if v is not None and np.isfinite(v):values.append(v)
            available=len(values)==expected
            discrepancy=max(values) if available else None
            qualified=qualified and good
            if discrepancy is not None and observed is not None:observed+=abs(c)*discrepancy
            else:observed=None if observed is not None else observed
            details.append(dict(platform=k[0],model=k[1],method=k[2],parameter_hash=k[3],coefficient=c,
                numerical_cases=len(cases),expected_cases=expected,production_resolved=bool(good),maximum_observed_J_difference_m=discrepancy))
        item.update(numerical_qualified=bool(qualified),observed_discrepancy_sum_m=observed,
            effect_exceeds_observed_discrepancy=None if observed is None else bool(abs(item['mean_m'])>observed),
            numerical_scope='Observed two-seed production/reference discrepancies; not a rigorous bound or validation over all test seeds.',numerical_configurations=details)

def simultaneous(arrays,meta,path,rng_seed,seeds):
    matrix=np.column_stack(arrays);mean=matrix.mean(0);se=matrix.std(0,ddof=1)/np.sqrt(len(matrix))
    assert matrix.shape==(50,12) and np.isfinite(matrix).all()
    active=(np.ptp(matrix,axis=0)>0)&(se>0)
    rng=np.random.default_rng(rng_seed);maxima=[]
    for _ in range(200):
        # Independent platforms, paired columns and paired blocks within each.
        draws=np.concatenate([matrix[rng.integers(0,50,(100,50)),:6],matrix[rng.integers(0,50,(100,50)),6:]],axis=2)
        bootse=draws.std(1,ddof=1)/np.sqrt(50)
        bootse[np.ptp(draws,axis=1)==0]=0.
        centered=abs(draws.mean(1)-mean)
        statistic=np.divide(centered,bootse,out=np.zeros_like(centered),where=bootse>0)
        statistic[(bootse==0)&(centered>0)]=np.inf
        maxima.extend(np.max(statistic[:,active],axis=1) if active.any() else np.zeros(100))
    # Inverse empirical CDF avoids interpolation of infinite order statistics.
    critical=float(np.sort(maxima)[int(np.ceil(.95*len(maxima)))-1])
    finite_critical=np.isfinite(critical)
    for i,r in enumerate(meta):
        eligible=active[i] and finite_critical
        r.update(contrast_id=f'c{i+1}',mean_m=float(mean[i]),lower_m=float(mean[i]-critical*se[i]) if eligible else None,upper_m=float(mean[i]+critical*se[i]) if eligible else None,n_test_blocks=50,
                 interval_status='estimated' if eligible else ('empirical_degenerate_no_equivalence_claim' if not active[i] else 'critical_value_unavailable'))
    pd.DataFrame(meta).to_csv(path/'contrasts.csv',index=False)
    table=pd.DataFrame(matrix,columns=[f'c{i+1}' for i in range(12)])
    table.insert(0,'otter_seed',seeds['otter']);table.insert(0,'native_seed',seeds['native'])
    table.to_csv(path/'paired_block_matrix.csv',index=False)
    return dict(critical_value=critical if finite_critical else None,resamples=20000,random_seed=rng_seed,family_size=12,positive_variance_columns=int(active.sum()),critical_quantile='inverse empirical CDF at .95',contrasts=meta)

def factorial(p,verify):
    folder=HERE/'data/factorial';out=HERE/'analysis/factorial';out.mkdir(parents=True,exist_ok=True)
    d,audit=records(folder/'test',verify);assert len(d)==9600
    d.to_csv(out/'design_outcomes.csv',index=False)
    if not audit['complete']:
        save(out/'summary.json',dict(status='inference_withheld_missing',audit=audit));return
    arrays=[];meta=[];local=[];cells=[];seed_rows=[]
    for platform in ('native','otter'):
        seeds=p['factorial_seeds'][platform];values={};effects={}
        draws=np.random.default_rng(p['inference']['bootstrap_seed']+(100 if platform=='native' else 200)).integers(0,50,(20000,50))
        for bg in p['factorial_backgrounds']:
            for model in ('point','rigid'):
                for method in p['factorial_methods']:
                    v=paired_values(d,platform,seeds,dict(background=bg,model=model,method=method))
                    values[bg,model,method]=v
                    cells.append(dict(platform=platform,background=bg,model=model,method=method,mean_J_m=float(blocks(v,seeds).mean()),n_blocks=50))
                f=values[bg,model,'full'];s=values[bg,model,'no_schedule'];w=values[bg,model,'no_powers'];sw=values[bg,model,'no_schedule_no_powers']
                for name,v in [('schedule_deletion',s-f),('powers_deletion',w-f),('module_interaction',sw-s-w+f)]:
                    effects[bg,model,name]=v;b=blocks(v,seeds)
                    low,high=np.quantile(b[draws].mean(1),[.025,.975])
                    coefficients={'schedule_deletion':{'no_schedule':1,'full':-1},'powers_deletion':{'no_powers':1,'full':-1},'module_interaction':{'no_schedule_no_powers':1,'no_schedule':-1,'no_powers':-1,'full':1}}[name]
                    terms=[(dict(platform=platform,model=model,background=bg,method=method),c) for method,c in coefficients.items()]
                    local.append(dict(platform=platform,background=bg,model=model,effect=name,mean_m=float(b.mean()),block_sd_m=float(b.std(ddof=1)),n_blocks=50,lower_m=float(low),upper_m=float(high),interval='secondary nominal pointwise 95% percentile bootstrap; 20000 paired seed-block draws; not simultaneous',_terms=terms))
        for model in ('point','rigid'):
            for name in ('schedule_deletion','powers_deletion','module_interaction'):
                v=effects['rigid_retuned_full',model,name]-effects['point_selected_full',model,name]
                b=blocks(v,seeds);arrays.append(b)
                coefficients={'schedule_deletion':{'no_schedule':1,'full':-1},'powers_deletion':{'no_powers':1,'full':-1},'module_interaction':{'no_schedule_no_powers':1,'no_schedule':-1,'no_powers':-1,'full':1}}[name]
                terms=[(dict(platform=platform,model=model,background=bg,method=method),sign*c) for bg,sign in [('rigid_retuned_full',1),('point_selected_full',-1)] for method,c in coefficients.items()]
                meta.append(dict(platform=platform,model=model,effect=name,contrast='rigid_background_minus_point_background',_terms=terms))
                for seed,value in zip(seeds,b):seed_rows.append(dict(platform=platform,seed=seed,model=model,effect=name,value_m=float(value)))
    pd.DataFrame(cells).to_csv(out/'cell_means.csv',index=False);pd.DataFrame(local).to_csv(out/'local_effects.csv',index=False);pd.DataFrame(seed_rows).to_csv(out/'paired_seed_values.csv',index=False)
    result=simultaneous(arrays,meta,out,p['inference']['bootstrap_seed'],p['factorial_seeds'])
    numerical_qualification(folder,meta)
    numerical_qualification(folder,local)
    pd.DataFrame(local).to_csv(out/'local_effects.csv',index=False)
    pd.DataFrame(meta).to_csv(out/'contrasts.csv',index=False)
    numeric=read(folder/'numerical/summary.json')
    result.update(status='analysed',audit=audit,numerical=numeric,scope='Fixed original Full parameter choices; new independent test seeds. Three search repetitions are a separate experiment. Numerical unresolved cases must restrict interpretation.')
    save(out/'summary.json',result)

def search(p,rep,verify):
    rid=rep['repetition'];folder=HERE/f'data/search_{rid}';out=HERE/f'analysis/search_{rid}';out.mkdir(parents=True,exist_ok=True)
    selected=read(folder/'selection.json');budget=read(folder/'budget.json');assert budget['equal']
    d,audit=records(folder/'test',verify);assert len(d)==16800
    d.to_csv(out/'design_outcomes.csv',index=False)
    if not audit['complete']:
        save(out/'summary.json',dict(status='inference_withheld_missing',audit=audit));return
    arrays=[];meta=[];seed_rows=[];performances=[];boundary=[]
    for platform in ('native','otter'):
        seeds=rep['seeds'][platform]['test'];interactions={}
        for strategy in ('transfer','retuned'):
            for comparator in ('minimal','family'):
                v={}
                for model in ('point','rigid'):
                    v[model]=paired_values(d,platform,seeds,dict(strategy=strategy,model=model,method='full'))-paired_values(d,platform,seeds,dict(strategy=strategy,model=model,method=comparator))
                b=blocks(v['rigid']-v['point'],seeds);interactions[strategy,comparator]=b;arrays.append(b)
                terms=[(dict(platform=platform,strategy=strategy,model=model,method=method),sign*coefficient) for model,sign in [('rigid',1),('point',-1)] for method,coefficient in [('full',1),(comparator,-1)]]
                meta.append(dict(platform=platform,strategy=strategy,comparator=comparator,contrast='full_minus_comparator_rigid_minus_point',_terms=terms))
                for seed,x in zip(seeds,b):seed_rows.append(dict(platform=platform,seed=seed,strategy=strategy,comparator=comparator,value_m=float(x)))
        for comparator in ('minimal','family'):
            arrays.append(interactions['retuned',comparator]-interactions['transfer',comparator])
            terms=[(dict(platform=platform,strategy=strategy,model=model,method=method),strategy_sign*model_sign*coefficient) for strategy,strategy_sign in [('retuned',1),('transfer',-1)] for model,model_sign in [('rigid',1),('point',-1)] for method,coefficient in [('full',1),(comparator,-1)]]
            meta.append(dict(platform=platform,strategy='retuned_minus_transfer',comparator=comparator,contrast='strategy_difference',_terms=terms))
        for strategy in ('transfer','retuned'):
            for model in ('point','lag','rigid'):
                for method in ('minimal','family','full','rise'):
                    vals=blocks(paired_values(d,platform,seeds,dict(strategy=strategy,model=model,method=method)),seeds)
                    performances.append(dict(repetition=rid,platform=platform,strategy=strategy,model=model,method=method,mean_J_m=float(vals.mean()),n_test_blocks=50))
    from enhancement.controllers import DEFAULT,parameter_indices,PARAM_NAMES
    for platform,methods in selected['choices'].items():
        for method,models in methods.items():
            indices=parameter_indices(method)
            low,high=(np.array([.51,.51,.1,.01]),np.array([20.,20.,50.,100.])) if method=='rise' else (DEFAULT[indices]/8,DEFAULT[indices]*8)
            for model,c in models.items():
                values=np.array(c['parameters'])[indices];fraction=(np.log(values)-np.log(low))/(np.log(high)-np.log(low))
                for j,idx in enumerate(indices):boundary.append(dict(platform=platform,model=model,method=method,candidate=c['candidate'],parameter=PARAM_NAMES[idx],value=float(values[j]),log_box_fraction=float(fraction[j]),nearest_log_boundary=float(min(fraction[j],1-fraction[j]))))
    result=simultaneous(arrays,meta,out,p['inference']['bootstrap_seed']+rid,{k:v['test'] for k,v in rep['seeds'].items()})
    numerical_qualification(folder,meta)
    pd.DataFrame(meta).to_csv(out/'contrasts.csv',index=False)
    pd.DataFrame(seed_rows).to_csv(out/'paired_seed_values.csv',index=False)
    pd.DataFrame(performances).to_csv(out/'method_performance.csv',index=False)
    pd.DataFrame(boundary).to_csv(out/'selected_parameter_boundaries.csv',index=False)
    result.update(status='analysed',repetition=rid,audit=audit,budget=budget,numerical=read(folder/'numerical/summary.json'),scope='Conditional on this search. Simultaneous coverage applies to this twelve-contrast family, not jointly across three searches.')
    save(out/'summary.json',result)

def aggregate(p):
    rows=[]
    for rep in p['repetitions']:
        r=read(HERE/f"analysis/search_{rep['repetition']}/summary.json")
        if r['status']!='analysed':
            save(HERE/'analysis/search_repetition_summary.json',dict(status='withheld_incomplete_search',repetition=rep['repetition']));return
        for c in r['contrasts']:rows.append(dict(repetition=rep['repetition'],**c))
    d=pd.DataFrame(rows);group=['platform','strategy','comparator','contrast']
    report=d.groupby(group).agg(search_mean_m=('mean_m','mean'),search_sd_m=('mean_m','std'),minimum_search_mean_m=('mean_m','min'),maximum_search_mean_m=('mean_m','max'),n_search_repetitions=('repetition','nunique')).reset_index()
    assert report.n_search_repetitions.eq(3).all()
    report['same_direction_in_all_three']=(report.minimum_search_mean_m*report.maximum_search_mean_m>0)
    report.to_csv(HERE/'analysis/search_repetition_effects.csv',index=False)
    d.to_csv(HERE/'analysis/all_search_contrasts.csv',index=False)
    save(HERE/'analysis/search_repetition_summary.json',dict(status='descriptive_three_search_summary',independent_searches=3,test_blocks_per_search_platform=50,scope='No calibrated high-precision uncertainty about the population of searches from n=3. Old search is not counted as a new replication.'))

if __name__=='__main__':
    if not __debug__:raise RuntimeError('Assertions required')
    parser=argparse.ArgumentParser();parser.add_argument('--scope',choices=['all','factorial','search'],default='all');parser.add_argument('--repetition',type=int,choices=[1,2,3]);parser.add_argument('--verify-traces',action='store_true');args=parser.parse_args();p=freeze()
    if args.scope in ('all','factorial'):factorial(p,args.verify_traces)
    if args.scope in ('all','search'):
        for rep in p['repetitions']:
            if args.repetition and rep['repetition']!=args.repetition:continue
            search(p,rep,args.verify_traces)
        if args.repetition is None:aggregate(p)
