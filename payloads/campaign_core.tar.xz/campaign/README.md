# Independent searches and crossed module interventions

This release contains three independent equal-budget searches, each with 18,432 training and 4,608 validation evaluations; 33,900 unique formal search tests; 9,600 crossed-intervention tests; and 1,740 numerical cases. All design references, failures, full-precision result records, frozen parameter selections and numerical qualifications are retained. Repeated references to a shared execution do not increase sample size. Three search repetitions remain three searches.

## Contents and access

The directory version includes the original lossless NPZ data under data/. Reproduction_light.zip contains everything required to reanalyse stored result records and replay parameter selection, except the NPZ arrays. This compact archive does not by itself allow rechecking raw trajectories. The local complete directory retains those arrays. No new public repository release or DOI is asserted by this package.

On this original Windows delivery volume, NPZ files are NTFS hard links to the frozen experiment files: both names refer to the same stored bytes. Deleting one pathname does not delete the other; editing either pathname changes shared bytes. Treat all supplied data as immutable. To modify a dataset, copy it to a separate location first. Copying this directory to another drive materializes an independent copy and requires approximately 63 GiB for the data.

## Reanalyse without running simulations

Use Python 3.12 and requirements.txt in a separate environment; the validated runtime was Python 3.12.14 on Windows 11. From this directory, run:

```text
python -B analyse_campaign.py --scope all
python -B audit_completed_campaign.py --scope factorial
python -B audit_completed_campaign.py --scope search --repetition 1
python -B audit_completed_campaign.py --scope search --repetition 2
python -B audit_completed_campaign.py --scope search --repetition 3
```

These commands read frozen designs and stored metrics, regenerate analysis/ tables, and independently reconstruct selections, paired means and simultaneous intervals. They do not launch simulation jobs. Do not run Python with -O because assertions verify data contracts. The frozen source ledger uses Windows path separators; direct command execution has been validated on Windows only.

For the complete directory, append --verify-traces to the four audit commands to also verify NPZ hashes, ZIP CRCs and trajectory-derived tracking-error/input-effort metrics. Numerical cases retain reference/fixed-step arrays and their case records; case-record and raw-array integrity are independently covered by the release inventory. Numerical pass flags retain their original meaning.

## New simulation runs

The original campaign_runner.py is unchanged and remains hash-bound to design/protocol.json. Its `all --workers 16` command validates existing records and runs missing evaluations. Existing frozen protocol and data paths must be retained; deleting the frozen protocol would invoke a baseline-dependent design-construction branch and is outside this reproduction procedure. The complete dataset is needed for cache validation. Full new simulation reproduction has substantial runtime and storage requirements; it was not repeated while preparing this release.

## Interpretation limits

Two RISE Otter conditions in search 2 and one in search 3 fail at least one numerical criterion at the production step; all three pass at the tested 1.25-ms step. These unresolved-production flags are retained. Passing an independent data/analysis audit does not erase numerical restrictions, establish RISE source-condition fidelity, validate hardware, or establish population-level search uncertainty from three repetitions. Numerical qualification uses two new seeds per platform and observed discrepancies, not a rigorous error bound over every formal-test seed.

The twelve-contrast simultaneous family is separate for each search and the crossed-intervention family. Pointwise secondary intervals are labelled accordingly. Cross-search ranges and standard deviations are descriptive. The prior compact baseline and its PX4 evidence limitations remain separately documented.
