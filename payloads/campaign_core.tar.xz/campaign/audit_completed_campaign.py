"""Independent outcome/selection audit. Default requires complete outputs.

Imports no producer analysis, runner, selection helper or simulation module.
--self-test uses only generated in-memory examples; --hash-only reads sources.
"""
from pathlib import Path
from collections import defaultdict
import argparse,hashlib,itertools,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
METHODS=('minimal','family','full','rise')
MODELS=('point','lag','rigid')

def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def frozen():
    p=read(ROOT/'design/protocol.json');q=dict(p);h=q.pop('protocol_hash');assert digest(q)==h
    execution=read(ROOT/'design/execution_sources.json');analysis=read(ROOT/'design/analysis_freeze.json')
    assert execution['protocol_hash']==analysis['protocol_hash']==h
    for name,expected in execution['files'].items():assert sha(ROOT/name)==expected,name
    assert sha(ROOT/'analyse_campaign.py')==analysis['analysis_sha256']
    assert sha(ROOT/'audit/test_analysis_fixes.py')==analysis['test_sha256']
    assert sha(ROOT/'campaign_runner.py')==p['runner_sha256']
    assert analysis['no_formal_test_started']
    groups=[]
    for rep in p['repetitions']:
        for platform in ('native','otter'):
            for stage,n in [('train',6),('validation',12),('test',50),('numerical',2)]:
                g=rep['seeds'][platform][stage];assert len(g)==len(set(g))==n;groups.append(set(g))
    for field,n in [('factorial_seeds',50),('factorial_numerical_seeds',2)]:
        for platform in ('native','otter'):
            g=p[field][platform];assert len(g)==len(set(g))==n;groups.append(set(g))
    assert sum(map(len,groups))==len(set().union(*groups))
    original=read(ROOT/'design/original_protocol.json')
    prior=set(original['numerical_seeds'])|set(original['source_fixture_seeds'])|{890001}
    for platform_groups in original['seed_groups'].values():
        for group in platform_groups.values():prior.update(group)
    assert not prior&set().union(*groups)
    return p

def load_stage(folder,p,trace=False):
    design=read(folder/'design.json');assert design['protocol_hash']==p['protocol_hash']
    jobs={};rows=[];identifiers=set()
    for ref in design['rows']:
        base={k:v for k,v in ref.items() if k not in ('design_id','job_id')}
        assert digest(base)[:28]==ref['design_id']
        assert ref['design_id'] not in identifiers;identifiers.add(ref['design_id'])
        job=dict(ref['job']);job.pop('candidate');job.pop('stage')
        jid=digest(dict(job=job,parameters=ref['parameters'],protocol=p['protocol_hash']))[:28]
        assert jid==ref['job_id']
        if jid not in jobs:
            r=read(folder/'jobs'/f'{jid}.json')
            assert r['job_id']==jid and r['protocol_hash']==p['protocol_hash']
            assert r['parameters']==ref['parameters']
            actual={k:v for k,v in r['job'].items() if k not in ('candidate','stage')};assert actual==job
            if trace:
                path=folder/r['trace'];assert sha(path)==r['trace_sha256']
                with np.load(path,allow_pickle=False) as arrays:
                    for name in arrays.files:arrays[name] # Force ZIP decompression and CRC.
                    if r['metrics']['complete']:
                        j=np.trapezoid(arrays['error_norm'].mean(1),arrays['time'])/ref['job']['duration']
                        np.testing.assert_allclose(j,r['metrics']['J_m'],atol=1e-12,rtol=1e-12)
                        np.testing.assert_allclose(arrays['actual_force_squared_integral'].sum(),r['metrics']['force_effort_N2s'],atol=1e-9,rtol=1e-12)
            jobs[jid]=r
        r=jobs[jid];assert r['parameters']==ref['parameters']
        rows.append(dict(**ref['job'],**r['metrics'],parameters=ref['parameters'],strategy=ref.get('strategy',''),background=ref.get('background',''),job_id=jid))
    return pd.DataFrame(rows),jobs

def rank(frame,tolerance):
    candidates=[]
    for candidate,g in frame.groupby('candidate',sort=True):
        g=g.sort_values(['seed','trajectory','current']);ok=g[g.complete]
        assert not ok.empty or (~g.complete).all()
        assert np.isfinite(ok.J_m).all() and np.isfinite(ok.force_effort_N2s).all()
        candidates.append(dict(candidate=int(candidate),failures=int((~g.complete).sum()),
            mean=float(ok.J_m.mean()) if len(ok) else None,
            effort=float(ok.force_effort_N2s.mean()) if len(ok) else None))
    order=[]
    while candidates:
        fail=min(x['failures'] for x in candidates)
        same=[x for x in candidates if x['failures']==fail]
        best=min((x['mean'] for x in same if x['mean'] is not None),default=None)
        tied=[x for x in same if (best is None and x['mean'] is None) or (best is not None and x['mean'] is not None and x['mean']<=best+tolerance)]
        win=min(tied,key=lambda x:(float('inf') if x['effort'] is None else x['effort'],x['candidate']))
        order.append(win['candidate']);candidates.remove(win)
    return order

def selection_audit(p,rep,folder,trace):
    # This function receives only development paths; no test inputs are loaded.
    train,_=load_stage(folder/'train',p,trace);validation,_=load_stage(folder/'validation',p,trace)
    short=read(folder/'shortlist.json');selected=read(folder/'selection.json')
    selected_copy=dict(selected);h=selected_copy.pop('selection_hash');assert digest(selected_copy)==h
    assert selected['protocol_hash']==p['protocol_hash']
    for platform,method,model in itertools.product(('native','otter'),METHODS,MODELS):
        groups=[]
        for frame,stage,candidate_ids in [(train,'train',range(64)),(validation,'validation',[x['candidate'] for x in short[platform][method][model]])]:
            g=frame[(frame.platform==platform)&(frame.method==method)&(frame.model==model)]
            assert g.stage.eq(stage).all()
            actual=list(zip(g.candidate,g.seed,g.trajectory,g.current))
            expected=set(itertools.product(candidate_ids,rep['seeds'][platform][stage],('straight','arc'),[0. if platform=='native' else .03]))
            assert len(actual)==len(set(actual))==len(expected) and set(actual)==expected
            for r in g.itertuples():assert r.parameters==rep['candidates'][platform][method][r.candidate]['parameters']
            groups.append(g)
        tolerance=p['selection_resolution_m'][platform][model]
        assert rank(groups[0],tolerance)[:8]==[x['candidate'] for x in short[platform][method][model]]
        assert rank(groups[1],tolerance)[0]==selected['choices'][platform][method][model]['candidate']
        c=selected['choices'][platform][method][model]
        assert c['parameters']==rep['candidates'][platform][method][c['candidate']]['parameters']
    totals=pd.concat([train,validation]).groupby(['platform','method']).size()
    assert len(totals)==8 and totals.eq(2880).all() and len(train)+len(validation)==23040
    return selected

def cell(frame,platform,seeds,**filters):
    g=frame[frame.platform.eq(platform)]
    for key,value in filters.items():g=g[g[key].eq(value)]
    actual=list(zip(g.seed,g.trajectory,g.current))
    expected=set(itertools.product(seeds,('ellipse','double_sine','speed_line'),[0.] if platform=='native' else [0.,.1,.2]))
    assert len(actual)==len(set(actual))==len(expected) and set(actual)==expected,(platform,filters)
    assert g.complete.all() and np.isfinite(g.J_m).all()
    # Aggregate complete cells before taking differences (independent order).
    return g.groupby('seed').J_m.mean().reindex(seeds).to_numpy()

def interval_reconstruction(values,random_seed):
    """Independent frozen maximum-t reconstruction, including null intervals."""
    assert values.shape==(50,12) and np.isfinite(values).all()
    center=np.mean(values,axis=0)
    standard_error=np.std(values,axis=0,ddof=1)/np.sqrt(50)
    varies=(np.max(values,axis=0)!=np.min(values,axis=0))&(standard_error>0)
    generator=np.random.default_rng(random_seed)
    extrema=np.empty(20000)
    for batch in range(200):
        indices=[generator.integers(0,50,size=(100,50)),generator.integers(0,50,size=(100,50))]
        maxima=np.zeros(100)
        for platform in range(2):
            cols=slice(6*platform,6*(platform+1))
            sample=values[indices[platform],cols]
            means=np.mean(sample,axis=1)
            errors=np.std(sample,axis=1,ddof=1)/np.sqrt(50)
            constant=np.max(sample,axis=1)==np.min(sample,axis=1)
            errors[constant]=0.
            distances=np.abs(means-center[cols])
            ratios=np.zeros_like(errors)
            np.divide(distances,errors,out=ratios,where=errors!=0)
            ratios[(errors==0)&(distances!=0)]=np.inf
            active=varies[cols]
            if active.any():maxima=np.maximum(maxima,np.max(ratios[:,active],axis=1))
        extrema[batch*100:(batch+1)*100]=maxima
    critical=float(np.partition(extrema,18999)[18999])
    rows=[]
    for j in range(12):
        if not varies[j]:
            status='empirical_degenerate_no_equivalence_claim';low=high=None
        elif not np.isfinite(critical):
            status='critical_value_unavailable';low=high=None
        else:
            status='estimated';low=float(center[j]-critical*standard_error[j]);high=float(center[j]+critical*standard_error[j])
        rows.append(dict(lower_m=low,upper_m=high,interval_status=status))
    return dict(critical_value=critical if np.isfinite(critical) else None,contrasts=rows,positive_variance_columns=int(varies.sum()))

def check_intervals(rebuilt,reported):
    assert rebuilt['positive_variance_columns']==reported['positive_variance_columns']
    for key in ['critical_value']:
        if rebuilt[key] is None:assert reported[key] is None
        else:np.testing.assert_allclose(rebuilt[key],reported[key],rtol=0,atol=1e-10)
    assert len(reported['contrasts'])==12
    for expected,actual in zip(rebuilt['contrasts'],reported['contrasts']):
        assert expected['interval_status']==actual['interval_status']
        for key in ('lower_m','upper_m'):
            if expected[key] is None:assert actual[key] is None
            else:np.testing.assert_allclose(expected[key],actual[key],rtol=0,atol=1e-10)

def audit(scope,repetition,trace):
    p=frozen();folder=ROOT/('data/factorial' if scope=='factorial' else f'data/search_{repetition}')
    if scope=='search':
        rep=next(r for r in p['repetitions'] if r['repetition']==repetition)
        selected=selection_audit(p,rep,folder,trace)
        seeds={k:v['test'] for k,v in rep['seeds'].items()}
    else:
        selected=read(ROOT/'design/original_selection.json');assert digest(selected)==p['original_selection_hash']
        seeds=p['factorial_seeds']
    d,jobs=load_stage(folder/'test',p,trace)
    assert len(d)==(9600 if scope=='factorial' else 16800)
    assert d.stage.eq('test').all() and d.complete.all() and np.isfinite(d.J_m).all(),'Incomplete formal outcomes'
    for r in d.itertuples():
        assert r.seed in seeds[r.platform]
        if scope=='factorial':
            parameter_model={'point_selected_full':'point','rigid_retuned_full':'rigid'}[r.background];method='full'
        else:
            assert r.strategy in ('transfer','retuned','fixed_full_background')
            parameter_model=r.model if r.strategy=='retuned' else 'point';method='full' if r.strategy=='fixed_full_background' else r.method
        assert r.parameters==selected['choices'][r.platform][method][parameter_model]['parameters']
    arrays=[];labels=[]
    for platform in ('native','otter'):
        ss=seeds[platform]
        if scope=='factorial':
            effects={}
            for bg,model in itertools.product(p['factorial_backgrounds'],('point','rigid')):
                values={m:cell(d,platform,ss,background=bg,model=model,method=m) for m in p['factorial_methods']}
                f,s,w,b=(values[m] for m in ('full','no_schedule','no_powers','no_schedule_no_powers'))
                effects[bg,model]=(s-f,w-f,b+f-s-w)
            for model in ('point','rigid'):
                for i,name in enumerate(('schedule_deletion','powers_deletion','module_interaction')):
                    arrays.append(effects['rigid_retuned_full',model][i]-effects['point_selected_full',model][i]);labels.append(dict(platform=platform,model=model,effect=name))
        else:
            interactions={}
            for strategy in ('transfer','retuned'):
                # Audit complete performance cells, including secondary RISE/lag.
                v={(model,method):cell(d,platform,ss,strategy=strategy,model=model,method=method) for model,method in itertools.product(MODELS,METHODS)}
                for comparator in ('minimal','family'):
                    x=(v['rigid','full']-v['point','full'])-(v['rigid',comparator]-v['point',comparator])
                    interactions[strategy,comparator]=x;arrays.append(x);labels.append(dict(platform=platform,strategy=strategy,comparator=comparator))
            for comparator in ('minimal','family'):
                arrays.append(interactions['retuned',comparator]-interactions['transfer',comparator]);labels.append(dict(platform=platform,strategy='retuned_minus_transfer',comparator=comparator))
            for model,method in itertools.product(('point','rigid'),('no_schedule','no_powers')):
                cell(d,platform,ss,strategy='fixed_full_background',model=model,method=method)
    out=ROOT/('analysis/factorial' if scope=='factorial' else f'analysis/search_{repetition}')
    matrix=pd.read_csv(out/'paired_block_matrix.csv');contrasts=pd.read_csv(out/'contrasts.csv')
    assert matrix.native_seed.tolist()==seeds['native'] and matrix.otter_seed.tolist()==seeds['otter']
    expected=np.column_stack(arrays);assert expected.shape==(50,12) and len(contrasts)==12
    np.testing.assert_allclose(matrix[[f'c{i}' for i in range(1,13)]],expected,atol=2e-12,rtol=1e-12)
    for i,label in enumerate(labels):
        row=contrasts.iloc[i];assert row.contrast_id==f'c{i+1}'
        for k,v in label.items():assert row[k]==v
    np.testing.assert_allclose(contrasts.mean_m,expected.mean(0),atol=2e-12,rtol=1e-12)
    seed=p['inference']['bootstrap_seed']+(repetition if scope=='search' else 0)
    rebuilt=interval_reconstruction(expected,seed)
    summary=read(out/'summary.json')
    assert summary['resamples']==20000 and summary['random_seed']==seed
    check_intervals(rebuilt,summary)
    for i,r in enumerate(rebuilt['contrasts']):
        assert contrasts.iloc[i].interval_status==r['interval_status']
        for key in ('lower_m','upper_m'):
            if r[key] is None:assert pd.isna(contrasts.iloc[i][key])
            else:np.testing.assert_allclose(contrasts.iloc[i][key],r[key],atol=1e-10,rtol=0)
    return dict(status='pass',scope=scope,repetition=repetition if scope=='search' else None,
        design_references=len(d),unique_test_executions=len(jobs),contrasts=12,paired_values=600,
        selection_replayed=scope=='search',trace_hash_crc_checked=trace,
        maximum_block_difference=float(np.max(abs(matrix[[f'c{i}' for i in range(1,13)]].to_numpy()-expected))),
        simultaneous_endpoints_checked=24,bootstrap_resamples=20000,critical_value=rebuilt['critical_value'],
        scope_limit='Independent cell-first means, paired matrices and simultaneous intervals; does not independently establish numerical validity or secondary percentile intervals.')

def self_test():
    g=pd.DataFrame([dict(candidate=0,seed=1,trajectory='straight',current=0.,complete=True,J_m=1.,force_effort_N2s=5.),dict(candidate=1,seed=1,trajectory='straight',current=0.,complete=True,J_m=1.0001,force_effort_N2s=2.),dict(candidate=2,seed=1,trajectory='straight',current=0.,complete=False,J_m=None,force_effort_N2s=None)])
    assert rank(g,.001)==[1,0,2] and rank(g,0.)==[0,1,2]
    seeds=list(range(50));rows=[dict(platform='native',seed=s,trajectory=t,current=0.,complete=True,J_m=s+1.,method='full') for s in seeds for t in ('ellipse','double_sine','speed_line')]
    frame=pd.DataFrame(rows).sample(frac=1,random_state=9)
    np.testing.assert_array_equal(cell(frame,'native',seeds,method='full'),np.arange(50)+1.)
    for broken in [frame.iloc[1:],pd.concat([frame,frame.iloc[:1]])]:
        try:cell(broken,'native',seeds,method='full')
        except AssertionError:pass
        else:raise AssertionError('Bad design accepted')
    return dict(status='self_test_pass',scientific_outcomes_read=False)

def interval_self_test():
    # Known null cases exercise constant nonzero columns and zero-SE resamples.
    zero=interval_reconstruction(np.full((50,12),.1),990081)
    assert zero['positive_variance_columns']==0 and all(r['lower_m'] is None for r in zero['contrasts'])
    sparse=np.zeros((50,12));sparse[0,:]=1.
    unavailable=interval_reconstruction(sparse,990082)
    assert unavailable['critical_value'] is None and all(r['interval_status']=='critical_value_unavailable' for r in unavailable['contrasts'])
    # Scalar per-resample implementation checks the vectorized independent path.
    values=np.random.default_rng(556).normal(size=(50,12));values[:,0]=0.;values[:,7]=.1
    got=interval_reconstruction(values,990083)
    rng=np.random.default_rng(990083);center=values.mean(0);se=values.std(0,ddof=1)/np.sqrt(50)
    active=[j for j in range(12) if np.ptp(values[:,j])>0];maxima=[]
    for batch in range(200):
        native=rng.integers(0,50,(100,50));otter=rng.integers(0,50,(100,50))
        for b in range(100):
            statistics=[]
            for j in active:
                x=values[native[b] if j<6 else otter[b],j]
                s=float(np.std(x,ddof=1)/np.sqrt(50));distance=abs(float(np.mean(x))-center[j])
                statistics.append(distance/s if s else (float('inf') if distance else 0.))
            maxima.append(max(statistics))
    critical=sorted(maxima)[18999]
    np.testing.assert_allclose(got['critical_value'],critical,atol=1e-10,rtol=0)
    for j in active:
        np.testing.assert_allclose([got['contrasts'][j]['lower_m'],got['contrasts'][j]['upper_m']],[center[j]-critical*se[j],center[j]+critical*se[j]],atol=1e-10,rtol=0)
    check_intervals(got,got)
    return dict(status='interval_self_test_pass',resamples=20000,finite_critical_value=critical,degenerate_columns=2,scientific_outcomes_read=False)

if __name__=='__main__':
    if not __debug__:raise RuntimeError('Assertions must remain enabled')
    parser=argparse.ArgumentParser();parser.add_argument('--scope',choices=['factorial','search']);parser.add_argument('--repetition',type=int,choices=[1,2,3]);parser.add_argument('--verify-traces',action='store_true');parser.add_argument('--self-test',action='store_true');parser.add_argument('--interval-self-test',action='store_true');parser.add_argument('--hash-only',action='store_true');args=parser.parse_args()
    if args.interval_self_test:result=interval_self_test()
    elif args.self_test:result=self_test()
    elif args.hash_only:result=dict(status='source_hashes_pass',protocol_hash=frozen()['protocol_hash'])
    else:
        if args.scope is None or (args.scope=='search' and args.repetition is None):parser.error('--scope is required, and search requires --repetition')
        result=audit(args.scope,args.repetition,args.verify_traces)
    print(json.dumps(result,indent=2,allow_nan=False))
