"""Paired seed-block inference on the frozen design, including failures."""
from pathlib import Path
from collections import defaultdict
import argparse, hashlib, json
import numpy as np
import pandas as pd
from .protocol import SEEDS, TEST_TRAJECTORIES
from .numerical_campaign import digest


def read_design_results(folder):
    design = json.loads((folder/"design.json").read_text())
    cache = {}
    rows = []
    for reference in design["rows"]:
        job_id = reference["job_id"]
        if job_id not in cache:
            path = folder/"jobs"/(job_id+".json")
            cache[job_id] = json.loads(path.read_text()) if path.exists() else None
        record = cache[job_id]
        row = {"design_id":reference["design_id"],"job_id":job_id,**reference["job"],
               "strategy":reference.get("strategy","development"),
               "parameter_hash":digest(reference["parameters"])}
        if record is None:
            row.update(complete=False,failure="missing_record",J_m=None,force_effort_N2s=None)
        else:
            row.update(record["metrics"])
        rows.append(row)
    return pd.DataFrame(rows), cache


def seed_blocks(frame):
    keys = ["platform","method","strategy","model","seed","parameter_hash"]
    output = []
    for key, group in frame.groupby(keys,dropna=False):
        platform = key[0]
        expected = 3 if platform=="native" else 9
        actual_design = set(zip(group["trajectory"],group["current"]))
        expected_design = {(s,c) for s in TEST_TRAJECTORIES for c in ([0.] if platform=="native" else [0.,.1,.2])}
        valid = (len(group)==expected and actual_design==expected_design
                 and group["complete"].all() and np.isfinite(group["J_m"].to_numpy(float)).all())
        row = dict(zip(keys,key))
        row.update(designed_scenarios=expected,recorded_scenarios=len(group),
                   complete=bool(valid),J_m=float(group["J_m"].mean()) if valid else None,
                   force_effort_N2s=float(group["force_effort_N2s"].mean()) if valid else None)
        output.append(row)
    return pd.DataFrame(output)


def primary_contrasts(blocks):
    definitions, columns = [], []
    def arm(platform,method,strategy,model):
        sub = blocks[(blocks.platform==platform)&(blocks.method==method)&
                     (blocks.strategy==strategy)&(blocks.model==model)].set_index("seed")
        expected = SEEDS[platform]["test"]
        if set(sub.index)!=set(expected) or not sub.complete.all():
            return np.full(50,np.nan)
        return sub.loc[expected,"J_m"].to_numpy(float)
    for platform in ["native","otter"]:
        for strategy in ["transfer","retuned"]:
            for comparator in ["minimal","family"]:
                terms = [("full",strategy,"rigid",1),(comparator,strategy,"rigid",-1),
                         ("full",strategy,"point",-1),(comparator,strategy,"point",1)]
                column = sum(sign*arm(platform,method,s,model) for method,s,model,sign in terms)
                definitions.append({"platform":platform,"type":"complete_method",
                    "strategy":strategy,"comparison":"full_minus_"+comparator,
                    "formula":"(Full-Comparator)_rigid - (Full-Comparator)_point","terms":terms})
                columns.append(column)
        for knockout in ["no_schedule","no_powers"]:
            terms = [(knockout,"fixed_full_background","rigid",1),("full","transfer","rigid",-1),
                     (knockout,"fixed_full_background","point",-1),("full","transfer","point",1)]
            column = sum(sign*arm(platform,method,s,model) for method,s,model,sign in terms)
            definitions.append({"platform":platform,"type":"module_deletion",
                "strategy":"fixed_full_background","comparison":knockout,
                "formula":"(Deletion-Full)_rigid - (Deletion-Full)_point","terms":terms})
            columns.append(column)
    return np.column_stack(columns),definitions


def simultaneous_intervals(matrix,resamples=20000,seed=880031):
    """Maximum bootstrap-t interval over two independent platform seed cohorts."""
    if matrix.shape!=(50,12) or not np.isfinite(matrix).all():
        return {"status":"withheld_incomplete_family","family_size":12}
    means = matrix.mean(0)
    standard_errors = matrix.std(0,ddof=1)/np.sqrt(50)
    rng = np.random.default_rng(seed)
    maxima = np.empty(resamples)
    for start in range(0,resamples,500):
        stop = min(start+500,resamples)
        indices_native = rng.integers(0,50,(stop-start,50))
        indices_otter = rng.integers(0,50,(stop-start,50))
        native = matrix[indices_native,:6]
        independent = matrix[indices_otter,6:]
        bootstrap = np.concatenate([native,independent],axis=2)
        boot_mean = bootstrap.mean(1)
        boot_se = bootstrap.std(1,ddof=1)/np.sqrt(50)
        delta = abs(boot_mean-means)
        pivots = np.divide(delta,boot_se,out=np.zeros_like(delta),where=boot_se>0)
        pivots[(boot_se==0)&(delta>1e-14)] = np.inf
        maxima[start:stop] = pivots.max(1)
    critical = float(np.quantile(maxima,.95,method="higher"))
    if not np.isfinite(critical):
        return {"status":"withheld_degenerate_bootstrap","family_size":12}
    return {"status":"evaluated","family_size":12,"seed_blocks_per_platform":50,
        "bootstrap_resamples":resamples,"bootstrap_seed":seed,"critical_value":critical,
        "mean":means.tolist(),"standard_error":standard_errors.tolist(),
        "lower":(means-critical*standard_errors).tolist(),
        "upper":(means+critical*standard_errors).tolist(),
        "interval_type":"nominal 95% simultaneous maximum bootstrap-t interval"}


def numerical_lookup(folder):
    output = defaultdict(lambda:{"bound":0.,"resolved":True,"cases":0})
    for path in folder.glob("*.json"):
        if path.name in {"summary.json","design.json"}:
            continue
        row = json.loads(path.read_text())
        j = row["job"]
        key = (j["platform"],j["method"],j["model"],digest(row["parameters"]))
        target = .00125 if j["platform"]=="native" else .0025
        if row["status"]!="evaluated":
            output[key]["resolved"] = False
            continue
        c = next(x for x in row["comparisons"] if x["physics_dt"]==target)
        output[key]["cases"] += 1
        output[key]["resolved"] &= c["pass"]
        if c.get("J_bound_m") is not None:
            output[key]["bound"] = max(output[key]["bound"],c["J_bound_m"])
        else:
            output[key]["resolved"] = False
    return output


def attach_numerics(definitions,blocks,lookup):
    results = []
    for definition in definitions:
        bound, resolved = 0.,True
        for method,strategy,model,sign in definition["terms"]:
            sub = blocks[(blocks.platform==definition["platform"])&(blocks.method==method)&
                         (blocks.strategy==strategy)&(blocks.model==model)]
            hashes = sub.parameter_hash.unique()
            if len(hashes)!=1:
                resolved=False; continue
            entry = lookup.get((definition["platform"],method,model,hashes[0]))
            if entry is None:
                resolved=False; continue
            bound += entry["bound"]
            resolved &= entry["resolved"]
        results.append({"numerical_conditions_resolved":bool(resolved),
                        "sum_observed_numerical_error_bounds_m":bound,
                        "bound_scope":"observed across held-out numerical seeds and test condition grid; not a uniform mathematical bound"})
    return results


def secondary_summaries(blocks):
    rows = []
    rng = np.random.default_rng(880032)
    indices = rng.integers(0,50,(20000,50))
    for key,group in blocks.groupby(["platform","method","strategy","model"]):
        row = dict(zip(["platform","method","strategy","model"],key))
        row["seed_blocks"] = len(group)
        if len(group)!=50 or not group.complete.all():
            row.update(status="incomplete",mean_J_m=None,lower=None,upper=None)
        else:
            values = group.sort_values("seed").J_m.to_numpy(float)
            means = values[indices].mean(1)
            lo,hi = np.quantile(means,[.025,.975])
            row.update(status="complete",mean_J_m=float(values.mean()),lower=float(lo),upper=float(hi),
                mean_force_effort_N2s=float(group.force_effort_N2s.mean()),
                interval_type="secondary pointwise 95% percentile bootstrap")
        rows.append(row)
    return pd.DataFrame(rows)


def local_module_contrasts(blocks):
    rows=[]
    rng=np.random.default_rng(880033)
    indices=rng.integers(0,50,(20000,50))
    for platform in ['native','otter']:
        for method in ['no_schedule','no_powers']:
            for model in ['point','rigid']:
                common=(blocks.platform==platform)&(blocks.model==model)
                full=blocks[common&(blocks.method=='full')&(blocks.strategy=='transfer')].set_index('seed')
                deleted=blocks[common&(blocks.method==method)].set_index('seed')
                row={'platform':platform,'deletion':method,'model':model,
                     'orientation':'Deletion minus Full; positive means removal increases error',
                     'analysis':'secondary, pointwise percentile interval'}
                expected=SEEDS[platform]['test']
                if (set(full.index)==set(expected) and set(deleted.index)==set(expected)
                        and full.complete.all() and deleted.complete.all()):
                    difference=deleted.loc[expected,'J_m'].to_numpy(float)-full.loc[expected,'J_m'].to_numpy(float)
                    lo,hi=np.quantile(difference[indices].mean(1),[.025,.975])
                    row.update(status='complete',mean=float(difference.mean()),lower=float(lo),upper=float(hi))
                else:
                    row.update(status='incomplete',mean=None,lower=None,upper=None)
                rows.append(row)
    return pd.DataFrame(rows)


def secondary_pairs(blocks):
    rows=[];indices=np.random.default_rng(880034).integers(0,50,(20000,50))
    for platform in ['native','otter']:
        for strategy in ['transfer','retuned']:
            for model in ['point','lag','rigid']:
                common=(blocks.platform==platform)&(blocks.strategy==strategy)&(blocks.model==model)
                full=blocks[common&(blocks.method=='full')].set_index('seed')
                expected=SEEDS[platform]['test']
                for comparator in ['minimal','family','rise']:
                    other=blocks[common&(blocks.method==comparator)].set_index('seed')
                    row=dict(platform=platform,strategy=strategy,model=model,comparator=comparator,
                             orientation='Full minus comparator',analysis='secondary pointwise percentile')
                    if (set(full.index)==set(expected) and set(other.index)==set(expected)
                            and full.complete.all() and other.complete.all()):
                        d=full.loc[expected,'J_m'].to_numpy(float)-other.loc[expected,'J_m'].to_numpy(float)
                        lo,hi=np.quantile(d[indices].mean(1),[.025,.975])
                        row.update(status='complete',mean=float(d.mean()),lower=float(lo),upper=float(hi))
                    else:row.update(status='incomplete',mean=None,lower=None,upper=None)
                    rows.append(row)
    return pd.DataFrame(rows)


def scenario_summaries(frame):
    rows=[];indices=np.random.default_rng(880035).integers(0,50,(20000,50))
    keys=['platform','method','strategy','model','trajectory','current']
    for key,group in frame.groupby(keys):
        row=dict(zip(keys,key));row['designed_seed_blocks']=50
        row['complete_seed_blocks']=int(group.complete.sum())
        expected=SEEDS[key[0]]['test']
        if (len(group)==50 and set(group.seed)==set(expected) and group.complete.all()
                and np.isfinite(group.J_m.to_numpy(float)).all()):
            values=group.sort_values('seed').J_m.to_numpy(float)
            lo,hi=np.quantile(values[indices].mean(1),[.025,.975])
            row.update(status='complete',mean_J_m=float(values.mean()),lower=float(lo),upper=float(hi),
                       interval_type='secondary pointwise 95% percentile bootstrap')
        else:row.update(status='incomplete',mean_J_m=None,lower=None,upper=None)
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--campaign",type=Path,required=True)
    parser.add_argument("--numerical",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    frame,records = read_design_results(args.campaign/"test")
    frame.to_csv(args.output/"designed_test_outcomes.csv",index=False)
    blocks = seed_blocks(frame)
    blocks.to_csv(args.output/"paired_seed_blocks.csv",index=False)
    matrix,definitions = primary_contrasts(blocks)
    np.save(args.output/"primary_contrast_blocks.npy",matrix)
    family = simultaneous_intervals(matrix)
    numeric = attach_numerics(definitions,blocks,numerical_lookup(args.numerical))
    rows = []
    for i,definition in enumerate(definitions):
        row = {"contrast_index":i+1,**definition,**numeric[i],"family_status":family["status"]}
        if family["status"]=="evaluated":
            row.update(mean=family["mean"][i],lower=family["lower"][i],upper=family["upper"][i])
            excludes_zero = row["lower"]>0 or row["upper"]<0
            row["direction_interpretable"] = bool(excludes_zero and row["numerical_conditions_resolved"]
                and abs(row["mean"])>row["sum_observed_numerical_error_bounds_m"])
        else:
            row.update(mean=None,lower=None,upper=None,direction_interpretable=False)
        rows.append(row)
    (args.output/"primary_family.json").write_text(json.dumps({"inference":family,"contrasts":rows},indent=2,allow_nan=False),encoding="utf-8")
    pd.DataFrame(rows).drop(columns="terms").to_csv(args.output/"primary_contrasts.csv",index=False)
    secondary_summaries(blocks).to_csv(args.output/"secondary_method_summaries.csv",index=False)
    local_module_contrasts(blocks).to_csv(args.output/'secondary_local_module_contrasts.csv',index=False)
    secondary_pairs(blocks).to_csv(args.output/'secondary_paired_method_contrasts.csv',index=False)
    scenario_summaries(frame).to_csv(args.output/'secondary_scenario_summaries.csv',index=False)
    failures = frame[~frame.complete].drop_duplicates("job_id")
    failures.to_csv(args.output/"failures.csv",index=False)
    summary = {"design_references":len(frame),"unique_executions":frame.job_id.nunique(),
        "failed_unique_executions":len(failures),"seed_blocks":len(blocks),
        "primary_family_status":family["status"],"direction_interpretable":sum(r["direction_interpretable"] for r in rows)}
    (args.output/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
