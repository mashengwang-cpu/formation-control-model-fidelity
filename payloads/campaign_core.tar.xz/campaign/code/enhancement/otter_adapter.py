"""Pinned upstream model and immutable parameters passed to its compiled view."""
from collections import namedtuple
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "vendor" / "PythonVehicleSimulator" / "src"))
from python_vehicle_simulator.vehicles.otter import otter

FIELDS = ("V_c", "beta_c", "m_total", "Ig", "H_rg", "MA", "mp", "g", "S_rp",
          "n_min", "n_max", "k_pos", "k_neg", "l1", "l2", "D", "L", "B_pont",
          "T", "G", "Minv", "T_n")
Boat = namedtuple("Boat", FIELDS)


def make_boat(current=0., direction_deg=90.):
    original = otter(V_current=current, beta_current=direction_deg)
    values = []
    for key in FIELDS:
        value = getattr(original, key)
        values.append(np.array(value, dtype=np.float64, order="C")
                      if isinstance(value, np.ndarray) else float(value))
    return original, Boat(*values)


def source_parity(seed=721, cases=100):
    """Euler output parity includes currents, reverse thrust and saturation."""
    from .otter_kernel import dynamics
    rng = np.random.default_rng(seed)
    worst = 0.
    for case in range(cases):
        original, boat = make_boat((case % 3) * .1)
        eta = rng.normal(0., .1, 6)
        nu = rng.normal(0., .2, 6)
        rpm = rng.uniform(-180., 180., 2)
        command = rng.uniform(boat.n_min, boat.n_max, 2)
        expected = original.dynamics(eta.copy(), nu.copy(), rpm.copy(), command.copy(), .0025)
        actual = dynamics(boat, eta.copy(), nu.copy(), rpm.copy(), command.copy(), .0025)
        for a, b in zip(actual, expected):
            np.testing.assert_allclose(a, b, rtol=2e-12, atol=2e-12)
            worst = max(worst, float(np.max(np.abs(a-b))))
    return {"cases": cases, "maximum_absolute_difference": worst,
            "compilation": "float64; fastmath disabled; upstream equations unchanged"}


if __name__ == "__main__":
    import json
    print(json.dumps(source_parity()))
