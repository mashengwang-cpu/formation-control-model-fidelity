"""Check exported artwork and render individual, readable review pages."""
from pathlib import Path
import argparse, hashlib, json
import xml.etree.ElementTree as ET
import numpy as np
import pdfplumber
import pypdfium2 as pdfium
from pdfminer.pdftypes import resolve1
from PIL import Image

# Machado matrices from Colour 0.4.7, verified against its source dataset.
# https://raw.githubusercontent.com/colour-science/colour/v0.4.7/colour/blindness/datasets/machado2010.py
CVD={
 'protan':[[.152286,1.052583,-.204868],[.114503,.786281,.099216],[-.003882,-.048116,1.051998]],
 'deutan':[[.367322,.860646,-.227968],[.280085,.672501,.047413],[-.01182,.04294,.968881]],
 'tritan':[[1.255528,-.076749,-.178779],[-.078411,.930809,.147602],[.004733,.691367,.3039]]}


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


def check_figure(pdf, output):
    checks={};font_sizes=[];fonts=[]
    with pdfplumber.open(pdf) as doc:
        checks['one_page']=len(doc.pages)==1
        page=doc.pages[0];width,height=page.width,page.height
        outside=[c['text'] for c in page.chars if c['text'].strip() and
                 (c['x0']<-.4 or c['top']<-.4 or c['x1']>width+.4 or c['bottom']>height+.4)]
        checks['all_text_inside_page']=not outside
        checks['no_embedded_raster']=not page.images
        font_sizes=sorted({round(c['size'],2) for c in page.chars if c['text'].strip()})
        resources=resolve1(page.page_obj.attrs.get('Resources',{}))
        for value in resolve1(resources.get('Font',{})).values():
            font=resolve1(value)
            for entry in resolve1(font.get('DescendantFonts',[])) or [font]:
                ft=resolve1(entry);descriptor=resolve1(ft.get('FontDescriptor',{}))
                fonts.append({'name':str(ft.get('BaseFont')),'embedded':any(k in descriptor for k in ['FontFile','FontFile2','FontFile3'])})
        checks['fonts_embedded']=bool(fonts) and all(f['embedded'] for f in fonts)
    svg=pdf.with_suffix('.svg');png=pdf.with_suffix('.png')
    tree=ET.parse(svg);elements=list(tree.getroot().iter())
    checks['svg_vector']=not any(e.tag.rsplit('}',1)[-1]=='image' for e in elements)
    checks['svg_editable_text']=any(e.tag.rsplit('}',1)[-1]=='text' for e in elements)
    with Image.open(png) as im:
        checks['png_1000dpi']=all(abs(d-1000)<.1 for d in im.info.get('dpi',(0,0)))
        checks['pixel_dimensions']=all(abs(p-q/72*1000)<=2 for p,q in zip(im.size,[width,height]))
        if 'A' in im.getbands():checks['opaque_background']=im.getchannel('A').getextrema()==(255,255)
    doc=pdfium.PdfDocument(str(pdf));page=doc[0]
    render=page.render(scale=220/72).to_pil().convert('RGB')
    render.save(output/(pdf.stem+'.png'))
    values=np.asarray(render,dtype=np.float64)/255
    linear=np.where(values<=.04045,values/12.92,((values+.055)/1.055)**2.4)
    gray=np.sum(linear*np.array([.2126,.7152,.0722]),axis=2)
    gray=np.where(gray<=.0031308,gray*12.92,1.055*gray**(1/2.4)-.055)
    Image.fromarray(np.uint8(np.clip(gray,0,1)*255)).save(output/(pdf.stem+'_gray.png'))
    for label,matrix in CVD.items():
        simulated=np.clip(linear@np.array(matrix).T,0,1)
        encoded=np.where(simulated<=.0031308,12.92*simulated,1.055*simulated**(1/2.4)-.055)
        Image.fromarray(np.uint8(np.clip(encoded,0,1)*255)).save(output/(pdf.stem+'_'+label+'.png'))
    page.close();doc.close()
    return {'figure':pdf.stem,'pdf_sha256':sha(pdf),'size_mm':[width*25.4/72,height*25.4/72],
            'font_sizes_pt':font_sizes,'font_resources':fonts,'checks':checks,'outside':outside,
            'passed':all(checks.values())}


def main():
    p=argparse.ArgumentParser();p.add_argument('--reading',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    paths=sorted(f for folder in ['figures','panels'] for f in (args.reading/folder).glob('*.pdf'))
    rows=[check_figure(f,args.output) for f in paths]
    result={'figures':len(rows),'passed':all(r['passed'] for r in rows),'results':rows,
            'cvd':{'matrices':CVD,'source_version':'Colour 0.4.7','severity':1.,
                   'method':'Decode sRGB, matrix transform in linear RGB, clip, re-encode.',
                   'limitation':'The tritan shift model is an approximation, not exact tritanopia reproduction; accessibility requires manual reading with labels, shapes and line styles.'},
            'scope':'Export structure, dimensions, embedded fonts and page boundaries. Individual color/grayscale renders support manual reading; these automated checks do not establish scientific validity.'}
    (args.output/'artwork_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'figures':len(rows),'passed':result['passed'],'failed':[r['figure'] for r in rows if not r['passed']]}))
    if not result['passed']:raise SystemExit(1)


if __name__=='__main__':main()
