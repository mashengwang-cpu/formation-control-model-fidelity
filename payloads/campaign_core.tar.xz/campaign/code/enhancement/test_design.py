"""Budget, missing-outcome and selection isolation tests."""
import numpy as np
from .protocol import (SEEDS, candidates, assert_seed_isolation, training_rows)
from .controllers import METHODS
from .campaign import rank_candidates, shortlist, validation_rows, execution_id


def test_seed_isolation_and_sobol_budget():
    assert_seed_isolation()
    table = {p:{m:candidates(p,m) for m in METHODS} for p in SEEDS}
    rows = list(training_rows({"candidates":table}))
    assert len(rows)==18432
    for p in SEEDS:
        for m in METHODS:
            subset = [r for r in rows if r["job"]["platform"]==p and r["job"]["method"]==m]
            assert len(subset)==2304
            assert len({r["job"]["candidate"] for r in subset})==64
            assert {r["job"]["seed"] for r in subset}==set(SEEDS[p]["train"])


def record(candidate,j,effort,complete=True):
    return {"job":{"candidate":candidate},"parameters":[candidate],
            "metrics":{"complete":complete,"J_m":j,"force_effort_N2s":effort}}


def test_failure_before_low_error_and_effort_tie():
    rows = [record(0,.2,3),record(0,None,None,False),record(1,.3,10),record(1,.3,10),
            record(2,.30001,2),record(2,.30001,2)]
    ranked = rank_candidates(rows,.0001)
    assert [r["candidate"] for r in ranked]==[2,1,0]
    assert ranked[-1]["failures"]==1


def test_nonfinite_missing_does_not_become_zero():
    ranked = rank_candidates([record(0,None,None,False),record(1,1000.,1000.)],.01)
    assert ranked[0]["candidate"]==1
    assert ranked[1]["mean_J_m"] is None


def test_shared_execution_has_one_identifier():
    row = {"job":{"stage":"test","candidate":1,"seed":40000,"method":"full"},"parameters":[1.,2.]}
    other = {"job":dict(row["job"],candidate=2),"parameters":[1.,2.],"strategy":"retuned"}
    assert execution_id(row,"same_frozen_protocol")==execution_id(other,"same_frozen_protocol")
