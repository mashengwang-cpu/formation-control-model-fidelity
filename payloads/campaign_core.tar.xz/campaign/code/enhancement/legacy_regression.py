"""Replay representative frozen legacy jobs without changing their entry point."""
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import argparse, hashlib, json, sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'simulation'/'src'))
from finite_control_sim.config import parse_config
from finite_control_sim.simulator import SimulationJob, simulate_job


def replay(payload):
    row, original = payload
    original = Path(original)
    record = json.loads((original/'data/native/jobs'/(row['job_id']+'.json')).read_text())
    output = simulate_job(parse_config(record['configuration']),SimulationJob(**row['job']))
    frozen = np.load(original/'data/native'/record['trajectory'])
    checks = []
    for name in frozen.files:
        fresh = getattr(output,name)
        before = frozen[name]
        equal = bool(np.array_equal(fresh,before,equal_nan=True))
        checks.append({'array':name,'shape':list(before.shape),'bitwise_equal':equal,
                       'max_absolute_difference':float(np.max(np.abs(fresh.astype(float)-before.astype(float))))})
    return {'job_id':row['job_id'],'job':row['job'],'checks':checks,
            'passed':all(r['bitwise_equal'] for r in checks)}


def main():
    p=argparse.ArgumentParser();p.add_argument('--original',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    design=json.loads((args.original/'data/native/design.json').read_text())
    selected={r['job_id']:r for r in design if r['campaign']=='core_fixed'
              and r['job']['seed']==1000 and r['job']['scenario']=='nominal'}
    assert len(selected)==9, len(selected)
    source=[]
    for file in sorted((ROOT/'simulation/src').rglob('*.py')):
        relative=file.relative_to(ROOT)
        old=args.original/relative
        source.append({'path':relative.as_posix(),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),
                       'unchanged':file.read_bytes()==old.read_bytes()})
    with ProcessPoolExecutor(max_workers=2) as pool:
        rows=list(pool.map(replay,[(r,str(args.original)) for r in selected.values()]))
    result={'source_files':source,'replays':rows,'passed':all(r['unchanged'] for r in source)
            and all(r['passed'] for r in rows)}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'jobs':len(rows),'arrays':sum(len(r['checks']) for r in rows),'passed':result['passed']}))
    if not result['passed']:raise SystemExit(1)


if __name__=='__main__':main()
