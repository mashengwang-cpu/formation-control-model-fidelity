"""Keep the citation order, bibliography and source-support metadata aligned."""
from pathlib import Path
import argparse, json, re


def main():
    p=argparse.ArgumentParser();p.add_argument('--submission',type=Path,required=True)
    p.add_argument('--references',type=Path,required=True);args=p.parse_args()
    main_path=args.submission/'Manuscript.tex';text=main_path.read_text(encoding='utf-8')
    text=text.replace('\\balance\n','')
    first=text.index('\\begin{thebibliography}')
    ending=text.index('\\end{thebibliography}',first)
    start=text.index('\n',first)+1
    bibliography=dict(re.findall(r'\\bibitem\{([^}]+)\}(.*?)(?=\\bibitem|\Z)',text[start:ending],flags=re.S))
    def expand(content):
        return re.sub(r'\\input\{([^}]+)\}',lambda m:expand((args.submission/(m.group(1) if m.group(1).endswith('.tex') else m.group(1)+'.tex')).read_text(encoding='utf-8')),content)
    body=expand(text[:first]);order=[]
    for group in re.findall(r'\\cite(?:[tp])?(?:\[[^\]]*\])*\{([^}]+)\}',body):
        for key in group.split(','):
            key=key.strip()
            if key not in order:order.append(key)
    missing=set(order)-set(bibliography);uncited=set(bibliography)-set(order)
    if missing or uncited:raise ValueError({'missing':sorted(missing),'uncited':sorted(uncited)})
    revised=''.join('\\bibitem{'+key+'}'+bibliography[key].strip()+'\n' for key in order)
    main_path.write_text(text[:start]+revised+text[ending:],encoding='utf-8')
    path=args.references/'selected_references.json';meta=json.loads(path.read_text(encoding='utf-8'))
    records={r['key']:r for r in meta['records']}
    if set(records)!=set(order):raise ValueError('Bibliography and metadata membership differ')
    locations={key:[] for key in order}
    for file in args.submission.rglob('*.tex'):
        for number,line in enumerate(file.read_text(encoding='utf-8').splitlines(),1):
            for group in re.findall(r'\\cite(?:[tp])?(?:\[[^\]]*\])*\{([^}]+)\}',line):
                for key in group.split(','):
                    locations[key.strip()].append({'file':file.relative_to(args.submission).as_posix(),'line':number,'text':line})
    for i,key in enumerate(order,1):records[key].update(reference_number=i,citation_locations=locations[key])
    meta['records']=[records[key] for key in order]
    path.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'references':len(order),'missing':len(missing),'uncited':len(uncited)}))


if __name__=='__main__':main()
