"""Reconstruct the published RISE simulation conditions with explicit RNG rules.

The source omits RNG seed, noise refresh interval, delay interpolation and
integral initialization. Those choices are recorded here and do not purport
to recover the authors' exact numerical realization or figure pixels.
"""
from pathlib import Path
import json
import numpy as np
from numba import njit
from .controllers import ring, rise_equations


@njit(cache=True)
def nonlinear_acceleration(t, q, v, c, control):
    result = np.empty_like(q)
    for i in range(len(q)):
        x, y, z = q[i]
        vx, vy, vz = v[i]
        drift = np.array([c[i, 0]*(y-z)+c[i, 1]*np.tanh(vx*t),
            c[i, 2]*(z-x)+c[i, 3]*np.tanh(vy*t),
            c[i, 4]*(x-y)+c[i, 5]*np.tanh(vz*t)])
        diagonal = np.array([1-c[i, 6]*np.cos(t), 1-c[i, 7]*np.sin(t),
                            1-c[i, 8]*np.cos(t)*np.sin(t)])
        d = np.array([c[i, 9]*np.cos(t), c[i, 10]*np.sin(t),
                      c[i, 11]*np.cos(t)*np.sin(t)])
        result[i] = drift + diagonal*control[i] + d
    return result


@njit(cache=True)
def target_acceleration(q, v):
    x, y, z = q
    vx, vy, vz = v
    return np.array([np.sin(x)-np.cos(y*vx), np.cos(z*vy)-np.sin(x),
                     -np.sin(y*vz)-np.sin(z)])


@njit(cache=True)
def simulate(initial, c, delays, noise, dt, noisy, edge_weight=1., relative_delay=False):
    steps = len(noise)
    q = np.empty((steps+1, 9, 3)); v = np.empty_like(q)
    q[0], v[0] = initial[0], initial[1]
    commands = np.zeros((steps, 8, 3))
    integral = np.zeros((8, 3))
    gains = np.array([10.,10.,25.,50.])
    adjacency = np.zeros((8, 8)); pinning = np.zeros(8)
    for i in range(8):
        adjacency[i, (i+1)%8] = edge_weight; adjacency[(i+1)%8, i] = edge_weight
        pinning[i] = 1. if i%2==0 else 0.
    for k in range(steps):
        t = k*dt
        eta, eta_dot, e, e_dot = np.zeros((8,3)),np.zeros((8,3)),np.zeros((8,3)),np.zeros((8,3))
        for i in range(8):
            target_index = max(0, k-int(round(delays[i, 2]/dt))) if noisy else k
            self_target_index = target_index if relative_delay else k
            e[i] = q[target_index, 8]-q[self_target_index, i]
            e_dot[i] = v[target_index, 8]-v[self_target_index, i]
            if noisy:
                e[i] += noise[k, i, 0]*.001
                e_dot[i] += noise[k, i, 1]*.001
            eta[i], eta_dot[i] = pinning[i]*e[i], pinning[i]*e_dot[i]
            comm_index = max(0, k-int(round(delays[i, 0]/dt))) if noisy else k
            self_comm_index = comm_index if relative_delay else k
            for j in range(8):
                eta[i] += adjacency[i,j]*(q[comm_index,j]-q[self_comm_index,i])
                eta_dot[i] += adjacency[i,j]*(v[comm_index,j]-v[self_comm_index,i])
                if noisy and adjacency[i,j]>0:
                    index = 0 if j==(i-1)%8 else 1
                    eta[i] += edge_weight*noise[k,i,2+index]*.001
                    eta_dot[i] += edge_weight*noise[k,i,4+index]*.001
            diagonal = np.array([1-c[i,6]*np.cos(t),1-c[i,7]*np.sin(t),1-c[i,8]*np.cos(t)*np.sin(t)])
            commands[k,i] = (25*eta_dot[i]+501*eta[i]+20*pinning[i]*e_dot[i]
                              +101*pinning[i]*e[i]+integral[i])/diagonal
        integral += dt*(2535*eta+50*np.sign(eta_dot+10*eta))
        applied = np.zeros((8,3))
        for i in range(8):
            index = k-int(round(delays[i,1]/dt)) if noisy else k
            if index >= 0:
                applied[i] = commands[index,i]
        # RK4 for physical states, with sampled and delayed control held.
        qa, va = q[k].copy(), v[k].copy()
        aa = np.empty((9,3)); aa[:8] = nonlinear_acceleration(t,qa[:8],va[:8],c,applied); aa[8] = target_acceleration(qa[8],va[8])
        qb, vb = qa+.5*dt*va, va+.5*dt*aa
        ab = np.empty((9,3)); ab[:8] = nonlinear_acceleration(t+.5*dt,qb[:8],vb[:8],c,applied); ab[8] = target_acceleration(qb[8],vb[8])
        qc, vc = qa+.5*dt*vb, va+.5*dt*ab
        ac = np.empty((9,3)); ac[:8] = nonlinear_acceleration(t+.5*dt,qc[:8],vc[:8],c,applied); ac[8] = target_acceleration(qc[8],vc[8])
        qd, vd = qa+dt*vc, va+dt*ac
        ad = np.empty((9,3)); ad[:8] = nonlinear_acceleration(t+dt,qd[:8],vd[:8],c,applied); ad[8] = target_acceleration(qd[8],vd[8])
        q[k+1] = qa+dt/6*(va+2*vb+2*vc+vd)
        v[k+1] = va+dt/6*(aa+2*ab+2*ac+ad)
    return q, v, commands, integral


def main():
    destination = Path(__file__).resolve().parents[1]/"data"/"source_fixture_v2"
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for seed in range(29000,29003):
        for dt in [.001,.0005]:
            rng = np.random.default_rng(seed)
            initial = np.zeros((2,9,3)); initial[0] = rng.uniform(-10,10,(9,3)); initial[1,8] = [1.,-1.,.5]
            c = rng.uniform(-.5,.5,(8,12)); delays = rng.uniform(.001,.02,(8,3))
            noise = rng.normal(size=(round(30/dt),8,6,3))
            variants = [(False,1.,False),(True,1.,False),(True,1.,True),
                        (True,.35,False),(True,.1,False)]
            for noisy,weight,relative_delay in variants:
                q,v,u,integral = simulate(initial,c,delays,noise,dt,noisy,weight,relative_delay)
                differences = q[:,:8]-q[:,8,None,:]
                # hypot avoids overflow of squared finite large components.
                errors = np.hypot(np.hypot(differences[:,:,0],differences[:,:,1]),differences[:,:,2])
                u_norm = np.hypot(np.hypot(u[:,:,0],u[:,:,1]),u[:,:,2])
                name = f"fixture_{seed}_{int(dt*1e6)}_{int(noisy)}_{weight}_{int(relative_delay)}"
                np.savez_compressed(destination/(name+".npz"),time=np.arange(len(q))*dt,positions=q,
                    velocities=v,requested_control=u,final_integral=integral,coefficients=c,delays=delays)
                record = {"seed":seed,"dt":dt,"noise_and_delays":noisy,
                    "edge_weight":weight,"delay_on_whole_relative_signal":relative_delay,
                    "complete":bool(np.isfinite(q).all() and np.isfinite(u).all() and np.isfinite(errors).all()),
                    "initial_mean_error_m":float(errors[0].mean()),
                    "last_5s_mean_error_m":float(errors[-round(5/dt):].mean()),
                    "maximum_requested_control":float(np.max(u_norm)),
                    "last_5s_error_below_1cm":bool(np.mean(errors[-round(5/dt):])<.01)}
                record = {key:(value if not isinstance(value,float) or np.isfinite(value) else None) for key,value in record.items()}
                records.append(record)
                print(json.dumps(record),flush=True)
    (destination/"summary.json").write_text(json.dumps(records,indent=2,allow_nan=False),encoding="utf-8")


if __name__ == "__main__":
    main()
