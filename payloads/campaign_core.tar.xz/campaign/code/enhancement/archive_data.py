"""Create independent ZIP volumes and verify every stored member."""
from pathlib import Path
import argparse,csv,hashlib,json,shutil,time,zipfile


def sha_file(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def create(volume,files,reproduction):
    if volume.exists():raise FileExistsError('Preserve existing archive: '+str(volume))
    records=[]
    with zipfile.ZipFile(volume,'w',allowZip64=True) as archive:
        for source in files:
            relative=source.relative_to(reproduction).as_posix();name='Reproduction/'+relative
            item=zipfile.ZipInfo(name,date_time=(2026,9,7,0,0,0));item.create_system=0
            item.compress_type=zipfile.ZIP_STORED if source.suffix.lower()=='.npz' else zipfile.ZIP_DEFLATED
            digest=hashlib.sha256();size=0
            with source.open('rb') as src,archive.open(item,'w',force_zip64=True) as dest:
                for block in iter(lambda:src.read(1024*1024),b''):
                    dest.write(block);digest.update(block);size+=len(block)
            records.append({'path':relative,'member':name,'bytes':size,'sha256':digest.hexdigest(),'crc32':item.CRC})
    verified=0
    with zipfile.ZipFile(volume) as archive:
        if len(archive.infolist())!=len(records):raise ValueError('Unexpected member count')
        for record in records:
            item=archive.getinfo(record['member']);digest=hashlib.sha256();size=0
            with archive.open(item) as src:
                for block in iter(lambda:src.read(1024*1024),b''):digest.update(block);size+=len(block)
            if size!=record['bytes'] or digest.hexdigest()!=record['sha256'] or item.CRC!=record['crc32']:
                raise ValueError('Member integrity mismatch: '+record['member'])
            verified+=1
    return {'archive':volume.name,'path':str(volume),'bytes':volume.stat().st_size,
            'sha256':sha_file(volume),'members':len(records),'verified_members':verified,'records':records}


def main():
    p=argparse.ArgumentParser();p.add_argument('--reproduction',type=Path,required=True)
    p.add_argument('--primary-archives',type=Path,required=True);p.add_argument('--overflow-archives',type=Path,required=True)
    p.add_argument('--index',type=Path,required=True);args=p.parse_args()
    files=sorted(f for f in (args.reproduction/'data').rglob('*') if f.is_file())
    if any('__pycache__' in f.parts or f.suffix in ['.pyc','.log'] for f in files):raise ValueError('Unexpected processing files in scientific data')
    batches=[];batch=[];size=0
    for f in files:
        length=f.stat().st_size
        if batch and size+length>4_000_000_000:batches.append(batch);batch=[];size=0
        batch.append(f);size+=length
    if batch:batches.append(batch)
    for directory in [args.primary_archives,args.overflow_archives]:directory.mkdir(parents=True,exist_ok=True)
    results=[];start=time.perf_counter()
    for i,batch in enumerate(batches,1):
        directory=args.primary_archives if i<=6 else args.overflow_archives
        expected=sum(f.stat().st_size for f in batch)
        if shutil.disk_usage(directory).free<expected+5_000_000_000:raise OSError('Insufficient space for volume with 5 GB reserve')
        volume=directory/f'Reproduction_Data_{i:02d}.zip'
        result=create(volume,batch,args.reproduction);results.append(result)
        args.index.parent.mkdir(parents=True,exist_ok=True)
        args.index.write_text(json.dumps({'complete':i==len(batches),'volumes':results,'files':len(files)},indent=2),encoding='utf-8')
        print(json.dumps({'volume':i,'volumes':len(batches),'members_verified':result['verified_members'],'bytes':result['bytes'],'elapsed_s':round(time.perf_counter()-start)}),flush=True)
    with args.index.with_suffix('.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=['archive','bytes','sha256','members','verified_members','path']);writer.writeheader()
        for r in results:writer.writerow({k:r[k] for k in writer.fieldnames})


if __name__=='__main__':main()
