"""Assemble numbered final artwork without overwriting frozen figure sources."""
from pathlib import Path
import argparse, hashlib, json, re, shutil

# Working source names remain stable in the two reproducible figure pipelines.
# Publication numbers follow their order in the revised manuscript.
MAPPING=[
    ('legacy','Figure_1','Figure_1'),
    ('new','Figure_7','Figure_2'),('new','Figure_8','Figure_3'),
    ('legacy','Figure_2','Figure_4'),('legacy','Figure_3','Figure_5'),
    ('legacy','Figure_4','Figure_6'),('legacy','Figure_5','Figure_7'),
    ('legacy','Figure_6','Figure_8'),
    ('new','Figure_S5','Figure_S1'),
    ('legacy','Figure_S1','Figure_S2'),('legacy','Figure_S2','Figure_S3'),
    ('legacy','Figure_S3','Figure_S4'),('legacy','Figure_S4','Figure_S5'),
    ('new','Graphical_abstract','Graphical_abstract')]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--working-submission',type=Path,required=True)
    p.add_argument('--legacy-figures',type=Path,required=True);p.add_argument('--new-figures',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--reading',type=Path,required=True)
    p.add_argument('--manifest',type=Path,required=True);args=p.parse_args()
    if args.output.exists() and any(args.output.iterdir()):
        raise ValueError('Use a new empty submission destination; preserve existing versions')
    args.output.mkdir(parents=True,exist_ok=True);(args.output/'figures').mkdir(exist_ok=True)
    args.reading.mkdir(parents=True,exist_ok=True);records=[]
    renames={old:new for cohort,old,new in MAPPING if cohort=='legacy'}
    renames.update(Comparison_tracking='Figure_2',Comparison_interactions='Figure_3',Numerical_qualification='Figure_S1')
    for file in args.working_submission.rglob('*'):
        relative=file.relative_to(args.working_submission)
        if not file.is_file() or relative.parts[0]=='figures' or file.name=='MANIFEST.sha256.json':continue
        if file.suffix not in ['.tex','.cls','.py','.docx','.txt']:continue
        dest=args.output/relative;dest.parent.mkdir(parents=True,exist_ok=True)
        if file.suffix=='.tex':
            text=file.read_text(encoding='utf-8')
            text=re.sub(r'(\\includegraphics(?:\[[^\]]*\])?\{)([^{}]+?)(\})',
                lambda m:m.group(1)+renames.get(Path(m.group(2)).stem,Path(m.group(2)).stem)+Path(m.group(2)).suffix+m.group(3),text)
            dest.write_text(text,encoding='utf-8')
        else:shutil.copy2(file,dest)
    for cohort,source_name,published in MAPPING:
        root=args.legacy_figures if cohort=='legacy' else args.new_figures
        entries=[(source_name,published,False)]
        for panel in sorted((root/'panels').glob(source_name+'?.pdf')):
            letter=panel.stem[-1]
            if letter in 'abcdefghi':entries.append((panel.stem,published+letter,True))
        for original,target_name,is_panel in entries:
            source_dir=root/'panels' if is_panel else root
            reading_dir=args.reading/'panels' if is_panel else args.reading/'figures'
            reading_dir.mkdir(parents=True,exist_ok=True)
            for ext in ['pdf','svg','png']:
                source=source_dir/(original+'.'+ext)
                if not source.exists():raise FileNotFoundError(source)
                target=reading_dir/(target_name+'.'+ext);shutil.copy2(source,target)
                if not is_panel:
                    sub_dest=(args.output if published=='Graphical_abstract' else args.output/'figures')/(target_name+'.'+ext)
                    shutil.copy2(source,sub_dest)
                records.append({'published':target_name,'cohort':cohort,'source_figure':original,
                                'format':ext,'reading_path':target.relative_to(args.reading).as_posix(),
                                'source_sha256':sha(source),'delivery_sha256':sha(target),
                                'panel':is_panel})
    assert all(r['source_sha256']==r['delivery_sha256'] for r in records)
    args.manifest.parent.mkdir(parents=True,exist_ok=True)
    args.manifest.write_text(json.dumps({'mapping':MAPPING,'artifacts':records},indent=2),encoding='utf-8')
    print(json.dumps({'artifacts':len(records),'whole_figures':sum(not r['panel'] and r['format']=='pdf' for r in records),
                      'standalone_panels':sum(r['panel'] and r['format']=='pdf' for r in records)}))


if __name__=='__main__':main()
