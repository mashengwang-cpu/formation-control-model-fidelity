"""Check frozen design coverage and recompute endpoints from every raw trace."""
from concurrent.futures import ProcessPoolExecutor, as_completed
from collections import Counter
from pathlib import Path
import argparse, hashlib, json, time
import numpy as np
import pandas as pd
from .campaign import execution_id
from .numerical_campaign import sources


def inspect(payload):
    stage,path,protocol_hash=payload;path=Path(path)
    row=json.loads(path.read_text());trace=path.parent.parent/row['trace'];problems=[]
    if row['protocol_hash']!=protocol_hash:problems.append('protocol_hash')
    if hashlib.sha256(trace.read_bytes()).hexdigest()!=row['trace_sha256']:problems.append('trace_hash')
    arrays=np.load(trace);m=row['metrics'];j=row['job'];n=8 if j['platform']=='native' else 4
    record={'stage':stage,'job_id':row['job_id'],'platform':j['platform'],'method':j['method'],
            'model':j['model'],'candidate':j['candidate'],'complete':m['complete'],'failure':m['failure'],
            'cpu_seconds':m.get('cpu_seconds'),'wall_seconds':m.get('wall_seconds')}
    if m['complete']:
        for name in arrays.files:
            if not np.isfinite(arrays[name]).all():problems.append('nonfinite_'+name)
        t=arrays['time'];err=arrays['error_norm'];delta=np.diff(t)
        recomputed=float(np.sum(.5*(err[:-1].mean(1)+err[1:].mean(1))*delta)/j['duration'])
        fe=float(np.sum(arrays['actual_force_squared_integral']));me=float(np.sum(arrays['actual_moment_squared_integral']))
        if not np.isclose(recomputed,m['J_m'],rtol=2e-13,atol=1e-12):problems.append('J_m')
        if not np.isclose(fe,m['force_effort_N2s'],rtol=2e-13,atol=1e-10):problems.append('force_effort')
        if not np.isclose(me,m['moment_effort_N2m2s'],rtol=2e-13,atol=1e-10):problems.append('moment_effort')
        if not np.allclose(delta,j['outer_dt'],rtol=0,atol=2e-12):problems.append('outer_clock')
        expected=int(round(j['duration']/j['outer_dt']))
        if err.shape!=(expected+1,n):problems.append('error_shape')
        if m['physics_steps']!=expected*round(j['outer_dt']/j['physics_dt']):problems.append('physics_clock_count')
        if m['inner_updates']!=expected*round(j['outer_dt']/j['inner_dt']):problems.append('inner_clock_count')
        if arrays['internal_state'].shape!=(expected+1,n,18):problems.append('internal_state_history')
        state=arrays['physical_state']
        if stage=='test' and state.shape!=(expected+1,n,15):problems.append('formal_physical_history')
        if not np.allclose(np.linalg.norm(state[:,:,6:10],axis=2),1,rtol=0,atol=2e-12):problems.append('quaternion_norm')
        events=arrays['physical_events']
        if not np.array_equal(events,np.array(m['event_counts'])):problems.append('event_record')
        record.update(J_m=recomputed,force_effort_N2s=fe,moment_effort_N2m2s=me,
                      plane_crossing=bool(events[:,0].sum()),inversion=bool(events[:,1].sum()),
                      speed_domain_entry=bool(events[:,2].sum()),
                      outer_saturated_agent_seconds=float(arrays['saturation_duration'][:,:,0].sum()),
                      allocation_saturated_agent_seconds=float(arrays['saturation_duration'][:,:,1].sum()))
    record['problems']=';'.join(problems)
    return record


def main():
    p=argparse.ArgumentParser();p.add_argument('--campaign',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--workers',type=int,default=6)
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    protocol=json.loads((args.campaign/'protocol.json').read_text());assert protocol['dynamics_sources']==sources()
    payloads=[];coverage=[]
    for stage in ['train','validation','test']:
        folder=args.campaign/stage;design=json.loads((folder/'design.json').read_text())['rows']
        expected={r['job_id'] for r in design};actual={r.stem for r in (folder/'jobs').glob('*.json')}
        coverage.append({'stage':stage,'references':len(design),'expected_unique':len(expected),
                         'actual_records':len(actual),'missing':sorted(expected-actual),'extra':sorted(actual-expected),
                         'execution_ids_valid':all(execution_id(r,protocol['protocol_hash'])==r['job_id'] for r in design)})
        payloads.extend((stage,str(folder/'jobs'/(job+'.json')),protocol['protocol_hash']) for job in sorted(expected&actual))
    rows=[];start=time.perf_counter()
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(inspect,payload) for payload in payloads]
        for future in as_completed(futures):
            rows.append(future.result())
            if len(rows)%2000==0:print(json.dumps({'audited':len(rows),'total':len(payloads),'elapsed_s':round(time.perf_counter()-start)}),flush=True)
    frame=pd.DataFrame(rows).sort_values(['stage','job_id']);frame.to_csv(args.output/'raw_trace_audit.csv',index=False)
    budget=frame[frame.stage.isin(['train','validation'])].groupby(['platform','method']).agg(
        evaluations=('job_id','count'),completed=('complete','sum'),cpu_seconds=('cpu_seconds','sum'),
        recorded_wall_seconds=('wall_seconds','sum')).reset_index()
    budget.to_csv(args.output/'budget_cpu_audit.csv',index=False)
    failures=frame[~frame.complete];failures.to_csv(args.output/'all_failure_records.csv',index=False)
    test=frame[frame.stage=='test']
    test_design=json.loads((args.campaign/'test/design.json').read_text())['rows']
    design_frame=pd.DataFrame([{'job_id':r['job_id'],'strategy':r['strategy']} for r in test_design])
    diagnostic=design_frame.merge(test,on='job_id',how='left',validate='many_to_one')
    diagnostic.groupby(['platform','method','model','strategy']).agg(
        design_denominator=('job_id','count'),complete=('complete','sum'),plane_crossings=('plane_crossing','sum'),
        inversions=('inversion','sum'),speed_domain_entries=('speed_domain_entry','sum'),
        outer_saturated_agent_seconds=('outer_saturated_agent_seconds','sum'),
        allocation_saturated_agent_seconds=('allocation_saturated_agent_seconds','sum')
    ).reset_index().to_csv(args.output/'physical_diagnostics.csv',index=False)
    result={'protocol_hash':protocol['protocol_hash'],'coverage':coverage,'raw_traces':len(frame),
            'mismatched_traces':int((frame.problems!='').sum()),'failed_executions':len(failures),
            'equal_2880_budget':bool(len(budget)==8 and (budget.evaluations==2880).all()),
            'passed':all(not r['missing'] and not r['extra'] and r['execution_ids_valid'] for r in coverage)
                     and bool((frame.problems=='').all()) and bool((budget.evaluations==2880).all())}
    (args.output/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)
    if not result['passed']:raise SystemExit(1)


if __name__=='__main__':main()
