"""Resumable equal-budget development and frozen independent testing."""
import os
for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[variable] = "1"
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, replace
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter, defaultdict
import argparse, hashlib, json, shutil, time, traceback
import numpy as np
from .experiment import Job, run
from .controllers import METHODS
from .protocol import (ROOT, SEEDS, MODELS, DEVELOPMENT, TEST_TRAJECTORIES,
                       freeze, training_rows, job_for, assert_seed_isolation)
from .numerical_campaign import sources, digest


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(".writing")
    temporary.write_text(json.dumps(value,indent=2,allow_nan=False),encoding="utf-8")
    temporary.replace(path)


def execution_id(row, protocol_hash):
    physical = dict(row["job"])
    for key in ["stage","candidate"]:
        physical.pop(key,None)
    return digest({"physical":physical,"parameters":row["parameters"],"protocol":protocol_hash})[:28]


def run_one(payload):
    row, protocol_hash, folder = payload
    folder = Path(folder)
    job_id = execution_id(row,protocol_hash)
    record_path = folder/"jobs"/(job_id+".json")
    if record_path.exists():
        record = json.loads(record_path.read_text())
        if record["protocol_hash"]!=protocol_hash:
            raise RuntimeError("Existing result provenance mismatch")
        trace = folder/record["trace"]
        if hashlib.sha256(trace.read_bytes()).hexdigest()!=record["trace_sha256"]:
            raise RuntimeError("Existing raw trace changed")
        return record
    if shutil.disk_usage(folder).free < 3*1024**3:
        raise OSError("Less than 3 GiB free: pause before starting another simulation")
    job = Job(**row["job"])
    record = {"job_id":job_id,"protocol_hash":protocol_hash,"job":row["job"],
              "parameters":row["parameters"],"started_utc":datetime.now(timezone.utc).isoformat()}
    try:
        metrics, arrays = run(job,row["parameters"],detailed=job.stage=="test")
        record["metrics"] = metrics
        record["status"] = "complete" if metrics["complete"] else "failed_simulation"
    except (FloatingPointError,OverflowError,ValueError,ZeroDivisionError):
        # Programming/type errors are deliberately not converted to scientific failures.
        record["metrics"] = {"complete":False,"J_m":None,"force_effort_N2s":None,
            "failure":"numerical_exception","cpu_seconds":None,"wall_seconds":None}
        record["status"] = "failed_simulation"
        record["error"] = traceback.format_exc()
        arrays = {"failed":np.array([1],dtype=np.int8)}
    trace = folder/"traces"/(job_id+".npz")
    np.savez_compressed(trace,**arrays)
    record["trace"] = "traces/"+trace.name
    record["trace_sha256"] = hashlib.sha256(trace.read_bytes()).hexdigest()
    atomic_json(record_path,record)
    return record


def evaluate(rows,protocol,root,stage,workers):
    if sources()!=protocol["dynamics_sources"]:
        raise RuntimeError("Controller/dynamics changed after freeze")
    destination = root/stage
    for name in ["jobs","traces"]:
        (destination/name).mkdir(parents=True,exist_ok=True)
    unique = {}
    references = []
    for row in rows:
        job_id = execution_id(row,protocol["protocol_hash"])
        unique[job_id] = row
        references.append({"design_id":digest(row)[:28],"job_id":job_id,**row})
    atomic_json(destination/"design.json",{"protocol_hash":protocol["protocol_hash"],"rows":references})
    start = time.perf_counter()
    results = []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(run_one,(row,protocol["protocol_hash"],str(destination))) for row in unique.values()]
        for future in as_completed(futures):
            record = future.result(); results.append(record)
            if len(results)%192==0 or len(results)==len(unique):
                counts = Counter(r["status"] for r in results)
                message = {"stage":stage,"executed":len(results),"designed_executions":len(unique),
                    "design_references":len(references),"statuses":dict(counts),"elapsed_s":round(time.perf_counter()-start)}
                atomic_json(destination/"progress.json",message)
                print(json.dumps(message),flush=True)
    atomic_json(destination/"summary.json",{"execution_count":len(results),"reference_count":len(references),
        "statuses":dict(Counter(r["status"] for r in results)),
        "cpu_seconds":sum(r["metrics"].get("cpu_seconds") or 0. for r in results),
        "elapsed_wall_seconds":time.perf_counter()-start})
    return results


def rank_candidates(records,tolerance):
    grouped = defaultdict(list)
    for row in records:
        grouped[row["job"]["candidate"]].append(row)
    summaries = []
    for candidate,rows in grouped.items():
        complete = [r for r in rows if r["metrics"]["complete"]]
        failures = len(rows)-len(complete)
        summaries.append({"candidate":candidate,"evaluations":len(rows),"failures":failures,
            "mean_J_m":float(np.mean([r["metrics"]["J_m"] for r in complete])) if complete else None,
            "mean_force_effort_N2s":float(np.mean([r["metrics"]["force_effort_N2s"] for r in complete])) if complete else None,
            "parameters":rows[0]["parameters"]})
    remaining = sorted(summaries,key=lambda r:(r["failures"],r["mean_J_m"] if r["mean_J_m"] is not None else np.inf,r["candidate"]))
    ordered = []
    while remaining:
        best = remaining[0]
        best_j = best["mean_J_m"]
        tied = [r for r in remaining if r["failures"]==best["failures"] and
            ((best_j is None and r["mean_J_m"] is None) or (best_j is not None and r["mean_J_m"] is not None and r["mean_J_m"]<=best_j+tolerance))]
        winner = min(tied,key=lambda r:(r["mean_force_effort_N2s"] if r["mean_force_effort_N2s"] is not None else np.inf,r["candidate"]))
        ordered.append(winner); remaining.remove(winner)
    return ordered


def shortlist(training,protocol):
    output = {p:{m:{} for m in METHODS} for p in SEEDS}
    for platform in SEEDS:
        for method in METHODS:
            for model in MODELS:
                rows = [r for r in training if r["job"]["platform"]==platform and r["job"]["method"]==method and r["job"]["model"]==model]
                assert len(rows)==64*6*2
                ranked = rank_candidates(rows,protocol["selection_resolution_m"][platform][model])
                output[platform][method][model] = ranked[:8]
    return output


def validation_rows(shortlisted):
    for platform in SEEDS:
        for method in METHODS:
            for model in MODELS:
                for choice in shortlisted[platform][method][model]:
                    for seed in SEEDS[platform]["validation"]:
                        for scenario in DEVELOPMENT:
                            job = job_for(platform,model,method,seed,scenario,"validation",choice["candidate"])
                            yield {"job":asdict(job),"parameters":choice["parameters"]}


def choose(validation,protocol):
    choices = {p:{m:{} for m in METHODS} for p in SEEDS}
    for platform in SEEDS:
        for method in METHODS:
            for model in MODELS:
                rows = [r for r in validation if r["job"]["platform"]==platform and r["job"]["method"]==method and r["job"]["model"]==model]
                assert len(rows)==8*12*2
                choices[platform][method][model] = rank_candidates(rows,protocol["selection_resolution_m"][platform][model])[0]
    result = {"protocol_hash":protocol["protocol_hash"],"choices":choices}
    result["selection_hash"] = digest(result)
    return result


def testing_rows(selection):
    for platform in SEEDS:
        for seed in SEEDS[platform]["test"]:
            for scenario in TEST_TRAJECTORIES:
                for current in ([0.] if platform=="native" else [0.,.1,.2]):
                    for method in METHODS:
                        for strategy in ["transfer","retuned"]:
                            for model in MODELS:
                                choice = selection["choices"][platform][method]["point" if strategy=="transfer" else model]
                                job = job_for(platform,model,method,seed,scenario,"test",choice["candidate"],current)
                                yield {"job":asdict(job),"parameters":choice["parameters"],"strategy":strategy}
                    choice = selection["choices"][platform]["full"]["point"]
                    for method in ["no_schedule","no_powers"]:
                        for model in ["point","rigid"]:
                            job = job_for(platform,model,method,seed,scenario,"test",choice["candidate"],current)
                            yield {"job":asdict(job),"parameters":choice["parameters"],"strategy":"fixed_full_background"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage",choices=["develop","test"])
    parser.add_argument("--data-root",type=Path,default=ROOT/"data")
    parser.add_argument("--numerical-folder",type=Path)
    parser.add_argument("--selected-numerical-folder",type=Path)
    parser.add_argument("--workers",type=int,default=16)
    args = parser.parse_args()
    assert_seed_isolation()
    protocol_path = ROOT/"design"/"protocol.json"
    protocol = json.loads(protocol_path.read_text()) if protocol_path.exists() else freeze(args.numerical_folder)
    for name,expected in protocol["selection_sources"].items():
        if hashlib.sha256((ROOT/"enhancement"/name).read_bytes()).hexdigest()!=expected:
            raise RuntimeError("Selection implementation changed after freeze: "+name)
    root = args.data_root/"campaign"/protocol["protocol_hash"][:12]
    root.mkdir(parents=True,exist_ok=True)
    atomic_json(root/"protocol.json",protocol)
    if args.stage=="develop":
        trained = evaluate(list(training_rows(protocol)),protocol,root,"train",args.workers)
        short = shortlist(trained,protocol)
        atomic_json(root/"shortlist.json",short)
        validated = evaluate(list(validation_rows(short)),protocol,root,"validation",args.workers)
        selection = choose(validated,protocol)
        atomic_json(root/"selection.json",selection)
        atomic_json(ROOT/"design"/"selection.json",selection)
        frozen_test = {"selection_hash":selection["selection_hash"],"rows":list(testing_rows(selection))}
        frozen_test["design_hash"] = digest(frozen_test)
        atomic_json(root/"test_design_frozen.json",frozen_test)
        counts = Counter((r["job"]["platform"],r["job"]["method"]) for r in trained+validated)
        assert set(counts.values())=={2880}
        atomic_json(root/"budget_audit.json",{"evaluations":[{"platform":p,"method":m,"count":n} for (p,m),n in counts.items()],"equal":True})
    else:
        selection = json.loads((root/"selection.json").read_text())
        if args.selected_numerical_folder is None:
            raise ValueError("Selected parameters must undergo numerical checks before formal testing")
        numerical = json.loads((args.selected_numerical_folder/"summary.json").read_text())
        if numerical["implementation_errors"] or numerical["source_hash"]!=digest(sources()):
            raise ValueError("Selected numerical campaign is incomplete or has different sources")
        frozen = json.loads((root/"test_design_frozen.json").read_text())
        assert frozen["selection_hash"]==selection["selection_hash"]
        assert frozen["rows"]==list(testing_rows(selection))
        evaluate(frozen["rows"],protocol,root,"test",args.workers)


if __name__ == "__main__":
    main()
