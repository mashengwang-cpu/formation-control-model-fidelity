"""Independent adaptive time integration of the held-input physical system.

SciPy DOP853 is restarted at every inner control boundary. Outer controller
states are updated only on their own clock. Force and moment effort are
additional ODE states; no trapezoidal approximation of requested force is used.
The RHS is shared to test integration, not to claim independent physics; the
Otter backend itself supplies the independent physical model.
"""
import time
import numpy as np
from scipy.integrate import solve_ivp
from .experiment import prepare
from .controllers import DEFAULT, METHOD_INDEX, periodic_control
from .physics import world_observation, inner_commands, rhs, rotation


def run_reference(job, parameters=None, rtol=1e-9, atol=1e-11):
    parameters = DEFAULT.copy() if parameters is None else np.asarray(parameters, dtype=float)
    (state, times, lp, lv, offsets, masses, boat, adjacency, pinning, gplus,
     platform, model, phase, length_scale, time_scale, force_scale) = prepare(job)
    n, samples = len(state), len(times)
    weights, filt, integral = np.zeros((n, 7, 2)), np.zeros((n, 2)), np.zeros((n, 2))
    errors = np.full((samples, n), np.nan)
    states = np.full((samples, n, 15), np.nan)
    effort = np.full((samples-1, n), np.nan)
    moments = np.full_like(effort, np.nan)
    sat = np.zeros((samples-1, n, 2))
    flags = np.zeros((n, 3), bool)
    events = np.zeros((n, 3), int)
    failure = "none"
    nfev = 0
    cpu_start = time.process_time()
    for k, t in enumerate(times):
        position, velocity = world_observation(state, platform, model)
        errors[k] = np.linalg.norm(position-lp[k]-offsets, axis=1)
        states[k] = state
        if k == samples-1:
            break
        raw = periodic_control(METHOD_INDEX[job.method], parameters, t/time_scale,
            job.outer_dt/time_scale, (position-offsets)/length_scale,
            velocity*time_scale/length_scale, lp[k]/length_scale,
            lv[k]*time_scale/length_scale, adjacency, pinning, gplus, weights, filt, integral)*force_scale
        if not np.all(np.isfinite(raw)):
            failure = "nonfinite_controller"
            break
        norms = np.linalg.norm(raw, axis=1)
        command = raw*np.minimum(1., 8.*force_scale/np.maximum(norms, 1e-30))[:, None]
        sat[k, :, 0] = (norms>8.*force_scale)*job.outer_dt
        total = np.zeros((n, 2))
        for sub in range(round(job.outer_dt/job.inner_dt)):
            start = t+sub*job.inner_dt
            stop = t+(sub+1)*job.inner_dt
            held, saturated = inner_commands(state, command, platform, model, masses, boat, job.response_scale)
            sat[k, :, 1] += saturated*job.inner_dt
            def ode(clock, augmented):
                physical = augmented[:n*15].reshape(n, 15)
                derivative, force, torque = rhs(physical, held, clock, platform, model,
                    masses, boat, phase, job.disturbance_scale)
                densities = np.column_stack([np.sum(force*force, axis=1), np.sum(torque*torque, axis=1)])
                return np.concatenate([derivative.ravel(), densities.ravel()])
            initial = np.concatenate([state.ravel(), np.zeros(n*2)])
            solution = solve_ivp(ode, (start, stop), initial, method="DOP853", rtol=rtol, atol=atol)
            nfev += solution.nfev
            if not solution.success or not np.all(np.isfinite(solution.y[:, -1])):
                failure = "reference_integrator_failure"
                break
            state = solution.y[:n*15, -1].reshape(n, 15)
            state[:, 6:10] /= np.linalg.norm(state[:, 6:10], axis=1)[:, None]
            total += solution.y[n*15:, -1].reshape(n, 2)
            if model == 2:
                for i in range(n):
                    now = np.array([platform==0 and i<4 and state[i, 2]<0.,
                        rotation(state[i, 6:10])[2, 2]<0.,
                        np.linalg.norm(state[i, 3:6])>(20. if platform==0 else 6*.5144)])
                    events[i] += (now & ~flags[i])
                    flags[i] = now
        if failure != "none":
            break
        effort[k], moments[k] = total[:, 0], total[:, 1]
    complete = failure=="none" and np.isfinite(errors).all()
    metrics = {"complete": bool(complete), "failure": failure,
        "J_m": float(np.trapezoid(errors.mean(axis=1), times)/job.duration) if complete else None,
        "force_effort_N2s": float(effort.sum()) if complete else None,
        "moment_effort_N2m2s": float(moments.sum()) if complete else None,
        "cpu_seconds": time.process_time()-cpu_start, "nfev": nfev,
        "rtol": rtol, "atol": atol, "event_counts": events.tolist()}
    return metrics, {"time": times, "error_norm": errors, "physical_state": states,
        "actual_force_squared_integral": effort, "actual_moment_squared_integral": moments,
        "saturation_duration": sat, "physical_events": events}


def compare(fixed_metrics, fixed_arrays, reference_metrics, reference_arrays):
    if not fixed_metrics["complete"] or not reference_metrics["complete"]:
        return {"pass": False, "status": "incomplete", "J_bound_m": None}
    j_ref = reference_metrics["J_m"]
    j_difference = abs(fixed_metrics["J_m"]-j_ref)
    tolerance = max(.002, .01*abs(j_ref))
    effort_ref = reference_metrics["force_effort_N2s"]
    effort_relative = abs(fixed_metrics["force_effort_N2s"]-effort_ref)/max(abs(effort_ref), 1e-12)
    delta = fixed_arrays["physical_state"]-reference_arrays["physical_state"]
    position_max = float(np.max(np.linalg.norm(delta[:, :, :3], axis=2)))
    velocity_max = float(np.max(np.linalg.norm(delta[:, :, 3:6], axis=2)))
    quaternions_fixed = fixed_arrays["physical_state"][:, :, 6:10]
    quaternions_ref = reference_arrays["physical_state"][:, :, 6:10]
    inner_product = np.clip(abs(np.sum(quaternions_fixed*quaternions_ref, axis=2)), 0., 1.)
    attitude_max = float(np.max(2*np.arccos(inner_product)))
    saturation_max = float(np.max(abs(fixed_arrays["saturation_duration"].sum(0)-reference_arrays["saturation_duration"].sum(0))))
    same_events = bool(np.array_equal(fixed_arrays["physical_events"], reference_arrays["physical_events"]))
    # State errors and boundary classifications are material even when the mean
    # tracking metric appears converged. Explicit tolerances are frozen here.
    passed = (j_difference<=tolerance and effort_relative<=.02 and same_events
              and position_max<=5*tolerance and velocity_max<=.02
              and attitude_max<=.02 and saturation_max<=.04)
    return {"pass": bool(passed), "status": "resolved" if passed else "unresolved",
        "J_difference_m": j_difference, "J_tolerance_m": tolerance, "J_bound_m": j_difference,
        "force_effort_relative_difference": effort_relative, "position_max_m": position_max,
        "velocity_max_mps": velocity_max, "attitude_max_rad": attitude_max,
        "saturation_duration_max_s": saturation_max, "event_counts_equal": same_events}
