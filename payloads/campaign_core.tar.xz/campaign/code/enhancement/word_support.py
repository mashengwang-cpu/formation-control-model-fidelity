"""Synchronize editable submission attachments with the compiled manuscript."""
from pathlib import Path
import argparse, json, re
from datetime import date
from docx import Document
from docx.shared import Inches, Pt, RGBColor


def group(text,start):
    if text[start]!='{':raise ValueError('Expected braced group')
    depth=1;i=start+1
    while i<len(text):
        if text[i]=='\\':i+=2;continue
        if text[i]=='{':depth+=1
        elif text[i]=='}':
            depth-=1
            if depth==0:return text[start+1:i],i+1
        i+=1
    raise ValueError('Unbalanced LaTeX group')


def expand(path):
    text=path.read_text(encoding='utf-8')
    return re.sub(r'\\input\{([^}]+)\}',lambda m:expand(path.parent/(m[1] if Path(m[1]).suffix else m[1]+'.tex')),text)


def labels(folder):
    result={}
    for prefix,name in [('', 'Manuscript'),('Supp-','Supplementary')]:
        text=(folder/(name+'.aux')).read_text(encoding='utf-8')
        for key,value in re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}',text):
            result[prefix+key]=value
            if name=='Manuscript':result['Main-'+key]=value
    return result


def plain(text,refs):
    text=re.sub(r'(?<!\\)%[^\n]*','',text)
    text=re.sub(r'\\(?:eqref|ref)\{([^}]+)\}',lambda m:refs[m[1]],text)
    text=re.sub(r'\\(?:text|mathrm|textrm|textbf|emph|operatorname|mathit|mathbf)\{([^{}]*)\}',r'\1',text)
    text=re.sub(r'\^\{2\}|\^2','²',text)
    text=re.sub(r'\^\{([^}]+)\}',r'^(\1)',text)
    text=re.sub(r'_\{([^}]+)\}',r'_(\1)',text)
    replacements={'^\\circ':'°','\\circ':'°','\\gamma':'γ','\\Delta':'Δ','\\delta':'δ','\\mu':'μ','\\rho':'ρ','\\phi':'φ',
      '\\alpha':'α','\\beta':'β','\\sigma':'σ','\\eta':'η','\\theta':'θ','\\lambda':'λ',
      '\\times':'×','\\pm':'±','\\leq':'≤','\\geq':'≥','\\neq':'≠','\\infty':'∞',
      '\\%':'%','\\&':'&','\\_':'_','\\,':' ','\\;':' ','\\!':'','\\ ':' ',
      '\\rm':'','\\max':'max','\\left':'','\\right':'','\\ge':'≥','\\le':'≤','\\textendash':'–'}
    for a,b in replacements.items():text=text.replace(a,b)
    text=text.replace('$','').replace('{','').replace('}','').replace('~',' ')
    text=text.replace('---','—').replace('--','–').replace('``','“').replace("''",'”')
    text=re.sub(r'\s+',' ',text).strip()
    if '\\' in text:raise ValueError('Unconverted LaTeX in attachment: '+text)
    return text


def document(title=None):
    d=Document();s=d.sections[0]
    s.page_width=Inches(8.27);s.page_height=Inches(11.69)
    s.top_margin=s.bottom_margin=Inches(.82);s.left_margin=s.right_margin=Inches(.9)
    normal=d.styles['Normal'];normal.font.name='Arial';normal.font.size=Pt(11)
    normal.font.color.rgb=RGBColor.from_string('283641')
    normal.paragraph_format.space_after=Pt(8);normal.paragraph_format.line_spacing=1.12
    for name in ['Heading 1','Heading 2']:
        d.styles[name].font.name='Arial';d.styles[name].font.color.rgb=RGBColor.from_string('283641')
    d.core_properties.author='Fuliang Ma; Yuzhen Dang; Yuping Ma; Ying Jiang; Hongbin Ma'
    d.core_properties.last_modified_by='';d.core_properties.comments=''
    if title:d.add_heading(title,level=1);d.core_properties.title=title
    return d


def caption_paragraph(document,text):
    paragraph=document.add_paragraph()
    for part in re.split(r'(_\([^)]*\)|_[A-Za-z0-9]|\^\([^)]*\)|\^[A-Za-z0-9])',text):
        if part.startswith(('_','^')) and len(part)>1:
            run=paragraph.add_run(part[2:-1].strip() if part[1]=='(' else part[1:])
            run.font.subscript=part[0]=='_';run.font.superscript=part[0]=='^'
        else:paragraph.add_run(part)
    return paragraph


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--submission',type=Path,required=True)
    parser.add_argument('--build',type=Path,required=True);parser.add_argument('--narrative',type=Path,required=True)
    args=parser.parse_args();refs=labels(args.build);rows=[]
    for name,prefix in [('Manuscript',''),('Supplementary','S')]:
        text=expand(args.submission/(name+'.tex'));number=0
        for match in re.finditer(r'\\begin\{figure\*?\}',text):
            end=text.index('\\end{figure',match.end());segment=text[match.end():end]
            cap=re.search(r'\\caption\s*\{',segment)
            if cap:
                number+=1;body,_=group(segment,cap.end()-1)
                rows.append({'label':'Figure '+prefix+str(number),'caption':plain(body,refs)})
    captions=document('Figure captions')
    for row in rows:
        captions.add_heading(row['label'],level=2);caption_paragraph(captions,row['caption'])
    captions.save(args.submission/'Figure_captions.docx')
    narrative=json.loads(args.narrative.read_text(encoding='utf-8'))
    highlights=document('Highlights')
    for line in narrative['highlights']:
        if len(line)>85:raise ValueError('Highlight exceeds 85 characters: '+line)
        highlights.add_paragraph(line,style='List Bullet')
    highlights.save(args.submission/'Highlights.docx')
    letter=document();letter.core_properties.title='Cover letter'
    for paragraph in narrative['cover_letter']:letter.add_paragraph(paragraph)
    letter.save(args.submission/'Cover_Letter.docx')
    (args.build/'attachment_sync.json').write_text(json.dumps({'captions':rows,'highlight_lengths':[len(x) for x in narrative['highlights']]},indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({'captions':len(rows),'highlights':len(narrative['highlights'])}))


if __name__=='__main__':main()
