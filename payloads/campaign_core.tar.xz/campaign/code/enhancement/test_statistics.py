import numpy as np
from .analysis import simultaneous_intervals, primary_contrasts, seed_blocks
import pandas as pd


def test_missing_family_is_withheld():
    matrix = np.ones((50,12)); matrix[3,7]=np.nan
    assert simultaneous_intervals(matrix)["status"]=="withheld_incomplete_family"


def test_simultaneous_intervals_translation_and_resample_reproducibility():
    matrix = np.random.default_rng(98).normal(size=(50,12))
    result = simultaneous_intervals(matrix,resamples=2000)
    shifted = simultaneous_intervals(matrix+3.,resamples=2000)
    np.testing.assert_allclose(np.array(result["lower"])+3,shifted["lower"],atol=1e-12)
    np.testing.assert_allclose(np.array(result["upper"])+3,shifted["upper"],atol=1e-12)
    assert result==simultaneous_intervals(matrix,resamples=2000)
    assert result["critical_value"]>1.96


def test_constant_contrast_is_flaggable_as_zero_sampling_variance():
    result = simultaneous_intervals(np.zeros((50,12)),resamples=100)
    assert result["status"]=="evaluated"
    assert result["standard_error"]==[0.]*12


def test_missing_scenario_is_not_replaced_by_duplicate_or_finite_subset():
    rows=[dict(platform='native',method='full',strategy='transfer',model='rigid',seed=40000,
               parameter_hash='x',trajectory=trajectory,current=0.,complete=True,J_m=j,force_effort_N2s=1.)
          for j,trajectory in enumerate(['ellipse','double_sine','speed_line'],1)]
    assert seed_blocks(pd.DataFrame(rows)).iloc[0].J_m==2.
    rows[-1]['trajectory']='ellipse'
    assert not seed_blocks(pd.DataFrame(rows)).iloc[0].complete
    rows[-1]['trajectory']='speed_line';rows[-1]['J_m']=np.inf
    assert not seed_blocks(pd.DataFrame(rows)).iloc[0].complete


def test_primary_interaction_uses_paired_differences_with_declared_orientation():
    rows=[]
    for platform,seed_start in [('native',40000),('otter',50000)]:
        for seed in range(seed_start,seed_start+50):
            for method in ['full','minimal','family','no_schedule','no_powers']:
                strategies=['fixed_full_background'] if method.startswith('no_') else ['transfer','retuned']
                for strategy in strategies:
                    for model in ['point','rigid']:
                        j=seed*0.001+{'full':2.,'minimal':1.,'family':3.,'no_schedule':4.,'no_powers':5.}[method]*(1 if model=='point' else 2)
                        rows.append(dict(platform=platform,method=method,strategy=strategy,model=model,
                                         seed=seed,J_m=j,complete=True))
    matrix,definitions=primary_contrasts(pd.DataFrame(rows))
    np.testing.assert_allclose(matrix,np.tile([1.,-1.,1.,-1.,2.,3.]*2,(50,1)),atol=1e-12)
