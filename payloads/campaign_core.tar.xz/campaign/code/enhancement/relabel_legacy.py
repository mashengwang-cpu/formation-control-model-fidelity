"""Update publication cross-references while preserving the legacy data pipeline."""
from pathlib import Path
import argparse,hashlib,json,sys


def main():
    p=argparse.ArgumentParser();p.add_argument('--legacy-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    sys.path.insert(0,str((args.legacy_root/'tools').resolve()))
    import publication_figures as figures
    import publication_panels as panels
    original_panel=figures.panel;original_contract=panels.panel_contract
    def relabeled_panel(ax,letter,title='',subtitle=None):
        if subtitle:subtitle=subtitle.replace('Fig. S4','Fig. S5')
        return original_panel(ax,letter,title,subtitle)
    def relabeled_contract(name,index):
        result=original_contract(name,index)
        result['notes']=[line.replace('Figure S4','Figure S5') for line in result['notes']]
        return result
    figures.panel=relabeled_panel;panels.panel_contract=relabeled_contract
    sys.argv=['publication_figures.py','--only','Figure_4','--output',str(args.output)]
    figures.main()
    old=args.legacy_root/'figures/Figure_4.plot_data.json'
    new=args.output/'Figure_4.plot_data.json'
    before=json.loads(old.read_text(encoding='utf-8'));after=json.loads(new.read_text(encoding='utf-8'))
    parity=before['axes']==after['axes'] and before['sources']==after['sources']
    record={'adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'change':'Displayed supplementary stress-figure reference S4 to S5 in whole Figure 4 and its reading panel b.',
            'data_and_axis_contract_equal':parity,'legacy_files_edited':False,
            'source_figure':'Figure_4','published_figure':'Figure_6'}
    (args.output/'PUBLICATION_LABEL_PROVENANCE.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    if not parity:raise ValueError('Publication relabeling changed the frozen data or axis contract')
    print(json.dumps(record))


if __name__=='__main__':main()
