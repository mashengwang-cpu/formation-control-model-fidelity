"""Steady-state controller timing, separate from the simulation evaluation budget."""
from pathlib import Path
import argparse, json, platform, time
import numpy as np
from numba import njit
from .controllers import periodic_control, METHOD_INDEX
from .experiment import Job, prepare


@njit(cache=True)
def batch(method, parameters, q, velocity, leader, leader_v, graph, pinning, gplus, dt, count):
    n=len(q);weights=np.zeros((n,7,2));filt=np.zeros((n,2));integral=np.zeros((n,2))
    checksum=0.
    for k in range(count):
        # A repeated input contract isolates the controller's update cost. Each
        # call starts from the same nonzero internal state, so no simulated
        # trajectory or unstable accumulation enters this timing experiment.
        weights[:]=.01;filt[:]=.02;integral[:]=.03
        force=periodic_control(method,parameters,1.,dt,q,velocity,leader,leader_v,
                               graph,pinning,gplus,weights,filt,integral)
        checksum+=force[0,0]
    return checksum


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--selection',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    selection=json.loads(args.selection.read_text());rows=[]
    updates_per_batch=50000;batch_count=20
    for system,methods in selection['choices'].items():
        data=prepare(Job(platform=system,stage='benchmark',seed=58000,
                         outer_dt=.02 if system=='native' else .05,
                         inner_dt=.00125 if system=='native' else .01,
                         physics_dt=.00125 if system=='native' else .0025))
        state,times,lp,lv,offsets,masses,boat,graph,pin,gplus,_,_,_,length,clock,force=data
        q=(state[:,:2]-offsets)/length;velocity=state[:,3:5]*clock/length
        for method,models in methods.items():
            for model,choice in models.items():
                inputs=(METHOD_INDEX[method],np.array(choice['parameters']),q,velocity,
                        lp[0]/length,lv[0]*clock/length,graph,pin,gplus,(times[1]-times[0])/clock,updates_per_batch)
                batch(*inputs)
                observations=[];elapsed_batches=[]
                for repeat in range(batch_count):
                    start=time.thread_time_ns();checksum=batch(*inputs)
                    elapsed=time.thread_time_ns()-start
                    elapsed_batches.append(elapsed)
                    observations.append(elapsed/1000/updates_per_batch)
                rows.append({'platform':system,'method':method,'selected_model':model,
                             'candidate':choice['candidate'],'fleet_size':len(q),
                             'microseconds_per_fleet_update':observations,
                             'batch_cpu_ns':elapsed_batches,
                             'pooled_mean_us':float(sum(elapsed_batches)/1000/(batch_count*updates_per_batch)),
                             'median_us':float(np.median(observations)),
                             'p95_us':float(np.quantile(observations,.95)),
                             'finite_checksum':bool(np.isfinite(checksum))})
    result={'selection_hash':selection['selection_hash'],'python':platform.python_version(),
            'processor':platform.processor(),'batches':batch_count,'updates_per_batch':updates_per_batch,
            'clock':'thread_time_ns; excludes JIT warm-up',
            'timing_note':'Long batches reduce the effect of coarse Windows thread CPU ticks; batch quantization and concurrent resource contention remain possible.',
            'scope':'CPU time for a repeated fleet controller call and state reset; excludes plant integration, communication and hardware scheduling',
            'results':rows}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'timing_conditions':len(rows),'finite':all(r['finite_checksum'] for r in rows)}))


if __name__=='__main__':main()
