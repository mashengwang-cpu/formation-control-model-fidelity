"""Run numerical resolution checks in a cohort isolated from parameter tuning."""
import os
for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[variable] = "1"
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, replace
from pathlib import Path
import argparse, hashlib, json, time, traceback
import numpy as np
from .experiment import Job, run
from .reference import run_reference, compare
from .controllers import DEFAULT

ROOT = Path(__file__).resolve().parents[1]


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def sources():
    names = ["controllers.py", "physics.py", "experiment.py", "otter_kernel.py",
             "otter_adapter.py", "reference.py"]
    return {name:hashlib.sha256((ROOT/"enhancement"/name).read_bytes()).hexdigest() for name in names}


def run_case(payload):
    job_dict, parameters, folder, source_hash, tight = payload
    job = Job(**job_dict)
    key = digest({"job":job_dict,"parameters":parameters,"source":source_hash})[:24]
    destination = Path(folder)
    record_path = destination/(key+".json")
    if record_path.exists():
        return json.loads(record_path.read_text())
    record = {"case_id":key,"job":job_dict,"parameters":parameters,"source_hash":source_hash}
    try:
        reference_metrics, reference_arrays = run_reference(job,parameters)
        np.savez_compressed(destination/(key+"_reference.npz"),**reference_arrays)
        record["reference"] = reference_metrics
        steps = [.00125,.000625,.0003125] if job.platform=="native" else [.01,.005,.0025,.00125]
        comparisons = []
        for h in steps:
            fixed_job = replace(job,physics_dt=h)
            metrics, arrays = run(fixed_job,parameters,detailed=True)
            np.savez_compressed(destination/(key+f"_h{h:.8f}.npz"),**arrays)
            comparisons.append({"physics_dt":h,"metrics":metrics,
                                **compare(metrics,arrays,reference_metrics,reference_arrays)})
        if job.platform=="native" and not comparisons[-1]["pass"]:
            h = .00015625
            metrics, arrays = run(replace(job,physics_dt=h),parameters,detailed=True)
            np.savez_compressed(destination/(key+f"_h{h:.8f}.npz"),**arrays)
            comparisons.append({"physics_dt":h,"metrics":metrics,
                                **compare(metrics,arrays,reference_metrics,reference_arrays)})
        record["comparisons"] = comparisons
        if tight:
            metrics, arrays = run_reference(job,parameters,rtol=1e-11,atol=1e-13)
            record["tight_reference"] = {"metrics":metrics,
                                         **compare(reference_metrics,reference_arrays,metrics,arrays)}
            np.savez_compressed(destination/(key+"_tight_reference.npz"),**arrays)
        record["status"] = "evaluated"
    except Exception:
        record["status"] = "implementation_error"
        record["traceback"] = traceback.format_exc()
    record_path.write_text(json.dumps(record,indent=2,allow_nan=False),encoding="utf-8")
    return record


def default_cases():
    native = ["minimal","family","full","rise","no_schedule","no_powers",
              "no_approximation","no_filter","no_faultcomp","no_topology","ppt_on"]
    for seed in [39000,39001]:
        for method in native:
            for model in ["point","lag","rigid"]:
                for scale in [.5,1.]:
                    yield Job(method=method,model=model,seed=seed,response_scale=scale), DEFAULT.tolist()
    for seed in [39100,39101]:
        for method in ["minimal","family","full","rise"]:
            for model in ["point","lag","rigid"]:
                yield Job(platform="otter",method=method,model=model,seed=seed,
                          outer_dt=.05,inner_dt=.01,physics_dt=.0025,duration=60.,current=.03), DEFAULT.tolist()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers",type=int,default=12)
    parser.add_argument("--selection",type=Path)
    parser.add_argument("--limit",type=int)
    parser.add_argument("--data-root",type=Path,default=ROOT/"data")
    args = parser.parse_args()
    source = sources()
    source_hash = digest(source)
    name = "selected" if args.selection else "defaults"
    destination = args.data_root/"numerical"/(name+"_"+source_hash[:12])
    destination.mkdir(parents=True,exist_ok=True)
    if args.selection:
        selected = json.loads(args.selection.read_text())
        cases = []
        for platform, platform_choices in selected["choices"].items():
            for method, choices in platform_choices.items():
                for model in ["point","lag","rigid"]:
                    for strategy in ["transfer","retuned"]:
                        choice = choices["point" if strategy=="transfer" else model]
                        for seed in ([39002,39003] if platform=="native" else [39102,39103]):
                            for trajectory in ["ellipse","double_sine","speed_line"]:
                                for current in ([0.] if platform=="native" else [0.,.1,.2]):
                                    job = Job(platform=platform,method=method,model=model,seed=seed,
                                        trajectory=trajectory,outer_dt=.02 if platform=="native" else .05,
                                        inner_dt=.00125 if platform=="native" else .01,
                                        physics_dt=.00125 if platform=="native" else .0025,
                                        duration=16. if platform=="native" else 60.,current=current)
                                    cases.append((job,choice["parameters"]))
            for method in ["no_schedule","no_powers"]:
                choice = platform_choices["full"]["point"]
                for model in ["point","rigid"]:
                    for seed in ([39002,39003] if platform=="native" else [39102,39103]):
                        for trajectory in ["ellipse","double_sine","speed_line"]:
                            for current in ([0.] if platform=="native" else [0.,.1,.2]):
                                job = Job(platform=platform,method=method,model=model,seed=seed,trajectory=trajectory,
                                    outer_dt=.02 if platform=="native" else .05,inner_dt=.00125 if platform=="native" else .01,
                                    physics_dt=.00125 if platform=="native" else .0025,duration=16. if platform=="native" else 60.,current=current)
                                cases.append((job,choice["parameters"]))
        # Shared point/retuned choices are one physical execution, not replicates.
        cases = list({digest({"job":asdict(j),"p":p}):(j,p) for j,p in cases}.values())
    else:
        cases = list(default_cases())
    if args.limit:
        cases = cases[:args.limit]
    design = {"source":source,"source_hash":source_hash,
              "cases":[{"job":asdict(j),"parameters":p} for j,p in cases]}
    (destination/"design.json").write_text(json.dumps(design,indent=2),encoding="utf-8")
    payloads = [(asdict(j),p,str(destination),source_hash,
                 j.method=="minimal" and j.seed in [39000,39100] and j.response_scale==1.) for j,p in cases]
    started = time.perf_counter()
    records = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(run_case,payload) for payload in payloads]
        for future in as_completed(futures):
            record = future.result(); records.append(record)
            if len(records)%6==0 or record["status"]!="evaluated":
                print(json.dumps({"completed":len(records),"designed":len(cases),
                    "last_status":record["status"],"elapsed_s":round(time.perf_counter()-started)}),flush=True)
    good = [r for r in records if r["status"]=="evaluated"]
    summary = {"cases":len(cases),"evaluated":len(good),
        "implementation_errors":len(records)-len(good),
        "unresolved_finest":[r["case_id"] for r in good if not r["comparisons"][-1]["pass"]],
        "source_hash":source_hash,"folder":str(destination)}
    (destination/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps(summary),flush=True)


if __name__ == "__main__":
    main()
