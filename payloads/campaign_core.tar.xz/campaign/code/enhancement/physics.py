"""Physical differential equations and held inner-loop commands.

State columns: inertial position (0:3), velocity (3:6: world for UAV/ideal,
body for vessels), quaternion wxyz (6:10), angular velocity (10:13),
lagged force or two propeller revolutions (13:15).
Inner controllers run outside the integrators. RK stages never call them.
"""
import math
import numpy as np
from numba import njit
from .otter_kernel import dynamics as otter_euler, Rzyx


@njit(cache=True)
def wrap(angle):
    return (angle + np.pi) % (2*np.pi) - np.pi


@njit(cache=True)
def rotation(q):
    q = q / np.sqrt(np.sum(q*q))
    w, x, y, z = q
    return np.array([[1.-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                     [2*(x*y+z*w), 1.-2*(x*x+z*z), 2*(y*z-x*w)],
                     [2*(x*z-y*w), 2*(y*z+x*w), 1.-2*(x*x+y*y)]])


@njit(cache=True)
def euler_angles(q):
    r = rotation(q)
    return np.array([np.arctan2(r[2, 1], r[2, 2]),
                     np.arcsin(min(1., max(-1., -r[2, 0]))),
                     np.arctan2(r[1, 0], r[0, 0])])


@njit(cache=True)
def quaternion_rate(q, omega):
    w, x, y, z = q
    a, b, c = omega
    return .5 * np.array([-x*a-y*b-z*c, w*a+y*c-z*b,
                           w*b+z*a-x*c, w*c+x*b-y*a])


@njit(cache=True)
def world_observation(state, platform, model):
    n = len(state)
    p = state[:, :2].copy()
    v = state[:, 3:5].copy()
    if model == 2:
        for i in range(n):
            if platform == 1 or i >= 4:
                v[i] = (rotation(state[i, 6:10]) @ state[i, 3:6])[:2]
    return p, v


@njit(cache=True)
def disturbance(t, n, phase, amplitude=1.):
    result = np.zeros((n, 2))
    for i in range(n):
        result[i, 0] = amplitude * .035 * np.sin(.7*t + .31*(i+1) + phase)
        result[i, 1] = amplitude * .030 * np.cos(.5*t + .17*(i+1) + .5*phase)
    return result


@njit(cache=True)
def inner_commands(state, command, platform, model, masses, boat, response_scale):
    """Deployment interface: compute once at an inner-clock boundary.

    Native allocation is the original mixer/yaw PD. Otter uses world-force
    projection, a stated yaw PD, then the upstream signed-square allocation.
    The Otter PD (wn=.8, zeta=1) is common and is not tuned by outer method.
    """
    held = np.zeros((len(state), 4))
    saturation = np.zeros(len(state))
    if model != 2:
        held[:, :2] = command
        return held, saturation
    for i in range(len(state)):
        r = rotation(state[i, 6:10])
        heading = np.arctan2(r[1, 0], r[0, 0])
        if platform == 1:
            surge = np.cos(heading)*command[i, 0] + np.sin(heading)*command[i, 1]
            target = np.arctan2(command[i, 1], command[i, 0])
            inertia = 1. / boat.Minv[5, 5]
            tau = inertia * (.8**2 * wrap(target-heading) - 2*.8*state[i, 12])
            # Identical allocation to upstream controlAllocation, followed by
            # explicit physical command saturation (actual thrust is upstream).
            left = (surge + tau/(-boat.l1)) / (2*boat.k_pos)
            right = (surge - tau/(-boat.l1)) / (2*boat.k_pos)
            rpm = np.array([np.sign(left)*np.sqrt(abs(left)),
                            np.sign(right)*np.sqrt(abs(right))])
            for k in range(2):
                held[i, k] = min(boat.n_max, max(boat.n_min, rpm[k]))
                if held[i, k] != rpm[k]:
                    saturation[i] = 1.
        elif i >= 4:
            surge = np.cos(heading)*command[i, 0] + np.sin(heading)*command[i, 1]
            target = np.arctan2(command[i, 1], command[i, 0])
            moment = 2.4*wrap(target-heading) - 1.1*state[i, 12]
            held[i, 0] = min(8., max(-8., surge))
            held[i, 1] = min(1.6, max(-1.6, moment))
            saturation[i] = 1. if abs(surge)>8. or abs(moment)>1.6 else 0.
        else:
            mass = masses[i]
            axy = command[i]/mass
            az = 16.*(1.5-state[i, 2])-8.*state[i, 5]
            cap = np.tan(.7)*max(az+9.81, .4)
            norm = np.sqrt(np.sum(axy*axy))
            if norm > cap:
                axy = axy * cap/norm
                saturation[i] = 1.
            desired_force = mass*np.array([axy[0], axy[1], az+9.81])
            f_norm = np.sqrt(np.sum(desired_force**2))
            thrust = min(2.4*mass*9.81, max(.18*mass*9.81, f_norm))
            if f_norm < 1e-12:
                desired_force = np.array([0., 0., mass*9.81])
                f_norm = mass*9.81
            b3 = desired_force/f_norm
            b1c = np.array([1., 0., 0.])
            b2 = np.cross(b3, b1c)
            b2 = b2/np.sqrt(np.sum(b2*b2))
            b1 = np.cross(b2, b3)
            rd = np.empty((3, 3))
            rd[:, 0], rd[:, 1], rd[:, 2] = b1, b2, b3
            delta = .5*(rd.T@r-r.T@rd)
            er = np.array([delta[2, 1], delta[0, 2], delta[1, 0]])
            omega = state[i, 10:13]
            inertia = mass*np.array([.010, .010, .018])
            torque = -8.*response_scale**2*er - 1.25*response_scale*omega + np.cross(omega, inertia*omega)
            rotor = np.array([
                .25*(thrust-torque[0]/.18-torque[1]/.18-torque[2]/.016),
                .25*(thrust+torque[0]/.18-torque[1]/.18+torque[2]/.016),
                .25*(thrust+torque[0]/.18+torque[1]/.18-torque[2]/.016),
                .25*(thrust-torque[0]/.18+torque[1]/.18+torque[2]/.016)])
            maximum = 2.4*mass*9.81/4
            for k in range(4):
                value = min(maximum, max(0., rotor[k]))
                if value != rotor[k]:
                    saturation[i] = 1.
                rotor[k] = value
            held[i, 0] = np.sum(rotor)
            held[i, 1] = .18*(-rotor[0]+rotor[1]+rotor[2]-rotor[3])
            held[i, 2] = .18*(-rotor[0]-rotor[1]+rotor[2]+rotor[3])
            held[i, 3] = .016*(-rotor[0]+rotor[1]-rotor[2]+rotor[3])
    return held, saturation


@njit(cache=True)
def rhs(state, held, t, platform, model, masses, boat, phase, disturbance_scale):
    n = len(state)
    dy = np.zeros_like(state)
    forces = np.zeros((n, 2))
    torques = np.zeros((n, 3))
    d = disturbance(t, n, phase, disturbance_scale)
    for i in range(n):
        y = state[i]
        mass = masses[i]
        if model < 2:
            actual = held[i, :2] if model == 0 else y[13:15]
            if platform == 1:
                relative = y[3:5] - boat.V_c*np.array([np.cos(boat.beta_c), np.sin(boat.beta_c)])
                drag = boat.D[0, 0]*relative
                lag = boat.T_n
            else:
                linear = .24 if i < 4 else .36
                quadratic = .012 if i < 4 else .065
                drag = (linear+quadratic*np.sqrt(np.sum(y[3:5]**2)))*y[3:5]
                lag = .08 if i < 4 else .24
            dy[i, :2] = y[3:5]
            dy[i, 3:5] = (actual+d[i]-drag)/mass
            if model == 1:
                dy[i, 13:15] = (held[i, :2]-y[13:15])/lag
            forces[i] = actual
        elif platform == 1:
            eta = np.empty(6)
            eta[:3] = y[:3]
            eta[3:] = euler_angles(y[6:10])
            nu = np.empty(6)
            nu[:3], nu[3:] = y[3:6], y[10:13]
            # A one-second Euler increment exposes the exact upstream RHS.
            # This is not an integration step; derivatives are subsequently
            # integrated at the specified physics step by RK4 or DOP853.
            new_nu, new_n = otter_euler(boat, eta, nu, y[13:15], held[i, :2], 1.)
            derivative = new_nu - nu
            r = rotation(y[6:10])
            extra = np.zeros(6)
            extra[:3] = r.T @ np.array([d[i, 0], d[i, 1], 0.])
            derivative += boat.Minv @ extra
            dy[i, :3] = r @ y[3:6]
            dy[i, 3:6], dy[i, 10:13] = derivative[:3], derivative[3:]
            dy[i, 6:10] = quaternion_rate(y[6:10], y[10:13])
            for k in range(2):
                clipped = min(boat.n_max, max(boat.n_min, y[13+k]))
                dy[i, 13+k] = new_n[k] - clipped
            thrust = np.empty(2)
            for k in range(2):
                speed = min(boat.n_max, max(boat.n_min, y[13+k]))
                coefficient = boat.k_pos if speed > 0 else boat.k_neg
                thrust[k] = coefficient*speed*abs(speed)
            forces[i] = (r @ np.array([thrust[0]+thrust[1], 0., 0.]))[:2]
            torques[i, 2] = -boat.l1*thrust[0]-boat.l2*thrust[1]
        elif i < 4:
            r = rotation(y[6:10])
            thrust = r[:, 2]*held[i, 0]
            speed = np.sqrt(np.sum(y[3:5]**2))
            drag = np.array([(.24+.012*speed)*y[3], (.24+.012*speed)*y[4],
                             (.24+.012*abs(y[5]))*y[5]])
            dy[i, :3] = y[3:6]
            dy[i, 3:6] = (thrust+np.array([d[i, 0], d[i, 1], 0.])-drag)/mass
            dy[i, 5] -= 9.81
            inertia = mass*np.array([.010, .010, .018])
            dy[i, 10:13] = (held[i, 1:4]-np.cross(y[10:13], inertia*y[10:13]))/inertia
            dy[i, 6:10] = quaternion_rate(y[6:10], y[10:13])
            forces[i] = thrust[:2]
            torques[i] = held[i, 1:4]
        else:
            r = rotation(y[6:10])
            world_dist = np.array([d[i, 0], d[i, 1], 0.])
            body_dist = r.T @ world_dist
            u, v, yaw_rate = y[3], y[4], y[12]
            damping = .36+.065*np.sqrt(u*u+v*v)
            dy[i, :3] = r @ y[3:6]
            dy[i, 3] = (held[i, 0]+body_dist[0]-damping*u+mass*v*yaw_rate)/mass
            dy[i, 4] = (body_dist[1]-damping*v-mass*u*yaw_rate)/mass
            dy[i, 12] = (held[i, 1]-.18*yaw_rate-.04*abs(yaw_rate)*yaw_rate)/(.12*mass)
            dy[i, 6:10] = quaternion_rate(y[6:10], y[10:13])
            forces[i] = (r @ np.array([held[i, 0], 0., 0.]))[:2]
            torques[i, 2] = held[i, 1]
    return dy, forces, torques


@njit(cache=True)
def rk4_step(state, held, t, h, platform, model, masses, boat, phase, disturbance_scale):
    a, fa, ta = rhs(state, held, t, platform, model, masses, boat, phase, disturbance_scale)
    b, fb, tb = rhs(state+.5*h*a, held, t+.5*h, platform, model, masses, boat, phase, disturbance_scale)
    c, fc, tc = rhs(state+.5*h*b, held, t+.5*h, platform, model, masses, boat, phase, disturbance_scale)
    d, fd, td = rhs(state+h*c, held, t+h, platform, model, masses, boat, phase, disturbance_scale)
    updated = state + h/6*(a+2*b+2*c+d)
    for i in range(len(state)):
        updated[i, 6:10] /= np.sqrt(np.sum(updated[i, 6:10]**2))
    # RK quadrature over actual physical forces, not requested controls.
    effort = h/6*(np.sum(fa*fa, axis=1)+2*np.sum(fb*fb, axis=1)
                   +2*np.sum(fc*fc, axis=1)+np.sum(fd*fd, axis=1))
    moment_effort = h/6*(np.sum(ta*ta, axis=1)+2*np.sum(tb*tb, axis=1)
                   +2*np.sum(tc*tc, axis=1)+np.sum(td*td, axis=1))
    impulse = h/6*(fa+2*fb+2*fc+fd)
    return updated, effort, moment_effort, impulse
