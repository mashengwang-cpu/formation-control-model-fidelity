"""Equation, physical-interface and legacy-regression contracts."""
from dataclasses import replace
from pathlib import Path
import sys
import numpy as np
import pytest
from .controllers import DEFAULT, rise_equations, periodic_control, ring
from .experiment import Job, prepare, run
from .physics import rhs, inner_commands, rk4_step, rotation
from .otter_adapter import source_parity

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "simulation" / "src"))


def test_rise_against_independent_matrix_equations():
    rng = np.random.default_rng(7)
    n, d = 8, 3
    q, v, integral = rng.normal(size=(3, n, d))
    leader_q, leader_v = rng.normal(size=(2, d))
    adjacency, pinning = ring(n, 1.)
    pinning[1::2] = 0.
    mapping = np.array([np.eye(3)*(1+i*.1) for i in range(n)])
    gains = np.array([10., 10., 25., 50.])
    actual, derivative, error, eta = rise_equations(q, v, leader_q, leader_v,
        adjacency, pinning, integral, gains, mapping)
    h = np.diag(adjacency.sum(axis=1)+pinning)-adjacency
    e, edot = leader_q-q, leader_v-v
    expected_eta, expected_eta_dot = h@e, h@edot
    virtual = 25*expected_eta_dot+501*expected_eta+20*pinning[:, None]*edot+101*pinning[:, None]*e+integral
    expected = np.einsum("nij,nj->ni", mapping, virtual)
    np.testing.assert_allclose(actual, expected, atol=2e-11)
    np.testing.assert_allclose(derivative, 2535*expected_eta+50*np.sign(expected_eta_dot+10*expected_eta), atol=2e-11)
    np.testing.assert_allclose(eta, expected_eta, atol=1e-13)
    np.testing.assert_allclose(error, e, atol=1e-13)
    shifted = rise_equations(q+123., v, leader_q+123., leader_v,
        adjacency, pinning, integral, gains, mapping)[0]
    np.testing.assert_allclose(shifted, actual, atol=1e-10)


def test_rise_zero_and_unclipped_sign_integral():
    adjacency, pinning = ring(4)
    zero = np.zeros((4, 2))
    maps = np.repeat(np.eye(2)[None], 4, axis=0)
    raw, derivative, _, _ = rise_equations(zero, zero, np.zeros(2), np.zeros(2),
        adjacency, pinning, zero, DEFAULT[11:], maps)
    np.testing.assert_array_equal(raw, zero)
    np.testing.assert_array_equal(derivative, zero)
    raw, derivative, _, _ = rise_equations(-np.ones((4, 2)), zero, np.zeros(2), np.zeros(2),
        adjacency, pinning, np.full((4, 2), 1e6), DEFAULT[11:], maps)
    assert np.min(raw) > 1e6
    np.testing.assert_allclose(derivative, 2585.)


@pytest.mark.parametrize("new_index,old_name", [(0,"proposed_minimal_causal"),
    (1,"recent_2025_resilient_fixed_time"),(2,"proposed_no_ppt"),
    (4,"hifi_ko_tvg"),(5,"hifi_ko_powers"),(6,"hifi_ko_approximator"),
    (7,"hifi_ko_observer"),(8,"hifi_ko_faultcomp"),(10,"proposed_full")])
def test_modular_periodic_adapter_against_frozen_source(new_index, old_name):
    from finite_control_sim.controllers import (ModularController, ControllerState,
        ControllerInput, get_method_spec)
    n = 8
    spec = replace(get_method_spec(old_name), position_gain=2.15, velocity_gain=2.05, event_triggered=False)
    old = ModularController(spec, n, dimensions=2, max_control=8.)
    state = ControllerState.zeros(n, 2, 7)
    weights, filt, integral = np.zeros((n, 7, 2)), np.zeros((n, 2)), np.zeros((n, 2))
    adjacency, pinning = ring(n)
    h = np.diag(adjacency.sum(1)+pinning)-adjacency
    rng = np.random.default_rng(19)
    maps = np.repeat(np.eye(2)[None], n, axis=0)
    for k in range(50):
        error = rng.normal(size=(n, 2))*.4
        velocity = rng.normal(size=(n, 2))*.2
        mixed = .65*error+.35*(h@error)/(adjacency.sum(1)+pinning)[:, None]
        inputs = ControllerInput(k*.02, .02, mixed, velocity, state.sampled_error,
            np.ones(n), np.ones(n, dtype=bool), np.ones(n), 5., 1., .035, .55)
        expected = old.step(state, inputs)
        actual = periodic_control(new_index, DEFAULT, k*.02, .02, error, velocity,
            np.zeros(2), np.zeros(2), adjacency, pinning, maps, weights, filt, integral)
        np.testing.assert_allclose(actual, expected.raw_control, atol=2e-13, rtol=1e-12)
        np.testing.assert_allclose(weights, expected.next_state.adaptive_weights, atol=1e-14)
        np.testing.assert_allclose(filt, expected.next_state.observer_state, atol=1e-14)
        state = expected.next_state


def test_upstream_otter_equations():
    assert source_parity(cases=100)["maximum_absolute_difference"] < 1e-10


def test_free_decay_against_closed_form():
    job = Job(model="point", duration=.2, disturbance_scale=0.)
    data = prepare(job)
    state, masses, boat = data[0], data[5], data[6]
    state[:, :6] = 0.
    state[0, 3] = 1.
    held = np.zeros((8, 4))
    for k in range(200):
        state, _, _, _ = rk4_step(state, held, k*.001, .001, 0, 0, masses, boat, 0., 0.)
    a, b, t = .24, .012, .2
    decay = np.exp(-a*t)
    expected_v = a*decay/(a+b*(1-decay))
    expected_p = np.log(1+b/a*(1-decay))/b
    np.testing.assert_allclose(state[0, 3], expected_v, atol=2e-13)
    np.testing.assert_allclose(state[0, 0], expected_p, atol=2e-13)


def test_native_hover_and_underactuation():
    data = prepare(Job(model="rigid"))
    state, masses, boat = data[0], data[5], data[6]
    state[:, 3:6] = 0.
    state[:, 6:10] = 0.
    state[:, 6] = 1.
    held, _ = inner_commands(state, np.zeros((8,2)), 0, 2, masses, boat, 1.)
    derivative, _, _ = rhs(state, held, 0., 0, 2, masses, boat, 0., 0.)
    np.testing.assert_allclose(derivative, 0., atol=2e-13)
    command = np.zeros((8, 2)); command[4:, 1] = 8.
    held, _ = inner_commands(state, command, 0, 2, masses, boat, 1.)
    assert np.all(held[4:, 0] == 0.)
    assert np.all(held[4:, 1] == 1.6)


def test_three_independent_clocks_and_finite_metrics():
    job = Job(duration=.2, model="rigid")
    coarse, arrays = run(job, detailed=True)
    fine, _ = run(replace(job, physics_dt=.000625))
    assert coarse["complete"] and fine["complete"]
    assert coarse["outer_updates"] == fine["outer_updates"] == 10
    assert coarse["inner_updates"] == fine["inner_updates"] == 160
    assert fine["physics_steps"] == 2*coarse["physics_steps"]
    assert abs(coarse["J_m"]-fine["J_m"]) < .002
    np.testing.assert_allclose(coarse["force_effort_N2s"], arrays["actual_force_squared_integral"].sum())
    np.testing.assert_allclose(np.linalg.norm(arrays["physical_state"][:,:,6:10], axis=2), 1., atol=1e-12)


def test_clock_contract_rejects_accidental_frequency_change():
    with pytest.raises(ValueError):
        prepare(Job(inner_dt=.00125, physics_dt=.001))


def test_response_scale_preserves_original_stiffness_damping_definition():
    data = prepare(Job(model="rigid"))
    state,masses,boat = data[0],data[5],data[6]
    state[:,3:6] = 0.; state[:,10:13] = 0.
    force = np.full((8,2),.05)
    half,sat_half = inner_commands(state,force,0,2,masses,boat,.5)
    full,sat_full = inner_commands(state,force,0,2,masses,boat,1.)
    assert not sat_half[:4].any() and not sat_full[:4].any()
    np.testing.assert_allclose(half[:4,1:],.25*full[:4,1:],atol=1e-14)
