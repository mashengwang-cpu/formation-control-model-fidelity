"""Write numerical tables from completed evidence, with no inferred outcomes."""
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
from .controllers import METHODS, PARAM_NAMES, parameter_indices

NAMES={'minimal':'Minimal','family':'Family','full':'Full (PPT off)','rise':'RISE',
       'no_schedule':'Delete schedule','no_powers':'Delete powers'}
SYMBOLS=[r'K_p',r'K_v',r'a_T',r'b_T',r'c_T',r'a_W',r'\ell_W',r'a_q',r'\ell_q',r'c_{p_1}',r'c_{p_2}',r'k_1',r'k_2',r'k_3',r'k_4']


def number(value,precision=4):
    if value is None or not np.isfinite(float(value)):return '--'
    v=float(value)
    if v==0:return '0'
    if abs(v)<1e-4 or abs(v)>=1e5:
        mantissa,exponent=f'{v:.3e}'.split('e')
        return mantissa+r'\times10^{'+str(int(exponent))+'}'
    return f'{v:.{precision}f}'.rstrip('0').rstrip('.')


def table(caption,label,columns,header,rows):
    return (r'\begin{table}[!ht]\centering'+'\n'+r'\caption{'+caption+'}\n'+r'\label{'+label+'}\n'
            +r'\small\begin{tabularx}{\textwidth}{'+columns+r'}\toprule'+'\n'
            +header+r' \\ \midrule'+'\n'+'\n'.join(' & '.join(row)+r' \\' for row in rows)+'\n'
            +r'\bottomrule\end{tabularx}\end{table}'+'\n\n')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data-root',type=Path,required=True)
    parser.add_argument('--submission',type=Path,required=True);parser.add_argument('--audit',type=Path,required=True)
    args=parser.parse_args();analysis=args.data_root/'analysis';campaign=args.data_root/'campaign/79b3058645f1'
    primary=pd.read_csv(analysis/'primary_contrasts.csv');means=pd.read_csv(analysis/'secondary_method_summaries.csv')
    selection=json.loads((campaign/'selection.json').read_text());budget=pd.read_csv(args.audit/'budget_cpu_audit.csv')
    summary=json.loads((analysis/'summary.json').read_text());physics=pd.read_csv(args.audit/'physical_diagnostics.csv')
    text=r'\section{Controlled-comparison result tables}\label{sec:controlledtables}'+'\n\n'
    text+=(f'The formal design contains {summary["design_references"]:,} references to '
           f'{summary["unique_executions"]:,} unique simulations. Each platform has 50 test seed blocks. '
           f'The execution audit records {summary["failed_unique_executions"]} failed unique formal-test runs. '
           'Reuse of a physical execution across strategies does not create a new seed block. '
           'Tables give the completed design, including physical diagnostics; finite completion alone '
           'does not establish feasible vehicle operation.\n\n')
    rows=[]
    for _,r in budget.sort_values(['platform','method']).iterrows():
        rows.append([r.platform.title(),NAMES[r.method],str(int(r.evaluations)),str(int(r.completed)),
                     '$'+number(r.cpu_seconds,1)+'$'])
    text+=table('Development budget and measured simulation-kernel CPU time. Training and validation together; equal evaluation counts do not imply equal computational cost. CPU time excludes archive writing and may include first-call compilation in a worker.','tab:newbudget','llrrr','Platform & Method & Evaluations & Complete & CPU (s)',rows)
    timing_path=analysis/'controller_computation_cost_refined.json'
    if not timing_path.exists():timing_path=analysis/'controller_computation_cost.json'
    timing=json.loads(timing_path.read_text());rows=[]
    for platform in ['native','otter']:
        for method in METHODS:
            cases=[r for r in timing['results'] if r['platform']==platform and r['method']==method]
            values=[r['pooled_mean_us'] for r in cases]
            rows.append([platform.title(),NAMES[method],str(cases[0]['fleet_size']),
                         '$'+number(min(values),2)+'$--$'+number(max(values),2)+'$'])
    text+=table('Warmed-up fleet controller-update CPU time, in microseconds. Ranges span the three selected model parameter vectors; they are not confidence intervals. Each condition uses 20 batches of 50,000 repeated nonzero-state updates, including the state reset. Integration, communication and hardware scheduling are excluded. Long batches reduce the effect of coarse Windows CPU ticks; contention and measurement quantization remain.','tab:newtiming','llrr','Platform & Method & Vehicles & CPU per update ($\\mu$s)',rows)
    rows=[]
    for _,r in primary.iterrows():
        contrast={'full_minus_minimal':'Full $-$ Minimal','full_minus_family':'Full $-$ Family',
                  'no_schedule':'Delete schedule $-$ Full','no_powers':'Delete powers $-$ Full'}[r.comparison]
        strategy={'transfer':'Transfer','retuned':'Retuned','fixed_full_background':'Fixed Full'}[r.strategy]
        rows.append([r.platform.title(),strategy,contrast,'$'+number(r['mean'])+'$',
                     '$['+number(r.lower)+','+number(r.upper)+']$' if r.family_status=='evaluated' else 'Withheld',
                     '$'+number(r.sum_observed_numerical_error_bounds_m)+'$'])
    text+=table(r'Twelve primary complete-minus-point interactions. Mean and nominal 95\% simultaneous maximum bootstrap-$t$ interval in metres. The last column sums observed per-arm numerical discrepancies on the held-out numerical condition grid; it is not a uniform mathematical bound.','tab:newprimary','llXrrr',r'Platform & Strategy & Contrast & Mean & Simultaneous CI & Numerical $\delta$',rows)
    for platform in ['native','otter']:
        for strategy in ['transfer','retuned']:
            rows=[]
            for method in METHODS:
                row=[NAMES[method]]
                for model in ['point','lag','rigid']:
                    r=means[(means.platform==platform)&(means.strategy==strategy)&(means.method==method)&(means.model==model)].iloc[0]
                    row.append('$'+number(r.mean_J_m)+r'\;['+number(r.lower)+','+number(r.upper)+']$' if r.status=='complete' else 'Incomplete')
                rows.append(row)
            caption=f'{platform.title()} {"point-selected transfer" if strategy=="transfer" else "model-specific retuning"}: tracking error $J$ (m), with secondary pointwise 95\\% percentile intervals over 50 paired seed blocks. Each block equally averages '+('three' if platform=='native' else 'nine')+' conditions. These intervals are not simultaneous.'
            text+=table(caption,'tab:newmeans'+platform+strategy,'lXXX','Method & Point mass & Command lag & Complete model',rows)
    rows=[]
    for platform in ['native','otter']:
        for method in METHODS:
            row=[platform.title(),NAMES[method]]
            for strategy in ['transfer','retuned']:
                r=means[(means.platform==platform)&(means.method==method)&(means.model=='rigid')&(means.strategy==strategy)].iloc[0]
                row.append('$'+number(r.mean_force_effort_N2s,2)+'$')
            rows.append(row)
    text+=table(r'Complete-model realized horizontal force effort, N$^2$\,s. Each value is a descriptive seed-block-equal mean; no confidence interval is attached. Mission duration and fleet size differ between platforms. These integrals are not electrical energy.','tab:neweffort','llrr','Platform & Method & Transfer & Retuned',rows)
    text+=r'\FloatBarrier'+'\n'+r'\subsection{Selected parameters}'+'\n'
    text+=('The tables list active parameters only, rounded for readability. The full-precision vectors in '
           '\\path{design/selection.json} define the experiment. $a_T,b_T,c_T$ are the schedule numerator, '
           'boundary offset and cap; $a_W,\\ell_W$ are approximation update and leakage; '
           '$a_q,\\ell_q$ are filter update and leakage; and $c_{p_1},c_{p_2}$ multiply the fixed signed powers. '
           'These coefficients are defined in the declared controller coordinates.\n\n')
    for platform in ['native','otter']:
        rows=[]
        for method in METHODS:
            for model,choice in selection['choices'][platform][method].items():
                params=', '.join('$'+SYMBOLS[i]+'='+number(choice['parameters'][i],5)+'$' for i in parameter_indices(method))
                rows.append([NAMES[method],{'point':'Point','lag':'Lag','rigid':'Complete'}[model],str(choice['candidate']),params])
        text+=table(platform.title()+' selected parameters. Transfer uses the point-selected vector on all models; retuning uses each model\'s row. Deletions use the Full point-selected vector.','tab:newparams'+platform,'llrX','Method & Model & ID & Active parameters',rows)
        text+=r'\FloatBarrier'+'\n'
    text+=r'\subsection{Physical events and input saturation}'+'\n'
    rows=[]
    for _,r in physics[physics.model=='rigid'].sort_values(['platform','method','strategy']).iterrows():
        strategy={'transfer':'Transfer','retuned':'Retuned','fixed_full_background':'Fixed Full'}[r.strategy]
        rows.append([r.platform.title(),NAMES[r.method],strategy,str(int(r.design_denominator)),str(int(r.complete)),
                     str(int(r.plane_crossings)),str(int(r.inversions)),str(int(r.speed_domain_entries))])
    text+=table('Complete-model physical diagnostics by analysis arm. Counts are runs with at least one event, not event-entry totals. Plane refers to native UAV reference-plane crossing; it is not an Otter ground-contact measure. Inversion and speed-domain flags remain distinct from numerical failure. Shared strategy rows reuse executions.','tab:newphysical','llXrrrrr','Platform & Method & Strategy & Designed & Complete & Plane & Invert & Speed',rows)
    text+=('Per-arm outer-request and inner-allocation saturation durations are in '
           r'\texttt{physical\_diagnostics.csv}; full trajectories and interval integrals remain in the raw archive. '
           'A saturation-duration sum is an agent-time total, not a packet count or an energy measurement.\n\n')
    text+=r'\begin{figure}[!ht]\centering\makebox[\linewidth][c]{\includegraphics[width=180mm]{Numerical_qualification.pdf}}'+'\n'
    text+=r'\caption{Numerical qualification of selected parameters. Each cell gives the worst observed $|J-J_{\rm ref}|/\max(0.002\,\mathrm{m},0.01|J_{\rm ref}|)$ for that method and physical step. An outline marks any unresolved criterion, including state, effort, event or saturation criteria beyond $J$. Controller clocks remain fixed. The reference integrator shares the physical right-hand side; agreement is not a validation of physical-model fidelity.}\label{fig:newnumerics}\end{figure}'+'\n'
    output=args.submission/'supp_sections/supp_controlled_results.tex';output.write_text(text,encoding='utf-8')
    print(json.dumps({'tables':text.count('\\begin{table}'),'primary_rows':len(primary),'output':str(output)}))


if __name__=='__main__':main()
