"""Sampled-control validation with frozen development and test cohorts."""
