"""Tighten the selected-parameter reference tolerance without changing selection."""
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import argparse, json
import numpy as np
from .experiment import Job
from .reference import run_reference, compare


def check(payload):
    record,folder,output=payload;folder,output=Path(folder),Path(output)
    case=record['case_id'];old=np.load(folder/(case+'_reference.npz'))
    metrics,arrays=run_reference(Job(**record['job']),record['parameters'],rtol=1e-11,atol=1e-13)
    result={'case_id':case,'job':record['job'],'parameters':record['parameters'],
            'reference_comparison':compare(record['reference'],dict(old),metrics,arrays),
            'tight_metrics':metrics}
    np.savez_compressed(output/(case+'_tight.npz'),**arrays)
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--numerical',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True);records=[]
    for path in sorted(args.numerical.glob('*.json')):
        if path.name in {'summary.json','design.json'}:continue
        r=json.loads(path.read_text());j=r['job']
        if (j['model']=='rigid' and j['method'] in ['minimal','rise']
                and j['trajectory']=='double_sine' and j['seed'] in [39002,39102]
                and j['current']==(0. if j['platform']=='native' else .2)):
            records.append(r)
    assert 4<=len(records)<=8,len(records)
    with ProcessPoolExecutor(max_workers=2) as pool:
        output=list(pool.map(check,[(r,str(args.numerical),str(args.output)) for r in records]))
    result={'cases':len(output),'passed':all(r['reference_comparison']['pass'] for r in output),'results':output}
    (args.output/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'cases':len(output),'passed':result['passed']}))


if __name__=='__main__':main()
