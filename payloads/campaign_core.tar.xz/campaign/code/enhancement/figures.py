"""Publication figures generated directly from the controlled-comparison tables."""
from pathlib import Path
from collections import defaultdict
import argparse, hashlib, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import LogLocator, FuncFormatter

MM=1/25.4
INK='#283641';LIGHT='#E6EBEF'
METHODS=['minimal','family','full','rise']
LABEL={'minimal':'Minimal','family':'Family comparator','full':'Full (PPT off)',
       'rise':'RISE','no_schedule':'No gain schedule','no_powers':'No signed powers'}
COLOR={'minimal':'#006C84','family':'#AD5700','full':'#684A98','rise':'#374B5D',
       'no_schedule':'#006E62','no_powers':'#955D00'}
MARKER={'minimal':'o','family':'s','full':'^','rise':'p','no_schedule':'D','no_powers':'v'}
LINE={'minimal':'-','family':'--','full':'-.','rise':':'}
MODELS=['point','lag','rigid']
MODEL_LABEL=['Point mass','Command lag','Complete model']
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
    'font.size':10,'axes.labelsize':10,'axes.titlesize':10.5,'xtick.labelsize':9.5,
    'ytick.labelsize':9.5,'legend.fontsize':9.5,'axes.spines.top':False,
    'axes.spines.right':False,'axes.linewidth':1.,'text.color':INK,'axes.labelcolor':INK,
    'xtick.color':INK,'ytick.color':INK,'axes.edgecolor':INK,'pdf.fonttype':42,
    'svg.fonttype':'none','svg.hashsalt':'formation-controlled-validation-20260907',
    'figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white',
    'legend.frameon':False,'mathtext.fontset':'dejavusans'})


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def title(ax,letter,text,reading=False):
    ax.text(0,1.10,letter,transform=ax.transAxes,fontsize=13 if reading else 12,
            fontweight='bold',va='bottom')
    ax.annotate(text,(0,1.10),xycoords='axes fraction',xytext=(17,0),
                textcoords='offset points',fontsize=12 if reading else 10.5,
                fontweight='bold',va='bottom')


def interval(ax,x,y,lo,hi,method,vertical=True,reading=False):
    if not np.isfinite([x,y,lo,hi]).all() or lo>hi:
        raise ValueError('Invalid interval or mean')
    size=6.1 if reading else 4.8
    if vertical:
        ax.plot([x,x],[lo,hi],lw=1.1,color=INK,zorder=5)
        ax.plot([x,x],[lo,hi],ls='none',marker='_',ms=7,mew=1.,color=INK,zorder=5)
    else:
        ax.plot([lo,hi],[y,y],lw=1.2,color=INK,zorder=5)
        ax.plot([lo,hi],[y,y],ls='none',marker='|',ms=7,mew=1.,color=INK,zorder=5)
    ax.plot(x,y,marker=MARKER[method],ms=size,mec=INK,mew=.75,
            mfc=COLOR[method],ls='none',zorder=6)


def style(ax,reading=False):
    ax.tick_params(direction='out',length=4,pad=4,width=.9)
    ax.set_axisbelow(True)
    if reading:
        ax.tick_params(labelsize=11)
        ax.xaxis.label.set_size(12);ax.yaxis.label.set_size(12)


def footer(fig,lines,base=.075,fontsize=8.5):
    height_pt=fig.get_size_inches()[1]*72
    for i,line in enumerate(lines):
        fig.text(.055,base-i*(fontsize+3)/height_pt,line,fontsize=fontsize,ha='left',va='top')


def export(fig,name,output,records,sources,caption):
    caption += ' OpenAI Codex assisted with plotting code and layout; reproducible scripts render the recorded data.'
    output.mkdir(parents=True,exist_ok=True)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer(); outside=[]
    from matplotlib.text import Text
    for item in fig.findobj(match=Text):
        if not item.get_visible() or not item.get_text().strip():continue
        box=item.get_window_extent(renderer)
        if box.x0 < -1 or box.y0 < -1 or box.x1>fig.bbox.width+1 or box.y1>fig.bbox.height+1:
            outside.append(item.get_text())
    if outside:raise ValueError(name+': labels outside canvas: '+repr(outside))
    labels=[]
    for ax in fig.axes:
        if not ax.axison:continue
        labels.extend([ax.xaxis.label,ax.yaxis.label])
        for ticks,texts,limits in [(ax.get_xticks(),ax.get_xticklabels(),ax.get_xlim()),
                                  (ax.get_yticks(),ax.get_yticklabels(),ax.get_ylim())]:
            low,high=sorted(limits)
            labels.extend(t for value,t in zip(ticks,texts) if low<=value<=high)
    for legend in fig.legends:labels.extend(legend.get_texts())
    for note in fig.texts:
        if note.get_position()[1]>.2:continue
        a=note.get_window_extent(renderer)
        for label in labels:
            if not label.get_visible() or not label.get_text().strip():continue
            b=label.get_window_extent(renderer)
            if min(a.x1,b.x1)-max(a.x0,b.x0)>2 and min(a.y1,b.y1)-max(a.y0,b.y0)>2:
                raise ValueError(name+': footer overlaps label: '+label.get_text())
    files={}
    for ext,dpi in [('pdf',None),('svg',None),('png',1000)]:
        path=output/(name+'.'+ext)
        metadata={'Creator':'Matplotlib','CreationDate':None,'ModDate':None} if ext=='pdf' else {'Date':None} if ext=='svg' else None
        fig.savefig(path,dpi=dpi,metadata=metadata)
        files[ext]={'file':path.name,'sha256':sha(path),'bytes':path.stat().st_size}
    preview=output/'reading';preview.mkdir(exist_ok=True)
    fig.savefig(preview/(name+'.png'),dpi=220)
    ledger={'figure':name,'width_mm':float(fig.get_size_inches()[0]*25.4),
            'height_mm':float(fig.get_size_inches()[1]*25.4),'caption':caption,
            'font_primary':'Arial','font_fallback':'DejaVu Sans',
            'font_sizes_pt':sorted({float(t.get_fontsize()) for t in fig.findobj(match=Text) if t.get_visible() and t.get_text().strip()}),
            'sources':[{'file':Path(p).name,'sha256':sha(p)} for p in sources],
            'generator_sha256':sha(__file__),'data':records,'files':files,'outside_text':outside,
            'svg_note':'Editable text requires Arial or the declared fallback; embedded-font PDF is the layout reference.'}
    (output/(name+'.plot_data.json')).write_text(json.dumps(ledger,indent=2,allow_nan=False),encoding='utf-8')
    plt.close(fig)
    return ledger


def performance_axis(ax,blocks,summary,platform,strategy,letter,reading=False):
    records=[];all_values=[];offsets=np.linspace(-.27,.27,4)
    for m,method in enumerate(METHODS):
        means=[];positions=[]
        for i,model in enumerate(MODELS):
            points=blocks[(blocks.platform==platform)&(blocks.strategy==strategy)&
                          (blocks.method==method)&(blocks.model==model)].sort_values('seed')
            if len(points)!=50 or not points.complete.all():
                raise ValueError(f'Incomplete {platform}/{method}/{strategy}/{model}; do not silently draw a subset')
            values=points.J_m.to_numpy(float)
            row=summary[(summary.platform==platform)&(summary.strategy==strategy)&
                        (summary.method==method)&(summary.model==model)].iloc[0]
            if not np.isfinite(values).all() or min(values)<=0:
                raise ValueError('Nonpositive or nonfinite tracking error on log axis')
            # Position-only deterministic jitter leaves every outcome unchanged.
            jitter=np.random.default_rng(83001+i*10+m).uniform(-.019,.019,50)
            x=i+offsets[m]
            ax.scatter(x-.032+jitter,values,s=9 if reading else 5.5,marker=MARKER[method],
                       color=COLOR[method],edgecolors=COLOR[method],linewidths=.3,alpha=.65,zorder=2)
            interval(ax,x+.023,row.mean_J_m,row.lower,row.upper,method,reading=reading)
            means.append(row.mean_J_m);positions.append(x+.023)
            all_values.extend([*values,row.lower,row.upper])
            records.append({'method':method,'model':model,'strategy':strategy,'platform':platform,
                            'seeds':points.seed.astype(int).tolist(),'block_J_m':values.tolist(),
                            'mean':float(row.mean_J_m),'lower':float(row.lower),'upper':float(row.upper)})
        ax.plot(positions,means,color=COLOR[method],ls=LINE[method],lw=1.5,zorder=3)
    ax.set_yscale('log');ax.minorticks_off()
    ax.yaxis.set_major_locator(LogLocator(base=10,subs=[1,2,5],numticks=7))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v:g}'))
    lower,upper=min(all_values),max(all_values)
    margin=max(.08,.10*np.log10(upper/lower))
    ax.set_ylim(lower/10**margin,upper*10**margin)
    ax.set_xlim(-.45,2.45)
    ax.set_xticks(range(3),MODEL_LABEL if reading else ['Point\nmass','Command\nlag','Complete\nmodel'])
    ax.set_ylabel(r'Tracking error, $J$ (m)')
    ax.grid(axis='y',color=LIGHT,lw=.5)
    title(ax,letter,('Native' if platform=='native' else 'Otter')+' · '+('point-selected transfer' if strategy=='transfer' else 'model-specific retuning'),reading)
    style(ax,reading)
    return records


def performance(blocks,summary,output,sources):
    fig,axes=plt.subplots(2,2,figsize=(180*MM,193*MM))
    fig.subplots_adjust(left=.10,right=.985,bottom=.23,top=.91,wspace=.35,hspace=.52)
    settings=[('native','transfer'),('native','retuned'),('otter','transfer'),('otter','retuned')]
    records=[]
    for i,(ax,(platform,strategy)) in enumerate(zip(axes.ravel(),settings)):
        records.extend(performance_axis(ax,blocks,summary,platform,strategy,chr(97+i)))
    handles=[Line2D([],[],marker=MARKER[m],ls=LINE[m],color=COLOR[m],ms=5,label=LABEL[m]) for m in METHODS]
    fig.legend(handles=handles,ncol=2,loc='lower center',bbox_to_anchor=(.52,.087),columnspacing=2.)
    notes=['50 paired seed blocks per platform; each averages 3 native or 9 Otter conditions equally.',
           'Small points: all blocks. Large marks: means and secondary pointwise 95% percentile intervals.',
           '20,000 block resamples. Logarithmic axes. Complete model includes platform-specific actuation.']
    footer(fig,notes,base=.065)
    caption='Independent test tracking error under point-selected transfer and model-specific retuning. All four methods received 2,880 development evaluations on each platform. Fifty paired seed blocks per platform; three native or nine Otter conditions per block. Intervals are secondary pointwise 95% percentile bootstrap intervals, not the primary simultaneous family. All block values are shown; narrow intervals retain their true extent. The complete Otter model changes hydrodynamics as well as actuation.'
    manifest=[export(fig,'Figure_7',output,records,sources,caption)]
    for i,(platform,strategy) in enumerate(settings):
        fig,ax=plt.subplots(figsize=(180*MM,139*MM));fig.subplots_adjust(left=.13,right=.97,bottom=.28,top=.86)
        data=performance_axis(ax,blocks,summary,platform,strategy,chr(97+i),True)
        fig.legend(handles=handles,ncol=2,loc='lower center',bbox_to_anchor=(.52,.16),fontsize=11)
        footer(fig,notes,base=.13,fontsize=9)
        manifest.append(export(fig,'Figure_7'+chr(97+i),output/'panels',data,sources,caption))
    return manifest


def primary_axis(ax,frame,platform,letter,reading=False):
    sub=frame[frame.platform==platform].sort_values('contrast_index')
    labels=['Transfer\nFull − Minimal','Transfer\nFull − Family','Retuned\nFull − Minimal',
            'Retuned\nFull − Family','Fixed Full\nDelete schedule','Fixed Full\nDelete powers']
    records=[];extent=[0.]
    for i,(_,row) in enumerate(sub.iterrows()):
        method='no_schedule' if row.comparison=='no_schedule' else 'no_powers' if row.comparison=='no_powers' else 'full'
        if row.family_status!='evaluated':
            ax.text(.05,i,'Inference withheld: incomplete primary family',transform=ax.get_yaxis_transform(),fontsize=9)
            records.append({'contrast_index':int(row.contrast_index),'status':row.family_status});continue
        interval(ax,row['mean'],i,row.lower,row.upper,method,vertical=False,reading=reading)
        ax.text(1.065,i,f"{row['mean']:+.4f}\n[{row.lower:+.4f}, {row.upper:+.4f}]",
                transform=ax.get_yaxis_transform(),fontsize=9.5 if reading else 8.5,
                va='center',ha='left',linespacing=1.35)
        extent.extend([row['mean'],row.lower,row.upper])
        if not row.numerical_conditions_resolved:
            ax.text(1.,i-.27,'Numerics unresolved',transform=ax.get_yaxis_transform(),ha='right',fontsize=8.5,color=INK)
        records.append({'contrast_index':int(row.contrast_index),'mean':float(row['mean']),
                        'lower':float(row.lower),'upper':float(row.upper),
                        'numerical_conditions_resolved':bool(row.numerical_conditions_resolved),
                        'observed_numerical_discrepancy_m':float(row.sum_observed_numerical_error_bounds_m)})
    lo,hi=min(extent),max(extent);margin=max(.002,(hi-lo)*.10)
    ax.set_xlim(lo-margin,hi+margin);ax.set_ylim(5.55,-.55)
    ax.set_yticks(range(6),labels);ax.tick_params(axis='y',length=0,pad=8)
    for y in np.arange(5)+.5:ax.axhline(y,color=LIGHT,lw=.6,zorder=0)
    ax.axvline(0,color='#687780',ls=(0,(3,2)),lw=1.,zorder=0)
    ax.set_xlabel('Complete-minus-point interaction\nin tracking error (m)')
    title(ax,letter,('Native' if platform=='native' else 'Otter')+' · primary mean contrasts',reading)
    ax.spines['left'].set_visible(False);style(ax,reading)
    return records


def primary(frame,output,sources):
    fig,axes=plt.subplots(2,1,figsize=(180*MM,193*MM))
    fig.subplots_adjust(left=.29,right=.73,bottom=.17,top=.91,hspace=.67)
    records=[]
    for i,(ax,platform) in enumerate(zip(axes,['native','otter'])):
        records.extend(primary_axis(ax,frame,platform,chr(97+i)))
    notes=['Means and nominal 95% simultaneous maximum bootstrap-t intervals across all 12 contrasts.',
           '50 blocks per platform; 20,000 resamples. The two platform cohorts are resampled independently.',
           'Complete methods: Full minus comparator. Deletions: deletion minus Full, in a fixed parameter background.']
    footer(fig,notes,base=.067)
    caption='Primary model interactions under transfer, model-specific retuning and fixed-background module deletion. Means and nominal 95% simultaneous maximum bootstrap-t intervals over the full twelve-contrast family. The dashed line is zero interaction. The complete-method and deletion orientations are written explicitly. Numerical qualification is assessed separately and unresolved rows are labeled. Intervals quantify seed-block sampling uncertainty, not vehicle-model uncertainty.'
    manifest=[export(fig,'Figure_8',output,records,sources,caption)]
    for i,platform in enumerate(['native','otter']):
        fig,ax=plt.subplots(figsize=(180*MM,159*MM));fig.subplots_adjust(left=.30,right=.71,bottom=.26,top=.86)
        data=primary_axis(ax,frame,platform,chr(97+i),True)
        footer(fig,notes,base=.15,fontsize=9)
        manifest.append(export(fig,'Figure_8'+chr(97+i),output/'panels',data,sources,caption))
    return manifest


def numerical_table(folder):
    rows=[]
    for path in sorted(folder.glob('*.json')):
        if path.name in {'summary.json','design.json'}:continue
        record=json.loads(path.read_text())
        if record['status']!='evaluated':raise ValueError('Unresolved implementation error in numerical figure')
        for c in record['comparisons']:
            rows.append({'case_id':record['case_id'],'platform':record['job']['platform'],
                         'method':record['job']['method'],'physics_dt':c['physics_dt'],
                         'ratio':c.get('J_difference_m',np.nan)/c.get('J_tolerance_m',1.),
                         'pass':c['pass'],'status':c['status']})
    return pd.DataFrame(rows)


def numerical_axis(ax,frame,platform,letter,reading=False):
    sub=frame[frame.platform==platform];steps=sorted(sub.physics_dt.unique(),reverse=True)
    methods=METHODS+['no_schedule','no_powers'];values=np.zeros((6,len(steps)));records=[]
    for i,method in enumerate(methods):
        for j,h in enumerate(steps):
            group=sub[(sub.method==method)&(sub.physics_dt==h)]
            finite=group.ratio.to_numpy(float);valid=len(group)>0 and np.isfinite(finite).all()
            value=float(np.max(finite)) if valid else None
            values[i,j]=min(1.,max(0.,value)) if valid else 1.
            all_pass=bool(valid and group['pass'].all())
            text='missing' if not valid else f'{value:.1e}'
            ax.text(j,i,text,ha='center',va='center',fontsize=10 if reading else 9,color=INK)
            if not all_pass:
                from matplotlib.patches import Rectangle
                ax.add_patch(Rectangle((j-.48,i-.48),.96,.96,fill=False,lw=1.8,color=INK))
            records.append({'method':method,'physics_dt':float(h),'cases':len(group),
                            'worst_J_difference_over_tolerance':value,'all_criteria_pass':all_pass})
    # Color supports a numeric table; values, not color alone, carry precision.
    from matplotlib.colors import LinearSegmentedColormap
    cmap=LinearSegmentedColormap.from_list('qualification',['#F4F7F9','#9BC9D1'])
    from matplotlib.patches import Rectangle
    for i in range(6):
        for j in range(len(steps)):
            ax.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor=cmap(values[i,j]),edgecolor='none',zorder=0))
    ax.set_xlim(-.5,len(steps)-.5);ax.set_ylim(5.5,-.5)
    ax.set_xticks(range(len(steps)),[f'{h*1000:g}' for h in steps]);ax.set_yticks(range(6),[LABEL[m] for m in methods])
    ax.set_xlabel('Physics step (ms); outer and inner periods held fixed')
    for spine in ax.spines.values():spine.set_visible(False)
    ax.tick_params(length=0,pad=6);title(ax,letter,('Native' if platform=='native' else 'Otter')+' · selected parameters',reading)
    style(ax,reading)
    return records


def numerical(frame,output,sources):
    fig,axes=plt.subplots(2,1,figsize=(180*MM,175*MM));fig.subplots_adjust(left=.29,right=.97,bottom=.20,top=.90,hspace=.61)
    records=[]
    for i,(ax,platform) in enumerate(zip(axes,['native','otter'])):
        records.extend(numerical_axis(ax,frame,platform,chr(97+i)))
    notes=['Cells: worst |J − Jreference| / max(0.002 m, 0.01|Jreference|) across the numerical condition set.',
           'Outline: at least one unresolved criterion, including state, force-effort, event or saturation checks.',
           'Reference: segmented DOP853 with a shared physical RHS. Agreement does not validate model fidelity.']
    footer(fig,notes,base=.085)
    caption='Numerical qualification of selected controller parameters across the held-out numerical condition grid. Each cell is the worst observed tracking-error discrepancy divided by its declared tolerance. An outline identifies any unresolved criterion, including criteria beyond tracking error. Sampling and inner-loop update periods are fixed as physical integration is refined. DOP853 shares the physical RHS with RK4; this is a numerical integration check. Exact case-level results and failure classifications remain in the reproduction data.'
    manifest=[export(fig,'Figure_S5',output,records,sources,caption)]
    for i,platform in enumerate(['native','otter']):
        fig,ax=plt.subplots(figsize=(180*MM,132*MM));fig.subplots_adjust(left=.30,right=.97,bottom=.29,top=.85)
        data=numerical_axis(ax,frame,platform,chr(97+i),True)
        footer(fig,notes,base=.16,fontsize=9)
        manifest.append(export(fig,'Figure_S5'+chr(97+i),output/'panels',data,sources,caption))
    return manifest


def graphical_abstract(frame,output,sources):
    fig=plt.figure(figsize=(180*MM,104*MM))
    fig.text(.055,.94,'Compare the model and the tuning strategy together',fontsize=13,weight='bold',va='top')
    layout=fig.add_axes([.055,.16,.31,.67]);layout.set_axis_off()
    from matplotlib.patches import FancyBboxPatch
    entries=[('Develop','2,880 evaluations\nper method and platform'),
             ('Freeze','Point-selected transfer\nor model-specific retuning'),
             ('Test','50 new seed blocks\non each platform')]
    for i,(head,body) in enumerate(entries):
        y=.90-i*.31
        layout.add_patch(FancyBboxPatch((0,y-.22),.97,.25,boxstyle='round,pad=0.008,rounding_size=0.012',
                                       facecolor='#F2F6F8',edgecolor='#CBD6DD',lw=.8))
        layout.text(.045,y,head,fontsize=10.5,weight='bold',va='top')
        layout.text(.045,y-.065,body,fontsize=9,va='top',linespacing=1.35)
        if i<2:layout.annotate('',xy=(.485,y-.277),xytext=(.485,y-.225),
                               arrowprops={'arrowstyle':'->','lw':1.,'color':INK})
    ax=fig.add_axes([.64,.27,.32,.54]);records=[];extent=[0.]
    selection=frame[(frame.type=='complete_method')&(frame.comparison=='full_minus_minimal')]
    labels=['Native\nTransfer','Native\nRetuned','Otter\nTransfer','Otter\nRetuned']
    for i,(platform,strategy) in enumerate([('native','transfer'),('native','retuned'),('otter','transfer'),('otter','retuned')]):
        row=selection[(selection.platform==platform)&(selection.strategy==strategy)].iloc[0]
        if row.family_status=='evaluated':
            interval(ax,row['mean'],i,row.lower,row.upper,'full',vertical=False)
            extent.extend([row.lower,row.upper,row['mean']])
            records.append({'platform':platform,'strategy':strategy,'mean':float(row['mean']),
                            'lower':float(row.lower),'upper':float(row.upper)})
        else:ax.text(.02,i,'Withheld',transform=ax.get_yaxis_transform(),fontsize=9)
    lo,hi=min(extent),max(extent);pad=max(.002,.12*(hi-lo))
    ax.set_xlim(lo-pad,hi+pad);ax.set_ylim(3.55,-.55);ax.set_yticks(range(4),labels)
    ax.tick_params(axis='y',length=0,pad=7,labelsize=9.5);ax.spines['left'].set_visible(False)
    ax.axvline(0,color='#697A85',lw=.9,ls=(0,(3,2)),zorder=0)
    ax.set_xlabel('Model interaction (m)',fontsize=10)
    ax.set_title('Full minus Minimal',fontsize=10.5,weight='bold',pad=12)
    footer(fig,['Shown: complete-minus-point interactions; intervals are simultaneous across the 12 primary contrasts.',
                'Four methods; native UAV–USV and independent Otter simulations. Model uncertainty remains outside the intervals.'],
           base=.12,fontsize=8.5)
    caption='Equal-budget development, parameter freezing and independent tests across two computational platforms. The illustrated results are Full-minus-Minimal complete-minus-point mean interactions under transfer and retuning. Nominal 95% simultaneous intervals belong to the full twelve-contrast primary family. The manuscript also reports Full-minus-Family and fixed-background module contrasts. These are simulation results, not physical vehicle validation.'
    return export(fig,'Graphical_abstract',output,records,sources,caption)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--analysis',type=Path,required=True)
    parser.add_argument('--numerical',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    block_path=args.analysis/'paired_seed_blocks.csv';summary_path=args.analysis/'secondary_method_summaries.csv'
    primary_path=args.analysis/'primary_contrasts.csv'
    blocks=pd.read_csv(block_path);summary=pd.read_csv(summary_path);frame=pd.read_csv(primary_path)
    manifest=[]
    # Incomplete data remain in tables and failure records. A figure that would
    # silently hide failed seed blocks is withheld as a whole.
    if blocks.complete.all():manifest.extend(performance(blocks,summary,args.output,[block_path,summary_path]))
    manifest.extend(primary(frame,args.output,[primary_path,args.analysis/'primary_family.json']))
    numeric=numerical_table(args.numerical);numeric_path=args.analysis/'numerical_plot_values.csv';numeric.to_csv(numeric_path,index=False)
    manifest.extend(numerical(numeric,args.output,[numeric_path,args.numerical/'design.json']))
    manifest.append(graphical_abstract(frame,args.output,[primary_path,args.analysis/'primary_family.json']))
    (args.output/'enhancement_figure_manifest.json').write_text(json.dumps(manifest,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'figures_and_panels':len(manifest),'main_artifacts':3*len(manifest)}))


if __name__=='__main__':main()
