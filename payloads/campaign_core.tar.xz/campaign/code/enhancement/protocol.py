"""Immutable candidate generation and disjoint development/test designs."""
from dataclasses import asdict
from pathlib import Path
import hashlib, json
import numpy as np
from scipy.stats import qmc
from .controllers import DEFAULT, METHODS, PARAM_NAMES, parameter_indices
from .experiment import Job
from .numerical_campaign import sources, digest

ROOT = Path(__file__).resolve().parents[1]
SEEDS = {"native":{"train":list(range(30000,30006)),"validation":list(range(31000,31012)),
                    "test":list(range(40000,40050))},
         "otter":{"train":list(range(32000,32006)),"validation":list(range(33000,33012)),
                   "test":list(range(50000,50050))}}
MODELS = ("point","lag","rigid")
DEVELOPMENT = ("straight","arc")
TEST_TRAJECTORIES = ("ellipse","double_sine","speed_line")


def candidates(platform, method):
    indices = parameter_indices(method)
    seed = 18001+100*int(platform=="otter")+METHODS.index(method)
    points = qmc.Sobol(len(indices),scramble=True,seed=seed).random_base2(6)[:63]
    if method == "rise":
        low, high = np.array([.51,.51,.1,.01]), np.array([20.,20.,50.,100.])
    else:
        low, high = DEFAULT[indices]/8., DEFAULT[indices]*8.
    rows = [DEFAULT.copy()]
    for point in points:
        parameters = DEFAULT.copy()
        parameters[indices] = np.exp(np.log(low)+point*(np.log(high)-np.log(low)))
        rows.append(parameters)
    assert len({tuple(row) for row in rows})==64
    return [{"candidate":i,"parameters":p.tolist()} for i,p in enumerate(rows)]


def job_for(platform, model, method, seed, trajectory, stage, candidate=0, current=None):
    native = platform=="native"
    return Job(platform=platform,model=model,method=method,seed=seed,trajectory=trajectory,
        stage=stage,candidate=candidate,outer_dt=.02 if native else .05,
        inner_dt=.00125 if native else .01,physics_dt=.00125 if native else .0025,
        duration=16. if native else 60.,current=(0. if native else .03) if current is None else current)


def freeze(numerical_folder):
    path = ROOT/"design"/"protocol.json"
    if path.exists():
        existing = json.loads(path.read_text())
        if existing["dynamics_sources"] != sources():
            raise RuntimeError("Dynamics changed after protocol freeze; a new cohort is required")
        return existing
    numerical = Path(numerical_folder)
    summary = json.loads((numerical/"summary.json").read_text())
    if summary["implementation_errors"]:
        raise RuntimeError("Numerical implementation errors must be resolved first")
    if summary["source_hash"] != digest(sources()):
        raise RuntimeError("Numerical checks and frozen experiment sources must agree")
    resolutions = {p:{m:0. for m in MODELS} for p in SEEDS}
    unresolved = []
    for result_path in numerical.glob("*.json"):
        if result_path.name in {"design.json","summary.json"}:
            continue
        record = json.loads(result_path.read_text())
        job = record["job"]
        target = .00125 if job["platform"]=="native" else .0025
        result = next(c for c in record["comparisons"] if c["physics_dt"]==target)
        if result["status"]=="incomplete" or not result["pass"]:
            unresolved.append(record["case_id"])
        if result.get("J_bound_m") is not None:
            p,m = job["platform"],job["model"]
            resolutions[p][m] = max(resolutions[p][m], result["J_bound_m"])
    # Numerical limitations are not hidden. Selection's tie threshold is the
    # measured maximum default resolution, frozen before any development result.
    for p in resolutions:
        for m in resolutions[p]:
            resolutions[p][m] = max(resolutions[p][m],1e-10)
    candidate_table = {p:{m:candidates(p,m) for m in METHODS} for p in SEEDS}
    protocol = {"version":"control-validation-1","dynamics_sources":sources(),
        "selection_sources":{name:hashlib.sha256((ROOT/"enhancement"/name).read_bytes()).hexdigest()
                             for name in ["protocol.py","campaign.py"]},
        "seed_groups":SEEDS,"source_fixture_seeds":[29000,29001,29002],
        "numerical_seeds":[39000,39001,39002,39003,39100,39101,39102,39103],
        "parameter_names":PARAM_NAMES,"candidates":candidate_table,
        "stage1":{"candidates":64,"models":3,"seeds":6,"scenarios":2,"evaluations_per_method_platform":2304},
        "stage2":{"candidates_per_model":8,"models":3,"seeds":12,"scenarios":2,"evaluations_per_method_platform":576},
        "budget_per_method_platform":2880,"total_tuning_evaluations":23040,
        "development_scenarios":DEVELOPMENT,"test_trajectories":TEST_TRAJECTORIES,
        "test_currents":{"native":[0.],"otter":[0.,.10,.20]},
        "selection_resolution_m":resolutions,"default_numerical_limitations":unresolved,
        "selection_rule":"failure count, equal-weight mean J, measured-resolution tie on actual force effort, candidate id",
        "primary_contrasts":12,"bootstrap_resamples":20000,"bootstrap_seed":880031,
        "simultaneous_CI":"studentized maximum absolute centered bootstrap mean; paired seed blocks; family of 12",
        "missing_rule":"Withhold the full primary family if a required designed endpoint is missing/nonfinite; no imputation",
        "numeric_rule":"Direction interpreted only when contrast exceeds summed per-arm numerical error bounds",
        "shared_execution":"One job_id for identical physical execution; design references do not add samples"}
    protocol["protocol_hash"] = digest(protocol)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(protocol,indent=2,allow_nan=False),encoding="utf-8")
    return protocol


def training_rows(protocol):
    for platform in SEEDS:
        for method in METHODS:
            for candidate in protocol["candidates"][platform][method]:
                for model in MODELS:
                    for seed in SEEDS[platform]["train"]:
                        for trajectory in DEVELOPMENT:
                            job = job_for(platform,model,method,seed,trajectory,"train",candidate["candidate"])
                            yield {"job":asdict(job),"parameters":candidate["parameters"]}


def assert_seed_isolation():
    groups = [set(seeds) for stages in SEEDS.values() for seeds in stages.values()]
    groups += [set([29000,29001,29002]),set([39000,39001,39002,39003,39100,39101,39102,39103])]
    for i, group in enumerate(groups):
        for other in groups[i+1:]:
            assert not group&other
