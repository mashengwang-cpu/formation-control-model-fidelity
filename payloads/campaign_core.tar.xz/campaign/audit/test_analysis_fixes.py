"""Synthetic contracts only; does not read scientific outcomes."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
WORK=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(WORK))
from analyse_campaign import simultaneous,paired_values,blocks,numerical_qualification
DEST=WORK/'audit/analysis_synthetic';DEST.mkdir(parents=True,exist_ok=True)
seeds={'native':list(range(50)),'otter':list(range(100,150))}
rng=np.random.default_rng(19)
matrix=rng.normal(size=(50,12));matrix[:,0]=0.;matrix[:,7]=2.
meta=[dict(column=i) for i in range(12)]
r=simultaneous(list(matrix.T),meta,DEST,730001,seeds)
assert r['positive_variance_columns']==10 and r['critical_value']>0
for i in [0,7]:
    assert meta[i]['lower_m'] is None and meta[i]['upper_m'] is None
    assert meta[i]['interval_status']=='empirical_degenerate_no_equivalence_claim'
assert all(meta[i]['lower_m']<meta[i]['mean_m']<meta[i]['upper_m'] for i in range(12) if i not in [0,7])
saved=pd.read_csv(DEST/'paired_block_matrix.csv')
assert saved.native_seed.tolist()==seeds['native'] and saved.otter_seed.tolist()==seeds['otter']
allzero=DEST/'allzero';allzero.mkdir(exist_ok=True)
r0=simultaneous([np.zeros(50) for _ in range(12)],[{} for _ in range(12)],allzero,730002,seeds)
assert r0['positive_variance_columns']==0 and all(x['lower_m'] is None for x in r0['contrasts'])
rows=[dict(platform='otter',seed=s,trajectory=t,current=c,method='full',complete=True,J_m=s+c)
      for s in seeds['otter'] for t in ['ellipse','double_sine','speed_line'] for c in [0.,.1,.2]]
frame=pd.DataFrame(rows).sample(frac=1,random_state=7)
v=paired_values(frame,'otter',seeds['otter'],{'method':'full'})
np.testing.assert_allclose(blocks(v,seeds['otter']),np.arange(100,150)+.1)
rejected=0
for broken in [frame.iloc[1:],pd.concat([frame,frame.iloc[:1]])]:
    try:paired_values(broken,'otter',seeds['otter'],{'method':'full'})
    except AssertionError:rejected+=1
assert rejected==2
sparse=DEST/'sparse';sparse.mkdir(exist_ok=True)
sparse_array=np.zeros(50);sparse_array[0]=1.
rs=simultaneous([sparse_array.copy() for _ in range(12)],[{} for _ in range(12)],sparse,730003,seeds)
assert rs['critical_value'] is None and all(x['interval_status']=='critical_value_unavailable' for x in rs['contrasts'])
fixture=DEST/'numerical_fixture'
for sub in ['test','numerical']:(fixture/sub).mkdir(parents=True,exist_ok=True)
job=dict(platform='native',model='point',method='full')
(fixture/'test/design.json').write_text(json.dumps({'rows':[dict(job=job,parameters=[1.],background='a')]}))
for i in range(6):
    (fixture/f'numerical/{i}.json').write_text(json.dumps(dict(case_id=str(i),job=job,parameters=[1.],status='evaluated',comparisons=[dict(physics_dt=.00125,pass_=True)] )).replace('"pass_"','"pass"'))
    record=json.loads((fixture/f'numerical/{i}.json').read_text());record['comparisons'][0]['J_difference_m']=.001
    (fixture/f'numerical/{i}.json').write_text(json.dumps(record))
m=[dict(mean_m=.01,_terms=[(dict(**job,background='a'),2)])]
numerical_qualification(fixture,m)
assert m[0]['numerical_qualified'] and m[0]['observed_discrepancy_sum_m']==.002 and m[0]['effect_exceeds_observed_discrepancy']
record=json.loads((fixture/'numerical/0.json').read_text());record['comparisons'][0]['pass']=False
(fixture/'numerical/0.json').write_text(json.dumps(record))
m=[dict(mean_m=.01,_terms=[(dict(**job,background='a'),2)])]
numerical_qualification(fixture,m)
assert not m[0]['numerical_qualified']
print(json.dumps({'status':'pass','positive_variance_columns':10,'degenerate_columns_retained':2,'all_zero_family_retained':True,'paired_blocks':50,'missing_and_duplicate_rejections':2}))
