if not __debug__:
    raise RuntimeError('Run without Python -O; validation assertions are required.')
"""Read frozen development archives and audit tie-breaking without test outcomes."""
from pathlib import Path
from collections import defaultdict
import csv, gzip, hashlib, json, tarfile, os
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
CODE = Path(os.environ.get('FORMATION_REPRO_PACKAGE',
    str(ROOT / '2026-09-08_GitHub精简复现交付/formation-control-repro')))
OUT = Path(__file__).resolve().parent
with gzip.open(CODE/'provenance/INPUT_MEMBERS.csv.gz', 'rt', encoding='utf-8') as f:
    ledger = {r['path']: r for r in csv.DictReader(f)}
records, frozen = [], {}
for bundle in ['controlled.tar.xz', 'development.tar.xz']:
    with tarfile.open(CODE/'payloads'/bundle) as archive:
        for member in archive:
            name = member.name
            if '/campaign/' not in name:
                continue
            wanted = name.endswith(('/protocol.json', '/selection.json', '/shortlist.json'))
            job = '/train/jobs/' in name or '/validation/jobs/' in name
            if not (wanted or job):
                continue
            raw = archive.extractfile(member).read()
            assert hashlib.sha256(raw).hexdigest() == ledger[name]['sha256']
            obj = json.loads(raw)
            if job:
                records.append(obj)
            else:
                frozen[Path(name).name] = obj
assert len(records) == 23040
protocol = frozen['protocol.json']
groups = defaultdict(list)
for r in records:
    j = r['job']
    groups[(j['platform'], j['method'], j['model'], j['stage'])].append(r)
rows = []
for (platform, method, model, stage), records in sorted(groups.items()):
    candidates = defaultdict(list)
    for r in records:
        candidates[r['job']['candidate']].append(r)
    summaries = []
    for cid, items in candidates.items():
        valid = [r for r in items if r['metrics']['complete']]
        summaries.append(dict(candidate=cid, failures=len(items)-len(valid),
            mean_J=np.mean([r['metrics']['J_m'] for r in valid]) if valid else np.inf,
            effort=np.mean([r['metrics']['force_effort_N2s'] for r in valid]) if valid else np.inf))
    tolerance = protocol['selection_resolution_m'][platform][model]
    remaining = sorted(summaries, key=lambda x:(x['failures'],x['mean_J'],x['candidate']))
    ordered, tie_sizes = [], []
    while remaining:
        best = remaining[0]
        tied = [r for r in remaining if r['failures']==best['failures'] and r['mean_J']<=best['mean_J']+tolerance]
        winner = min(tied, key=lambda x:(x['effort'],x['candidate']))
        ordered.append(winner['candidate']); tie_sizes.append(len(tied)); remaining.remove(winner)
    if stage == 'train':
        expected = [r['candidate'] for r in frozen['shortlist.json'][platform][method][model]]
        assert ordered[:8] == expected
        used = 8
    else:
        assert stage == 'validation'
        assert ordered[0] == frozen['selection.json']['choices'][platform][method][model]['candidate']
        used = 1
    rows.append(dict(platform=platform, method=method, model=model, stage=stage,
        evaluations=len(records), candidates=len(candidates), tolerance_m=tolerance,
        relevant_selection_steps=used, steps_with_multiple_tied_candidates=sum(s>1 for s in tie_sizes[:used]),
        winner_candidate=ordered[0]))
assert len(rows)==48
with (OUT/'selection_tie_audit.csv').open('w', newline='', encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
report=dict(status='pass', development_evaluations=23040,
    training_shortlists_reconstructed=24, validation_selections_reconstructed=24,
    selection_resolution_m=protocol['selection_resolution_m'],
    relevant_tie_steps=sum(r['steps_with_multiple_tied_candidates'] for r in rows),
    definition='Multiple candidates eligible at a retained shortlist step or validation winner step; not only ties that change the lowest-J winner.')
(OUT/'selection_tie_summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
