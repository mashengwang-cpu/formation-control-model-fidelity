if not __debug__:
    raise RuntimeError('Run without Python -O; validation assertions are required.')
"""Independent group/pivot reconstruction of published and added contrasts."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

H = Path(__file__).resolve().parent
d = pd.read_csv(H / 'designed_test_outcomes.csv', float_precision='round_trip')
p = pd.read_csv(H / 'primary_contrasts.csv', float_precision='round_trip')
out = pd.read_csv(H / 'exploratory_direct_contrasts.csv', float_precision='round_trip')
vectors = []
assert d.complete.eq(True).all() and np.isfinite(d.J_m).all()
assert len(d) == 16800 and d.job_id.nunique() == 12150
assert d.groupby('platform').seed.nunique().eq(50).all()
# Pivot block averages, independently of the scenario-level join in the producer.
g = d.groupby(['platform', 'seed', 'method', 'strategy', 'model']).J_m.mean()
for platform in ['native', 'otter']:
    q = g.loc[platform].unstack(['method', 'strategy', 'model'])
    def arm(method, strategy, model):
        a = q[(method, strategy, model)]
        assert len(a) == 50 and np.isfinite(a).all()
        return a.copy()
    for row in p.loc[p.platform == platform].to_dict('records'):
        if row['type'] == 'complete_method':
            comp = row['comparison'].split('full_minus_')[1]
            s = row['strategy']
            x = arm('full', s, 'rigid') - arm(comp, s, 'rigid')
            x -= arm('full', s, 'point') - arm(comp, s, 'point')
        else:
            k = row['comparison']
            x = arm(k, 'fixed_full_background', 'rigid') - arm('full', 'transfer', 'rigid')
            x -= arm(k, 'fixed_full_background', 'point') - arm('full', 'transfer', 'point')
        np.testing.assert_allclose(x.mean(), row['mean'], atol=1e-12, rtol=0)
    for row in out.loc[out.platform == platform].to_dict('records'):
        if row['contrast'] == 'retuned_minus_transfer':
            comp = row['comparison'].split('full_minus_')[1]
            # Point-selected and retuned point arms share executions by design.
            x = arm('full', 'retuned', 'rigid') - arm(comp, 'retuned', 'rigid')
            x -= arm('full', 'transfer', 'rigid') - arm(comp, 'transfer', 'rigid')
        else:
            x = arm(row['comparison'], 'fixed_full_background', row['model'])
            x -= arm('full', 'transfer', row['model'])
        np.testing.assert_allclose(x.mean(), row['mean_m'], atol=1e-12, rtol=0)
        assert row['lower_m'] <= row['mean_m'] <= row['upper_m']
        vectors.append(x.to_numpy())
matrix = np.column_stack(vectors)
saved = pd.read_csv(H/'exploratory_seed_matrix.csv', float_precision='round_trip')
assert saved.native_seed.tolist() == list(range(40000,40050))
assert saved.otter_seed.tolist() == list(range(50000,50050))
np.testing.assert_allclose(matrix, saved[[f'contrast_{i+1}' for i in range(12)]], atol=1e-12, rtol=0)
generator = np.random.default_rng(880041)
pivots = []
for _ in range(200):
    indices_native = generator.integers(0,50,(100,50))
    indices_otter = generator.integers(0,50,(100,50))
    for native, otter in zip(indices_native, indices_otter):
        sampled = np.hstack((matrix[native,:6], matrix[otter,6:]))
        studentized = abs(sampled.mean(0)-matrix.mean(0))/(sampled.std(0,ddof=1)/np.sqrt(50))
        assert np.isfinite(studentized).all()
        pivots.append(max(studentized))
critical = np.quantile(pivots,.95)
standard_errors = matrix.std(0,ddof=1)/np.sqrt(50)
np.testing.assert_allclose(matrix.mean(0)-critical*standard_errors,out.lower_m,atol=1e-12,rtol=0)
np.testing.assert_allclose(matrix.mean(0)+critical*standard_errors,out.upper_m,atol=1e-12,rtol=0)
result = {'status': 'pass', 'design_references': len(d), 'unique_executions': d.job_id.nunique(),
          'primary_means_independently_reconstructed': 12,
          'exploratory_means_independently_reconstructed': 12,
          'bootstrap_endpoints_independently_reconstructed':24,
          'critical_value':float(critical),
          'validation_method': 'block-first group/pivot, distinct from condition-first producer'}
(H / 'independent_verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
