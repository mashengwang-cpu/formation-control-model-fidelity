if not __debug__:
    raise RuntimeError('Run without Python -O; validation assertions are required.')
"""Post hoc condition sensitivity. Does not refit or select any controller."""
from pathlib import Path
import csv
import gzip
import hashlib
import json
import os
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CODE = Path(os.environ.get('FORMATION_REPRO_PACKAGE',
    str(ROOT / '2026-09-08_GitHub精简复现交付/formation-control-repro')))


def run():
    with gzip.open(CODE / 'provenance/INPUT_MEMBERS.csv.gz', 'rt', encoding='utf-8') as f:
        ledger = list(csv.DictReader(f))
    hashes = {}
    for name in ('designed_test_outcomes.csv', 'primary_contrasts.csv'):
        digest = hashlib.sha256((HERE / name).read_bytes()).hexdigest()
        matches = [r for r in ledger if r['path'].endswith('/' + name)]
        assert len(matches) == 1 and matches[0]['sha256'] == digest, name
        hashes[name] = digest
    data = pd.read_csv(HERE / 'designed_test_outcomes.csv', float_precision='round_trip')
    frozen = pd.read_csv(HERE / 'primary_contrasts.csv', float_precision='round_trip')
    keys = ['trajectory', 'current', 'seed']
    output = []
    for c in frozen.to_dict('records'):
        if c['type'] == 'complete_method':
            other = c['comparison'].removeprefix('full_minus_')
            terms = [('full', c['strategy'], 'rigid', 1),
                     (other, c['strategy'], 'rigid', -1),
                     ('full', c['strategy'], 'point', -1),
                     (other, c['strategy'], 'point', 1)]
        else:
            terms = [(c['comparison'], 'fixed_full_background', 'rigid', 1),
                     ('full', 'transfer', 'rigid', -1),
                     (c['comparison'], 'fixed_full_background', 'point', -1),
                     ('full', 'transfer', 'point', 1)]
        values = []
        for method, strategy, model, sign in terms:
            part = data.loc[(data.platform == c['platform']) & (data.method == method)
                            & (data.strategy == strategy) & (data.model == model)]
            assert len(part) and part.complete.eq(True).all()
            assert not part.duplicated(keys).any()
            assert np.isfinite(part.J_m).all()
            values.append(part.set_index(keys).J_m.sort_index() * sign)
        assert all(s.index.equals(values[0].index) for s in values)
        paired = sum(values)
        assert paired.groupby(level=['trajectory', 'current']).size().eq(50).all()
        estimate = paired.groupby(level='seed').mean().mean()
        assert abs(estimate - c['mean']) < 1e-12, (c['contrast_index'], estimate, c['mean'])
        rows = paired.rename('contrast_m').reset_index()
        for field in ('contrast_index', 'platform', 'type', 'strategy', 'comparison'):
            rows[field] = c[field]
        output.append(rows)
    paired = pd.concat(output, ignore_index=True)
    meta = ['contrast_index', 'platform', 'type', 'strategy', 'comparison']
    scenarios = paired.groupby(meta + ['trajectory', 'current'], as_index=False).agg(
        mean_m=('contrast_m', 'mean'), n_seed_blocks=('seed', 'nunique'))
    exclusions = []
    summaries = []
    for cid, part in paired.groupby('contrast_index'):
        c = frozen.loc[frozen.contrast_index == cid].iloc[0]
        for axis in ['trajectory'] + (['current'] if c.platform == 'otter' else []):
            for excluded in sorted(part[axis].unique()):
                subset = part.loc[part[axis] != excluded]
                value = subset.groupby('seed').contrast_m.mean().mean()
                exclusions.append(dict(contrast_index=int(cid), platform=c.platform,
                    omitted_axis=axis, omitted_value=str(excluded), mean_m=float(value),
                    same_sign_as_aggregate=bool(np.sign(value) == np.sign(c['mean']))))
        cond = scenarios.loc[scenarios.contrast_index == cid]
        summaries.append(dict(contrast_index=int(cid), platform=c.platform,
            aggregate_m=float(c['mean']), scenario_min_m=float(cond.mean_m.min()),
            scenario_max_m=float(cond.mean_m.max()), n_conditions=len(cond),
            conditions_opposite_sign=int((np.sign(cond.mean_m) != np.sign(c['mean'])).sum())))
    assert len(scenarios) == 72 and len(exclusions) == 54
    paired.to_csv(HERE / 'per_seed_scenario_contrasts.csv', index=False)
    scenarios.to_csv(HERE / 'scenario_sensitivity.csv', index=False)
    pd.DataFrame(exclusions).to_csv(HERE / 'leave_one_condition_out.csv', index=False)
    result = dict(status='verified descriptive post hoc analysis', source_sha256=hashes,
                  paired_rows=len(paired), scenario_rows=len(scenarios),
                  omission_rows=len(exclusions), primary_means_reproduced=12,
                  summary=summaries, omission_sign_changes=[r for r in exclusions
                    if not r['same_sign_as_aggregate']])
    (HERE / 'sensitivity_summary.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    run()
