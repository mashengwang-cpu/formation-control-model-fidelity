# Exploratory direct-contrast analysis

This analysis is specified after the existing primary results were inspected. It is not preregistered and does not replace the frozen twelve-contrast primary family.

Estimate four paired changes in model interaction (retuned minus transfer, Full minus Minimal/Family, separately by platform), plus eight local deletion-minus-Full effects (two modules, two model layers, two platforms). Hold the point-selected Full parameter background fixed for all deletion contrasts.

Aggregate trajectories and currents equally within each seed before inference. Use 50 paired blocks per platform. Construct one exploratory twelve-contrast family with 20,000 maximum studentized bootstrap draws, independent platform resampling, fixed RNG seed 880041. Report nominal simultaneous intervals within this new family only, not across all manuscript analyses. Stop inference for any missing arm or degenerate pivot. Preserve original primary estimates and intervals verbatim.

These estimates do not quantify variability across independent tuning searches or establish engineering equivalence.
