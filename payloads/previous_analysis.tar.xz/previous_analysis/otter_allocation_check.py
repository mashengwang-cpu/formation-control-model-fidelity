if not __debug__:
    raise RuntimeError('Run without Python -O; validation assertions are required.')
"""Steady unsaturated allocation examples, not additional flight/vessel trials."""
import os, sys, json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
default=HERE.parents[1]/'2026-09-08_GitHub精简复现交付/formation-control-repro'
code=Path(os.environ.get('FORMATION_REPRO_PACKAGE',str(default)))
vendor=code/'vendor/PythonVehicleSimulator/src'
sys.path.insert(0,str(vendor))
from python_vehicle_simulator.vehicles.otter import otter
boat=otter()
rows=[]
for name, surge, yaw in [('forward',20.,0.),('reverse',-20.,0.),('differential',0.,7.9)]:
    n=np.array(boat.controlAllocation(surge,yaw))
    assert ((n>=boat.n_min)&(n<=boat.n_max)).all()
    thrust=np.where(n>=0,boat.k_pos,boat.k_neg)*n*np.abs(n)
    actual=np.array([thrust.sum(),-boat.l1*thrust[0]-boat.l2*thrust[1]])
    rows.append(dict(case=name,requested_surge_N=surge,requested_yaw_Nm=yaw,
        actual_surge_N=float(actual[0]),actual_yaw_Nm=float(actual[1]),
        surge_residual_N=float(actual[0]-surge),yaw_residual_Nm=float(actual[1]-yaw)))
ratio=boat.k_neg/boat.k_pos
np.testing.assert_allclose(rows[0]['actual_surge_N'],20.,rtol=1e-14)
np.testing.assert_allclose(rows[1]['actual_surge_N'],-20.*ratio,rtol=1e-14)
np.testing.assert_allclose(rows[2]['actual_surge_N'],10.*(1-ratio),rtol=1e-14)
np.testing.assert_allclose(rows[2]['actual_yaw_Nm'],3.95*(1+ratio),rtol=1e-14)
pd.DataFrame(rows).to_csv(HERE/'otter_allocation_examples.csv',index=False)
source=vendor/'python_vehicle_simulator/vehicles/otter.py'
result=dict(status='pass',scope='algebraic steady unsaturated map only; no new vessel trajectories',
    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),reverse_forward_ratio=ratio,rows=rows)
(HERE/'otter_allocation_summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
