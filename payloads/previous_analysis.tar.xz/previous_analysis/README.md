# Supplementary reproduction addendum

This addendum reproduces Supplementary Section S15. It is separate from the immutable public compact package at GitHub commit fbfa3fb2a2eb6eb2e63f28258e1ab59db86a84f5. The original simulation results, selected parameters and twelve primary confidence intervals have not changed. New direct contrasts and condition-sensitivity analyses are post hoc. The allocation examples are algebraic, not vessel trials.

The base package ZIP is included one directory above. Extract it first. Use its documented Python dependencies. This addendum was checked with the supplied Windows Python environment; no cross-platform test is claimed. Do not use Python -O.

Run in this addendum directory, setting the extracted package location explicitly. PowerShell example:

```powershell
$env:FORMATION_REPRO_PACKAGE = 'C:\path\to\formation-control-repro'
python -B direct_contrasts.py
python -B verify_analysis.py
python -B selection_audit.py
python -B otter_allocation_check.py
```

The first command checks input hashes against the base package ledger and regenerates scenario and direct-contrast outputs. The second independently reconstructs block-level means, the labeled seed matrix and all bootstrap interval endpoints. The third reads only frozen development archives and replays shortlist and final selection. The fourth calls the frozen upstream Otter allocation and checks its steady unsaturated thrust map. None launches a simulation campaign or reselects parameters using test results.

Files include frozen input CSVs, explicit protocols, scripts, full-precision CSV outputs and machine-readable summaries. Native and Otter seed identities and contrast column IDs are provided. CSV values are in meters unless the column unit indicates otherwise. The 72 condition means and 54 omission means are descriptive; they are not 126 new significant results. The exploratory twelve-contrast interval family is separate from the primary family and does not provide joint coverage across all manuscript analyses.

Original code is MIT; original data are CC BY 4.0. Third-party licenses remain as distributed in the base package. Full original time-series and PX4 raw logs remain outside this compact release and are not claimed to be publicly archived here.
