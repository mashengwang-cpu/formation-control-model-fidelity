if not __debug__:
    raise RuntimeError('Run without Python -O; validation assertions are required.')
"""Exploratory direct strategy and local deletion contrasts from frozen records."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scenario_sensitivity import run as validate_sources

HERE = Path(__file__).resolve().parent


def run():
    validate_sources()
    d = pd.read_csv(HERE / 'designed_test_outcomes.csv', float_precision='round_trip')
    p = pd.read_csv(HERE / 'per_seed_scenario_contrasts.csv', float_precision='round_trip')
    arrays, meta = [], []
    for platform in ('native', 'otter'):
        subset = d.loc[d.platform == platform]
        seeds = sorted(subset.seed.unique())
        assert len(seeds) == 50
        def interaction(strategy, comparator):
            rows = p.loc[(p.platform == platform) & (p.strategy == strategy)
                         & (p.comparison == 'full_minus_' + comparator)]
            s = rows.groupby('seed').contrast_m.mean().reindex(seeds)
            assert np.isfinite(s).all()
            return s.to_numpy()
        for comparator in ('minimal', 'family'):
            arrays.append(interaction('retuned', comparator) - interaction('transfer', comparator))
            meta.append(dict(platform=platform, contrast='retuned_minus_transfer',
                             comparison='full_minus_' + comparator, model='rigid_minus_point'))
        for module in ('no_schedule', 'no_powers'):
            for model in ('point', 'rigid'):
                keys = ['seed', 'trajectory', 'current']
                a = subset.loc[(subset.method == module) & (subset.model == model)
                               & (subset.strategy == 'fixed_full_background')]
                b = subset.loc[(subset.method == 'full') & (subset.model == model)
                               & (subset.strategy == 'transfer')]
                assert a.complete.eq(True).all() and b.complete.eq(True).all()
                assert not a.duplicated(keys).any() and not b.duplicated(keys).any()
                a = a.set_index(keys).J_m.sort_index()
                b = b.set_index(keys).J_m.sort_index()
                assert a.index.equals(b.index)
                diff = (a - b).groupby('seed').mean().reindex(seeds)
                assert np.isfinite(diff).all()
                arrays.append(diff.to_numpy())
                meta.append(dict(platform=platform, contrast='deletion_minus_full',
                                 comparison=module, model=model))
    matrix = np.column_stack(arrays)
    mean = matrix.mean(axis=0)
    se = matrix.std(axis=0, ddof=1) / np.sqrt(50)
    assert matrix.shape == (50, 12) and (se > 0).all()
    rng = np.random.default_rng(880041)
    maxima = []
    for _ in range(200):
        sample = np.concatenate([matrix[rng.integers(0, 50, (100, 50)), :6],
                                 matrix[rng.integers(0, 50, (100, 50)), 6:]], axis=2)
        sample_se = sample.std(axis=1, ddof=1) / np.sqrt(50)
        assert (sample_se > 0).all()
        maxima.extend(np.max(np.abs(sample.mean(axis=1) - mean) / sample_se, axis=1))
    critical = float(np.quantile(maxima, .95))
    for i, row in enumerate(meta):
        row['contrast_id'] = f'contrast_{i+1}'
        row.update(mean_m=float(mean[i]), lower_m=float(mean[i] - critical * se[i]),
                   upper_m=float(mean[i] + critical * se[i]), n_seed_blocks=50)
    pd.DataFrame(meta).to_csv(HERE / 'exploratory_direct_contrasts.csv', index=False)
    seed_table = pd.DataFrame(matrix, columns=[f'contrast_{i+1}' for i in range(12)])
    seed_table.insert(0, 'otter_seed', sorted(d.loc[d.platform=='otter'].seed.unique()))
    seed_table.insert(0, 'native_seed', sorted(d.loc[d.platform=='native'].seed.unique()))
    seed_table.to_csv(HERE / 'exploratory_seed_matrix.csv', index=False)
    result = dict(analysis='exploratory, post hoc', family_size=12,
                  resamples=20000, rng_seed=880041, critical_value=critical, rows=meta)
    (HERE / 'direct_contrasts_summary.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    run()
