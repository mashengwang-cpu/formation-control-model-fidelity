# 事后场景敏感性分析协议
不新增确认性p值，不改原主终点、原12项检验族或置信区间。仅对现有逐执行指标开展描述性分层与影响分析。
1. 输入来自冻结summaries.tar.xz的designed_test_outcomes.csv及primary_contrasts.csv，核对INPUT_MEMBERS来源哈希。
2. 所有方法按平台、场景和seed成对。完整方法用(Full-C)_rigid-(Full-C)_point；删除用(Deletion-Full)_rigid-(Deletion-Full)_point。
3. 平台内场景定义为trajectory与current；每个场景50个seed，方法组合不得缺失，不补零。
4. 输出12项原聚合、72个场景均值，以及删除一个轨迹/流速水平后剩余场景等权平均。对照原聚合均值；不以符号稳定定义统计显著或工程重要性。
5. 检查场景均值的等权平均与直接seed聚合结果一致。所有正负反例完整输出，不选择有利场景。
6. 本协议在该新增脚本读取场景数值前保存，但分析是见过旧主结果后提出，不能称预注册。
