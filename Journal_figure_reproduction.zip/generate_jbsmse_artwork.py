"""Journal-size rendering of frozen data. No fitting or simulation is performed."""
from pathlib import Path
import sys,json,hashlib,importlib.util
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.text import Text,Annotation
from matplotlib.lines import Line2D
from matplotlib.collections import Collection
from matplotlib.patches import Patch
ROOT=Path(__file__).resolve().parent
OUT=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'artwork'
OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'baseline/tools'));sys.path.insert(0,str(ROOT/'baseline'))
import publication_style as st
import publication_figures as old
import publication_schematics as sch
from enhancement import figures as ctrl
ONLY=set(sys.argv[2:])
REPORT=json.loads((OUT/'render_records.json').read_text(encoding='utf8')) if ONLY and (OUT/'render_records.json').exists() else {}
def signature(fig):
    data=[]
    for ax in fig.axes:
        data.append({'xlim':ax.get_xlim(),'ylim':ax.get_ylim(),'scales':[ax.get_xscale(),ax.get_yscale()],
         'lines':[(np.asarray(l.get_xdata()).tolist(),np.asarray(l.get_ydata()).tolist()) for l in ax.lines],
         'collections':[(np.asarray(c.get_offsets()).tolist(),[p.vertices.tolist() for p in c.get_paths()]) for c in ax.collections]})
    return hashlib.sha256(json.dumps(data,default=str,sort_keys=True).encode()).hexdigest()
def render(fig,name,sources=(),records=None):
    if ONLY and name not in ONLY:plt.close(fig);return {}
    fig.canvas.draw();before=signature(fig)
    removed=[]
    if name=='Fig2':
        for legend in fig.legends:
            if legend.get_title().get_text():removed.append(legend.get_title().get_text());legend.set_title('')
    # Full-sentence figure-level notes are represented by manuscript captions.
    for t in list(fig.texts):
        if t.get_text().strip():removed.append(t.get_text());t.remove()
    for ax in fig.axes:
        for t in list(ax.texts):
            note=t.get_text()
            if note.startswith(('Matched initial states,','Simulated measurements:','Convergence unresolved')):
                removed.append(note);t.remove()
    # Panel condition labels are concise identifiers, not whole-figure titles.
    # Keep these to preserve direct interpretation of model and strategy.
    w,h=fig.get_size_inches()*25.4
    scale=min(174/w,175/h)
    fig.set_size_inches(w*scale/25.4,h*scale/25.4,forward=True)
    for t in fig.findobj(match=Text):
        t.set_fontsize(max(8.4,min(11.0,t.get_fontsize()*scale)))
    for l in fig.findobj(match=Line2D):
        if l.get_linewidth()>0:l.set_linewidth(max(.45,l.get_linewidth()*scale))
        if l.get_markeredgewidth()>0:l.set_markeredgewidth(max(.45,l.get_markeredgewidth()*scale))
    for ax in fig.axes:
        for p in list(ax.patches)+list(ax.spines.values()):
            if p.get_linewidth()>0:p.set_linewidth(max(.45,p.get_linewidth()*scale))
        for c in ax.collections:
            lw=np.array(c.get_linewidths());c.set_linewidths(np.where(lw>0,np.maximum(.45,lw*scale),lw))
    for p in fig.findobj(match=Patch):
        if p.get_linewidth()>0:p.set_linewidth(max(.45,p.get_linewidth()))
    for c in fig.findobj(match=Collection):
        lw=np.array(c.get_linewidths());c.set_linewidths(np.where(lw>0,np.maximum(.45,lw),lw))
    fig.canvas.draw(); assert signature(fig)==before,name+' data geometry changed'
    renderer=fig.canvas.get_renderer();outside=[]
    for t in fig.findobj(match=Text):
        if not t.get_visible() or not t.get_text().strip():continue
        bb=t.get_window_extent(renderer)
        # Tick labels outside the active axis limits are not rendered.
        if bb.x0 < -2 or bb.y0 < -2 or bb.x1>fig.bbox.width+2 or bb.y1>fig.bbox.height+2:outside.append(t.get_text())
    for ext in ['pdf','svg','png']:
        md={'CreationDate':None,'ModDate':None,'Creator':'Matplotlib'} if ext=='pdf' else {'Date':None} if ext=='svg' else None
        fig.savefig(OUT/(name+'.'+ext),dpi=300,metadata=md)
    REPORT[name]={'removed_notes':removed,'width_mm':w*scale,'height_mm':h*scale,'minimum_text_artist_pt':8.4,'minimum_nonzero_linewidth_pt':.45,'data_geometry_sha256':before,'geometry_unchanged':True,'outside_text_candidates':outside,'sources':[{'name':str(p),'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in sources], 'records':records}
    plt.close(fig);print(name,flush=True)
    return REPORT[name]
mapping={'Figure_1':'Fig5','Figure_2':'Fig6','Figure_3':'Fig7','Figure_4':'Fig8','Figure_5':'Fig9','Figure_6':'Fig10','Figure_S1':'FigS2','Figure_S2':'FigS3','Figure_S3':'FigS4','Figure_S4':'FigS5'}
def oldsave(fig,name,out,sources,caption,panels=False):return render(fig,mapping[name],sources,[getattr(ax,'_plot_records',[]) for ax in fig.axes])
old.save=oldsave;sch.save=oldsave
for f in [sch.protocol,old.core,old.modules,old.attitude,old.information,old.px4,lambda o:old.sensitivity(o,False),lambda o:old.sensitivity(o,True),old.robustness,old.attitude_stress]:f(OUT)
def export(fig,name,output,records,sources,caption):
    if output.name=='panels':plt.close(fig);return {}
    return render(fig,{'Figure_7':'Fig3','Figure_8':'Fig4','Figure_S5':'FigS1'}[name],sources,records)
ctrl.export=export
a=ROOT/'baseline/data/analysis'
ctrl.performance(pd.read_csv(a/'paired_seed_blocks.csv'),pd.read_csv(a/'secondary_method_summaries.csv'),OUT,[a/'paired_seed_blocks.csv',a/'secondary_method_summaries.csv'])
ctrl.primary(pd.read_csv(a/'primary_contrasts.csv'),OUT,[a/'primary_contrasts.csv'])
ctrl.numerical(pd.read_csv(a/'numerical_plot_values.csv',float_precision='round_trip'),OUT,[a/'numerical_plot_values.csv'])
spec=importlib.util.spec_from_file_location('newplot',ROOT/'new_search/plot_new_results.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
for name,fn in [('Fig1',lambda:m.figure9(m.read_table('search_contrasts.csv',36))),('Fig2',lambda:m.figure10(m.read_table('local_effects.csv',24),m.read_table('background_contrasts.csv',12))),('FigS6',lambda:m.figureS6(m.read_table('local_effects.csv',24)))]:
    start=len(m.PLOTTED);render(fn(),name,list((ROOT/'new_search/source_data').glob('*.csv')),m.PLOTTED[start:])
(OUT/'render_records.json').write_text(json.dumps(REPORT,ensure_ascii=False,indent=2,default=lambda v:v.item() if isinstance(v,np.generic) else str(v)),encoding='utf8')
