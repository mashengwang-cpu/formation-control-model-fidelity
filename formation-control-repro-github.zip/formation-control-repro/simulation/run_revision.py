"""Execute the frozen revision design with resumable per-job evidence."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time
import traceback
import zipfile

for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(key, "1")
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from finite_control_sim.config import load_config, parse_config
from finite_control_sim.controllers import get_method_spec, spec_with_gains
from finite_control_sim.simulator import SimulationJob, simulate_job
from revision_design import digest

ROOT = Path(__file__).resolve().parents[1]


def atomic_json(path: Path, value: object):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def source_record():
    files = sorted((ROOT / "simulation" / "src").rglob("*.py"))
    files += [Path(__file__).resolve(), ROOT / "simulation/revision_design.py",
              ROOT / "simulation/configs/stage2_final.json"]
    return {str(p.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in files}


def run_one(payload):
    row, base_config, out, provenance_id = payload
    out = Path(out)
    config_raw = json.loads(json.dumps(base_config))
    config_raw["simulation"].update(row["simulation_overrides"])
    config = parse_config(config_raw)
    job = SimulationJob(**row["job"])
    started = time.perf_counter()
    record = dict(job_id=row["job_id"], provenance_id=provenance_id,
                  started_utc=datetime.now(timezone.utc).isoformat(), job=asdict(job),
                  configuration=config_raw, status="error")
    try:
        output = simulate_job(config, job)
        arrays = {"times": output.times, "tracking_errors": output.tracking_errors,
                  "controls": output.controls, "actual_controls": output.actual_controls,
                  "trigger_events": output.trigger_events,
                  "physical_position_errors": output.physical_position_errors,
                  "held_position_errors": output.held_position_errors,
                  "sensor_biases": output.sensor_biases, "bias_estimates": output.bias_estimates,
                  "actuator_efficiencies": output.actuator_efficiencies,
                  "actuator_efficiency_estimates": output.actuator_efficiency_estimates,
                  "uav_altitudes": output.uav_altitudes, "uav_tilts": output.uav_tilts,
                  "uav_attitude_errors": output.uav_attitude_errors,
                  "actual_force_interval_effort": output.actual_force_interval_effort,
                  "usv_yaw_interval_effort": output.usv_yaw_interval_effort}
        arrays = {k: v for k, v in arrays.items() if v is not None}
        for name, array in arrays.items():
            if not np.isfinite(array).all():
                raise FloatingPointError(f"Nonfinite trajectory: {name}")
        trace_path = out / "traces" / f"{row['job_id']}.npz"
        np.savez_compressed(trace_path, **arrays)
        dt = np.diff(output.times)
        duration = float(output.times[-1] - output.times[0])
        mean_error = np.mean(output.tracking_errors, axis=1)
        metrics = {k: (float(v) if np.isfinite(v) else None) for k, v in output.metrics.items()}
        metrics["legacy_sample_mean_error"] = metrics["formation_tracking_error"]
        metrics["legacy_trapezoid_command_effort"] = metrics["control_energy"]
        metrics["legacy_endpoint_inclusive_refresh_count"] = metrics["event_trigger_count"]
        metrics["formation_tracking_error"] = float(np.sum(0.5 * (mean_error[1:] + mean_error[:-1]) * dt) / duration)
        metrics["control_energy"] = float(np.sum(np.sum(output.controls[:-1] ** 2, axis=(1, 2)) * dt))
        metrics["control_energy_per_agent_time"] = metrics["control_energy"] / (duration * output.controls.shape[1])
        metrics["xy_formation_tracking_error"] = metrics["formation_tracking_error"]
        for key, sl in (("uav_tracking_error", slice(0, job.uav_count)),
                        ("usv_tracking_error", slice(job.uav_count, job.uav_count + job.usv_count))):
            errors = output.tracking_errors[:, sl]
            if errors.shape[1]:
                series = errors.mean(axis=1)
                metrics[key] = float(np.sum(0.5 * (series[1:] + series[:-1]) * dt) / duration)
        if output.actual_force_interval_effort is None:
            raise ValueError("Revision raw traces require actual per-interval force effort")
        if not np.isclose(output.actual_force_interval_effort.sum(), metrics["actual_control_energy"], rtol=1e-12):
            raise ValueError("Raw interval effort does not reproduce actual force effort")
        metrics["event_trigger_count"] = int(output.trigger_events[:-1].sum())
        metrics["command_evaluation_count"] = int(np.prod(output.controls.shape[:2]))
        metrics["plant_command_intervals"] = int((len(output.times) - 1) * output.controls.shape[1])
        metrics["no_event_command_change_count"] = int(np.sum(
            (~output.trigger_events[1:-1]) &
            (np.max(np.abs(output.controls[1:-1] - output.controls[:-2]), axis=2) > 1e-12)))
        required = ["formation_tracking_error", "control_energy", "actual_control_energy", "event_trigger_count"]
        if any(metrics.get(k) is None for k in required):
            raise FloatingPointError("Missing finite primary metric")
        spec = spec_with_gains(get_method_spec(job.method), position_gain=job.position_gain,
                               velocity_gain=job.velocity_gain)
        record.update(status="ok", metrics=metrics, method_spec=asdict(spec),
                      trajectory=str(trace_path.relative_to(out)),
                      trajectory_sha256=hashlib.sha256(trace_path.read_bytes()).hexdigest())
    except Exception:
        record["error"] = traceback.format_exc()
    record["elapsed_wall_s"] = time.perf_counter() - started
    atomic_json(out / "jobs" / f"{row['job_id']}.json", record)
    return record["job_id"], record["status"], record["elapsed_wall_s"]


def assemble(design, out):
    records = []
    for row in design:
        path = out / "jobs" / f"{row['job_id']}.json"
        if not path.exists():
            continue
        result = json.loads(path.read_text(encoding="utf-8"))
        sim = result["configuration"]["simulation"]
        spec = result.get("method_spec", {})
        record = {k: v for k, v in row.items() if k not in {"job", "simulation_overrides"}}
        record.update(row["job"])
        record.update(result.get("metrics", {}))
        record.update(status=result["status"], gamma=row["job"]["topology_feedback_gain"],
                      information_mode=row["job"]["resilience_information_mode"],
                      attitude_response_scale=row["job"]["uav_attitude_bandwidth_scale"],
                      ppt_enabled=spec.get("constraint_aware"),
                      efficiency_gain=sim["resilience_efficiency_gain"],
                      efficiency_alignment_min=sim["resilience_efficiency_alignment_min"],
                      trigger_base_threshold=sim["event_trigger_threshold"],
                      provenance_id=result["provenance_id"],
                      elapsed_wall_s=result["elapsed_wall_s"])
        records.append(record)
    frame = pd.DataFrame(records)
    temporary = out / "runs.tmp.csv"
    frame.to_csv(temporary, index=False)
    temporary.replace(out / "runs.csv")
    return frame


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--design", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--campaign", action="append")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--assemble-only", action="store_true")
    args = parser.parse_args()
    all_design = json.loads(args.design.read_text(encoding="utf-8"))
    design = [r for r in all_design if not args.campaign or r["campaign"] in args.campaign]
    unique = {r["job_id"]: r for r in design}
    if args.limit is not None:
        unique = dict(list(unique.items())[:args.limit])
    out = args.output.resolve()
    for folder in (out, out / "jobs", out / "traces"):
        folder.mkdir(parents=True, exist_ok=True)
    if args.assemble_only:
        assemble(all_design, out)
        return 0
    base_config = json.loads((ROOT / "simulation/configs/stage2_final.json").read_text())
    provenance = dict(design_sha256=digest(all_design), source=source_record(), base_config=base_config,
                      python=sys.version, platform=platform.platform(), numpy=np.__version__, pandas=pd.__version__)
    provenance_id = digest(provenance)
    provenance_path = out / "provenance.json"
    if provenance_path.exists():
        existing = json.loads(provenance_path.read_text())
        if existing["provenance_id"] != provenance_id:
            raise RuntimeError("Source/config/environment changed: use a separate output directory")
    else:
        atomic_json(provenance_path, {**provenance, "provenance_id": provenance_id,
                                      "frozen_utc": datetime.now(timezone.utc).isoformat()})
        with zipfile.ZipFile(out / "source_snapshot.zip", "w", zipfile.ZIP_DEFLATED) as archive:
            for relative in provenance["source"]:
                archive.write(ROOT / relative, relative)
        atomic_json(out / "design.json", all_design)
    pending = [r for job_id, r in unique.items() if not (out / "jobs" / f"{job_id}.json").exists()]
    print(f"Design rows={len(all_design)}; selected unique jobs={len(unique)}; pending={len(pending)}", flush=True)
    with (out / "execution.jsonl").open("a", encoding="utf-8") as log:
        with ProcessPoolExecutor(max_workers=args.workers) as executor:
            futures = [executor.submit(run_one, (r, base_config, str(out), provenance_id)) for r in pending]
            for count, future in enumerate(as_completed(futures), 1):
                job_id, status, elapsed = future.result()
                log.write(json.dumps(dict(job_id=job_id, status=status, elapsed_wall_s=elapsed,
                                          completed_utc=datetime.now(timezone.utc).isoformat())) + "\n")
                log.flush()
                if count % 25 == 0 or count == len(pending):
                    print(f"Completed {count}/{len(pending)}; last={status}, {elapsed:.2f}s", flush=True)
                if count % 100 == 0:
                    assemble(all_design, out)
    frame = assemble(all_design, out)
    counts = frame.drop_duplicates("job_id")["status"].value_counts().to_dict()
    print(json.dumps(dict(completed_unique_jobs=int(frame["job_id"].nunique()), status=counts)), flush=True)
    return 1 if counts.get("error", 0) else 0


if __name__ == "__main__":
    raise SystemExit(main())
