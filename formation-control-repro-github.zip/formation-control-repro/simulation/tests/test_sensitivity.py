import unittest
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from finite_control_sim.config import parse_config  # noqa: E402
from finite_control_sim.controllers import METHOD_SPECS, spec_with_gains  # noqa: E402
from finite_control_sim.models import (  # noqa: E402
    apply_usv_underactuation_scale,
    build_agent_dynamics,
    platform_command_response,
)
from finite_control_sim.scenarios import build_scenario_profile  # noqa: E402
from finite_control_sim.simulator import SimulationJob, simulate_job  # noqa: E402


def _short_config(**sim_over):
    simulation = {
        "numeric_backend": "numpy",
        "state_dtype": "float64",
        "integrator": "rk4",
        "dt_s": 0.02,
        "duration_s": 0.4,
        "resilience_bias_gain": 0.10,
        "resilience_bias_decay": 0.35,
        "resilience_bias_limit": 0.40,
        "resilience_efficiency_gain": 0.12,
        "resilience_efficiency_decay": 0.45,
        "resilience_efficiency_min": 0.55,
        "resilience_efficiency_max": 1.05,
        "resilience_min_command_norm": 0.005,
    }
    simulation.update(sim_over)
    return parse_config(
        {
            "name": "sensitivity-unit-test",
            "followers": {"uav": 1, "usv": 1},
            "predefined_times_s": [0.2],
            "supplement_predefined_times_s": [0.1],
            "seeds": [0],
            "methods": ["proposed_full"],
            "scenarios": ["nominal"],
            "scalability_agents": [2],
            "simulation": simulation,
            "statistics": {},
        }
    )


class SensitivityTests(unittest.TestCase):
    def test_spec_with_gains_overrides_only_requested_channels(self) -> None:
        spec = spec_with_gains(METHOD_SPECS["proposed_full"], position_gain=1.9, velocity_gain=1.9)
        self.assertAlmostEqual(spec.position_gain, 1.9)
        self.assertAlmostEqual(spec.velocity_gain, 1.9)
        self.assertAlmostEqual(spec.finite_power, 0.60)
        self.assertTrue(spec.predefined)

    def test_event_hold_off_uses_live_error_in_the_command(self) -> None:
        config = _short_config()
        common = dict(
            method="proposed_full",
            scenario="nominal",
            seed=1,
            predefined_time_s=0.2,
            uav_count=1,
            usv_count=1,
            integrator="rk4",
            resilience_information_mode="oracle",
        )
        held = simulate_job(config, SimulationJob(**common, event_hold=True))
        live = simulate_job(config, SimulationJob(**common, event_hold=False))
        self.assertTrue(np.isfinite(held.metrics["actual_control_energy"]))
        self.assertFalse(np.allclose(held.held_position_errors, live.held_position_errors))

    def test_bernoulli_dos_is_stochastic_and_windows_dos_is_deterministic(self) -> None:
        times = np.linspace(0.0, 16.0, 801)
        rng = np.random.default_rng(0)
        windows = build_scenario_profile(
            "dos_attack", times, 4, rng, dos_model="windows", dos_duty_scale=1.0
        )
        bernoulli = build_scenario_profile(
            "dos_attack", times, 4, np.random.default_rng(0), dos_model="bernoulli", dos_duty_scale=1.0
        )
        self.assertLess(float(np.mean(windows.communication_available)), 1.0)
        self.assertLess(float(np.mean(bernoulli.communication_available)), 1.0)
        self.assertNotEqual(
            float(np.mean(windows.communication_available)),
            float(np.mean(bernoulli.communication_available)),
        )

    def test_usv_underactuation_scale_does_not_change_uav_sway(self) -> None:
        base = build_agent_dynamics(["leader", "UAV", "USV"], max_control=5.0)
        scaled = apply_usv_underactuation_scale(base, 0.5)
        self.assertAlmostEqual(float(scaled.lateral_control_gain[0]), float(base.lateral_control_gain[0]))
        self.assertAlmostEqual(float(scaled.lateral_control_gain[1]), 0.5 * float(base.lateral_control_gain[1]))

    def test_course_aligned_plant_rotates_the_lagged_command(self) -> None:
        dynamics = build_agent_dynamics(["leader", "USV"], max_control=5.0)
        command_state = np.zeros((1, 2), dtype=float)
        command = np.array([[1.0, 0.0]], dtype=float)
        velocity = np.array([[0.0, 1.0]], dtype=float)
        _, inertial = platform_command_response(
            dynamics, command_state, command, velocity, 0.05, plant_model="planar_proxy"
        )
        _, body = platform_command_response(
            dynamics, command_state, command, velocity, 0.05, plant_model="course_aligned"
        )
        self.assertGreater(abs(float(body[0, 1])), abs(float(inertial[0, 1])))

    def test_causal_estimator_stays_finite_on_combined_stress(self) -> None:
        config = _short_config()
        output = simulate_job(
            config,
            SimulationJob(
                method="proposed_full",
                scenario="combined_attack_fault",
                seed=0,
                predefined_time_s=0.2,
                uav_count=1,
                usv_count=1,
                integrator="rk4",
                resilience_information_mode="causal",
            ),
        )
        self.assertTrue(np.isfinite(output.metrics["formation_tracking_error"]))
        self.assertTrue(np.isfinite(output.metrics["bias_estimate_rmse"]))
        self.assertTrue(np.isfinite(output.metrics["efficiency_estimate_rmse"]))
        self.assertLess(float(output.metrics["formation_tracking_error"]), 5.0)

    def test_quadrotor_plant_is_opt_in_and_finite(self) -> None:
        config = _short_config()
        output = simulate_job(
            config,
            SimulationJob(
                method="proposed_full",
                scenario="nominal",
                seed=0,
                predefined_time_s=0.2,
                uav_count=1,
                usv_count=1,
                integrator="rk4",
                resilience_information_mode="oracle",
                plant_model="quadrotor_6dof",
            ),
        )
        self.assertTrue(np.isfinite(output.metrics["formation_tracking_error"]))
        self.assertIn("altitude_rmse", output.metrics)
        self.assertLess(float(output.metrics["formation_tracking_error"]), 5.0)


if __name__ == "__main__":
    unittest.main()
