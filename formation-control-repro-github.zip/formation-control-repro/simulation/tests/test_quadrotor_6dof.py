import unittest
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from finite_control_sim.config import parse_config  # noqa: E402
from finite_control_sim.models import platform_command_response, build_agent_dynamics  # noqa: E402
from finite_control_sim.quadrotor_6dof import (  # noqa: E402
    allocate_rotors,
    initialize_fleet,
    mixer_matrix,
    project_so3,
    step_fleet,
)
from finite_control_sim.simulator import SimulationJob, simulate_job  # noqa: E402


def _short_config(**sim_over):
    simulation = {
        "numeric_backend": "numpy",
        "state_dtype": "float64",
        "integrator": "rk4",
        "dt_s": 0.02,
        "duration_s": 0.6,
        "resilience_bias_gain": 0.10,
        "resilience_bias_decay": 0.35,
        "resilience_bias_limit": 0.40,
        "resilience_efficiency_gain": 0.12,
        "resilience_efficiency_decay": 0.45,
        "resilience_efficiency_min": 0.55,
        "resilience_efficiency_max": 1.05,
        "resilience_min_command_norm": 0.005,
    }
    simulation.update(sim_over)
    return parse_config(
        {
            "name": "quadrotor-unit-test",
            "followers": {"uav": 2, "usv": 2},
            "predefined_times_s": [0.4],
            "supplement_predefined_times_s": [0.2],
            "seeds": [0],
            "methods": ["proposed_full"],
            "scenarios": ["nominal"],
            "scalability_agents": [2],
            "simulation": simulation,
            "statistics": {},
        }
    )


class QuadrotorSixDofTests(unittest.TestCase):
    def test_mixer_hover_is_equal_rotor_thrust(self) -> None:
        mass = 1.0
        hover = mass * 9.81
        rotor, wrench = allocate_rotors(
            np.array([hover]),
            np.zeros((1, 3)),
            arm_length=0.18,
            yaw_moment_arm=0.016,
            thrust_max=np.array([0.8 * hover]),
        )
        self.assertTrue(np.allclose(rotor, hover / 4.0, atol=1e-9))
        self.assertAlmostEqual(float(wrench[0, 0]), hover, places=8)
        self.assertTrue(np.allclose(wrench[0, 1:], 0.0, atol=1e-9))
        allocation = mixer_matrix(0.18, 0.016)
        self.assertEqual(allocation.shape, (4, 4))
        self.assertGreater(abs(np.linalg.det(allocation)), 1e-9)

    def test_so3_projection_restores_rotation(self) -> None:
        rng = np.random.default_rng(0)
        noisy = np.eye(3) + 0.05 * rng.normal(size=(2, 3, 3))
        restored = project_so3(noisy)
        gram = np.matmul(np.transpose(restored, (0, 2, 1)), restored)
        self.assertTrue(np.allclose(gram, np.eye(3), atol=1e-8))
        self.assertTrue(np.allclose(np.linalg.det(restored), 1.0, atol=1e-8))

    def test_hover_hold_stays_near_setpoint(self) -> None:
        fleet = initialize_fleet(
            mass=np.array([1.0, 1.0]),
            p_xy=np.zeros((2, 2)),
            v_xy=np.zeros((2, 2)),
            hover_z=1.5,
            inner_dt_s=0.005,
            rng=np.random.default_rng(1),
        )
        for _ in range(400):
            step_fleet(
                fleet,
                force_xy=np.zeros((2, 2)),
                actuator_efficiency=np.ones(2),
                disturbance_3d=np.zeros((2, 3)),
                yaw_des=0.0,
                outer_dt_s=0.02,
                z_des=1.5,
            )
        self.assertTrue(np.all(np.isfinite(fleet.p)))
        self.assertLess(float(np.max(np.abs(fleet.p[:, 2] - 1.5))), 0.15)
        self.assertLess(float(np.max(np.linalg.norm(fleet.p[:, :2], axis=1))), 0.20)
        gram = np.matmul(np.transpose(fleet.R, (0, 2, 1)), fleet.R)
        self.assertTrue(np.allclose(gram, np.eye(3), atol=1e-6))

    def test_mixed_team_job_stays_finite(self) -> None:
        config = _short_config()
        output = simulate_job(
            config,
            SimulationJob(
                method="proposed_full",
                scenario="nominal",
                seed=0,
                predefined_time_s=0.4,
                uav_count=2,
                usv_count=2,
                integrator="rk4",
                resilience_information_mode="oracle",
                plant_model="quadrotor_6dof",
            ),
        )
        self.assertTrue(np.isfinite(output.metrics["formation_tracking_error"]))
        self.assertTrue(np.isfinite(output.metrics["altitude_rmse"]))
        self.assertTrue(np.isfinite(output.metrics["tilt_mean_rad"]))
        self.assertLess(float(output.metrics["formation_tracking_error"]), 5.0)
        self.assertLess(float(output.metrics["altitude_rmse"]), 1.5)
        self.assertEqual(output.uav_altitudes.shape[1], 2)
        self.assertGreater(float(np.mean(output.uav_altitudes)), 0.5)

    def test_unknown_plant_is_rejected(self) -> None:
        dynamics = build_agent_dynamics(["leader", "UAV"], max_control=5.0)
        with self.assertRaises(ValueError):
            platform_command_response(
                dynamics,
                np.zeros((1, 2)),
                np.ones((1, 2)),
                np.zeros((1, 2)),
                0.02,
                plant_model="not_a_plant",
            )
        config = _short_config()
        with self.assertRaises(ValueError):
            simulate_job(
                config,
                SimulationJob(
                    method="proposed_full",
                    scenario="nominal",
                    seed=0,
                    predefined_time_s=0.4,
                    uav_count=1,
                    usv_count=1,
                    plant_model="not_a_plant",
                ),
            )

    def test_mixed_6dof_3dof_job_stays_finite(self) -> None:
        config = _short_config()
        output = simulate_job(
            config,
            SimulationJob(
                method="proposed_full",
                scenario="nominal",
                seed=0,
                predefined_time_s=0.4,
                uav_count=2,
                usv_count=2,
                integrator="rk4",
                resilience_information_mode="oracle",
                plant_model="mixed_6dof_3dof",
            ),
        )
        self.assertTrue(np.isfinite(output.metrics["formation_tracking_error"]))
        self.assertIn("altitude_rmse", output.metrics)
        self.assertLess(float(output.metrics["formation_tracking_error"]), 8.0)

    def test_planar_job_does_not_grow_quadrotor_metrics(self) -> None:
        config = _short_config()
        output = simulate_job(
            config,
            SimulationJob(
                method="proposed_full",
                scenario="nominal",
                seed=0,
                predefined_time_s=0.4,
                uav_count=2,
                usv_count=2,
                plant_model="planar_proxy",
            ),
        )
        self.assertNotIn("altitude_rmse", output.metrics)
        self.assertIsNone(output.uav_altitudes)


if __name__ == "__main__":
    unittest.main()
