import unittest
from pathlib import Path

from finite_control_sim.config import ExperimentConfig, load_config


ROOT = Path(__file__).resolve().parents[1]


class ConfigTests(unittest.TestCase):
    def test_stage1_config_covers_q1_matrix(self) -> None:
        config = load_config(ROOT / "configs" / "stage1_screening.json")

        self.assertIsInstance(config, ExperimentConfig)
        self.assertEqual(config.followers.total, 8)
        self.assertEqual(config.followers.uav, 4)
        self.assertEqual(config.followers.usv, 4)
        self.assertEqual(config.predefined_times_s, [3.0, 5.0, 7.0, 10.0])
        self.assertEqual(len(config.seeds), 10)
        self.assertIn("proposed_full", config.methods)
        self.assertIn("fixed_time_adaptive", config.methods)
        self.assertIn("event_triggered_fixed_time", config.methods)
        self.assertIn("combined_attack_fault", config.scenarios)
        self.assertEqual(config.simulation.get("minimum_inter_event_s"), 0.02)

    def test_stage2_config_has_50_final_seeds_and_supplement_times(self) -> None:
        config = load_config(ROOT / "configs" / "stage2_final.json")

        self.assertEqual(len(config.seeds), 50)
        self.assertEqual(config.supplement_predefined_times_s, [1.0, 2.0, 12.0, 15.0])
        self.assertEqual(config.scalability_agents, [20, 50, 100])
        self.assertEqual(config.statistics["bootstrap_samples"], 1000)
        self.assertEqual(config.statistics["multiple_comparison"], "Holm correction")
        self.assertEqual(config.simulation.get("minimum_inter_event_s"), 0.02)


if __name__ == "__main__":
    unittest.main()
