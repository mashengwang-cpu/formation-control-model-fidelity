import tempfile
import unittest
from pathlib import Path

from finite_control_sim.config import load_config
from finite_control_sim.diagnostics import export_diagnostic_run
from finite_control_sim.figures import make_diagnostic_main_figure
from finite_control_sim.simulator import SimulationJob


class FigureGenerationTests(unittest.TestCase):
    def test_diagnostic_main_figure_exports_publication_bundle(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            config = load_config("simulation/configs/stage1_screening.json")
            diagnostic = export_diagnostic_run(
                config,
                SimulationJob("proposed_full", "combined_attack_fault", 0, 5.0, 4, 4),
                tmp_path / "diagnostics",
            )
            bundle = make_diagnostic_main_figure(
                diagnostic.npz_path,
                diagnostic.summary_path,
                tmp_path / "figures",
                stem="test_fig",
            )
            expected_paths = [
                bundle.svg_path,
                bundle.pdf_path,
                bundle.tiff_path,
                bundle.png_path,
                bundle.source_data_path,
                bundle.qa_notes_path,
            ]
            for path in expected_paths:
                self.assertTrue(path.exists(), path)
                self.assertGreater(path.stat().st_size, 100, path)

            svg_text = bundle.svg_path.read_text(encoding="utf-8")

        self.assertIn("<text", svg_text)
        self.assertIn("Tracking error", svg_text)
        self.assertIn("Trigger metric", svg_text)


if __name__ == "__main__":
    unittest.main()
