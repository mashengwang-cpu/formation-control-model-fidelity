import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from finite_control_sim.config import load_config
from finite_control_sim.simulator import SimulationJob, simulate_job


class RecertifyGapTests(unittest.TestCase):
    def test_v1000_canonical_is_near_archived_seed0(self) -> None:
        config = load_config(
            Path(__file__).resolve().parents[1] / "configs" / "stage2_final.json"
        )
        config.simulation["numeric_backend"] = "numpy"
        config.simulation["state_dtype"] = "float64"
        config.simulation["integrator"] = "rk4"
        output = simulate_job(
            config,
            SimulationJob(
                method="proposed_full",
                scenario="nominal",
                seed=0,
                predefined_time_s=5.0,
                uav_count=4,
                usv_count=4,
                integrator="rk4",
                resilience_information_mode="oracle",
                event_hold=True,
                topology_name="leader_ring",
                topology_feedback_gain=0.65,
                topology_switch_period_s=0.8,
                plant_model="v1000_canonical",
            ),
        )
        value = float(output.metrics["formation_tracking_error"])
        frozen = 0.0657045965878811
        self.assertLess(abs(value - frozen) / frozen, 0.04)

    def test_public_oracle_rk4_does_not_match_archived_nominal_j(self) -> None:
        config = load_config(
            Path(__file__).resolve().parents[1] / "configs" / "stage1_screening.json"
        )
        config.simulation["numeric_backend"] = "numpy"
        config.simulation["state_dtype"] = "float64"
        config.simulation["integrator"] = "rk4"
        config.simulation["dt_s"] = 0.02
        config.simulation["duration_s"] = 2.0
        output = simulate_job(
            config,
            SimulationJob(
                method="proposed_full",
                scenario="nominal",
                seed=0,
                predefined_time_s=5.0,
                uav_count=2,
                usv_count=2,
                integrator="rk4",
                resilience_information_mode="oracle",
                event_hold=True,
                plant_model="planar_proxy",
            ),
        )
        value = float(output.metrics["formation_tracking_error"])
        self.assertTrue(np_finite := __import__("math").isfinite(value))
        self.assertGreater(value, 0.05)
        self.assertNotAlmostEqual(value, 0.0657, delta=0.02)


if __name__ == "__main__":
    unittest.main()
