import unittest

from finite_control_sim.config import load_config
from finite_control_sim.experiments import build_experiment_jobs, run_experiment_jobs


class SimulatorSmokeTests(unittest.TestCase):
    def test_small_subset_runs_and_returns_required_metrics(self) -> None:
        config = load_config("simulation/configs/stage1_screening.json")
        jobs = build_experiment_jobs(
            config,
            max_seeds=1,
            max_methods=2,
            max_scenarios=2,
            max_predefined_times=1,
        )

        frame = run_experiment_jobs(jobs, progress=False)

        self.assertEqual(len(frame), 4)
        required_columns = {
            "method",
            "scenario",
            "seed",
            "predefined_time_s",
            "settling_time",
            "appointed_time_violation",
            "formation_tracking_error",
            "constraint_violation_rate",
            "control_energy",
            "control_energy_per_agent_time",
            "itae_tracking_error",
            "integral_tracking_error",
            "peak_control_input",
            "event_trigger_count",
            "minimum_inter_event_time",
            "resilience_degradation_index",
            "computation_time",
        }
        self.assertTrue(required_columns.issubset(frame.columns))
        self.assertTrue((frame["computation_time"] >= 0.0).all())


if __name__ == "__main__":
    unittest.main()
