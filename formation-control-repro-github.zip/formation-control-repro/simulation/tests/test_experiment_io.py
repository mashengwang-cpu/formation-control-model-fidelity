import tempfile
import unittest

import pandas as pd

from finite_control_sim.experiments import write_results


class ExperimentIoTests(unittest.TestCase):
    def test_summary_csv_has_flat_header_and_one_row_per_group(self) -> None:
        frame = pd.DataFrame(
            [
                {
                    "method": "m1",
                    "scenario": "nominal",
                    "predefined_time_s": 3.0,
                    "appointed_time_violation": 0.0,
                    "settling_time": 2.0,
                    "formation_tracking_error": 0.1,
                    "prescribed_constraint_violation_rate": 0.0,
                    "control_energy": 1.0,
                    "peak_control_input": 1.0,
                    "event_trigger_count": 4.0,
                    "minimum_inter_event_time": 0.1,
                    "resilience_degradation_index": 0.0,
                    "computation_time": 0.01,
                }
            ]
        )
        with tempfile.TemporaryDirectory() as tmp:
            _, summary_path = write_results(frame, tmp)
            summary = pd.read_csv(summary_path)

        self.assertEqual(len(summary), 1)
        self.assertIn("settling_time_mean", summary.columns)
        self.assertNotIn("Unnamed: 0_level_1", summary.columns)


if __name__ == "__main__":
    unittest.main()
