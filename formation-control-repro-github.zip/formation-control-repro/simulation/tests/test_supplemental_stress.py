import unittest
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from finite_control_sim.config import load_config
from finite_control_sim.scenarios import build_scenario_profile
from finite_control_sim.simulator import SimulationJob, simulate_job
from finite_control_sim.topology import (
    build_leader_follower_topology,
    dynamic_topology_weight_matrices,
    topology_consensus_error,
    topology_weight_matrices,
)


class SupplementalStressTests(unittest.TestCase):
    def test_topology_variants_have_distinct_weight_matrices(self) -> None:
        leader_ring = build_leader_follower_topology(4, 4, topology_name="leader_ring", seed=3)
        sparse = build_leader_follower_topology(4, 4, topology_name="sparse_random", seed=3)
        ring_leader, ring_follower = topology_weight_matrices(leader_ring)
        sparse_leader, sparse_follower = topology_weight_matrices(sparse)

        self.assertEqual(ring_leader.shape, sparse_leader.shape)
        self.assertEqual(ring_follower.shape, sparse_follower.shape)
        self.assertFalse(np.allclose(ring_leader, sparse_leader))

    def test_switching_topology_changes_weights_over_time(self) -> None:
        topology = build_leader_follower_topology(4, 4, topology_name="switching_sparse", seed=1)
        _, early = dynamic_topology_weight_matrices(
            topology,
            topology_name="switching_sparse",
            time_s=0.1,
            switch_period_s=0.5,
        )
        _, late = dynamic_topology_weight_matrices(
            topology,
            topology_name="switching_sparse",
            time_s=0.7,
            switch_period_s=0.5,
        )

        self.assertFalse(np.allclose(early, late))

    def test_topology_consensus_error_uses_neighbor_weights(self) -> None:
        error = np.array([[1.0, 0.0], [0.0, 0.0]], dtype=float)
        leader_weights = np.array([1.0, 0.0], dtype=float)
        follower_weights = np.array([[0.0, 0.0], [1.0, 0.0]], dtype=float)

        consensus = topology_consensus_error(error, leader_weights, follower_weights)

        self.assertTrue(np.allclose(consensus[0], [1.0, 0.0]))
        self.assertTrue(np.allclose(consensus[1], [-1.0, 0.0]))

    def test_attack_intensity_scales_fdi_and_dos_profiles(self) -> None:
        times = np.linspace(0.0, 10.0, 501)
        rng_low = np.random.default_rng(10)
        rng_high = np.random.default_rng(10)
        low = build_scenario_profile("combined_attack_fault", times, 8, rng_low, fdi_scale=0.5, dos_duty_scale=0.5)
        high = build_scenario_profile("combined_attack_fault", times, 8, rng_high, fdi_scale=2.0, dos_duty_scale=2.0)

        self.assertGreater(np.max(np.abs(high.sensor_bias)), np.max(np.abs(low.sensor_bias)))
        self.assertLess(np.mean(high.communication_available), np.mean(low.communication_available))

    def test_topology_feedback_changes_simulation_metrics(self) -> None:
        config = load_config(Path(__file__).resolve().parents[1] / "configs" / "stage1_screening.json")
        baseline = SimulationJob("proposed_full", "combined_attack_fault", 2, 5.0, 4, 4)
        sparse = SimulationJob(
            "proposed_full",
            "combined_attack_fault",
            2,
            5.0,
            4,
            4,
            stress_tag="topology_sparse_random",
            topology_name="sparse_random",
            topology_feedback_gain=1.0,
        )

        baseline_output = simulate_job(config, baseline)
        sparse_output = simulate_job(config, sparse)

        self.assertNotEqual(
            baseline_output.metrics["formation_tracking_error"],
            sparse_output.metrics["formation_tracking_error"],
        )


if __name__ == "__main__":
    unittest.main()
