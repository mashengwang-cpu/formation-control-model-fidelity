"""Tests for the reproduced true-baseline controllers (true_baselines.py)."""

import unittest

import numpy as np

from finite_control_sim.controllers import (
    ControllerInput,
    ControllerState,
    ModularController,
    get_method_spec,
)
from finite_control_sim.true_baselines import (
    TRUE_BASELINE_METHODS,
    build_true_baseline_controller,
)

FOLLOWERS = 3
MAX_CONTROL = 8.0


def _make_inputs(
    position_error: np.ndarray,
    velocity_error: np.ndarray,
    *,
    time_s: float = 0.0,
    dt_s: float = 0.02,
    time_since_event: float = 1.0,
    comm: bool = True,
) -> ControllerInput:
    return ControllerInput(
        time_s=time_s,
        dt_s=dt_s,
        position_error=position_error,
        velocity_error=velocity_error,
        sampled_error=position_error.copy(),
        time_since_event=np.full(FOLLOWERS, time_since_event, dtype=float),
        communication_available=np.full(FOLLOWERS, comm, dtype=bool),
        actuator_efficiency=np.ones(FOLLOWERS, dtype=float),
        predefined_time_s=5.0,
        constraint_radius=1.0,
        trigger_base_threshold=0.035,
        trigger_max_hold_s=0.55,
        minimum_inter_event_s=0.02,
    )


def _closed_loop_final_errors(method: str, *, duration_s: float = 12.0, dt: float = 0.02):
    """Nominal double-integrator regulation loop matching the canonical plant."""
    rng = np.random.default_rng(7)
    spec = get_method_spec(method)
    controller = ModularController(
        spec=spec, follower_count=FOLLOWERS, dimensions=2, max_control=MAX_CONTROL
    )
    state = ControllerState.zeros(FOLLOWERS, 2, controller.basis_size)
    positions = rng.normal(0.0, 0.5, size=(FOLLOWERS, 2))
    velocities = np.zeros((FOLLOWERS, 2), dtype=float)
    state = ControllerState(
        adaptive_weights=state.adaptive_weights,
        observer_state=state.observer_state,
        trigger_filter=state.trigger_filter,
        sampled_error=positions.copy(),
        sampled_velocity_error=velocities.copy(),
    )
    initial_norm = float(np.mean(np.linalg.norm(positions, axis=1)))
    damping = 0.35
    steps = int(duration_s / dt)
    max_error = 0.0
    max_control_seen = 0.0
    for step in range(steps):
        inputs = _make_inputs(
            positions.copy(), velocities.copy(), time_s=step * dt, dt_s=dt
        )
        output = controller.step(state, inputs)
        state = output.next_state
        control = output.commanded_control
        accel = control - damping * velocities
        velocities = velocities + dt * accel
        positions = positions + dt * velocities
        max_error = max(max_error, float(np.max(np.linalg.norm(positions, axis=1))))
        max_control_seen = max(
            max_control_seen, float(np.max(np.linalg.norm(control, axis=1)))
        )
        if not np.isfinite(positions).all():
            raise AssertionError(f"{method} diverged at step {step}")
    final_norm = float(np.mean(np.linalg.norm(positions, axis=1)))
    return initial_norm, final_norm, max_error, max_control_seen


class TrueBaselineRegistrationTests(unittest.TestCase):
    def test_methods_registered_with_expected_flags(self) -> None:
        ref36 = get_method_spec("ref36_reproduction")
        ref72 = get_method_spec("ref72_reproduction")
        oa = get_method_spec("oa_alternative_baseline")

        self.assertTrue(ref36.resilience)
        self.assertFalse(ref36.event_triggered)
        self.assertFalse(ref72.resilience)
        self.assertTrue(ref72.event_triggered)
        self.assertTrue(oa.event_triggered)
        self.assertFalse(oa.resilience)
        for spec in (ref36, ref72, oa):
            self.assertFalse(spec.fault_tolerant)
            self.assertFalse(spec.constraint_aware)

    def test_dispatch_only_for_true_baseline_methods(self) -> None:
        legacy = ModularController(
            spec=get_method_spec("proposed_full"),
            follower_count=FOLLOWERS,
            dimensions=2,
            max_control=MAX_CONTROL,
        )
        self.assertIsNone(legacy._delegate)
        for method in sorted(TRUE_BASELINE_METHODS):
            dispatched = ModularController(
                spec=get_method_spec(method),
                follower_count=FOLLOWERS,
                dimensions=2,
                max_control=MAX_CONTROL,
            )
            self.assertIsNotNone(dispatched._delegate)

    def test_factory_rejects_unknown_method(self) -> None:
        with self.assertRaises(ValueError):
            build_true_baseline_controller(
                get_method_spec("proposed_full"), FOLLOWERS, MAX_CONTROL
            )


class TrueBaselineStepContractTests(unittest.TestCase):
    def test_step_outputs_are_finite_and_saturated(self) -> None:
        rng = np.random.default_rng(3)
        for method in sorted(TRUE_BASELINE_METHODS):
            controller = ModularController(
                spec=get_method_spec(method),
                follower_count=FOLLOWERS,
                dimensions=2,
                max_control=MAX_CONTROL,
            )
            state = ControllerState.zeros(FOLLOWERS, 2, controller.basis_size)
            for step in range(50):
                inputs = _make_inputs(
                    rng.normal(0.0, 1.5, size=(FOLLOWERS, 2)),
                    rng.normal(0.0, 1.0, size=(FOLLOWERS, 2)),
                    time_s=step * 0.02,
                )
                output = controller.step(state, inputs)
                state = output.next_state
                self.assertTrue(
                    np.isfinite(output.commanded_control).all(), msg=method
                )
                norms = np.linalg.norm(output.commanded_control, axis=1)
                self.assertTrue((norms <= MAX_CONTROL + 1e-9).all(), msg=method)
                self.assertTrue(np.isfinite(output.approximation).all(), msg=method)
                self.assertEqual(output.triggered.shape, (FOLLOWERS,), msg=method)

    def test_event_triggered_methods_hold_control_between_events(self) -> None:
        for method in ("ref72_reproduction", "oa_alternative_baseline"):
            controller = ModularController(
                spec=get_method_spec(method),
                follower_count=FOLLOWERS,
                dimensions=2,
                max_control=MAX_CONTROL,
            )
            state = ControllerState.zeros(FOLLOWERS, 2, controller.basis_size)
            error = np.full((FOLLOWERS, 2), 0.4, dtype=float)
            velocity = np.zeros((FOLLOWERS, 2), dtype=float)
            first = controller.step(state, _make_inputs(error, velocity, time_s=0.0))
            self.assertTrue(first.triggered.all(), msg=method)
            # A tiny perturbation must stay below the relative threshold.
            second = controller.step(
                first.next_state,
                _make_inputs(error + 1e-5, velocity, time_s=0.02, time_since_event=0.02),
            )
            self.assertFalse(second.triggered.any(), msg=method)
            np.testing.assert_allclose(
                second.commanded_control, first.commanded_control, err_msg=method
            )

    def test_ref72_trigger_threshold_is_relative(self) -> None:
        controller = ModularController(
            spec=get_method_spec("ref72_reproduction"),
            follower_count=FOLLOWERS,
            dimensions=2,
            max_control=MAX_CONTROL,
        )
        state = ControllerState.zeros(FOLLOWERS, 2, controller.basis_size)
        error = np.full((FOLLOWERS, 2), 0.6, dtype=float)
        velocity = np.zeros((FOLLOWERS, 2), dtype=float)
        first = controller.step(state, _make_inputs(error, velocity, time_s=0.0))
        held_norm = np.linalg.norm(first.raw_control, axis=1)
        expected = 0.2 * held_norm + 0.06
        second = controller.step(
            first.next_state,
            _make_inputs(error, velocity, time_s=0.02, time_since_event=0.02),
        )
        np.testing.assert_allclose(second.trigger_threshold, expected, rtol=1e-9)

    def test_dos_blocks_event_updates(self) -> None:
        controller = ModularController(
            spec=get_method_spec("ref72_reproduction"),
            follower_count=FOLLOWERS,
            dimensions=2,
            max_control=MAX_CONTROL,
        )
        state = ControllerState.zeros(FOLLOWERS, 2, controller.basis_size)
        error = np.full((FOLLOWERS, 2), 0.5, dtype=float)
        velocity = np.zeros((FOLLOWERS, 2), dtype=float)
        first = controller.step(state, _make_inputs(error, velocity, time_s=0.0))
        # Large change but communication unavailable: no event, control held.
        second = controller.step(
            first.next_state,
            _make_inputs(-3.0 * error, velocity, time_s=0.02, comm=False),
        )
        self.assertFalse(second.triggered.any())
        np.testing.assert_allclose(second.commanded_control, first.commanded_control)


class TrueBaselineClosedLoopTests(unittest.TestCase):
    def test_nominal_regulation_converges_and_stays_bounded(self) -> None:
        for method in sorted(TRUE_BASELINE_METHODS):
            initial, final, max_error, max_u = _closed_loop_final_errors(method)
            self.assertLess(final, 0.35 * initial, msg=method)
            self.assertLess(max_error, 6.0, msg=method)
            self.assertLessEqual(max_u, MAX_CONTROL + 1e-9, msg=method)

    def test_adaptive_states_remain_bounded_under_persistent_excitation(self) -> None:
        rng = np.random.default_rng(11)
        for method in sorted(TRUE_BASELINE_METHODS):
            controller = ModularController(
                spec=get_method_spec(method),
                follower_count=FOLLOWERS,
                dimensions=2,
                max_control=MAX_CONTROL,
            )
            state = ControllerState.zeros(FOLLOWERS, 2, controller.basis_size)
            for step in range(600):
                inputs = _make_inputs(
                    rng.normal(0.0, 1.0, size=(FOLLOWERS, 2)),
                    rng.normal(0.0, 0.5, size=(FOLLOWERS, 2)),
                    time_s=step * 0.02,
                )
                output = controller.step(state, inputs)
                state = output.next_state
            delegate = controller._delegate
            for name in (
                "theta_hat",
                "theta2_hat",
                "eps2_hat",
                "gamma1_hat",
                "lambda1_hat",
                "gamma2_hat",
                "lambda2_hat",
                "gamma0_hat",
                "nussbaum_theta",
            ):
                value = getattr(delegate, name, None)
                if value is not None:
                    self.assertTrue(np.isfinite(value).all(), msg=f"{method}.{name}")
                    self.assertLessEqual(float(np.max(np.abs(value))), 50.0, msg=method)

    def test_ref36_tuning_function_estimates_stay_nonnegative(self) -> None:
        """The delayed tuning-function laws keep positive-initialized estimates
        nonnegative (acs.4002 requires gamma_hat(0) > 0, lambda_hat(0) > 0)."""
        rng = np.random.default_rng(23)
        controller = ModularController(
            spec=get_method_spec("ref36_reproduction"),
            follower_count=FOLLOWERS,
            dimensions=2,
            max_control=MAX_CONTROL,
        )
        state = ControllerState.zeros(FOLLOWERS, 2, controller.basis_size)
        delegate = controller._delegate
        for step in range(400):
            inputs = _make_inputs(
                rng.normal(0.0, 0.8, size=(FOLLOWERS, 2)),
                rng.normal(0.0, 0.4, size=(FOLLOWERS, 2)),
                time_s=step * 0.02,
            )
            state = controller.step(state, inputs).next_state
            for name in (
                "gamma1_hat",
                "lambda1_hat",
                "gamma2_hat",
                "lambda2_hat",
                "gamma0_hat",
            ):
                value = getattr(delegate, name)
                self.assertTrue((value >= 0.0).all(), msg=name)
                self.assertTrue((value <= delegate.adaptive_clip).all(), msg=name)

    def test_ref36_nussbaum_disabled_by_default_but_functional(self) -> None:
        """The Nussbaum outer loop is disabled by default (pathological on
        this known-direction saturated channel; see
        true_baseline_requirements.md) yet remains implemented per
        N(theta) = exp(theta^2) sin(pi theta) when enabled."""
        from finite_control_sim.true_baselines import (
            Ref36FixedTimeResilientController,
        )

        default = ModularController(
            spec=get_method_spec("ref36_reproduction"),
            follower_count=FOLLOWERS,
            dimensions=2,
            max_control=MAX_CONTROL,
        )
        self.assertFalse(default._delegate.nussbaum_enabled)

        enabled = Ref36FixedTimeResilientController(
            get_method_spec("ref36_reproduction"),
            FOLLOWERS,
            MAX_CONTROL,
            nussbaum_enabled=True,
        )
        theta = enabled.nussbaum_theta.copy()
        gain = np.exp(theta**2) * np.sin(np.pi * theta)
        # Initialization must sit in a stabilizing pocket (N < 0).
        self.assertTrue((gain < 0.0).all())
        state = ControllerState.zeros(FOLLOWERS, 2, enabled.basis_size)
        error = np.full((FOLLOWERS, 2), 0.5, dtype=float)
        velocity = np.zeros((FOLLOWERS, 2), dtype=float)
        output = enabled.step(state, _make_inputs(error, velocity))
        self.assertTrue(np.isfinite(output.commanded_control).all())
        self.assertTrue(
            (np.abs(enabled.nussbaum_theta) <= enabled.nussbaum_clip).all()
        )


class TrueBaselineSimulatorIntegrationTests(unittest.TestCase):
    def test_simulate_job_runs_on_canonical_plant(self) -> None:
        from finite_control_sim.config import load_config
        from finite_control_sim.simulator import SimulationJob, simulate_job
        from pathlib import Path

        config = load_config(
            Path(__file__).resolve().parents[1] / "configs" / "stage2_final.json"
        )
        config.simulation["duration_s"] = 6.0
        for method in sorted(TRUE_BASELINE_METHODS):
            job = SimulationJob(
                method=method,
                scenario="nominal",
                seed=0,
                predefined_time_s=5.0,
                uav_count=2,
                usv_count=2,
                plant_model="v1000_canonical",
                resilience_information_mode="causal",
                topology_feedback_gain=0.65,
            )
            output = simulate_job(config, job)
            self.assertTrue(
                np.isfinite(output.metrics["formation_tracking_error"]), msg=method
            )
            self.assertGreater(output.metrics["event_trigger_count"], 0.0, msg=method)


if __name__ == "__main__":
    unittest.main()
