"""Bit-level recertification of the V2 canonical loop."""

from __future__ import annotations

from pathlib import Path
import unittest

import pandas as pd

from finite_control_sim.config import load_config
from finite_control_sim.simulator import SimulationJob, simulate_job

GOLD = Path(__file__).resolve().parents[2] / "data" / "v1000_v2_goldset.csv"
CONFIG = Path(__file__).resolve().parents[1] / "configs" / "stage2_final.json"


class V1000GoldsetTests(unittest.TestCase):
    def test_seed0_matches_v2_regeneration(self) -> None:
        gold = pd.read_csv(GOLD)
        row = gold[(gold.method == "proposed_full") & (gold.scenario == "nominal") & (gold.seed == 0)].iloc[0]
        config = load_config(CONFIG)
        config.simulation["integrator"] = "rk4"
        config.simulation["state_dtype"] = "float64"
        config.simulation["numeric_backend"] = "numpy"
        output = simulate_job(
            config,
            SimulationJob(
                method="proposed_full",
                scenario="nominal",
                seed=0,
                predefined_time_s=5.0,
                uav_count=4,
                usv_count=4,
                integrator="rk4",
                resilience_information_mode="oracle",
                event_hold=True,
                topology_name="leader_ring",
                topology_feedback_gain=0.65,
                topology_switch_period_s=0.8,
                plant_model="v1000_canonical",
            ),
        )
        self.assertAlmostEqual(
            float(output.metrics["formation_tracking_error"]),
            float(row.formation_tracking_error),
            places=12,
        )
        self.assertAlmostEqual(
            float(output.metrics["control_energy"]),
            float(row.control_energy),
            places=10,
        )


if __name__ == "__main__":
    unittest.main()
