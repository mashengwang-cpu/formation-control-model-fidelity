import unittest

from finite_control_sim.topology import build_leader_follower_topology


class TopologyTests(unittest.TestCase):
    def test_mixed_uav_usv_followers_are_assigned_and_connected(self) -> None:
        topology = build_leader_follower_topology(uav_count=4, usv_count=4)

        self.assertEqual(topology.agent_count, 9)
        self.assertEqual(topology.leader_id, 0)
        self.assertEqual(topology.agent_types.count("UAV"), 4)
        self.assertEqual(topology.agent_types.count("USV"), 4)
        self.assertTrue(all(edge.source == 0 for edge in topology.leader_edges))
        self.assertEqual(len(topology.leader_edges), 8)
        self.assertGreaterEqual(len(topology.follower_edges), 7)


if __name__ == "__main__":
    unittest.main()
