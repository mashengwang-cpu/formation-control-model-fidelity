from dataclasses import replace
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from finite_control_sim.config import load_config
from finite_control_sim.models import build_agent_dynamics, explicit_command_lag, isotropic_planar_drag
from finite_control_sim.quadrotor_6dof import initialize_fleet
from finite_control_sim.usv_3dof import initialize_usv_fleet, step_usv_fleet
from finite_control_sim.simulator import SimulationJob, simulate_job


def boat():
    return initialize_usv_fleet(mass=np.array([1.35]), p_xy=np.zeros((1, 2)), v_xy=np.zeros((1, 2)))


def test_external_force_changes_velocity_in_correct_units_and_position_uses_that_velocity():
    fleet = boat()
    h, external_force = .02, .035
    out = step_usv_fleet(fleet, force_xy=np.zeros((1, 2)), actuator_efficiency=np.ones(1),
                        disturbance_xy=np.array([[external_force, 0.]]), dt_s=h, n_inner=1)
    expected_v = h * external_force / 1.35
    np.testing.assert_allclose(fleet.inertial_vxy, [[expected_v, 0]], atol=1e-14)
    np.testing.assert_allclose(fleet.p, h * fleet.inertial_vxy, atol=1e-14)
    np.testing.assert_array_equal(out['force_xy'], [[0, 0]])
    np.testing.assert_array_equal(out['force_effort'], [0])


def test_unactuated_sway_is_never_logged_as_applied_force():
    for rho in [1., .5]:
        fleet = boat()
        out = step_usv_fleet(fleet, force_xy=np.array([[0., 1.]]), actuator_efficiency=np.array([rho]),
                            disturbance_xy=np.zeros((1, 2)), dt_s=.02, n_inner=1)
        np.testing.assert_array_equal(out['force_xy'], [[0, 0]])
        np.testing.assert_array_equal(out['force_effort'], [0])
        assert out['yaw_torque_effort'][0] > 0


def test_true_surge_effort_scales_with_rho_squared():
    values = []
    for rho in [1., .5]:
        fleet = boat()
        out = step_usv_fleet(fleet, force_xy=np.array([[2., 0.]]), actuator_efficiency=np.array([rho]),
                            disturbance_xy=np.zeros((1, 2)), dt_s=.02, n_inner=1)
        np.testing.assert_allclose(out['force_xy'], [[2 * rho, 0]])
        values.append(out['force_effort'][0])
    np.testing.assert_allclose(values, [.08, .02])


def test_matched_drag_is_same_world_xy_force_for_planar_uav_and_rotated_usv():
    velocity = np.array([[.3, -.2], [-.4, .6]])
    dynamics = build_agent_dynamics(['leader', 'UAV', 'USV'], 8.)
    expected = isotropic_planar_drag(dynamics, velocity)
    quad = initialize_fleet(mass=np.ones(1), p_xy=np.zeros((1, 2)), v_xy=velocity[:1], matched_drag=True)
    quad.v[:, 2] = 3.0  # Vertical speed cannot change the matched horizontal drag.
    np.testing.assert_allclose(quad.drag_force[:, :2], expected[:1])
    fleet = initialize_usv_fleet(mass=np.array([1.35]), p_xy=np.zeros((1, 2)), v_xy=velocity[1:], matched_drag=True)
    np.testing.assert_allclose(fleet.drag_world, expected[1:])


def test_attitude_intervention_changes_only_uav_gains_and_direct_wire_has_no_lag():
    args = dict(mass=np.ones(1), p_xy=np.zeros((1, 2)), v_xy=np.zeros((1, 2)))
    baseline = initialize_fleet(**args, rng=np.random.default_rng(1))
    faster = initialize_fleet(**args, rng=np.random.default_rng(1), attitude_bandwidth_scale=2.)
    assert faster.k_r == 4 * baseline.k_r
    assert faster.k_omega == 2 * baseline.k_omega
    np.testing.assert_array_equal(faster.inertia, baseline.inertia)
    np.testing.assert_array_equal(faster.p, baseline.p)
    assert faster.tilt_limit_rad == baseline.tilt_limit_rad
    assert faster.thrust_max_frac == baseline.thrust_max_frac
    state = np.zeros((2, 2)); command = np.ones((2, 2))
    out = explicit_command_lag(state, command, np.array([0., .08]), .02)
    np.testing.assert_array_equal(out[0], command[0])
    np.testing.assert_allclose(out[1], 1 - np.exp(-.02 / .08))


def short_config():
    config = load_config(Path(__file__).resolve().parents[1] / 'configs/stage2_final.json')
    config.simulation.update({'duration_s': .8, 'numeric_backend': 'numpy', 'state_dtype': 'float64',
                             'resilience_efficiency_gain': .25, 'resilience_efficiency_alignment_min': .8})
    return config


def test_matched_layers_share_initial_xy_and_partial_oracles_are_separate():
    config = short_config()
    base = SimulationJob('proposed_minimal_causal', 'combined_attack_fault', 0, .4, 2, 2,
                         matched_drag=True, topology_feedback_gain=.35)
    runs = [simulate_job(config, replace(base, plant_model=plant))
            for plant in ['matched_point_mass', 'matched_lagged', 'mixed_6dof_3dof']]
    for out in runs:
        assert np.isfinite(out.metrics['formation_tracking_error'])
        assert out.metrics['actual_control_energy'] >= 0
        np.testing.assert_allclose(out.actual_force_interval_effort.sum(), out.metrics['actual_control_energy'], rtol=1e-13)
        np.testing.assert_allclose(out.usv_yaw_interval_effort.sum(), out.metrics['actual_usv_yaw_torque_effort'], rtol=1e-13)
        np.testing.assert_array_equal(out.actual_force_interval_effort[-1], np.zeros(4))
        np.testing.assert_allclose(out.physical_position_errors[0], runs[0].physical_position_errors[0], atol=1e-14)
    oracle_eff = simulate_job(config, replace(base, plant_model='matched_point_mass', resilience_information_mode='oracle_efficiency'))
    oracle_bias = simulate_job(config, replace(base, plant_model='matched_point_mass', resilience_information_mode='oracle_bias'))
    np.testing.assert_array_equal(oracle_eff.actuator_efficiency_estimates, oracle_eff.actuator_efficiencies)
    np.testing.assert_array_equal(oracle_bias.bias_estimates, oracle_bias.sensor_biases)
    assert np.max(np.abs(oracle_eff.bias_estimates - oracle_eff.sensor_biases)) > 0
    assert np.max(np.abs(oracle_bias.actuator_efficiency_estimates - oracle_bias.actuator_efficiencies)) > 0


def test_uav_intervention_cannot_change_usv_only_team():
    config = short_config()
    base = SimulationJob('proposed_minimal_causal', 'nominal', 0, .4, 0, 2,
                         plant_model='mixed_6dof_3dof', matched_drag=True)
    a = simulate_job(config, base)
    b = simulate_job(config, replace(base, uav_attitude_bandwidth_scale=2., inner_dt_s=.00125))
    np.testing.assert_array_equal(a.tracking_errors, b.tracking_errors)
    np.testing.assert_array_equal(a.actual_controls, b.actual_controls)
