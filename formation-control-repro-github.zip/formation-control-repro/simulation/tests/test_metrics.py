import unittest

import numpy as np

from finite_control_sim.metrics import compute_run_metrics


class MetricsTests(unittest.TestCase):
    def test_metrics_report_contract_violation_and_energy(self) -> None:
        times = np.array([0.0, 1.0, 2.0, 3.0])
        errors = np.array(
            [
                [0.5, 0.4],
                [0.2, 0.1],
                [0.05, 0.04],
                [0.01, 0.02],
            ],
            dtype=float,
        )
        controls = np.ones((4, 2, 2), dtype=float)
        events = np.array([[True, False], [False, True], [False, False], [True, False]])
        constraints = np.array([[False, True], [False, False], [False, False], [False, False]])

        metrics = compute_run_metrics(
            times=times,
            tracking_errors=errors,
            controls=controls,
            trigger_events=events,
            constraint_violations=constraints,
            predefined_time_s=3.0,
            error_tolerance=0.1,
            nominal_integral_error=0.4,
            computation_time_s=0.25,
        )

        self.assertEqual(metrics["appointed_time_violation"], 0.0)
        self.assertAlmostEqual(metrics["constraint_violation_rate"], 1.0 / 8.0)
        self.assertGreater(metrics["control_energy"], 0.0)
        self.assertGreater(metrics["control_energy_per_agent_time"], 0.0)
        self.assertGreater(metrics["itae_tracking_error"], 0.0)
        self.assertEqual(metrics["event_trigger_count"], 3)
        self.assertGreater(metrics["minimum_inter_event_time"], 0.0)
        self.assertAlmostEqual(metrics["computation_time"], 0.25)
        self.assertIn("integral_tracking_error", metrics)


if __name__ == "__main__":
    unittest.main()
