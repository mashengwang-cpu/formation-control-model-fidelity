import tempfile
import unittest
from pathlib import Path

import pandas as pd

from finite_control_sim.figures import make_stage1_screening_figure


class Stage1FigureGenerationTests(unittest.TestCase):
    def test_stage1_screening_figure_exports_bundle(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            runs_path = tmp_path / "runs.csv"
            _minimal_stage1_runs().to_csv(runs_path, index=False)
            bundle = make_stage1_screening_figure(runs_path, tmp, stem="test_stage1")
            for path in [
                bundle.svg_path,
                bundle.pdf_path,
                bundle.tiff_path,
                bundle.png_path,
                bundle.source_data_path,
                bundle.qa_notes_path,
            ]:
                self.assertTrue(path.exists(), path)
                self.assertGreater(path.stat().st_size, 100, path)
            svg_text = bundle.svg_path.read_text(encoding="utf-8")

        self.assertIn("<text", svg_text)
        self.assertIn("Stage-1 screening", svg_text)
        self.assertIn("Communication events", svg_text)


def _minimal_stage1_runs() -> pd.DataFrame:
    methods = [
        "proposed_full",
        "predefined_time_no_event",
        "predefined_time_no_resilience",
        "fixed_time_adaptive",
    ]
    records = []
    for idx, method in enumerate(methods):
        for scenario in ["nominal", "combined_attack_fault"]:
            records.append(
                {
                    "method": method,
                    "scenario": scenario,
                    "seed": 0,
                    "predefined_time_s": 5.0,
                    "uav_count": 4,
                    "usv_count": 4,
                    "appointed_time_violation": 0.01 * idx,
                    "settling_time": 3.0 + idx,
                    "formation_tracking_error": 0.08 + 0.02 * idx,
                    "prescribed_constraint_violation_rate": 0.0,
                    "constraint_violation_rate": 0.0,
                    "control_energy": 10.0 + idx,
                    "peak_control_input": 2.0 + idx,
                    "event_trigger_count": 100.0 + 50.0 * idx,
                    "minimum_inter_event_time": 0.1,
                    "resilience_degradation_index": 0.02 * idx,
                    "computation_time": 0.01,
                }
            )
    return pd.DataFrame.from_records(records)


if __name__ == "__main__":
    unittest.main()
