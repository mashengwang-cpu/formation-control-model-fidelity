"""Prevent scientific comparisons from silently changing multiple factors."""
from dataclasses import asdict
import importlib.util
from pathlib import Path

from finite_control_sim.controllers import get_method_spec


def test_named_module_knockouts_change_only_the_named_component():
    reference = asdict(get_method_spec("proposed_no_ppt"))
    expected = {
        "hifi_ko_tvg": {"predefined"},
        "hifi_ko_powers": {"finite_power", "fixed_power"},
        "hifi_ko_approximator": {"adaptive_approximation"},
        "hifi_ko_observer": {"disturbance_observer"},
        "hifi_ko_faultcomp": {"fault_tolerant"},
        "proposed_full": {"constraint_aware"},
    }
    for method, allowed in expected.items():
        current = asdict(get_method_spec(method))
        changed = {k for k in reference if k != "name" and reference[k] != current[k]}
        assert changed == allowed


def test_prospective_design_pairs_all_layers_and_reuses_jobs_without_new_replicates():
    path = Path(__file__).resolve().parents[1] / "revision_design.py"
    spec = importlib.util.spec_from_file_location("revision_design_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = module.build_design()
    assert len(rows) == 8820
    assert len({r["job_id"] for r in rows}) == 7620
    assert len({r["design_id"] for r in rows}) == len(rows)
    for row in rows:
        job = row["job"]
        assert job["seed"] >= 1000
        assert job["integrator"] == "semi_implicit_euler"
        assert row["simulation_overrides"]["resilience_efficiency_gain"] == 0.25
        if row["campaign"] == "module_ablation":
            assert job["position_gain"] == 2.15 and job["velocity_gain"] == 2.05
            assert job["matched_drag"] and job["event_hold"]
            assert job["resilience_information_mode"] == "causal"
        if row["campaign"] == "attitude_intervention":
            assert job["usv_count"] == 0 and job["inner_dt_s"] == 0.00125
