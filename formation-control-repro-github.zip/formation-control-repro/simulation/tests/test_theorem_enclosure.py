import importlib.util
from pathlib import Path

import numpy as np

spec = importlib.util.spec_from_file_location('theorem_verifier',
    Path(__file__).resolve().parents[2] / 'tools/verify_theorem_conditions.py')
theorem = importlib.util.module_from_spec(spec)
spec.loader.exec_module(theorem)


def test_intersample_enclosure_covers_zero_endpoint_and_continuous_gain_samples():
    p = np.array([[.7939, .3655], [.3655, .3520]])
    a, m = .28, 1.
    lo, hi = theorem.theta_box(.2)
    result = theorem.intersample_upper_bound(p, a, m, lo, hi, .56, mesh_s=.007)
    assert result['upper'] >= np.sqrt(np.linalg.inv(p)[0, 0])
    # Sample every interval at non-grid points, plus all endpoints. This is a
    # regression check; the rectangle argument, not sampling, supplies proof.
    rng = np.random.default_rng(7)
    for r in np.r_[0., .56, rng.uniform(0., .56, 1000)]:
        q1, q2, _ = theorem.kernel_integrals(r, a, m)
        for theta in [lo, hi, rng.uniform(lo, hi)]:
            matrix = theorem.hold_matrix(r, a, theta * q1, theta * q2)
            row = matrix[0]
            value = np.sqrt(row @ np.linalg.solve(p, row))
            assert value <= result['upper']


def test_reported_certificate_still_contracts_all_hold_lengths():
    for plant in theorem.PLANTS:
        certificate = theorem.certify(plant, .2, verbose=False)
        assert certificate is not None
        assert certificate['gamma_max'] < 1
        assert certificate['kappa_e'] >= certificate['kappa_enclosure']['at_zero']
        assert certificate['e_ult'] > 2.09
