import unittest

import numpy as np

from finite_control_sim.config import load_config
from finite_control_sim.simulator import SimulationJob, simulate_job


class SimulatorDiagnosticsTests(unittest.TestCase):
    def test_proposed_run_records_theory_diagnostics_for_figures(self) -> None:
        config = load_config("simulation/configs/stage1_screening.json")
        job = SimulationJob(
            method="proposed_full",
            scenario="combined_attack_fault",
            seed=0,
            predefined_time_s=5.0,
            uav_count=4,
            usv_count=4,
        )

        output = simulate_job(config, job)
        steps = len(output.times)
        followers = 8

        self.assertEqual(output.transformed_errors.shape, (steps, followers, 2))
        self.assertEqual(output.normalized_errors.shape, (steps, followers, 2))
        self.assertEqual(output.performance_bounds.shape, (steps,))
        self.assertEqual(output.approximations.shape, (steps, followers, 2))
        self.assertEqual(output.observer_estimates.shape, (steps, followers, 2))
        self.assertEqual(output.trigger_metrics.shape, (steps, followers))
        self.assertEqual(output.trigger_thresholds.shape, (steps, followers))
        self.assertTrue(np.isfinite(output.transformed_errors).all())
        self.assertTrue(np.isfinite(output.observer_estimates).all())
        self.assertTrue((output.performance_bounds >= 1.0).all())
        self.assertGreater(np.linalg.norm(output.observer_estimates), 0.0)
        self.assertGreater(np.max(output.trigger_thresholds), 0.0)


if __name__ == "__main__":
    unittest.main()
