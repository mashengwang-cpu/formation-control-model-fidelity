import tempfile
import unittest

import numpy as np
import pandas as pd

from finite_control_sim.config import load_config
from finite_control_sim.diagnostics import export_diagnostic_run
from finite_control_sim.simulator import SimulationJob


class DiagnosticExportTests(unittest.TestCase):
    def test_export_diagnostic_run_writes_npz_and_summary_csv(self) -> None:
        config = load_config("simulation/configs/stage1_screening.json")
        job = SimulationJob(
            method="proposed_full",
            scenario="combined_attack_fault",
            seed=0,
            predefined_time_s=5.0,
            uav_count=4,
            usv_count=4,
        )

        with tempfile.TemporaryDirectory() as tmp:
            result = export_diagnostic_run(config, job, tmp)
            with np.load(result.npz_path) as arrays:
                files = set(arrays.files)
                times_len = len(arrays["times"])
            summary = pd.read_csv(result.summary_path)

        self.assertTrue(result.npz_path.name.endswith(".npz"))
        self.assertTrue(result.summary_path.name.endswith(".csv"))
        self.assertIn("transformed_errors", files)
        self.assertIn("observer_estimates", files)
        self.assertIn("trigger_thresholds", files)
        self.assertIn("performance_bounds", files)
        self.assertIn("physical_position_errors", files)
        self.assertIn("network_position_errors", files)
        self.assertIn("controller_position_errors", files)
        self.assertIn("held_position_errors", files)
        self.assertIn("max_tracking_error", summary.columns)
        self.assertIn("mean_control_norm", summary.columns)
        self.assertIn("mean_network_error", summary.columns)
        self.assertIn("mean_hold_gap", summary.columns)
        self.assertEqual(len(summary), times_len)


if __name__ == "__main__":
    unittest.main()
