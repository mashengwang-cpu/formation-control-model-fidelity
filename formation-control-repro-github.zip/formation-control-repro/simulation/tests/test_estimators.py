import unittest
from pathlib import Path
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from finite_control_sim.estimators import (  # noqa: E402
    OnlineBiasEstimator,
    OnlineEfficiencyEstimator,
    OnlineEstimatorConfig,
)
from finite_control_sim.controllers import METHOD_SPECS  # noqa: E402
from finite_control_sim.models import build_agent_dynamics, platform_command_response  # noqa: E402
from finite_control_sim.config import parse_config  # noqa: E402
from finite_control_sim.simulator import SimulationJob, simulate_job  # noqa: E402
from finite_control_sim.statistics import (  # noqa: E402
    add_bootstrap_ci,
    matched_pairs_rank_biserial,
    paired_wilcoxon_holm,
)


class EstimatorContractTests(unittest.TestCase):
    def test_oracle_leakage_patterns_are_removed_from_controller_paths(self) -> None:
        root = Path(__file__).resolve().parents[1]
        simulator = (root / "src" / "finite_control_sim" / "simulator.py").read_text(encoding="utf-8")
        torch_backend = (root / "src" / "finite_control_sim" / "experiments_torch.py").read_text(encoding="utf-8")

        self.assertNotIn("0.82 * sensor", simulator + torch_backend)
        self.assertIn("actuator_efficiency=actuator_efficiency_estimate", simulator)
        fault_call = torch_backend[torch_backend.find("commanded = _fault_tolerance_torch") : torch_backend.find("commanded = _fault_tolerance_torch") + 220]
        self.assertNotIn("actuator[:, step]", fault_call)
        self.assertIn("efficiency_hat if spec.resilience else torch.ones_like(efficiency_hat)", torch_backend)

    def test_online_estimators_update_without_ground_truth_labels(self) -> None:
        bias = OnlineBiasEstimator(follower_count=2, dimensions=2)
        first = bias.update(np.array([[0.2, 0.1], [0.0, -0.1]]), np.zeros((2, 2)), 0.02)
        second = bias.update(np.array([[0.35, 0.1], [0.0, -0.2]]), np.zeros((2, 2)), 0.02)
        self.assertTrue(np.allclose(first, 0.0))
        self.assertGreater(np.linalg.norm(second), 0.0)

        efficiency = OnlineEfficiencyEstimator(follower_count=1)
        estimate = efficiency.update(
            applied_control=np.array([[2.0, 0.0]]),
            observed_acceleration=np.array([[1.0, 0.0]]),
            mass=np.array([1.0]),
            modelled_drag=np.zeros((1, 2)),
            dt_s=0.02,
        )
        self.assertTrue(np.isfinite(estimate).all())
        self.assertGreaterEqual(float(estimate[0]), 0.35)

    def test_bias_estimator_does_not_invent_bias_in_nominal_motion(self) -> None:
        estimator = OnlineBiasEstimator(follower_count=1, dimensions=2)
        measured = np.array([[0.2, -0.1]], dtype=float)
        velocity = np.array([[0.3, -0.2]], dtype=float)
        estimates = []
        for _ in range(200):
            estimates.append(estimator.update(measured, velocity, 0.02))
            measured = measured + 0.02 * velocity
        self.assertLess(float(np.max(np.abs(estimates))), 1e-10)

    def test_bias_estimator_tracks_a_persistent_step_without_positive_feedback(self) -> None:
        estimator = OnlineBiasEstimator(follower_count=1, dimensions=2)
        measured = np.zeros((1, 2), dtype=float)
        velocity = np.zeros((1, 2), dtype=float)
        estimator.update(measured, velocity, 0.02)
        for _ in range(40):
            estimate = estimator.update(measured + np.array([[0.3, -0.2]]), velocity, 0.02)
        gain = estimator.config.bias_gain
        leak = estimator.config.bias_decay * 0.02
        steady = gain / (gain + leak) * np.array([[0.3, -0.2]])
        self.assertTrue(np.allclose(estimate, steady, atol=0.02))
        self.assertLess(float(np.max(np.abs(estimate))), 0.40)

    def test_bias_bandwidth_is_nearly_step_size_invariant(self) -> None:
        estimates = []
        for dt_s in (0.02, 0.01, 0.005):
            estimator = OnlineBiasEstimator(
                follower_count=1,
                dimensions=2,
                config=OnlineEstimatorConfig(bias_bandwidth_s_inv=7.5),
            )
            zero = np.zeros((1, 2), dtype=float)
            estimator.update(zero, zero, dt_s)
            for _ in range(round(1.0 / dt_s)):
                estimate = estimator.update(
                    np.array([[0.3, -0.2]]), zero, dt_s
                )
            estimates.append(estimate)
        self.assertLess(float(np.max(np.ptp(np.stack(estimates), axis=0))), 0.002)

    def test_efficiency_estimator_tracks_loss_without_prior_bias_when_excited(self) -> None:
        estimator = OnlineEfficiencyEstimator(follower_count=1)
        applied = np.array([[2.0, 0.0]])
        for _ in range(150):
            estimate = estimator.update(
                applied_control=applied,
                observed_acceleration=np.array([[1.2, 0.0]]),
                mass=np.array([1.0]),
                modelled_drag=np.zeros((1, 2)),
                dt_s=0.02,
            )
        # Under persistent excitation the gated-recovery law tracks the
        # projection value (rho = 1.2/2.0 = 0.6) without a healthy-prior bias.
        self.assertAlmostEqual(float(estimate[0]), 0.6, delta=0.03)

    def test_efficiency_estimator_can_represent_deep_loss_of_effectiveness(self) -> None:
        estimator = OnlineEfficiencyEstimator(follower_count=1)
        applied = np.array([[2.0, 0.0]])
        for _ in range(300):
            estimate = estimator.update(
                applied_control=applied,
                observed_acceleration=np.array([[0.8, 0.0]]),
                mass=np.array([1.0]),
                modelled_drag=np.zeros((1, 2)),
                dt_s=0.02,
            )
        # rho = 0.8/2.0 = 0.40 lies below the old 0.55 projection floor and
        # inside the widened one; the estimate must be able to reach it.
        self.assertAlmostEqual(float(estimate[0]), 0.4, delta=0.03)

    def test_efficiency_estimator_drifts_to_health_prior_without_excitation(self) -> None:
        estimator = OnlineEfficiencyEstimator(follower_count=1)
        estimator.efficiency = np.array([0.5])
        for _ in range(2000):
            estimate = estimator.update(
                applied_control=np.zeros((1, 2)),
                observed_acceleration=np.zeros((1, 2)),
                mass=np.array([1.0]),
                modelled_drag=np.zeros((1, 2)),
                dt_s=0.02,
            )
        self.assertGreater(float(estimate[0]), 0.85)

    def test_efficiency_estimator_is_bounded_under_adversarial_inputs(self) -> None:
        estimator = OnlineEfficiencyEstimator(follower_count=1)
        rng = np.random.default_rng(0)
        for _ in range(500):
            estimate = estimator.update(
                applied_control=rng.normal(0.0, 5.0, size=(1, 2)),
                observed_acceleration=rng.normal(0.0, 500.0, size=(1, 2)),
                mass=np.array([1.0]),
                modelled_drag=rng.normal(0.0, 50.0, size=(1, 2)),
                dt_s=0.02,
            )
            self.assertTrue(np.isfinite(estimate).all())
            self.assertGreaterEqual(float(estimate[0]), estimator.config.efficiency_min)
            self.assertLessEqual(float(estimate[0]), estimator.config.efficiency_max)

    def test_oracle_mode_is_explicit_and_causal_mode_does_not_equal_truth(self) -> None:
        config = parse_config(
            {
                "name": "information-mode-test",
                "followers": {"uav": 1, "usv": 1},
                "predefined_times_s": [0.2],
                "supplement_predefined_times_s": [0.1],
                "seeds": [0],
                "methods": ["proposed_full"],
                "scenarios": ["combined_attack_fault"],
                "scalability_agents": [2],
                "simulation": {
                    "numeric_backend": "numpy",
                    "state_dtype": "float64",
                    "integrator": "semi_implicit_euler",
                    "dt_s": 0.02,
                    "duration_s": 0.4,
                    "resilience_bias_bandwidth_s_inv": 7.5,
                },
                "statistics": {},
            }
        )
        common = dict(
            method="proposed_full",
            scenario="combined_attack_fault",
            seed=0,
            predefined_time_s=0.2,
            uav_count=1,
            usv_count=1,
        )
        oracle = simulate_job(
            config,
            SimulationJob(**common, resilience_information_mode="oracle"),
        )
        causal = simulate_job(
            config,
            SimulationJob(**common, resilience_information_mode="causal"),
        )
        self.assertTrue(np.array_equal(oracle.bias_estimates, oracle.sensor_biases))
        self.assertTrue(
            np.array_equal(
                oracle.actuator_efficiency_estimates,
                oracle.actuator_efficiencies,
            )
        )
        self.assertFalse(np.array_equal(causal.bias_estimates, causal.sensor_biases))

    def test_bootstrap_signature_accepts_old_and_new_argument_names(self) -> None:
        frame = pd.DataFrame(
            {
                "method": ["a", "a", "b", "b"],
                "metric_a": [1.0, 2.0, 3.0, 4.0],
            }
        )
        old_style = add_bootstrap_ci(frame, group_cols=["method"], metric_cols=["metric_a"], bootstrap_samples=10)
        new_style = add_bootstrap_ci(frame, "metric_a", group_columns=["method"], samples=10)

        self.assertEqual(set(old_style["method"]), {"a", "b"})
        self.assertEqual(set(new_style["method"]), {"a", "b"})

    def test_paired_wilcoxon_outputs_holm_and_effect_size_columns(self) -> None:
        frame = pd.DataFrame(
            {
                "method": ["proposed_full", "baseline"] * 4,
                "seed": [0, 0, 1, 1, 2, 2, 3, 3],
                "scenario": ["nominal"] * 8,
                "predefined_time_s": [5.0] * 8,
                "formation_tracking_error": [0.1, 0.2, 0.11, 0.2, 0.1, 0.19, 0.12, 0.21],
            }
        )
        tests = paired_wilcoxon_holm(
            frame,
            reference_method="proposed_full",
            comparator_methods=["baseline"],
            metrics=["formation_tracking_error"],
            pair_columns=["seed", "scenario", "predefined_time_s"],
            lower_is_better={"formation_tracking_error"},
        )

        self.assertEqual(len(tests), 1)
        self.assertIn("holm_adjusted_p", tests.columns)
        self.assertIn("cliffs_delta", tests.columns)
        self.assertIn("matched_pairs_rank_biserial", tests.columns)
        self.assertIn("reference_win_rate", tests.columns)
        self.assertIn("holm_family", tests.columns)
        self.assertEqual(int(tests.loc[0, "paired_blocks"]), 4)

    def test_matched_pairs_rank_biserial_has_explicit_direction(self) -> None:
        self.assertEqual(matched_pairs_rank_biserial(np.array([-3.0, -2.0, -1.0])), -1.0)
        self.assertEqual(matched_pairs_rank_biserial(np.array([3.0, 2.0, 1.0])), 1.0)

    def test_bca_interval_contains_the_mean(self) -> None:
        from finite_control_sim.statistics import bca_mean_ci, wilcoxon_r_from_z

        values = np.linspace(0.10, 0.14, 50)
        mean, lo, hi = bca_mean_ci(values, samples=400, seed=1)
        self.assertTrue(lo <= mean <= hi)
        self.assertLess(wilcoxon_r_from_z(np.full(50, -0.01)), 0.0)
        self.assertGreater(wilcoxon_r_from_z(np.full(50, 0.01)), 0.0)

    def test_uav_usv_platform_model_is_not_mass_damping_only(self) -> None:
        dynamics = build_agent_dynamics(["leader", "UAV", "USV"], max_control=5.0)

        self.assertLess(dynamics.control_time_constant[0], dynamics.control_time_constant[1])
        self.assertGreater(dynamics.lateral_control_gain[0], dynamics.lateral_control_gain[1])
        self.assertGreater(dynamics.yaw_coupling_gain[1], dynamics.yaw_coupling_gain[0])
        self.assertGreater(dynamics.crossflow_drag[1], dynamics.crossflow_drag[0])

        command_state = np.zeros((2, 2), dtype=float)
        command = np.array([[1.0, 1.0], [1.0, 1.0]], dtype=float)
        velocity = np.array([[0.5, 0.2], [0.5, 0.2]], dtype=float)
        _, effective = platform_command_response(dynamics, command_state, command, velocity, 0.02)

        self.assertGreater(effective[0, 1], effective[1, 1])

    def test_proposed_full_parameters_are_fixed(self) -> None:
        spec = METHOD_SPECS["proposed_full"]

        self.assertAlmostEqual(spec.position_gain, 2.15)
        self.assertAlmostEqual(spec.velocity_gain, 2.05)
        self.assertAlmostEqual(spec.finite_power, 0.60)
        self.assertAlmostEqual(spec.fixed_power, 1.45)


if __name__ == "__main__":
    unittest.main()
