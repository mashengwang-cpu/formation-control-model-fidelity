import dataclasses
import unittest

import numpy as np

from finite_control_sim.config import load_config
from finite_control_sim.controllers import (
    ControllerInput,
    ControllerState,
    ModularController,
    get_method_spec,
)
from finite_control_sim.simulator import SimulationJob, simulate_job


def _signed_power(values: np.ndarray, power: float) -> np.ndarray:
    return np.sign(values) * np.power(np.abs(values) + 1e-9, power)


class V200ControllerContractTests(unittest.TestCase):
    def test_event_triggered_control_law_uses_held_error_when_no_update_is_accepted(self) -> None:
        spec = get_method_spec("predefined_time_no_resilience")
        controller = ModularController(spec=spec, follower_count=1, dimensions=2, max_control=50.0)
        held_error = np.array([[0.05, -0.02]], dtype=float)
        state = ControllerState(
            adaptive_weights=np.zeros((1, controller.basis_size, 2), dtype=float),
            observer_state=np.zeros((1, 2), dtype=float),
            trigger_filter=np.zeros(1, dtype=float),
            sampled_error=held_error.copy(),
        )
        inputs = ControllerInput(
            time_s=0.4,
            dt_s=0.02,
            position_error=np.array([[0.8, -0.6]], dtype=float),
            velocity_error=np.zeros((1, 2), dtype=float),
            sampled_error=held_error.copy(),
            time_since_event=np.array([0.02], dtype=float),
            communication_available=np.array([False]),
            actuator_efficiency=np.ones(1, dtype=float),
            predefined_time_s=5.0,
            constraint_radius=1.0,
            trigger_base_threshold=0.0,
            trigger_max_hold_s=10.0,
        )

        output = controller.step(state, inputs)
        held_z = controller.performance.transform(held_error, output.performance_bound)
        gain = spec.position_gain * controller.schedule.gain(
            spec,
            time_s=inputs.time_s,
            predefined_time_s=inputs.predefined_time_s,
        )
        expected_raw = -gain * held_z
        expected_raw += -0.6 * _signed_power(held_z, spec.finite_power)
        expected_raw += -0.25 * _signed_power(held_z, spec.fixed_power)

        self.assertFalse(output.triggered[0])
        np.testing.assert_allclose(output.raw_control, expected_raw, rtol=1e-8, atol=1e-8)

    def test_controller_input_declares_minimum_inter_event_guard(self) -> None:
        field_names = {field.name for field in dataclasses.fields(ControllerInput)}

        self.assertIn("minimum_inter_event_s", field_names)

    def test_topology_aware_simulator_reports_physical_network_and_held_errors(self) -> None:
        config = load_config("simulation/configs/stage1_screening.json")
        job = SimulationJob(
            method="proposed_full",
            scenario="nominal",
            seed=3,
            predefined_time_s=5.0,
            uav_count=4,
            usv_count=4,
            topology_name="ring",
            topology_feedback_gain=1.0,
        )

        output = simulate_job(config, job)

        for attribute in (
            "physical_position_errors",
            "network_position_errors",
            "controller_position_errors",
            "held_position_errors",
        ):
            self.assertTrue(hasattr(output, attribute), attribute)
            value = getattr(output, attribute)
            self.assertEqual(value.shape, (len(output.times), 8, 2))
            self.assertTrue(np.isfinite(value).all())

        self.assertGreater(
            np.linalg.norm(output.network_position_errors - output.physical_position_errors),
            0.0,
        )
        np.testing.assert_allclose(
            output.tracking_errors,
            np.linalg.norm(output.physical_position_errors, axis=2),
            rtol=1e-10,
            atol=1e-10,
        )


if __name__ == "__main__":
    unittest.main()
