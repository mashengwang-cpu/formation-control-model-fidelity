import unittest

import numpy as np

from finite_control_sim.controllers import (
    ControllerInput,
    ControllerState,
    ModularController,
    PrescribedPerformance,
    get_method_spec,
)


class ControllerModuleTests(unittest.TestCase):
    def test_proposed_method_exposes_full_theory_modules(self) -> None:
        spec = get_method_spec("proposed_full")

        self.assertTrue(spec.predefined)
        self.assertTrue(spec.constraint_aware)
        self.assertTrue(spec.adaptive_approximation)
        self.assertTrue(spec.disturbance_observer)
        self.assertTrue(spec.event_triggered)
        self.assertTrue(spec.fault_tolerant)
        self.assertTrue(spec.resilience)

    def test_prescribed_performance_transform_is_finite_and_monotone(self) -> None:
        transform = PrescribedPerformance(initial_radius=1.6, final_radius=0.4)
        early = transform.bounds(time_s=0.0, predefined_time_s=5.0)
        late = transform.bounds(time_s=5.0, predefined_time_s=5.0)
        errors = np.array([[0.1, -0.2], [1.2, 0.0]], dtype=float)

        normalized = transform.normalize(errors, early)
        transformed = transform.transform(errors, early)

        self.assertGreater(early, late)
        self.assertGreaterEqual(late, 0.4)
        self.assertTrue(np.isfinite(normalized).all())
        self.assertTrue(np.isfinite(transformed).all())
        self.assertLess(np.max(np.abs(normalized)), 1.0)

    def test_modular_controller_step_updates_state_and_returns_diagnostics(self) -> None:
        spec = get_method_spec("proposed_full")
        controller = ModularController(spec=spec, follower_count=2, dimensions=2, max_control=5.0)
        state = ControllerState.zeros(follower_count=2, dimensions=2, basis_size=controller.basis_size)
        inputs = ControllerInput(
            time_s=0.2,
            dt_s=0.02,
            position_error=np.array([[0.4, -0.2], [-0.3, 0.1]], dtype=float),
            velocity_error=np.array([[0.1, 0.0], [0.0, -0.2]], dtype=float),
            sampled_error=np.zeros((2, 2), dtype=float),
            time_since_event=np.array([0.2, 0.2], dtype=float),
            communication_available=np.array([True, True]),
            actuator_efficiency=np.array([0.7, 1.0], dtype=float),
            predefined_time_s=5.0,
            constraint_radius=1.0,
            trigger_base_threshold=0.03,
            trigger_max_hold_s=0.5,
        )

        output = controller.step(state, inputs)

        self.assertEqual(output.commanded_control.shape, (2, 2))
        self.assertTrue(np.isfinite(output.commanded_control).all())
        self.assertTrue((np.linalg.norm(output.commanded_control, axis=1) <= 5.0 + 1e-9).all())
        self.assertTrue(np.isfinite(output.transformed_error).all())
        self.assertTrue(np.isfinite(output.approximation).all())
        self.assertTrue(np.isfinite(output.observer_estimate).all())
        self.assertEqual(output.triggered.shape, (2,))
        self.assertGreater(np.linalg.norm(output.next_state.adaptive_weights), 0.0)
        self.assertGreater(np.linalg.norm(output.next_state.observer_state), 0.0)
        self.assertEqual(output.next_state.sampled_error.shape, (2, 2))


if __name__ == "__main__":
    unittest.main()
