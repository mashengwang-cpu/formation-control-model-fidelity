"""Newton–Euler 6-DOF quadrotor plant with a geometric SO(3) inner loop.

UAV followers in ``plant_model='quadrotor_6dof'`` use this rigid-body model.
USV followers stay on the lagged planar map. The outer formation law remains
two-dimensional; this module only realises the UAV command as tilted thrust.

The model is a confirmatory plant, not a PX4/Gazebo recertification of the
frozen V1000 matrix. Units are SI (kg, m, s, N, N·m) with the same 1 kg UAV
mass used by the planar proxy.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

GRAVITY = 9.81
E3 = np.array([0.0, 0.0, 1.0], dtype=float)


@dataclass
class QuadrotorFleet:
    mass: np.ndarray
    inertia: np.ndarray
    p: np.ndarray
    v: np.ndarray
    R: np.ndarray
    omega: np.ndarray
    arm_length: float = 0.18
    yaw_moment_arm: float = 0.016
    k_r: float = 8.0
    k_omega: float = 1.25
    k_z: float = 16.0
    k_vz: float = 8.0
    tilt_limit_rad: float = 0.70
    thrust_min_frac: float = 0.18
    thrust_max_frac: float = 2.40
    linear_drag: float = 0.24
    quadratic_drag: float = 0.012
    gravity: float = GRAVITY
    inner_dt_s: float = 0.005
    hover_z: float = 1.5
    matched_drag: bool = False

    @property
    def n(self) -> int:
        return int(self.mass.shape[0])

    @property
    def drag_force(self) -> np.ndarray:
        if self.matched_drag:
            xy_speed = np.linalg.norm(self.v[:, :2], axis=1, keepdims=True)
            drag_xy = (self.linear_drag + self.quadratic_drag * xy_speed) * self.v[:, :2]
            drag_z = (self.linear_drag + self.quadratic_drag * np.abs(self.v[:, 2])) * self.v[:, 2]
            return np.column_stack((drag_xy, drag_z))
        speed = np.linalg.norm(self.v, axis=1, keepdims=True)
        return (self.linear_drag + self.quadratic_drag * speed) * self.v


def initialize_fleet(
    *,
    mass: np.ndarray,
    p_xy: np.ndarray,
    v_xy: np.ndarray,
    hover_z: float = 1.5,
    inner_dt_s: float = 0.005,
    rng: np.random.Generator | None = None,
    attitude_bandwidth_scale: float = 1.0,
    tilt_limit_rad: float = 0.70,
    thrust_max_frac: float = 2.40,
    matched_drag: bool = False,
) -> QuadrotorFleet:
    if attitude_bandwidth_scale <= 0 or inner_dt_s <= 0:
        raise ValueError("Attitude bandwidth scale and inner step must be positive.")
    if not 0 < tilt_limit_rad < np.pi / 2 or thrust_max_frac <= 0.18:
        raise ValueError("Invalid tilt limit or thrust ceiling.")
    mass = np.asarray(mass, dtype=float).reshape(-1)
    n = int(mass.shape[0])
    if n == 0:
        return QuadrotorFleet(
            mass=mass,
            inertia=np.zeros((0, 3), dtype=float),
            p=np.zeros((0, 3), dtype=float),
            v=np.zeros((0, 3), dtype=float),
            R=np.zeros((0, 3, 3), dtype=float),
            omega=np.zeros((0, 3), dtype=float),
            inner_dt_s=float(inner_dt_s),
            hover_z=float(hover_z),
        )
    p_xy = np.asarray(p_xy, dtype=float).reshape(n, 2)
    v_xy = np.asarray(v_xy, dtype=float).reshape(n, 2)
    generator = rng if rng is not None else np.random.default_rng(0)
    z_noise = generator.normal(0.0, 0.04, size=n)
    vz_noise = generator.normal(0.0, 0.02, size=n)
    p = np.column_stack((p_xy, float(hover_z) + z_noise))
    v = np.column_stack((v_xy, vz_noise))
    R = np.broadcast_to(np.eye(3, dtype=float), (n, 3, 3)).copy()
    omega = np.zeros((n, 3), dtype=float)
    inertia = np.column_stack((0.010 * mass, 0.010 * mass, 0.018 * mass))
    return QuadrotorFleet(
        mass=mass,
        inertia=inertia,
        p=p,
        v=v,
        R=R,
        omega=omega,
        inner_dt_s=float(inner_dt_s),
        hover_z=float(hover_z),
        k_r=8.0 * float(attitude_bandwidth_scale)**2,
        k_omega=1.25 * float(attitude_bandwidth_scale),
        tilt_limit_rad=float(tilt_limit_rad),
        thrust_max_frac=float(thrust_max_frac),
        matched_drag=bool(matched_drag),
    )


def mixer_matrix(arm_length: float, yaw_moment_arm: float) -> np.ndarray:
    """Map per-rotor thrust to wrench ``[T, tau_x, tau_y, tau_z]`` (X-config)."""

    length = float(arm_length)
    yaw = float(yaw_moment_arm)
    return np.array(
        [
            [1.0, 1.0, 1.0, 1.0],
            [-length, length, length, -length],
            [length, -length, length, -length],
            [-yaw, -yaw, yaw, yaw],
        ],
        dtype=float,
    )


def allocate_rotors(
    thrust: np.ndarray,
    torque: np.ndarray,
    *,
    arm_length: float,
    yaw_moment_arm: float,
    thrust_max: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    allocation = mixer_matrix(arm_length, yaw_moment_arm)
    inverse = np.linalg.inv(allocation)
    wrench = np.column_stack((np.asarray(thrust, dtype=float), np.asarray(torque, dtype=float)))
    rotor = wrench @ inverse.T
    rotor = np.clip(rotor, 0.0, np.asarray(thrust_max, dtype=float)[:, None])
    wrench_act = rotor @ allocation.T
    return rotor, wrench_act


def hat_map(omega: np.ndarray) -> np.ndarray:
    w = np.asarray(omega, dtype=float)
    if w.ndim == 1:
        w = w[None, :]
    skew = np.zeros((w.shape[0], 3, 3), dtype=float)
    skew[:, 0, 1] = -w[:, 2]
    skew[:, 0, 2] = w[:, 1]
    skew[:, 1, 0] = w[:, 2]
    skew[:, 1, 2] = -w[:, 0]
    skew[:, 2, 0] = -w[:, 1]
    skew[:, 2, 1] = w[:, 0]
    return skew


def exp_so3(omega_dt: np.ndarray) -> np.ndarray:
    w = np.asarray(omega_dt, dtype=float)
    if w.ndim == 1:
        w = w[None, :]
    theta = np.linalg.norm(w, axis=1)
    rotation = np.broadcast_to(np.eye(3, dtype=float), (w.shape[0], 3, 3)).copy()
    small = theta < 1e-10
    if np.any(small):
        rotation[small] = np.eye(3) + hat_map(w[small])
    large = ~small
    if np.any(large):
        axis = w[large] / theta[large, None]
        skew = hat_map(axis)
        skew2 = np.matmul(skew, skew)
        sine = np.sin(theta[large])[:, None, None]
        cosine = np.cos(theta[large])[:, None, None]
        rotation[large] = np.eye(3) + sine * skew + (1.0 - cosine) * skew2
    return rotation


def project_so3(rotation: np.ndarray) -> np.ndarray:
    u_factor, _, vt = np.linalg.svd(rotation)
    projected = np.matmul(u_factor, vt)
    det = np.linalg.det(projected)
    if np.ndim(det) == 0:
        if det < 0.0:
            u_factor = u_factor.copy()
            u_factor[:, 2] *= -1.0
            projected = u_factor @ vt
        return projected
    flip = det < 0.0
    if np.any(flip):
        u_factor = u_factor.copy()
        u_factor[flip, :, 2] *= -1.0
        projected[flip] = np.matmul(u_factor[flip], vt[flip])
    return projected


def attitude_error(rotation: np.ndarray, desired: np.ndarray) -> np.ndarray:
    relative = np.matmul(np.transpose(desired, (0, 2, 1)), rotation)
    relative_t = np.matmul(np.transpose(rotation, (0, 2, 1)), desired)
    skew = relative - relative_t
    return 0.5 * np.stack((skew[:, 2, 1], skew[:, 0, 2], skew[:, 1, 0]), axis=1)


def desired_rotation(f_des: np.ndarray, yaw: np.ndarray) -> np.ndarray:
    force = np.asarray(f_des, dtype=float)
    norm = np.linalg.norm(force, axis=1, keepdims=True)
    b3 = np.divide(force, np.maximum(norm, 1e-9))
    yaw = np.asarray(yaw, dtype=float).reshape(-1)
    b1c = np.column_stack((np.cos(yaw), np.sin(yaw), np.zeros(force.shape[0], dtype=float)))
    b2 = np.cross(b3, b1c)
    b2_norm = np.linalg.norm(b2, axis=1, keepdims=True)
    fallback = (b2_norm[:, 0] < 1e-8)
    if np.any(fallback):
        b1c_fb = np.column_stack(
            (-np.sin(yaw[fallback]), np.cos(yaw[fallback]), np.zeros(int(np.sum(fallback)), dtype=float))
        )
        b2[fallback] = np.cross(b3[fallback], b1c_fb)
        b2_norm = np.linalg.norm(b2, axis=1, keepdims=True)
    b2 = np.divide(b2, np.maximum(b2_norm, 1e-9))
    b1 = np.cross(b2, b3)
    return np.stack((b1, b2, b3), axis=2)


def tilt_angle(rotation: np.ndarray) -> np.ndarray:
    body_z = rotation[:, :, 2]
    cosine = np.clip(body_z[:, 2], -1.0, 1.0)
    return np.arccos(cosine)


def step_fleet(
    fleet: QuadrotorFleet,
    *,
    force_xy: np.ndarray,
    actuator_efficiency: np.ndarray,
    disturbance_3d: np.ndarray,
    yaw_des: float | np.ndarray,
    outer_dt_s: float,
    z_des: float | None = None,
) -> dict[str, np.ndarray]:
    """Advance the fleet through inner substeps covering one outer interval."""

    if fleet.n == 0:
        empty = np.zeros((0, 2), dtype=float)
        return {
            "force_xy": empty,
            "tilt": np.zeros(0, dtype=float),
            "attitude_error": np.zeros(0, dtype=float),
            "altitude": np.zeros(0, dtype=float),
        }

    n_inner = max(1, int(np.ceil(float(outer_dt_s) / float(fleet.inner_dt_s))))
    inner_dt = float(outer_dt_s) / n_inner
    hover_force = fleet.mass * fleet.gravity
    t_min = fleet.thrust_min_frac * hover_force
    t_max = fleet.thrust_max_frac * hover_force
    rotor_max = t_max / 4.0
    z_cmd = float(fleet.hover_z if z_des is None else z_des)
    yaw = np.full(fleet.n, float(np.asarray(yaw_des).reshape(-1)[0]), dtype=float)
    force_xy = np.asarray(force_xy, dtype=float).reshape(fleet.n, 2)
    rho = np.clip(np.asarray(actuator_efficiency, dtype=float).reshape(fleet.n), 0.05, 1.2)
    disturbance_3d = np.asarray(disturbance_3d, dtype=float).reshape(fleet.n, 3)
    last_force_xy = np.zeros((fleet.n, 2), dtype=float)
    force_sum = np.zeros_like(last_force_xy)
    force_effort = np.zeros(fleet.n)
    rotor_saturated = np.zeros(fleet.n)
    tilt_saturated = np.zeros(fleet.n)

    for _ in range(n_inner):
        a_xy = force_xy / fleet.mass[:, None]
        a_z = fleet.k_z * (z_cmd - fleet.p[:, 2]) + fleet.k_vz * (0.0 - fleet.v[:, 2])
        horiz = np.linalg.norm(a_xy, axis=1)
        max_horiz = np.tan(fleet.tilt_limit_rad) * np.maximum(a_z + fleet.gravity, 0.4)
        scale = np.minimum(1.0, max_horiz / np.maximum(horiz, 1e-9))
        tilt_saturated += (scale < 1.0 - 1e-12)
        a_xy = a_xy * scale[:, None]
        f_des = np.column_stack((a_xy[:, 0], a_xy[:, 1], a_z + fleet.gravity)) * fleet.mass[:, None]
        thrust_cmd = np.clip(np.linalg.norm(f_des, axis=1), t_min, t_max)
        near_zero = np.linalg.norm(f_des, axis=1) < 1e-9
        if np.any(near_zero):
            f_des[near_zero] = np.broadcast_to(E3 * hover_force[near_zero, None], (int(np.sum(near_zero)), 3))
        desired = desired_rotation(f_des, yaw)
        error_r = attitude_error(fleet.R, desired)
        error_w = fleet.omega
        j_omega = fleet.inertia * fleet.omega
        gyro = np.cross(fleet.omega, j_omega)
        torque_cmd = -fleet.k_r * error_r - fleet.k_omega * error_w + gyro
        _rotor, wrench = allocate_rotors(
            thrust_cmd,
            torque_cmd,
            arm_length=fleet.arm_length,
            yaw_moment_arm=fleet.yaw_moment_arm,
            thrust_max=rotor_max,
        )
        desired_wrench = np.column_stack((thrust_cmd, torque_cmd))
        rotor_saturated += np.any(np.abs(wrench - desired_wrench) > 1e-9, axis=1)
        wrench[:, 0] *= rho
        wrench[:, 1:4] *= rho[:, None]
        thrust = wrench[:, 0]
        torque = wrench[:, 1:4]
        body_z = fleet.R[:, :, 2]
        force_inertial = body_z * thrust[:, None]
        drag = fleet.drag_force
        accel = (force_inertial + disturbance_3d - drag) / fleet.mass[:, None]
        accel[:, 2] -= fleet.gravity
        inertia_inv = 1.0 / fleet.inertia
        omega_dot = inertia_inv * (torque - np.cross(fleet.omega, fleet.inertia * fleet.omega))
        fleet.omega = fleet.omega + inner_dt * omega_dot
        fleet.R = project_so3(np.matmul(fleet.R, exp_so3(fleet.omega * inner_dt)))
        fleet.v = fleet.v + inner_dt * accel
        fleet.p = fleet.p + inner_dt * fleet.v
        last_force_xy = force_inertial[:, :2]
        force_sum += last_force_xy
        force_effort += inner_dt * np.sum(last_force_xy**2, axis=1)

    att_norm = np.linalg.norm(attitude_error(fleet.R, desired), axis=1)
    return {
        "force_xy": force_sum / n_inner,
        "force_effort": force_effort,
        "rotor_saturation_fraction": rotor_saturated / n_inner,
        "tilt_saturation_fraction": tilt_saturated / n_inner,
        "tilt": tilt_angle(fleet.R),
        "attitude_error": att_norm,
        "altitude": fleet.p[:, 2].copy(),
    }


def disturbance_3d(
    time_s: float,
    n: int,
    seed_scale: float,
    *,
    disturbance_scale: float = 1.0,
) -> np.ndarray:
    idx = np.arange(1, n + 1, dtype=float)
    xy_z = np.column_stack(
        [
            0.035 * np.sin(0.7 * time_s + 0.31 * idx + seed_scale),
            0.03 * np.cos(0.5 * time_s + 0.17 * idx + 0.5 * seed_scale),
            0.020 * np.sin(0.4 * time_s + 0.22 * idx + 0.3 * seed_scale),
        ]
    )
    return float(disturbance_scale) * xy_z
