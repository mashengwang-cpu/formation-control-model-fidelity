from __future__ import annotations

from dataclasses import dataclass, replace

import numpy as np


@dataclass(frozen=True)
class AgentDynamics:
    agent_types: list[str]
    damping: np.ndarray
    mass: np.ndarray
    control_limit: np.ndarray
    control_time_constant: np.ndarray
    lateral_control_gain: np.ndarray
    yaw_coupling_gain: np.ndarray
    crossflow_drag: np.ndarray
    quadratic_drag: np.ndarray


def leader_reference(time_s: float) -> tuple[np.ndarray, np.ndarray]:
    position = np.array(
        [
            0.55 * time_s,
            1.4 * np.sin(0.28 * time_s),
        ],
        dtype=float,
    )
    velocity = np.array(
        [
            0.55,
            1.4 * 0.28 * np.cos(0.28 * time_s),
        ],
        dtype=float,
    )
    return position, velocity


def formation_offsets(follower_count: int, spacing: float) -> np.ndarray:
    if follower_count < 1:
        raise ValueError("follower_count must be positive.")
    offsets = np.zeros((follower_count, 2), dtype=float)
    for idx in range(follower_count):
        column = idx // 2 + 1
        row = -0.5 if idx % 2 == 0 else 0.5
        offsets[idx] = np.array([-spacing * column, spacing * row], dtype=float)
    return offsets


def build_agent_dynamics(
    agent_types: list[str],
    max_control: float,
    *,
    uncertainty: float = 0.0,
    rng: np.random.Generator | None = None,
) -> AgentDynamics:
    follower_types = agent_types[1:]
    damping = np.zeros(len(follower_types), dtype=float)
    mass = np.zeros(len(follower_types), dtype=float)
    limit = np.full(len(follower_types), float(max_control), dtype=float)
    control_time_constant = np.zeros(len(follower_types), dtype=float)
    lateral_control_gain = np.ones(len(follower_types), dtype=float)
    yaw_coupling_gain = np.zeros(len(follower_types), dtype=float)
    crossflow_drag = np.zeros(len(follower_types), dtype=float)
    quadratic_drag = np.zeros(len(follower_types), dtype=float)

    for idx, agent_type in enumerate(follower_types):
        if agent_type == "UAV":
            damping[idx] = 0.24
            mass[idx] = 1.0
            control_time_constant[idx] = 0.08
            lateral_control_gain[idx] = 1.0
            yaw_coupling_gain[idx] = 0.02
            crossflow_drag[idx] = 0.0
            quadratic_drag[idx] = 0.012
        elif agent_type == "USV":
            damping[idx] = 0.36
            mass[idx] = 1.35
            control_time_constant[idx] = 0.24
            lateral_control_gain[idx] = 0.34
            yaw_coupling_gain[idx] = 0.22
            crossflow_drag[idx] = 0.10
            quadratic_drag[idx] = 0.065
        else:
            raise ValueError(f"Unsupported follower type: {agent_type}")
    uncertainty = float(uncertainty)
    if uncertainty < 0.0:
        raise ValueError("dynamics uncertainty must be non-negative.")
    if uncertainty > 0.0:
        generator = rng if rng is not None else np.random.default_rng(0)
        mass *= generator.uniform(1.0 - uncertainty, 1.0 + uncertainty, size=mass.shape)
        damping *= generator.uniform(1.0 - uncertainty, 1.0 + uncertainty, size=damping.shape)
        control_time_constant *= generator.uniform(1.0 - uncertainty, 1.0 + uncertainty, size=control_time_constant.shape)
        lateral_control_gain *= generator.uniform(1.0 - 0.5 * uncertainty, 1.0 + 0.5 * uncertainty, size=lateral_control_gain.shape)
        yaw_coupling_gain *= generator.uniform(1.0 - uncertainty, 1.0 + uncertainty, size=yaw_coupling_gain.shape)
        crossflow_drag *= generator.uniform(1.0 - uncertainty, 1.0 + uncertainty, size=crossflow_drag.shape)
        quadratic_drag *= generator.uniform(1.0 - uncertainty, 1.0 + uncertainty, size=quadratic_drag.shape)
        mass = np.maximum(mass, 1e-6)
        damping = np.maximum(damping, 0.0)
        control_time_constant = np.maximum(control_time_constant, 0.02)
        lateral_control_gain = np.maximum(lateral_control_gain, 0.05)
        yaw_coupling_gain = np.maximum(yaw_coupling_gain, 0.0)
        crossflow_drag = np.maximum(crossflow_drag, 0.0)
        quadratic_drag = np.maximum(quadratic_drag, 0.0)
    return AgentDynamics(
        agent_types=list(follower_types),
        damping=damping,
        mass=mass,
        control_limit=limit,
        control_time_constant=control_time_constant,
        lateral_control_gain=lateral_control_gain,
        yaw_coupling_gain=yaw_coupling_gain,
        crossflow_drag=crossflow_drag,
        quadratic_drag=quadratic_drag,
    )


def deterministic_disturbance(
    time_s: float,
    follower_count: int,
    seed_scale: float,
    *,
    disturbance_scale: float = 1.0,
) -> np.ndarray:
    idx = np.arange(1, follower_count + 1, dtype=float)
    disturbance = np.column_stack(
        [
            0.035 * np.sin(0.7 * time_s + 0.31 * idx + seed_scale),
            0.03 * np.cos(0.5 * time_s + 0.17 * idx + 0.5 * seed_scale),
        ]
    )
    return float(disturbance_scale) * disturbance


def follower_type_mask(dynamics: AgentDynamics, agent_type: str) -> np.ndarray:
    return np.array([item == agent_type for item in dynamics.agent_types], dtype=bool)


def slice_agent_dynamics(dynamics: AgentDynamics, mask: np.ndarray) -> AgentDynamics:
    mask = np.asarray(mask, dtype=bool)
    return AgentDynamics(
        agent_types=[name for name, keep in zip(dynamics.agent_types, mask) if keep],
        damping=np.asarray(dynamics.damping, dtype=float)[mask],
        mass=np.asarray(dynamics.mass, dtype=float)[mask],
        control_limit=np.asarray(dynamics.control_limit, dtype=float)[mask],
        control_time_constant=np.asarray(dynamics.control_time_constant, dtype=float)[mask],
        lateral_control_gain=np.asarray(dynamics.lateral_control_gain, dtype=float)[mask],
        yaw_coupling_gain=np.asarray(dynamics.yaw_coupling_gain, dtype=float)[mask],
        crossflow_drag=np.asarray(dynamics.crossflow_drag, dtype=float)[mask],
        quadratic_drag=np.asarray(dynamics.quadratic_drag, dtype=float)[mask],
    )


def apply_v1000_canonical_point_mass(dynamics: AgentDynamics) -> AgentDynamics:
    """Restore the archived V1000 UAV/USV linear damping (0.28 / 0.42)."""

    damping = np.asarray(dynamics.damping, dtype=float).copy()
    for idx, agent_type in enumerate(dynamics.agent_types):
        if agent_type == "UAV":
            damping[idx] = 0.28
        elif agent_type == "USV":
            damping[idx] = 0.42
    return replace(dynamics, damping=damping)


def apply_usv_underactuation_scale(dynamics: AgentDynamics, scale: float) -> AgentDynamics:
    """Scale USV sway authority; UAV gains are unchanged. Scale 1.0 is a no-op."""
    factor = float(scale)
    if abs(factor - 1.0) < 1e-12:
        return dynamics
    if factor <= 0.0:
        raise ValueError("usv_underactuation_scale must be positive.")
    lateral = np.asarray(dynamics.lateral_control_gain, dtype=float).copy()
    for idx, agent_type in enumerate(dynamics.agent_types):
        if agent_type == "USV":
            lateral[idx] *= factor
    return replace(dynamics, lateral_control_gain=np.maximum(lateral, 0.05))


def platform_command_response(
    dynamics: AgentDynamics,
    command_state: np.ndarray,
    commanded_control: np.ndarray,
    velocity: np.ndarray,
    dt_s: float,
    plant_model: str = "planar_proxy",
) -> tuple[np.ndarray, np.ndarray]:
    """Map controller commands to platform-aware planar forces.

    UAV followers use a fast first-order outer-loop lag. USV followers use a
    slower response with weak direct sway authority and a yaw-coupled lateral
    force proxy. ``planar_proxy`` keeps the force axes aligned with the
    inertial frame. ``course_aligned`` rotates the lagged command into a
    body frame whose x-axis follows the present velocity heading, which is a
    reduced underactuated kinematics proxy, not a 3-DOF Fossen plant.
    """

    model = str(plant_model)
    if model not in {"planar_proxy", "course_aligned"}:
        raise ValueError(
            f"Unsupported plant_model {model!r}. "
            "Use planar_proxy or course_aligned here; quadrotor_6dof, mixed_6dof_3dof "
            "and v1000_canonical are handled by the simulator."
        )
    tau = np.maximum(dynamics.control_time_constant[:, None], 1e-6)
    next_state = command_state + float(dt_s) * (commanded_control - command_state) / tau
    next_state = np.clip(next_state, -dynamics.control_limit[:, None], dynamics.control_limit[:, None])
    if model == "course_aligned":
        heading = np.arctan2(velocity[:, 1], velocity[:, 0])
        cosine = np.cos(heading)
        sine = np.sin(heading)
        surge = next_state[:, 0]
        sway = dynamics.lateral_control_gain * next_state[:, 1]
        yaw_coupled_sway = dynamics.yaw_coupling_gain * np.tanh(np.hypot(velocity[:, 0], velocity[:, 1])) * next_state[:, 0]
        sway = sway + yaw_coupled_sway
        effective = np.column_stack((cosine * surge - sine * sway, sine * surge + cosine * sway))
        return next_state, effective
    effective = next_state.copy()
    surge_velocity = velocity[:, 0]
    yaw_coupled_sway = dynamics.yaw_coupling_gain * np.tanh(surge_velocity) * next_state[:, 0]
    effective[:, 1] = dynamics.lateral_control_gain * next_state[:, 1] + yaw_coupled_sway
    return next_state, effective


def platform_hydrodynamic_drag(dynamics: AgentDynamics, velocity: np.ndarray) -> np.ndarray:
    linear = dynamics.damping[:, None] * velocity
    quadratic = dynamics.quadratic_drag[:, None] * np.abs(velocity) * velocity
    crossflow = np.column_stack(
        [
            np.zeros(len(velocity), dtype=float),
            dynamics.crossflow_drag * np.abs(velocity[:, 0]) * velocity[:, 1],
        ]
    )
    return linear + quadratic + crossflow


def isotropic_planar_drag(dynamics: AgentDynamics, velocity: np.ndarray) -> np.ndarray:
    """Common SI drag contract for the new matched-fidelity layers."""
    speed = np.linalg.norm(velocity, axis=1, keepdims=True)
    return (dynamics.damping[:, None] + dynamics.quadratic_drag[:, None] * speed) * velocity


def explicit_command_lag(command_state: np.ndarray, command: np.ndarray,
                         tau_s: np.ndarray, dt_s: float) -> np.ndarray:
    """Exact first-order world-frame command filter; tau=0 is a direct wire."""
    tau = np.asarray(tau_s, dtype=float)
    if np.any(tau < 0) or dt_s <= 0:
        raise ValueError("Command lags must be nonnegative and dt positive.")
    alpha = np.ones_like(tau)
    positive = tau > 0
    alpha[positive] = -np.expm1(-float(dt_s) / tau[positive])
    return command_state + alpha[:, None] * (command - command_state)
