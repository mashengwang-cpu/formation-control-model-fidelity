from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict
from time import perf_counter

import numpy as np
import pandas as pd

from .config import ExperimentConfig
from .controllers import MethodSpec, get_method_spec
from .estimators import (
    estimator_config_from_mapping,
    torch_bias_estimator_step,
    torch_efficiency_estimator_step,
)
from .experiments import apply_nominal_rdi
from .metrics import compute_run_metrics
from .models import build_agent_dynamics
from .scenarios import build_scenario_profile
from .simulator import SimulationJob
from .torch_backend.device import import_torch, resolve_torch_device
from .topology import build_leader_follower_topology, topology_weight_matrices


def run_torch_experiment_jobs(
    jobs: list[SimulationJob],
    config: ExperimentConfig,
    *,
    device_spec: str = "cpu",
    batch_size: int = 256,
    progress: bool = True,
) -> pd.DataFrame:
    if not jobs:
        return pd.DataFrame()
    torch = import_torch()
    device = resolve_torch_device(device_spec)
    groups: dict[tuple[str, str, int, int], list[SimulationJob]] = defaultdict(list)
    for job in jobs:
        groups[(job.method, job.scenario, job.uav_count, job.usv_count)].append(job)

    records: list[dict[str, float | int | str]] = []
    total = len(jobs)
    completed = 0
    batch_size = max(1, int(batch_size))
    for group_key, group_jobs in groups.items():
        for start in range(0, len(group_jobs), batch_size):
            batch_jobs = group_jobs[start : start + batch_size]
            batch_records = simulate_job_batch_torch(torch, config, batch_jobs, device=device)
            records.extend(batch_records)
            completed += len(batch_jobs)
            if progress:
                print(f"[{completed}/{total}] torch {device} group={group_key} batch={len(batch_jobs)}")
    return apply_nominal_rdi(pd.DataFrame.from_records(records))


def simulate_job_batch_torch(torch, config: ExperimentConfig, jobs: list[SimulationJob], *, device) -> list[dict[str, float | int | str]]:
    if not jobs:
        return []
    first = jobs[0]
    if any((job.method, job.scenario, job.uav_count, job.usv_count) != (first.method, first.scenario, first.uav_count, first.usv_count) for job in jobs):
        raise ValueError("Torch batches must share method, scenario, uav_count and usv_count.")

    spec = get_method_spec(first.method)
    follower_count = first.uav_count + first.usv_count
    dt = float(config.simulation["dt_s"])
    duration = float(config.simulation["duration_s"])
    times_np = np.arange(0.0, duration + 0.5 * dt, dt, dtype=np.float32)
    steps = len(times_np)
    batch = len(jobs)

    spacing = float(config.simulation.get("formation_spacing", 1.2))
    max_control = float(config.simulation.get("max_control", 8.0))
    error_tolerance = float(config.simulation.get("error_tolerance", 0.08))
    constraint_radius = float(config.simulation.get("constraint_radius", 1.2))
    performance_initial_radius = float(config.simulation.get("performance_initial_radius", 1.5))
    trigger_threshold = float(config.simulation.get("event_trigger_threshold", 0.035))
    max_hold_s = float(config.simulation.get("max_event_hold_s", 0.55))
    minimum_inter_event_s = float(config.simulation.get("minimum_inter_event_s", 0.0))
    observer_gain = float(config.simulation.get("observer_gain", 0.7))
    observer_leakage = float(config.simulation.get("observer_leakage", 0.25))
    trigger_sigma_1 = float(config.simulation.get("trigger_sigma_1", 0.08))
    trigger_filter_decay = float(config.simulation.get("trigger_filter_decay", 1.2))
    trigger_filter_gain = float(config.simulation.get("trigger_filter_gain", 0.015))
    nominal_integral = float(config.simulation.get("nominal_integral_error", 1.0))
    estimator_config = estimator_config_from_mapping(config.simulation)

    prepared = [_prepare_numpy_inputs(config, job, times_np, follower_count, spacing, max_control) for job in jobs]
    positions = _tensor(torch, np.stack([item["positions"] for item in prepared]), device)
    velocities = _tensor(torch, np.stack([item["velocities"] for item in prepared]), device)
    actuator = _tensor(torch, np.stack([item["actuator"] for item in prepared]), device)
    sensor_bias = _tensor(torch, np.stack([item["sensor_bias"] for item in prepared]), device)
    communication = torch.as_tensor(np.stack([item["communication"] for item in prepared]), dtype=torch.bool, device=device)
    mass = _tensor(torch, np.stack([item["mass"] for item in prepared]), device)
    damping = _tensor(torch, np.stack([item["damping"] for item in prepared]), device)
    control_time_constant = _tensor(torch, np.stack([item["control_time_constant"] for item in prepared]), device)
    lateral_control_gain = _tensor(torch, np.stack([item["lateral_control_gain"] for item in prepared]), device)
    yaw_coupling_gain = _tensor(torch, np.stack([item["yaw_coupling_gain"] for item in prepared]), device)
    crossflow_drag = _tensor(torch, np.stack([item["crossflow_drag"] for item in prepared]), device)
    quadratic_drag = _tensor(torch, np.stack([item["quadratic_drag"] for item in prepared]), device)
    leader_weights = _tensor(torch, np.stack([item["leader_weights"] for item in prepared]), device)
    follower_weights = _tensor(torch, np.stack([item["follower_weights"] for item in prepared]), device)
    topology_gain_values = np.array([job.topology_feedback_gain for job in jobs], dtype=np.float32)
    topology_gains = _tensor(torch, topology_gain_values, device)
    has_topology_feedback = bool(np.any(topology_gain_values > 0.0))
    topology_mode_values = np.array([_topology_mode_code(job.topology_name) for job in jobs], dtype=np.int64)
    topology_codes = torch.as_tensor(
        topology_mode_values,
        dtype=torch.int64,
        device=device,
    )
    has_switching_topology = bool(np.any(topology_mode_values == 1))
    has_leader_dropout_topology = bool(np.any(topology_mode_values == 2))
    switch_periods = _tensor(torch, np.array([job.topology_switch_period_s for job in jobs], dtype=np.float32), device)
    disturbance_scales = _tensor(torch, np.array([job.disturbance_scale for job in jobs], dtype=np.float32), device)
    predefined_times = _tensor(torch, np.array([job.predefined_time_s for job in jobs], dtype=np.float32), device)

    offsets = _formation_offsets_torch(torch, follower_count, spacing, device)
    adaptive_weights = torch.zeros((batch, follower_count, 7, 2), dtype=torch.float32, device=device)
    observer_state = torch.zeros((batch, follower_count, 2), dtype=torch.float32, device=device)
    trigger_filter = torch.zeros((batch, follower_count), dtype=torch.float32, device=device)
    bias_hat = torch.zeros((batch, follower_count, 2), dtype=torch.float32, device=device)
    efficiency_hat = torch.ones((batch, follower_count), dtype=torch.float32, device=device)
    platform_command_state = torch.zeros((batch, follower_count, 2), dtype=torch.float32, device=device)

    leader0, leader_vel0 = _leader_reference_torch(torch, 0.0, device)
    desired0 = leader0[None, None, :] + offsets[None, :, :]
    initial_error = positions - desired0
    predicted_unbiased_error = initial_error.clone()
    if has_topology_feedback:
        initial_network_error = _topology_error_torch(
            torch,
            initial_error,
            leader_weights,
            follower_weights,
            topology_codes,
            switch_periods,
            time_s=0.0,
            has_switching=has_switching_topology,
            has_leader_dropout=has_leader_dropout_topology,
        )
        initial_blend = torch.clamp(topology_gains, min=0.0, max=1.0)[:, None, None]
        sampled_error = (1.0 - initial_blend) * initial_error + initial_blend * initial_network_error
    else:
        sampled_error = initial_error
    sampled_velocity_error = velocities - leader_vel0[None, None, :].expand(batch, follower_count, 2)
    last_event_time = torch.zeros((batch, follower_count), dtype=torch.float32, device=device)

    tracking_errors = torch.zeros((steps, batch, follower_count), dtype=torch.float32, device=device)
    controls = torch.zeros((steps, batch, follower_count, 2), dtype=torch.float32, device=device)
    trigger_events = torch.zeros((steps, batch, follower_count), dtype=torch.bool, device=device)
    constraint_violations = torch.zeros((steps, batch, follower_count), dtype=torch.bool, device=device)

    started = perf_counter()
    for step, time_s_np in enumerate(times_np):
        time_s = float(time_s_np)
        leader_position, leader_velocity = _leader_reference_torch(torch, time_s, device)
        desired = leader_position[None, None, :] + offsets[None, :, :]
        desired_velocity = leader_velocity[None, None, :].expand(batch, follower_count, 2)
        current_velocity_error = velocities - desired_velocity

        sensor_step = sensor_bias[:, step]
        raw_measured_positions = positions + sensor_step
        raw_measured_error = raw_measured_positions - desired
        if spec.resilience:
            bias_hat, predicted_unbiased_error = torch_bias_estimator_step(
                torch,
                bias_hat,
                predicted_unbiased_error,
                raw_measured_error,
                current_velocity_error,
                dt_s=dt,
                config=estimator_config,
            )
            measured_positions = raw_measured_positions - bias_hat
        else:
            measured_positions = raw_measured_positions
        current_error = measured_positions - desired
        if has_topology_feedback:
            network_error = _topology_error_torch(
                torch,
                current_error,
                leader_weights,
                follower_weights,
                topology_codes,
                switch_periods,
                time_s=time_s,
                has_switching=has_switching_topology,
                has_leader_dropout=has_leader_dropout_topology,
            )
            blend = torch.clamp(topology_gains, min=0.0, max=1.0)[:, None, None]
            current_error = (1.0 - blend) * current_error + blend * network_error
        time_since_event = time_s - last_event_time

        output = _controller_step_torch(
            torch,
            spec,
            adaptive_weights,
            observer_state,
            trigger_filter,
            sampled_error,
            sampled_velocity_error,
            current_error,
            current_velocity_error,
            time_since_event,
            communication[:, step],
            efficiency_hat if spec.resilience else torch.ones_like(efficiency_hat),
            predefined_times,
            time_s=time_s,
            dt=dt,
            constraint_radius=constraint_radius,
            performance_initial_radius=performance_initial_radius,
            trigger_base_threshold=trigger_threshold,
            trigger_max_hold_s=max_hold_s,
            minimum_inter_event_s=minimum_inter_event_s,
            observer_gain=observer_gain,
            observer_leakage=observer_leakage,
            trigger_sigma_1=trigger_sigma_1,
            trigger_filter_decay=trigger_filter_decay,
            trigger_filter_gain=trigger_filter_gain,
            max_control=max_control,
        )
        (
            commanded,
            adaptive_weights,
            observer_state,
            trigger_filter,
            sampled_error,
            sampled_velocity_error,
            event_mask,
            envelope,
        ) = output
        if step == 0:
            event_mask = torch.ones_like(event_mask, dtype=torch.bool)
            sampled_error = current_error
            sampled_velocity_error = current_velocity_error
        last_event_time = torch.where(event_mask, torch.full_like(last_event_time, time_s), last_event_time)

        platform_command_state, platform_control = _platform_command_response_torch(
            torch,
            platform_command_state,
            commanded,
            velocities,
            control_time_constant,
            lateral_control_gain,
            yaw_coupling_gain,
            max_control,
            dt,
        )
        actual_control = actuator[:, step, :, None] * platform_control
        true_error = positions - desired
        error_norm = torch.linalg.norm(true_error, dim=2)
        tracking_errors[step] = error_norm
        controls[step] = commanded
        trigger_events[step] = event_mask
        constraint_violations[step] = error_norm > envelope[:, None]

        if step == steps - 1:
            break
        previous_velocities = velocities
        disturbance = _disturbance_torch(
            torch,
            time_s,
            follower_count,
            np.array([0.01 * job.seed for job in jobs], dtype=np.float32),
            disturbance_scales,
            device,
        )
        drag = _platform_drag_torch(torch, velocities, damping, quadratic_drag, crossflow_drag)
        acceleration = (actual_control + disturbance - drag) / mass[:, :, None]
        velocities = velocities + dt * acceleration
        positions = positions + dt * velocities
        if spec.resilience:
            observed_acceleration = (velocities - previous_velocities) / dt
            efficiency_hat = torch_efficiency_estimator_step(
                torch,
                efficiency_hat,
                applied_control=platform_control,
                observed_acceleration=observed_acceleration,
                mass=mass,
                modelled_drag=drag,
                dt_s=dt,
                config=estimator_config,
            )

    elapsed = perf_counter() - started
    return _records_from_tensors(
        jobs,
        times_np.astype(float),
        tracking_errors.detach().cpu().numpy(),
        controls.detach().cpu().numpy(),
        trigger_events.detach().cpu().numpy(),
        constraint_violations.detach().cpu().numpy(),
        predefined_times.detach().cpu().numpy(),
        error_tolerance=error_tolerance,
        nominal_integral=nominal_integral,
        elapsed_per_job=elapsed / max(batch, 1),
    )


def _prepare_numpy_inputs(
    config: ExperimentConfig,
    job: SimulationJob,
    times: np.ndarray,
    follower_count: int,
    spacing: float,
    max_control: float,
) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(job.seed)
    topology = build_leader_follower_topology(
        job.uav_count,
        job.usv_count,
        topology_name=job.topology_name,
        seed=job.seed,
    )
    dynamics = build_agent_dynamics(
        topology.agent_types,
        max_control=max_control,
        uncertainty=job.dynamics_uncertainty,
        rng=rng,
    )
    scenario = build_scenario_profile(
        job.scenario,
        times.astype(float),
        follower_count,
        rng,
        actuator_loss_scale=job.actuator_loss_scale,
        fdi_scale=job.fdi_scale,
        dos_duty_scale=job.dos_duty_scale,
    )
    leader_weights, follower_weights = topology_weight_matrices(topology)
    offsets = _formation_offsets_np(follower_count, spacing)
    leader_pos0 = np.array([0.0, 0.0], dtype=np.float32)
    leader_vel0 = np.array([0.55, 1.4 * 0.28], dtype=np.float32)
    desired0 = leader_pos0[None, :] + offsets
    positions = desired0 + rng.normal(0.0, 0.42, size=(follower_count, 2)).astype(np.float32)
    velocities = np.tile(leader_vel0, (follower_count, 1)).astype(np.float32) * 0.15
    return {
        "positions": positions.astype(np.float32),
        "velocities": velocities.astype(np.float32),
        "actuator": scenario.actuator_efficiency.astype(np.float32),
        "sensor_bias": scenario.sensor_bias.astype(np.float32),
        "communication": scenario.communication_available.astype(bool),
        "mass": dynamics.mass.astype(np.float32),
        "damping": dynamics.damping.astype(np.float32),
        "control_time_constant": dynamics.control_time_constant.astype(np.float32),
        "lateral_control_gain": dynamics.lateral_control_gain.astype(np.float32),
        "yaw_coupling_gain": dynamics.yaw_coupling_gain.astype(np.float32),
        "crossflow_drag": dynamics.crossflow_drag.astype(np.float32),
        "quadratic_drag": dynamics.quadratic_drag.astype(np.float32),
        "leader_weights": leader_weights.astype(np.float32),
        "follower_weights": follower_weights.astype(np.float32),
        "max_control": np.array(max_control, dtype=np.float32),
    }


def _controller_step_torch(
    torch,
    spec: MethodSpec,
    adaptive_weights,
    observer_state,
    trigger_filter,
    sampled_error,
    sampled_velocity_error,
    position_error,
    velocity_error,
    time_since_event,
    communication_available,
    actuator_efficiency_estimate,
    predefined_times,
    *,
    time_s: float,
    dt: float,
    constraint_radius: float,
    performance_initial_radius: float,
    trigger_base_threshold: float,
    trigger_max_hold_s: float,
    minimum_inter_event_s: float,
    observer_gain: float,
    observer_leakage: float,
    trigger_sigma_1: float,
    trigger_filter_decay: float,
    trigger_filter_gain: float,
    max_control: float,
):
    bound = _performance_bound_torch(torch, time_s, predefined_times, performance_initial_radius, constraint_radius)
    if spec.constraint_aware:
        normalized_error = torch.clamp(position_error / bound[:, None, None].clamp_min(1e-9), -0.98, 0.98)
        transformed_error = 0.5 * torch.log((1.0 + normalized_error) / (1.0 - normalized_error))
        sampled_norm = torch.clamp(sampled_error / bound[:, None, None].clamp_min(1e-9), -0.98, 0.98)
        transformed_sampled = 0.5 * torch.log((1.0 + sampled_norm) / (1.0 - sampled_norm))
    else:
        normalized_error = position_error / bound[:, None, None].clamp_min(1e-9)
        transformed_error = position_error
        transformed_sampled = sampled_error

    metric = torch.linalg.norm(transformed_error - transformed_sampled, dim=2)
    error_norm = torch.linalg.norm(transformed_error, dim=2)
    next_filter = torch.clamp(
        trigger_filter
        + dt
        * (
            -float(trigger_filter_decay) * trigger_filter
            + float(trigger_filter_gain) * error_norm**2
            - 0.5 * float(trigger_filter_gain) * metric**2
        ),
        min=0.0,
    )
    trigger_threshold = float(trigger_base_threshold) + float(trigger_sigma_1) * error_norm + next_filter
    if spec.event_triggered:
        triggered = ((metric >= trigger_threshold) | (time_since_event >= trigger_max_hold_s)) & communication_available
        triggered = triggered & (time_since_event >= max(float(minimum_inter_event_s), 0.0))
    else:
        triggered = communication_available
    sampled_error = torch.where(triggered[:, :, None], position_error, sampled_error)
    sampled_velocity_error = torch.where(triggered[:, :, None], velocity_error, sampled_velocity_error)
    if spec.constraint_aware:
        sampled_norm_after = torch.clamp(sampled_error / bound[:, None, None].clamp_min(1e-9), -0.98, 0.98)
        control_transformed_error = 0.5 * torch.log((1.0 + sampled_norm_after) / (1.0 - sampled_norm_after))
    else:
        control_transformed_error = sampled_error

    basis = _basis_torch(torch, transformed_error, velocity_error)
    if spec.adaptive_approximation:
        approximation = torch.einsum("bnhd,bnh->bnd", adaptive_weights, basis)
        weight_update = 0.18 * basis[:, :, :, None] * transformed_error[:, :, None, :] - 0.02 * adaptive_weights
        next_weights = adaptive_weights + dt * weight_update
    else:
        approximation = torch.zeros_like(transformed_error)
        next_weights = adaptive_weights

    if spec.disturbance_observer:
        next_observer = observer_state + dt * (float(observer_gain) * transformed_error - float(observer_leakage) * observer_state)
        observer_estimate = next_observer
    else:
        next_observer = observer_state
        observer_estimate = torch.zeros_like(transformed_error)

    gain = spec.position_gain * _time_contract_gain_torch(torch, spec, time_s, predefined_times)
    raw_control = -gain[:, None, None] * control_transformed_error - spec.velocity_gain * sampled_velocity_error
    if spec.finite_power is not None:
        raw_control = raw_control - 0.6 * _signed_power_torch(torch, control_transformed_error, spec.finite_power)
    if spec.fixed_power is not None:
        raw_control = raw_control - 0.25 * _signed_power_torch(torch, control_transformed_error, spec.fixed_power)
    raw_control = raw_control - approximation - observer_estimate
    commanded = _fault_tolerance_torch(torch, raw_control, actuator_efficiency_estimate, spec.fault_tolerant, max_control)
    return commanded, next_weights, next_observer, next_filter, sampled_error, sampled_velocity_error, triggered, bound


def _records_from_tensors(
    jobs: list[SimulationJob],
    times: np.ndarray,
    tracking_errors: np.ndarray,
    controls: np.ndarray,
    trigger_events: np.ndarray,
    constraint_violations: np.ndarray,
    predefined_times: np.ndarray,
    *,
    error_tolerance: float,
    nominal_integral: float,
    elapsed_per_job: float,
) -> list[dict[str, float | int | str]]:
    records = []
    for index, job in enumerate(jobs):
        metrics = compute_run_metrics(
            times=times,
            tracking_errors=tracking_errors[:, index, :],
            controls=controls[:, index, :, :],
            trigger_events=trigger_events[:, index, :],
            constraint_violations=constraint_violations[:, index, :],
            predefined_time_s=float(predefined_times[index]),
            error_tolerance=error_tolerance,
            nominal_integral_error=nominal_integral,
            computation_time_s=elapsed_per_job,
        )
        records.append({**asdict(job), **metrics})
    return records


def _tensor(torch, array: np.ndarray, device):
    return torch.as_tensor(array, dtype=torch.float32, device=device)


def _leader_reference_torch(torch, time_s: float, device):
    t = torch.tensor(float(time_s), dtype=torch.float32, device=device)
    position = torch.stack([0.55 * t, 1.4 * torch.sin(0.28 * t)])
    velocity = torch.stack([torch.tensor(0.55, dtype=torch.float32, device=device), 1.4 * 0.28 * torch.cos(0.28 * t)])
    return position, velocity


def _formation_offsets_np(follower_count: int, spacing: float) -> np.ndarray:
    idx = np.arange(follower_count, dtype=np.float32)
    columns = np.floor(idx / 2.0) + 1.0
    rows = np.where((idx % 2.0) == 0.0, -0.5, 0.5)
    return np.stack([-spacing * columns, spacing * rows], axis=1).astype(np.float32)


def _formation_offsets_torch(torch, follower_count: int, spacing: float, device):
    return torch.as_tensor(_formation_offsets_np(follower_count, spacing), dtype=torch.float32, device=device)


def _platform_command_response_torch(
    torch,
    command_state,
    commanded_control,
    velocity,
    control_time_constant,
    lateral_control_gain,
    yaw_coupling_gain,
    max_control: float,
    dt: float,
):
    tau = torch.clamp(control_time_constant[:, :, None], min=1e-6)
    next_state = command_state + float(dt) * (commanded_control - command_state) / tau
    next_state = torch.clamp(next_state, min=-float(max_control), max=float(max_control))
    effective_x = next_state[:, :, 0]
    yaw_coupled_sway = yaw_coupling_gain * torch.tanh(velocity[:, :, 0]) * effective_x
    effective_y = lateral_control_gain * next_state[:, :, 1] + yaw_coupled_sway
    effective = torch.stack([effective_x, effective_y], dim=2)
    return next_state, effective


def _platform_drag_torch(torch, velocity, damping, quadratic_drag, crossflow_drag):
    linear = damping[:, :, None] * velocity
    quadratic = quadratic_drag[:, :, None] * torch.abs(velocity) * velocity
    zeros = torch.zeros_like(velocity[:, :, 0])
    lateral_crossflow = crossflow_drag * torch.abs(velocity[:, :, 0]) * velocity[:, :, 1]
    crossflow = torch.stack([zeros, lateral_crossflow], dim=2)
    return linear + quadratic + crossflow


def _disturbance_torch(torch, time_s: float, follower_count: int, seed_scale: np.ndarray, disturbance_scales, device):
    idx = torch.arange(1, follower_count + 1, dtype=torch.float32, device=device)
    seed = torch.as_tensor(seed_scale, dtype=torch.float32, device=device)[:, None]
    x = 0.035 * torch.sin(0.7 * float(time_s) + 0.31 * idx[None, :] + seed)
    y = 0.03 * torch.cos(0.5 * float(time_s) + 0.17 * idx[None, :] + 0.5 * seed)
    return disturbance_scales[:, None, None] * torch.stack([x, y], dim=2)


def _topology_mode_code(topology_name: str) -> int:
    if topology_name == "switching_sparse":
        return 1
    if topology_name == "leader_dropout":
        return 2
    return 0


def _topology_error_torch(
    torch,
    position_error,
    leader_weights,
    follower_weights,
    topology_codes,
    switch_periods,
    *,
    time_s: float,
    has_switching: bool,
    has_leader_dropout: bool,
):
    effective_leader = leader_weights
    effective_follower = follower_weights
    switching_mask = topology_codes == 1
    if has_switching:
        batch, follower_count, _ = follower_weights.shape
        rows = torch.arange(follower_count, dtype=torch.int64, device=position_error.device)[:, None]
        cols = torch.arange(follower_count, dtype=torch.int64, device=position_error.device)[None, :]
        periods = torch.clamp(switch_periods, min=1e-9)
        phase = torch.remainder(torch.floor(torch.full_like(periods, float(time_s)) / periods).to(torch.int64), 2)
        keep = torch.remainder(rows[None, :, :] + cols[None, :, :] + phase[:, None, None], 2) == 0
        effective_follower = torch.where(switching_mask[:, None, None], torch.where(keep, follower_weights, torch.zeros_like(follower_weights)), follower_weights)
        _ = batch
    dropout_mask = topology_codes == 2
    if has_leader_dropout:
        span_position = (float(time_s) % 5.0) / 5.0
        in_dropout = 0.28 <= span_position <= 0.42 or 0.62 <= span_position <= 0.74
        if in_dropout:
            effective_leader = torch.where(dropout_mask[:, None], torch.zeros_like(leader_weights), leader_weights)

    follower_weight_sum = torch.sum(effective_follower, dim=2)
    total_weight = effective_leader + follower_weight_sum
    weighted_error = (
        effective_leader[:, :, None] * position_error
        + follower_weight_sum[:, :, None] * position_error
        - torch.matmul(effective_follower, position_error)
    )
    return torch.where(
        total_weight[:, :, None] > 1e-9,
        weighted_error / torch.clamp(total_weight[:, :, None], min=1e-9),
        position_error,
    )


def _performance_bound_torch(torch, time_s: float, predefined_times, initial_radius: float, final_radius: float):
    tau = torch.clamp(torch.full_like(predefined_times, float(time_s)), min=0.0) / predefined_times.clamp_min(1e-9)
    tau = torch.minimum(tau, torch.ones_like(tau))
    radius = float(final_radius) + max(float(initial_radius) - float(final_radius), 0.0) * torch.exp(-3.0 * tau)
    return torch.clamp(radius, min=float(final_radius))


def _basis_torch(torch, transformed_error, velocity_error):
    z_norm = torch.linalg.norm(transformed_error, dim=2)
    v_norm = torch.linalg.norm(velocity_error, dim=2)
    ones = torch.ones_like(z_norm)
    return torch.stack(
        [
            ones,
            transformed_error[:, :, 0],
            transformed_error[:, :, 1],
            velocity_error[:, :, 0],
            velocity_error[:, :, 1],
            z_norm,
            v_norm,
        ],
        dim=2,
    )


def _time_contract_gain_torch(torch, spec: MethodSpec, time_s: float, predefined_times):
    if not spec.predefined:
        return torch.ones_like(predefined_times)
    remaining = torch.clamp(predefined_times - float(time_s), min=0.0)
    gain = 1.0 + 0.45 / (remaining + 0.35)
    return torch.clamp(gain, max=3.0)


def _signed_power_torch(torch, values, power: float):
    return torch.sign(values) * torch.pow(torch.abs(values) + 1e-9, float(power))


def _fault_tolerance_torch(torch, control, actuator_efficiency_estimate, resilience_enabled: bool, max_control: float):
    if resilience_enabled:
        compensated = control / torch.clamp(actuator_efficiency_estimate[:, :, None], min=0.35)
    else:
        compensated = control
    norm = torch.linalg.norm(compensated, dim=2)
    scale = torch.minimum(torch.ones_like(norm), float(max_control) / torch.clamp(norm, min=1e-9))
    return compensated * scale[:, :, None]
