from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib as mpl

mpl.use("Agg")

import matplotlib.pyplot as plt


PALETTE = {
    "blue_main": "#0F4D92",
    "blue_secondary": "#3775BA",
    "red_strong": "#B64342",
    "teal": "#42949E",
    "violet": "#9A4D8E",
    "neutral_light": "#CFCECE",
    "neutral_mid": "#767676",
    "neutral_dark": "#4D4D4D",
    "neutral_black": "#272727",
}


@dataclass(frozen=True)
class FigureBundle:
    svg_path: Path
    pdf_path: Path
    tiff_path: Path
    png_path: Path
    source_data_path: Path
    qa_notes_path: Path


def make_diagnostic_main_figure(
    npz_path: str | Path,
    summary_path: str | Path,
    output_dir: str | Path,
    *,
    stem: str = "fig1_predefined_time_diagnostics",
) -> FigureBundle:
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    npz_path = Path(npz_path)
    summary_path = Path(summary_path)
    summary = pd.read_csv(summary_path)
    with np.load(npz_path) as arrays:
        data = {name: arrays[name].copy() for name in arrays.files}

    source = _build_figure_source_data(data, summary)
    source_data_path = output_path / f"{stem}_source_data.csv"
    source.to_csv(source_data_path, index=False, encoding="utf-8")

    _apply_publication_style()
    fig, axes = plt.subplots(
        2,
        2,
        figsize=(7.2, 5.2),
        constrained_layout=True,
        sharex=True,
    )
    ax_a, ax_b, ax_c, ax_d = axes.ravel()

    _plot_tracking_panel(ax_a, data, source)
    _plot_control_panel(ax_b, data, source)
    _plot_observer_panel(ax_c, data, source)
    _plot_trigger_panel(ax_d, data, source)

    for axis in axes[-1, :]:
        axis.set_xlabel("Time (s)")
    for axis in axes.ravel():
        axis.grid(True, axis="y", color="#E5E5E5", linewidth=0.45)
        axis.tick_params(axis="both", labelsize=6, width=0.55, length=2.5)
        axis.margins(x=0)

    _add_panel_label(ax_a, "a")
    _add_panel_label(ax_b, "b")
    _add_panel_label(ax_c, "c")
    _add_panel_label(ax_d, "d")

    svg_path = output_path / f"{stem}.svg"
    pdf_path = output_path / f"{stem}.pdf"
    tiff_path = output_path / f"{stem}.tiff"
    png_path = output_path / f"{stem}.png"
    fig.savefig(svg_path, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    fig.savefig(tiff_path, dpi=600, bbox_inches="tight")
    fig.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.close(fig)

    qa_notes_path = output_path / f"{stem}_qa_notes.md"
    qa_notes_path.write_text(_qa_notes(svg_path, pdf_path, tiff_path, png_path, source_data_path), encoding="utf-8")
    return FigureBundle(
        svg_path=svg_path,
        pdf_path=pdf_path,
        tiff_path=tiff_path,
        png_path=png_path,
        source_data_path=source_data_path,
        qa_notes_path=qa_notes_path,
    )


def make_stage1_screening_figure(
    runs_path: str | Path,
    output_dir: str | Path,
    *,
    stem: str = "fig2_stage1_screening_summary",
) -> FigureBundle:
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    runs = pd.read_csv(runs_path)
    source = _build_stage1_source_data(runs)
    source_data_path = output_path / f"{stem}_source_data.csv"
    source.to_csv(source_data_path, index=False, encoding="utf-8")

    _apply_publication_style()
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.4), constrained_layout=True)
    ax_a, ax_b, ax_c, ax_d = axes.ravel()

    method_order = (
        runs.groupby("method")["formation_tracking_error"]
        .mean()
        .sort_values()
        .index.tolist()
    )
    label_map = _method_label_map()
    colors = [_method_color(method) for method in method_order]

    _barh_metric(
        ax_a,
        runs.groupby("method")["formation_tracking_error"].mean().reindex(method_order),
        label_map,
        colors,
        "Stage-1 screening: tracking error",
        "Mean tracking error",
    )
    combined = (
        runs[runs["scenario"].eq("combined_attack_fault")]
        .groupby("method")["formation_tracking_error"]
        .mean()
        .reindex(method_order)
    )
    _barh_metric(
        ax_b,
        combined,
        label_map,
        colors,
        "Combined-stress tracking",
        "Mean tracking error",
    )
    events = runs.groupby("method")["event_trigger_count"].mean().reindex(method_order)
    _barh_metric(
        ax_c,
        events,
        label_map,
        colors,
        "Communication events",
        "Mean event count",
    )

    proposed = runs[runs["method"].eq("proposed_full")]
    tp_summary = (
        proposed.groupby("predefined_time_s")
        .agg(
            appointed_time_violation=("appointed_time_violation", "mean"),
            control_energy=("control_energy", "mean"),
            event_trigger_count=("event_trigger_count", "mean"),
        )
        .reset_index()
        .sort_values("predefined_time_s")
    )
    ax_d.plot(
        tp_summary["predefined_time_s"],
        tp_summary["appointed_time_violation"],
        marker="o",
        color=PALETTE["blue_main"],
        label="violation",
    )
    ax_d.set_title("Appointed-time sensitivity", loc="left", fontsize=7, pad=3)
    ax_d.set_xlabel("$T_p$ (s)")
    ax_d.set_ylabel("Violation (s)")
    ax_d.grid(True, axis="y", color="#E5E5E5", linewidth=0.45)
    ax_d.tick_params(axis="both", labelsize=6, width=0.55, length=2.5)
    ax_d.set_xticks(tp_summary["predefined_time_s"])

    _add_panel_label(ax_a, "a")
    _add_panel_label(ax_b, "b")
    _add_panel_label(ax_c, "c")
    _add_panel_label(ax_d, "d")

    svg_path = output_path / f"{stem}.svg"
    pdf_path = output_path / f"{stem}.pdf"
    tiff_path = output_path / f"{stem}.tiff"
    png_path = output_path / f"{stem}.png"
    fig.savefig(svg_path, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    fig.savefig(tiff_path, dpi=600, bbox_inches="tight")
    fig.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.close(fig)

    qa_notes_path = output_path / f"{stem}_qa_notes.md"
    qa_notes_path.write_text(_stage1_qa_notes(svg_path, pdf_path, tiff_path, png_path, source_data_path), encoding="utf-8")
    return FigureBundle(svg_path, pdf_path, tiff_path, png_path, source_data_path, qa_notes_path)


def _apply_publication_style() -> None:
    plt.rcParams["font.family"] = "sans-serif"
    plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans", "Liberation Sans"]
    plt.rcParams["svg.fonttype"] = "none"
    plt.rcParams["pdf.fonttype"] = 42
    mpl.rcParams.update(
        {
            "font.size": 7,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "axes.linewidth": 0.65,
            "legend.frameon": False,
            "lines.linewidth": 1.2,
        }
    )


def _build_figure_source_data(data: dict[str, np.ndarray], summary: pd.DataFrame) -> pd.DataFrame:
    times = data["times"]
    tracking_errors = data["tracking_errors"]
    controls = data["controls"]
    observer = data["observer_estimates"]
    trigger_metrics = data["trigger_metrics"]
    trigger_thresholds = data["trigger_thresholds"]
    control_norm = np.linalg.norm(controls, axis=2)
    observer_norm = np.linalg.norm(observer, axis=2)

    source = pd.DataFrame(
        {
            "time_s": times,
            "max_tracking_error": np.max(tracking_errors, axis=1),
            "mean_tracking_error": np.mean(tracking_errors, axis=1),
            "performance_bound": data["performance_bounds"],
            "mean_control_norm": np.mean(control_norm, axis=1),
            "peak_control_norm": np.max(control_norm, axis=1),
            "mean_observer_norm": np.mean(observer_norm, axis=1),
            "peak_observer_norm": np.max(observer_norm, axis=1),
            "mean_trigger_metric": np.mean(trigger_metrics, axis=1),
            "mean_trigger_threshold": np.mean(trigger_thresholds, axis=1),
            "event_count": np.sum(data["trigger_events"], axis=1),
            "constraint_violation_count": np.sum(data["constraint_violations"], axis=1),
        }
    )
    for column in summary.columns:
        if column not in source.columns and len(summary[column]) == len(source):
            source[column] = summary[column]
    return source


def _build_stage1_source_data(runs: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "appointed_time_violation",
        "settling_time",
        "formation_tracking_error",
        "itae_tracking_error",
        "constraint_violation_rate",
        "control_energy",
        "control_energy_per_agent_time",
        "peak_control_input",
        "event_trigger_count",
        "minimum_inter_event_time",
        "resilience_degradation_index",
        "computation_time",
    ]
    metrics = [metric for metric in metrics if metric in runs.columns]
    method_summary = runs.groupby("method")[metrics].mean().reset_index()
    method_summary["summary_type"] = "all_scenarios"
    combined = (
        runs[runs["scenario"].eq("combined_attack_fault")]
        .groupby("method")[metrics]
        .mean()
        .reset_index()
    )
    combined["summary_type"] = "combined_attack_fault"
    proposed_tp = (
        runs[runs["method"].eq("proposed_full")]
        .groupby("predefined_time_s")[metrics]
        .mean()
        .reset_index()
    )
    proposed_tp["method"] = "proposed_full"
    proposed_tp["summary_type"] = "proposed_tp_sweep"
    return pd.concat([method_summary, combined, proposed_tp], ignore_index=True, sort=False)


def _barh_metric(ax, values: pd.Series, label_map: dict[str, str], colors: list[str], title: str, xlabel: str) -> None:
    y = np.arange(len(values))
    ax.barh(y, values.to_numpy(), color=colors, height=0.72)
    ax.set_yticks(y)
    ax.set_yticklabels([label_map.get(method, method) for method in values.index], fontsize=5.8)
    ax.invert_yaxis()
    ax.set_xlabel(xlabel)
    ax.set_title(title, loc="left", fontsize=7, pad=3)
    ax.grid(True, axis="x", color="#E5E5E5", linewidth=0.45)
    ax.tick_params(axis="x", labelsize=6, width=0.55, length=2.5)
    for idx, value in enumerate(values.to_numpy()):
        ax.text(value, idx, f" {value:.3g}", va="center", fontsize=5.6, color=PALETTE["neutral_dark"])


def _method_label_map() -> dict[str, str]:
    return {
        "proposed_full": "Proposed",
        "predefined_time_no_event": "No event",
        "recent_2025_resilient_fixed_time": "Recent fixed",
        "predefined_time_no_resilience": "No resilience",
        "fixed_time_adaptive": "Fixed-time",
        "event_triggered_fixed_time": "ET fixed",
        "finite_time_adaptive": "Finite-time",
        "asymptotic_adaptive": "Asymptotic",
    }


def _method_color(method: str) -> str:
    if method == "proposed_full":
        return PALETTE["blue_main"]
    if "no_resilience" in method:
        return PALETTE["red_strong"]
    if "no_event" in method:
        return PALETTE["teal"]
    if "recent" in method:
        return PALETTE["violet"]
    return PALETTE["neutral_light"]


def _plot_tracking_panel(ax, data: dict[str, np.ndarray], source: pd.DataFrame) -> None:
    times = source["time_s"].to_numpy()
    for idx in range(data["tracking_errors"].shape[1]):
        ax.plot(times, data["tracking_errors"][:, idx], color=PALETTE["neutral_light"], linewidth=0.55, alpha=0.75)
    ax.plot(times, source["max_tracking_error"], color=PALETTE["blue_main"], linewidth=1.45, label="max follower error")
    ax.plot(
        times,
        source["performance_bound"],
        color=PALETTE["red_strong"],
        linewidth=1.15,
        linestyle=(0, (4, 2)),
        label="prescribed bound",
    )
    ax.set_title("Tracking error under combined attacks", loc="left", fontsize=7, pad=3)
    ax.set_ylabel("Tracking error")
    ax.legend(loc="upper right", fontsize=5.8, handlelength=1.8)


def _plot_control_panel(ax, data: dict[str, np.ndarray], source: pd.DataFrame) -> None:
    times = source["time_s"].to_numpy()
    control_norm = np.linalg.norm(data["controls"], axis=2)
    for idx in range(control_norm.shape[1]):
        ax.plot(times, control_norm[:, idx], color=PALETTE["neutral_light"], linewidth=0.5, alpha=0.65)
    ax.plot(times, source["mean_control_norm"], color=PALETTE["teal"], linewidth=1.45, label="mean")
    ax.plot(times, source["peak_control_norm"], color=PALETTE["neutral_dark"], linewidth=1.0, label="peak")
    ax.set_title("Bounded compensated control", loc="left", fontsize=7, pad=3)
    ax.set_ylabel("Control norm")
    ax.legend(loc="upper right", fontsize=5.8, handlelength=1.8)


def _plot_observer_panel(ax, data: dict[str, np.ndarray], source: pd.DataFrame) -> None:
    times = source["time_s"].to_numpy()
    observer_norm = np.linalg.norm(data["observer_estimates"], axis=2)
    for idx in range(observer_norm.shape[1]):
        ax.plot(times, observer_norm[:, idx], color="#D9C6E1", linewidth=0.5, alpha=0.7)
    ax.plot(times, source["mean_observer_norm"], color=PALETTE["violet"], linewidth=1.45, label="mean estimate")
    ax.plot(times, source["peak_observer_norm"], color=PALETTE["neutral_dark"], linewidth=1.0, label="peak estimate")
    ax.set_title("Observer response", loc="left", fontsize=7, pad=3)
    ax.set_ylabel("Observer norm")
    ax.legend(loc="upper right", fontsize=5.8, handlelength=1.8)


def _plot_trigger_panel(ax, data: dict[str, np.ndarray], source: pd.DataFrame) -> None:
    times = source["time_s"].to_numpy()
    ax.plot(times, source["mean_trigger_metric"], color=PALETTE["blue_secondary"], linewidth=1.45, label="Trigger metric")
    ax.plot(
        times,
        source["mean_trigger_threshold"],
        color=PALETTE["red_strong"],
        linewidth=1.15,
        linestyle=(0, (4, 2)),
        label="dynamic threshold",
    )
    event_times = times[source["event_count"].to_numpy() > 0]
    if len(event_times):
        ymin, ymax = ax.get_ylim()
        ax.vlines(event_times, ymin=ymin, ymax=ymin + 0.08 * (ymax - ymin), color=PALETTE["neutral_mid"], linewidth=0.35, alpha=0.45)
    ax.set_title("Dynamic event-triggering", loc="left", fontsize=7, pad=3)
    ax.set_ylabel("Trigger metric")
    ax.legend(loc="upper right", fontsize=5.8, handlelength=1.8)


def _add_panel_label(ax, label: str) -> None:
    ax.text(
        -0.11,
        1.06,
        label,
        transform=ax.transAxes,
        fontsize=8,
        fontweight="bold",
        ha="left",
        va="bottom",
        color=PALETTE["neutral_black"],
    )


def _qa_notes(
    svg_path: Path,
    pdf_path: Path,
    tiff_path: Path,
    png_path: Path,
    source_data_path: Path,
) -> str:
    return "\n".join(
        [
            "# Figure QA Notes",
            "",
            "Core conclusion: the proposed predefined-time resilient controller maintains constrained formation tracking under combined actuator fault, FDI, and DoS stress while keeping control and event-trigger signals bounded.",
            "Archetype: quantitative grid.",
            "Backend: Python/matplotlib only.",
            "Final size: 183 mm double-column equivalent, 7.2 x 5.2 in before tight bounding box.",
            "Editable text: SVG uses `svg.fonttype = none`; PDF uses TrueType font embedding.",
            "Panels: a tracking error with prescribed bound; b control norm; c observer norm; d trigger metric and dynamic threshold.",
            "Statistics: single diagnostic trajectory, no inferential statistics claimed in this figure.",
            f"SVG: {svg_path.name}",
            f"PDF: {pdf_path.name}",
            f"TIFF: {tiff_path.name}",
            f"PNG preview: {png_path.name}",
            f"Source data: {source_data_path.name}",
            "",
        ]
    )


def _stage1_qa_notes(svg_path: Path, pdf_path: Path, tiff_path: Path, png_path: Path, source_data_path: Path) -> str:
    return "\n".join(
        [
            "# Figure QA Notes",
            "",
            "Core conclusion: stage-1 screening ranks the proposed full controller against seven baselines across 10 seeds, five scenarios and four predefined-time values.",
            "Archetype: quantitative grid.",
            "Backend: Python/matplotlib only.",
            "Panels: a all-scenario mean tracking error; b combined-stress mean tracking error; c communication event count; d proposed-method appointed-time sensitivity.",
            "Statistics: mean values from stage-1 screening only; final inferential statistics require the 50-seed evaluation.",
            f"SVG: {svg_path.name}",
            f"PDF: {pdf_path.name}",
            f"TIFF: {tiff_path.name}",
            f"PNG preview: {png_path.name}",
            f"Source data: {source_data_path.name}",
            "",
        ]
    )
