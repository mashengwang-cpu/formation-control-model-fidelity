"""3-DOF underactuated USV plant (Fossen-style surge-sway-yaw).

USV followers in ``plant_model='mixed_6dof_3dof'`` use this rigid-body map.
Surge and yaw are actuated; sway is not. The outer formation law remains
planar. This is a confirmatory plant, not a certified hull model.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class UsvFleet:
    mass: np.ndarray
    iz: np.ndarray
    p: np.ndarray
    psi: np.ndarray
    u: np.ndarray
    v_sway: np.ndarray
    r: np.ndarray
    xu: float = 0.36
    yv: float = 0.55
    nr: float = 0.18
    xuu: float = 0.065
    yvv: float = 0.10
    nrr: float = 0.04
    k_yaw: float = 2.4
    k_r: float = 1.1
    tau_u_max: float = 8.0
    tau_r_max: float = 1.6
    matched_drag: bool = False

    @property
    def n(self) -> int:
        return int(self.mass.shape[0])

    @property
    def inertial_xy(self) -> np.ndarray:
        return self.p.copy()

    @property
    def inertial_vxy(self) -> np.ndarray:
        cosine = np.cos(self.psi)
        sine = np.sin(self.psi)
        return np.column_stack(
            (
                cosine * self.u - sine * self.v_sway,
                sine * self.u + cosine * self.v_sway,
            )
        )

    @property
    def drag_world(self) -> np.ndarray:
        """Physical translational drag, excluding external force and actuator."""
        if self.matched_drag:
            speed = np.hypot(self.u, self.v_sway)
            drag_u = (self.xu + self.xuu * speed) * self.u
            drag_v = (self.xu + self.xuu * speed) * self.v_sway
        else:
            drag_u = self.xu * self.u + self.xuu * np.abs(self.u) * self.u
            drag_v = self.yv * self.v_sway + self.yvv * np.abs(self.v_sway) * self.v_sway
        cosine, sine = np.cos(self.psi), np.sin(self.psi)
        return np.column_stack((cosine * drag_u - sine * drag_v,
                                sine * drag_u + cosine * drag_v))


def initialize_usv_fleet(
    *,
    mass: np.ndarray,
    p_xy: np.ndarray,
    v_xy: np.ndarray,
    matched_drag: bool = False,
) -> UsvFleet:
    mass = np.asarray(mass, dtype=float).reshape(-1)
    n = int(mass.shape[0])
    if n == 0:
        return UsvFleet(
            mass=mass,
            iz=np.zeros(0, dtype=float),
            p=np.zeros((0, 2), dtype=float),
            psi=np.zeros(0, dtype=float),
            u=np.zeros(0, dtype=float),
            v_sway=np.zeros(0, dtype=float),
            r=np.zeros(0, dtype=float),
        )
    p_xy = np.asarray(p_xy, dtype=float).reshape(n, 2)
    v_xy = np.asarray(v_xy, dtype=float).reshape(n, 2)
    psi = np.arctan2(v_xy[:, 1], v_xy[:, 0])
    speed = np.linalg.norm(v_xy, axis=1)
    return UsvFleet(
        mass=mass,
        iz=0.12 * mass,
        p=p_xy.copy(),
        psi=psi,
        u=speed,
        v_sway=np.zeros(n, dtype=float),
        r=np.zeros(n, dtype=float),
        matched_drag=bool(matched_drag),
    )


def step_usv_fleet(
    fleet: UsvFleet,
    *,
    force_xy: np.ndarray,
    actuator_efficiency: np.ndarray,
    disturbance_xy: np.ndarray,
    dt_s: float,
    n_inner: int = 4,
) -> dict[str, np.ndarray]:
    if fleet.n == 0:
        return {"force_xy": np.zeros((0, 2), dtype=float), "yaw": np.zeros(0, dtype=float)}
    inner_dt = float(dt_s) / max(int(n_inner), 1)
    force_xy = np.asarray(force_xy, dtype=float).reshape(fleet.n, 2)
    rho = np.clip(np.asarray(actuator_efficiency, dtype=float).reshape(fleet.n), 0.05, 1.2)
    disturbance_xy = np.asarray(disturbance_xy, dtype=float).reshape(fleet.n, 2)
    last_force = np.zeros((fleet.n, 2), dtype=float)
    force_sum = np.zeros_like(last_force)
    force_effort = np.zeros(fleet.n)
    yaw_effort = np.zeros(fleet.n)
    yaw_sum = np.zeros(fleet.n)
    for _ in range(max(int(n_inner), 1)):
        cosine = np.cos(fleet.psi)
        sine = np.sin(fleet.psi)
        f_surge = cosine * force_xy[:, 0] + sine * force_xy[:, 1]
        f_sway = -sine * force_xy[:, 0] + cosine * force_xy[:, 1]
        psi_des = np.arctan2(force_xy[:, 1], force_xy[:, 0])
        yaw_err = np.arctan2(np.sin(psi_des - fleet.psi), np.cos(psi_des - fleet.psi))
        tau_u = np.clip(f_surge, -fleet.tau_u_max, fleet.tau_u_max) * rho
        tau_r = np.clip(fleet.k_yaw * yaw_err - fleet.k_r * fleet.r, -fleet.tau_r_max, fleet.tau_r_max) * rho
        disturbance_u = cosine * disturbance_xy[:, 0] + sine * disturbance_xy[:, 1]
        disturbance_v = -sine * disturbance_xy[:, 0] + cosine * disturbance_xy[:, 1]
        if fleet.matched_drag:
            speed = np.hypot(fleet.u, fleet.v_sway)
            drag_u = (fleet.xu + fleet.xuu * speed) * fleet.u
            drag_v = (fleet.xu + fleet.xuu * speed) * fleet.v_sway
        else:
            drag_u = fleet.xu * fleet.u + fleet.xuu * np.abs(fleet.u) * fleet.u
            drag_v = fleet.yv * fleet.v_sway + fleet.yvv * np.abs(fleet.v_sway) * fleet.v_sway
        du = (
            tau_u + disturbance_u - drag_u
            + fleet.mass * fleet.v_sway * fleet.r
        ) / fleet.mass
        dv = (
            disturbance_v - drag_v
            - fleet.mass * fleet.u * fleet.r
        ) / fleet.mass
        dr = (
            tau_r
            - fleet.nr * fleet.r
            - fleet.nrr * np.abs(fleet.r) * fleet.r
        ) / fleet.iz
        fleet.u = fleet.u + inner_dt * du
        fleet.v_sway = fleet.v_sway + inner_dt * dv
        fleet.r = fleet.r + inner_dt * dr
        fleet.psi = fleet.psi + inner_dt * fleet.r
        vxy = fleet.inertial_vxy
        fleet.p = fleet.p + inner_dt * vxy
        last_force = np.column_stack((cosine * tau_u, sine * tau_u))
        force_sum += last_force
        force_effort += inner_dt * tau_u**2
        yaw_effort += inner_dt * tau_r**2
        yaw_sum += tau_r
    return {"force_xy": force_sum / max(int(n_inner), 1), "yaw": fleet.psi.copy(),
            "force_effort": force_effort, "yaw_torque_effort": yaw_effort,
            "yaw_torque": yaw_sum / max(int(n_inner), 1)}
