from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict
from pathlib import Path

import numpy as np
import pandas as pd

from .config import ExperimentConfig, load_config
from .simulator import SimulationJob, simulate_job


def build_experiment_jobs(
    config: ExperimentConfig,
    *,
    max_seeds: int | None = None,
    max_methods: int | None = None,
    max_scenarios: int | None = None,
    max_predefined_times: int | None = None,
    include_supplement: bool = False,
    uav_count: int | None = None,
    usv_count: int | None = None,
) -> list[SimulationJob]:
    seeds = _limit(config.seeds, max_seeds)
    methods = _limit(config.methods, max_methods)
    scenarios = _limit(config.scenarios, max_scenarios)
    predefined_times = list(config.predefined_times_s)
    if include_supplement:
        predefined_times += list(config.supplement_predefined_times_s)
    predefined_times = _limit(predefined_times, max_predefined_times)

    jobs: list[SimulationJob] = []
    for seed in seeds:
        for method in methods:
            for scenario in scenarios:
                for predefined_time_s in predefined_times:
                    jobs.append(
                        SimulationJob(
                            method=method,
                            scenario=scenario,
                            seed=int(seed),
                            predefined_time_s=float(predefined_time_s),
                            uav_count=int(uav_count if uav_count is not None else config.followers.uav),
                            usv_count=int(usv_count if usv_count is not None else config.followers.usv),
                        )
                    )
    return jobs


def run_experiment_jobs(
    jobs: list[SimulationJob],
    config: ExperimentConfig | None = None,
    progress: bool = True,
    *,
    workers: int = 1,
    chunksize: int = 1,
) -> pd.DataFrame:
    if config is None:
        config = load_config("simulation/configs/stage1_screening.json")
    workers = max(1, int(workers))
    chunksize = max(1, int(chunksize))
    if workers == 1:
        return apply_nominal_rdi(_run_experiment_jobs_serial(jobs, config, progress=progress))

    records: list[dict[str, float | int | str]] = []
    total = len(jobs)
    if progress:
        print(f"Running {total} jobs with {workers} worker processes.")
    payloads = [(config, job) for job in jobs]
    with ProcessPoolExecutor(max_workers=workers) as executor:
        iterator = executor.map(_simulate_job_record, payloads, chunksize=chunksize)
        for index, record in enumerate(iterator, start=1):
            if progress and (index == 1 or index == total or index % max(1, total // 20) == 0):
                print(f"[{index}/{total}] completed")
            records.append(record)
    return apply_nominal_rdi(pd.DataFrame.from_records(records))


def shard_jobs(jobs: list[SimulationJob], *, shard_index: int, shard_count: int) -> list[SimulationJob]:
    shard_count = int(shard_count)
    shard_index = int(shard_index)
    if shard_count < 1:
        raise ValueError("shard_count must be at least 1.")
    if shard_index < 0 or shard_index >= shard_count:
        raise ValueError("shard_index must be in [0, shard_count).")
    if shard_count == 1:
        return list(jobs)
    return [job for index, job in enumerate(jobs) if index % shard_count == shard_index]


def _run_experiment_jobs_serial(
    jobs: list[SimulationJob],
    config: ExperimentConfig,
    *,
    progress: bool,
) -> pd.DataFrame:
    records: list[dict[str, float | int | str]] = []
    total = len(jobs)
    for index, job in enumerate(jobs, start=1):
        if progress:
            print(f"[{index}/{total}] {job.method} | {job.scenario} | seed={job.seed} | Tp={job.predefined_time_s}")
        records.append(_simulate_job_record((config, job)))
    return pd.DataFrame.from_records(records)


def _simulate_job_record(payload: tuple[ExperimentConfig, SimulationJob]) -> dict[str, float | int | str]:
    config, job = payload
    output = simulate_job(config, job)
    return {
        **asdict(job),
        **output.metrics,
    }


def summarize_results(frame: pd.DataFrame) -> pd.DataFrame:
    metric_columns = [
        "integral_tracking_error",
        "itae_tracking_error",
        "appointed_time_violation",
        "settling_time",
        "formation_tracking_error",
        "prescribed_constraint_violation_rate",
        "control_energy",
        "control_energy_per_agent_time",
        "peak_control_input",
        "event_trigger_count",
        "minimum_inter_event_time",
        "resilience_degradation_index",
        "computation_time",
    ]
    present = [column for column in metric_columns if column in frame.columns]
    summary = (
        frame.groupby(["method", "scenario", "predefined_time_s"], dropna=False)[present]
        .agg(["mean", "std", "median"])
        .reset_index()
    )
    summary.columns = [
        "_".join(str(part) for part in column if str(part))
        if isinstance(column, tuple)
        else str(column)
        for column in summary.columns
    ]
    return summary


def apply_nominal_rdi(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty or "integral_tracking_error" not in frame.columns or "scenario" not in frame.columns:
        return frame
    result = frame.copy()
    result["rdi_baseline_source"] = "config_fallback"

    strict_columns = [
        "method",
        "seed",
        "predefined_time_s",
        "uav_count",
        "usv_count",
        "topology_name",
        "topology_feedback_gain",
        "topology_switch_period_s",
    ]
    relaxed_columns = ["method", "seed", "predefined_time_s", "uav_count", "usv_count"]
    for columns, source in ((strict_columns, "matched_nominal_pass"), (relaxed_columns, "matched_nominal_pass_relaxed")):
        available = [column for column in columns if column in result.columns]
        if not available:
            continue
        nominal = (
            result[result["scenario"].eq("nominal")][available + ["integral_tracking_error"]]
            .drop_duplicates(available)
            .rename(columns={"integral_tracking_error": "_matched_rdi_baseline"})
        )
        if nominal.empty:
            continue
        merged = result[available].merge(nominal, how="left", on=available)
        missing = result["rdi_baseline_source"].ne("config_fallback")
        usable = merged["_matched_rdi_baseline"].notna() & ~missing
        baseline = merged.loc[usable, "_matched_rdi_baseline"].to_numpy(dtype=float)
        integral = result.loc[usable, "integral_tracking_error"].to_numpy(dtype=float)
        result.loc[usable, "rdi_baseline_integral_error"] = baseline
        result.loc[usable, "resilience_degradation_index"] = np.maximum(0.0, (integral - np.maximum(baseline, 1e-9)) / np.maximum(baseline, 1e-9))
        result.loc[usable, "rdi_baseline_source"] = source
    return result


def write_results(frame: pd.DataFrame, output_dir: str | Path) -> tuple[Path, Path]:
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    raw_path = output_path / "runs.csv"
    summary_path = output_path / "summary.csv"
    frame.to_csv(raw_path, index=False, encoding="utf-8")
    summarize_results(frame).to_csv(summary_path, index=False, encoding="utf-8")
    return raw_path, summary_path


def _limit(values: list, limit: int | None) -> list:
    if limit is None:
        return list(values)
    return list(values)[: max(0, int(limit))]
