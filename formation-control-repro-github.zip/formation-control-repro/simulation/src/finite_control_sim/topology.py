from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Edge:
    source: int
    target: int
    weight: float = 1.0


@dataclass(frozen=True)
class Topology:
    leader_id: int
    agent_types: list[str]
    leader_edges: list[Edge]
    follower_edges: list[Edge]

    @property
    def agent_count(self) -> int:
        return len(self.agent_types)

    @property
    def follower_count(self) -> int:
        return self.agent_count - 1

    def adjacency_matrix(self) -> np.ndarray:
        matrix = np.zeros((self.agent_count, self.agent_count), dtype=float)
        for edge in self.leader_edges + self.follower_edges:
            matrix[edge.target, edge.source] = edge.weight
        return matrix


def build_leader_follower_topology(
    uav_count: int,
    usv_count: int,
    *,
    topology_name: str = "leader_ring",
    seed: int = 0,
) -> Topology:
    if uav_count < 0 or usv_count < 0:
        raise ValueError("Agent counts must be non-negative.")
    if uav_count + usv_count < 1:
        raise ValueError("At least one follower is required.")

    agent_types = ["LEADER"] + ["UAV"] * uav_count + ["USV"] * usv_count
    follower_ids = list(range(1, len(agent_types)))
    topology_name = str(topology_name)
    if topology_name in {"leader_ring", "baseline"}:
        leader_edges = [Edge(source=0, target=target, weight=1.0) for target in follower_ids]
        follower_edges = _ring_edges(follower_ids)
    elif topology_name == "ring":
        leader_edges = [Edge(source=0, target=follower_ids[0], weight=1.0)]
        if len(follower_ids) > 1:
            leader_edges.append(Edge(source=0, target=follower_ids[-1], weight=0.65))
        follower_edges = _ring_edges(follower_ids, neighbor_weight=0.55, closing_weight=0.55)
    elif topology_name in {"sparse", "sparse_random", "random"}:
        leader_edges, follower_edges = _sparse_random_edges(follower_ids, seed=seed)
    elif topology_name == "switching_sparse":
        leader_edges, follower_edges = _sparse_random_edges(follower_ids, seed=seed)
        follower_edges += _ring_edges(follower_ids, neighbor_weight=0.25, closing_weight=0.25)
    elif topology_name == "leader_dropout":
        leader_edges = [Edge(source=0, target=target, weight=1.0) for target in follower_ids]
        follower_edges = _ring_edges(follower_ids, neighbor_weight=0.55, closing_weight=0.55)
    else:
        known = "leader_ring, ring, sparse_random, random, sparse, switching_sparse, leader_dropout"
        raise ValueError(f"Unknown topology_name '{topology_name}'. Known topologies: {known}")

    return Topology(
        leader_id=0,
        agent_types=agent_types,
        leader_edges=leader_edges,
        follower_edges=follower_edges,
    )


def _ring_edges(
    follower_ids: list[int],
    *,
    neighbor_weight: float = 0.35,
    closing_weight: float = 0.2,
) -> list[Edge]:
    follower_edges: list[Edge] = []
    for left, right in zip(follower_ids, follower_ids[1:]):
        follower_edges.append(Edge(source=left, target=right, weight=float(neighbor_weight)))
        follower_edges.append(Edge(source=right, target=left, weight=float(neighbor_weight)))
    if len(follower_ids) > 2:
        follower_edges.append(Edge(source=follower_ids[-1], target=follower_ids[0], weight=float(closing_weight)))
        follower_edges.append(Edge(source=follower_ids[0], target=follower_ids[-1], weight=float(closing_weight)))
    return follower_edges


def _sparse_random_edges(follower_ids: list[int], *, seed: int) -> tuple[list[Edge], list[Edge]]:
    rng = np.random.default_rng(int(seed))
    follower_count = len(follower_ids)
    leader_edges = [
        Edge(source=0, target=follower, weight=1.0)
        for index, follower in enumerate(follower_ids)
        if index == 0 or index % 3 == 0
    ]
    follower_edges = _ring_edges(follower_ids, neighbor_weight=0.28, closing_weight=0.28)
    if follower_count >= 4:
        for source in follower_ids:
            for target in follower_ids:
                if source == target:
                    continue
                if rng.random() < 0.16:
                    follower_edges.append(Edge(source=source, target=target, weight=0.22))
    return leader_edges, _deduplicate_edges(follower_edges)


def _deduplicate_edges(edges: list[Edge]) -> list[Edge]:
    merged: dict[tuple[int, int], float] = {}
    for edge in edges:
        key = (edge.source, edge.target)
        merged[key] = max(merged.get(key, 0.0), float(edge.weight))
    return [Edge(source=source, target=target, weight=weight) for (source, target), weight in sorted(merged.items())]


def topology_weight_matrices(topology: Topology) -> tuple[np.ndarray, np.ndarray]:
    follower_count = topology.follower_count
    leader_weights = np.zeros(follower_count, dtype=float)
    follower_weights = np.zeros((follower_count, follower_count), dtype=float)
    for edge in topology.leader_edges:
        if edge.source != topology.leader_id:
            continue
        leader_weights[edge.target - 1] += float(edge.weight)
    for edge in topology.follower_edges:
        target = edge.target - 1
        source = edge.source - 1
        if 0 <= target < follower_count and 0 <= source < follower_count:
            follower_weights[target, source] += float(edge.weight)
    return leader_weights, follower_weights


def dynamic_topology_weight_matrices(
    topology: Topology,
    *,
    topology_name: str,
    time_s: float,
    switch_period_s: float,
) -> tuple[np.ndarray, np.ndarray]:
    leader_weights, follower_weights = topology_weight_matrices(topology)
    topology_name = str(topology_name)
    if topology_name == "switching_sparse":
        period = max(float(switch_period_s), 1e-9)
        phase = int(float(time_s) // period) % 2
        rows, cols = np.indices(follower_weights.shape)
        keep = ((rows + cols + phase) % 2) == 0
        follower_weights = np.where(keep, follower_weights, 0.0)
    elif topology_name == "leader_dropout":
        span_position = (float(time_s) % 5.0) / 5.0
        if 0.28 <= span_position <= 0.42 or 0.62 <= span_position <= 0.74:
            leader_weights = np.zeros_like(leader_weights)
    return leader_weights, follower_weights


def topology_consensus_error(
    position_error: np.ndarray,
    leader_weights: np.ndarray,
    follower_weights: np.ndarray,
) -> np.ndarray:
    error = np.asarray(position_error, dtype=float)
    leader_weights = np.asarray(leader_weights, dtype=float)
    follower_weights = np.asarray(follower_weights, dtype=float)
    if error.ndim != 2:
        raise ValueError("position_error must be a follower_count x dimensions matrix.")
    if leader_weights.shape != (error.shape[0],):
        raise ValueError("leader_weights length must match follower_count.")
    if follower_weights.shape != (error.shape[0], error.shape[0]):
        raise ValueError("follower_weights must be follower_count x follower_count.")
    follower_weight_sum = np.sum(follower_weights, axis=1)
    total_weight = leader_weights + follower_weight_sum
    weighted_error = (
        leader_weights[:, None] * error
        + follower_weight_sum[:, None] * error
        - follower_weights @ error
    )
    return np.divide(
        weighted_error,
        np.maximum(total_weight[:, None], 1e-9),
        out=error.copy(),
        where=total_weight[:, None] > 1e-9,
    )
