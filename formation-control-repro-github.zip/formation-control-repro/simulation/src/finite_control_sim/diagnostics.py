from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from .config import ExperimentConfig
from .simulator import SimulationJob, simulate_job


@dataclass(frozen=True)
class DiagnosticExport:
    npz_path: Path
    summary_path: Path


def export_diagnostic_run(
    config: ExperimentConfig,
    job: SimulationJob,
    output_dir: str | Path,
) -> DiagnosticExport:
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    output = simulate_job(config, job)
    stem = _diagnostic_stem(job)
    npz_path = output_path / f"{stem}_diagnostics.npz"
    summary_path = output_path / f"{stem}_diagnostic_summary.csv"

    np.savez_compressed(
        npz_path,
        times=output.times,
        tracking_errors=output.tracking_errors,
        controls=output.controls,
        trigger_events=output.trigger_events,
        constraint_violations=output.constraint_violations,
        transformed_errors=output.transformed_errors,
        normalized_errors=output.normalized_errors,
        performance_bounds=output.performance_bounds,
        approximations=output.approximations,
        observer_estimates=output.observer_estimates,
        trigger_metrics=output.trigger_metrics,
        trigger_thresholds=output.trigger_thresholds,
        physical_position_errors=output.physical_position_errors,
        network_position_errors=output.network_position_errors,
        controller_position_errors=output.controller_position_errors,
        held_position_errors=output.held_position_errors,
        sensor_biases=output.sensor_biases,
        bias_estimates=output.bias_estimates,
        actuator_efficiencies=output.actuator_efficiencies,
        actuator_efficiency_estimates=output.actuator_efficiency_estimates,
    )
    _diagnostic_summary_frame(output).to_csv(summary_path, index=False, encoding="utf-8")
    return DiagnosticExport(npz_path=npz_path, summary_path=summary_path)


def _diagnostic_summary_frame(output) -> pd.DataFrame:
    control_norm = np.linalg.norm(output.controls, axis=2)
    observer_norm = np.linalg.norm(output.observer_estimates, axis=2)
    transformed_norm = np.linalg.norm(output.transformed_errors, axis=2)
    network_norm = np.linalg.norm(output.network_position_errors, axis=2)
    hold_gap = np.linalg.norm(output.controller_position_errors - output.held_position_errors, axis=2)
    bias_error = np.linalg.norm(output.bias_estimates - output.sensor_biases, axis=2)
    efficiency_error = np.abs(output.actuator_efficiency_estimates - output.actuator_efficiencies)
    return pd.DataFrame(
        {
            "time_s": output.times,
            "max_tracking_error": np.max(output.tracking_errors, axis=1),
            "mean_tracking_error": np.mean(output.tracking_errors, axis=1),
            "performance_bound": output.performance_bounds,
            "max_transformed_error": np.max(transformed_norm, axis=1),
            "mean_control_norm": np.mean(control_norm, axis=1),
            "peak_control_norm": np.max(control_norm, axis=1),
            "event_count": np.sum(output.trigger_events, axis=1),
            "constraint_violation_count": np.sum(output.constraint_violations, axis=1),
            "mean_observer_norm": np.mean(observer_norm, axis=1),
            "mean_trigger_metric": np.mean(output.trigger_metrics, axis=1),
            "mean_trigger_threshold": np.mean(output.trigger_thresholds, axis=1),
            "mean_network_error": np.mean(network_norm, axis=1),
            "mean_hold_gap": np.mean(hold_gap, axis=1),
            "mean_sensor_bias_norm": np.mean(np.linalg.norm(output.sensor_biases, axis=2), axis=1),
            "mean_bias_estimate_norm": np.mean(np.linalg.norm(output.bias_estimates, axis=2), axis=1),
            "bias_estimator_rmse": np.sqrt(np.mean(bias_error**2, axis=1)),
            "efficiency_estimator_mae": np.mean(efficiency_error, axis=1),
        }
    )


def _diagnostic_stem(job: SimulationJob) -> str:
    predefined = str(job.predefined_time_s).replace(".", "p")
    return f"{job.method}_{job.scenario}_seed{job.seed}_Tp{predefined}"
