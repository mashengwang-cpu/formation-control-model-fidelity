from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class ScenarioProfile:
    name: str
    actuator_efficiency: np.ndarray
    sensor_bias: np.ndarray
    communication_available: np.ndarray


def build_scenario_profile(
    name: str,
    times: np.ndarray,
    follower_count: int,
    rng: np.random.Generator,
    *,
    actuator_loss_scale: float = 1.0,
    fdi_scale: float = 1.0,
    dos_duty_scale: float = 1.0,
    dos_model: str = "windows",
) -> ScenarioProfile:
    steps = len(times)
    actuator = np.ones((steps, follower_count), dtype=float)
    sensor_bias = np.zeros((steps, follower_count, 2), dtype=float)
    communication = np.ones((steps, follower_count), dtype=bool)

    if name == "nominal":
        return ScenarioProfile(name, actuator, sensor_bias, communication)
    if name in {"actuator_fault", "combined_attack_fault"}:
        _apply_actuator_fault(actuator, times, follower_count, loss_scale=actuator_loss_scale)
    if name in {"fdi_attack", "combined_attack_fault"}:
        _apply_fdi_attack(sensor_bias, times, follower_count, rng, fdi_scale=fdi_scale)
    if name in {"dos_attack", "combined_attack_fault"}:
        if str(dos_model) == "bernoulli":
            _apply_bernoulli_dos(communication, times, follower_count, rng, duty_scale=dos_duty_scale)
        else:
            _apply_dos_attack(communication, times, follower_count, duty_scale=dos_duty_scale)
    if name not in {"actuator_fault", "fdi_attack", "dos_attack", "combined_attack_fault"}:
        raise ValueError(f"Unknown scenario: {name}")
    return ScenarioProfile(name, actuator, sensor_bias, communication)


def _apply_actuator_fault(
    actuator: np.ndarray,
    times: np.ndarray,
    follower_count: int,
    *,
    loss_scale: float,
) -> None:
    start = times[0] + 0.42 * (times[-1] - times[0])
    affected = np.arange(follower_count) % 3 == 0
    nominal_fault_curve = 0.55 + 0.08 * np.sin(1.7 * times)
    fault_curve = 1.0 - float(loss_scale) * (1.0 - nominal_fault_curve)
    fault_curve = np.clip(fault_curve, 0.2, 1.0)
    actuator[:, affected] = np.where(times[:, None] >= start, fault_curve[:, None], 1.0)


def _apply_fdi_attack(
    sensor_bias: np.ndarray,
    times: np.ndarray,
    follower_count: int,
    rng: np.random.Generator,
    *,
    fdi_scale: float,
) -> None:
    start = times[0] + 0.35 * (times[-1] - times[0])
    affected = np.arange(follower_count) % 2 == 1
    phase = rng.uniform(0.0, 2.0 * np.pi, size=follower_count)
    for step, time_s in enumerate(times):
        if time_s < start:
            continue
        bias = np.column_stack(
            [
                0.16 * float(fdi_scale) * np.sin(0.9 * time_s + phase),
                0.13 * float(fdi_scale) * np.cos(0.7 * time_s + phase),
            ]
        )
        sensor_bias[step, affected, :] = bias[affected, :]


def _apply_dos_attack(
    communication: np.ndarray,
    times: np.ndarray,
    follower_count: int,
    *,
    duty_scale: float,
) -> None:
    affected = np.arange(follower_count) % 2 == 0
    windows = [(0.28, 0.35), (0.52, 0.59), (0.73, 0.8)]
    span = times[-1] - times[0]
    for left, right in windows:
        center = 0.5 * (left + right)
        half_width = 0.5 * (right - left) * float(duty_scale)
        scaled_left = max(0.0, center - half_width)
        scaled_right = min(1.0, center + half_width)
        mask = (times >= times[0] + scaled_left * span) & (times <= times[0] + scaled_right * span)
        communication[np.ix_(mask, affected)] = False


def _apply_bernoulli_dos(
    communication: np.ndarray,
    times: np.ndarray,
    follower_count: int,
    rng: np.random.Generator,
    *,
    duty_scale: float,
) -> None:
    drop_probability = float(np.clip(0.21 * float(duty_scale), 0.0, 0.95))
    drops = rng.random((len(times), follower_count)) < drop_probability
    communication[drops] = False
