"""Optional torch/torch-npu batched simulation backend."""

