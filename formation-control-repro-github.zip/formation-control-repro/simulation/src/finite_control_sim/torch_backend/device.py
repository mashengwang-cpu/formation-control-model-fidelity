from __future__ import annotations

import os


def import_torch():
    os.environ.setdefault("TORCH_DEVICE_BACKEND_AUTOLOAD", "0")
    try:
        import torch
    except Exception as exc:  # pragma: no cover - depends on optional dependency.
        raise RuntimeError(
            "PyTorch import failed. If this is an Ascend server, set "
            "TORCH_DEVICE_BACKEND_AUTOLOAD=0 before importing torch, source the CANN "
            "environment, and verify that PyTorch and torch-npu versions match."
        ) from exc
    return torch


def resolve_torch_device(device_spec: str):
    torch = import_torch()
    spec = str(device_spec)
    if spec == "auto":
        if _npu_available(torch):
            return torch.device("npu:0")
        if torch.cuda.is_available():
            return torch.device("cuda:0")
        return torch.device("cpu")
    if spec.startswith("npu"):
        try:
            import torch_npu  # noqa: F401
        except Exception as exc:  # pragma: no cover - depends on Ascend runtime.
            raise RuntimeError(
                "Requested an NPU torch device, but torch_npu import failed. "
                "This is an Ascend runtime/setup issue, not a simulation-code issue. "
                "Run: export TORCH_DEVICE_BACKEND_AUTOLOAD=0; source the CANN set_env.sh; "
                "then verify `import torch; import torch_npu; torch.npu.is_available()`."
            ) from exc
        if hasattr(torch, "npu") and not torch.npu.is_available():  # pragma: no cover - NPU only.
            raise RuntimeError("torch_npu imported, but torch.npu.is_available() is false.")
        return torch.device(spec)
    return torch.device(spec)


def _npu_available(torch) -> bool:
    try:
        import torch_npu  # noqa: F401
    except Exception:
        return False
    return bool(hasattr(torch, "npu") and torch.npu.is_available())
