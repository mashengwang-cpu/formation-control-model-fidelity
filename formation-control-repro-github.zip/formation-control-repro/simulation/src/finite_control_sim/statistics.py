from __future__ import annotations

import math

import numpy as np
import pandas as pd
from scipy import stats


def bootstrap_mean_ci(
    values: np.ndarray,
    *,
    samples: int = 20000,
    confidence: float = 0.95,
    seed: int = 1234,
    method: str = "bca",
) -> tuple[float, float, float]:
    array = np.asarray(values, dtype=float)
    array = array[np.isfinite(array)]
    if array.size == 0:
        return float("nan"), float("nan"), float("nan")
    if str(method) == "percentile":
        rng = np.random.default_rng(seed)
        draws = rng.choice(array, size=(int(samples), array.size), replace=True)
        means = np.mean(draws, axis=1)
        alpha = 1.0 - confidence
        return (
            float(np.mean(array)),
            float(np.quantile(means, alpha / 2.0)),
            float(np.quantile(means, 1.0 - alpha / 2.0)),
        )
    if str(method) != "bca":
        raise ValueError("bootstrap method must be 'bca' or 'percentile'.")
    return bca_mean_ci(array, samples=samples, confidence=confidence, seed=seed)


def bca_mean_ci(
    values: np.ndarray,
    *,
    samples: int = 20000,
    confidence: float = 0.95,
    seed: int = 1234,
) -> tuple[float, float, float]:
    """Efron bias-corrected and accelerated interval for the mean."""

    array = np.asarray(values, dtype=float)
    array = array[np.isfinite(array)]
    n = int(array.size)
    if n == 0:
        return float("nan"), float("nan"), float("nan")
    theta = float(np.mean(array))
    if n == 1:
        return theta, theta, theta
    rng = np.random.default_rng(seed)
    boots = np.mean(rng.choice(array, size=(int(samples), n), replace=True), axis=1)
    jack = (np.sum(array) - array) / (n - 1)
    jack_mean = float(np.mean(jack))
    d = jack_mean - jack
    den = np.sum(d**2)
    acc = float(np.sum(d**3) / (6.0 * den**1.5)) if den > 0.0 else 0.0
    prop = float(np.mean(boots < theta))
    prop = min(max(prop, 1.0 / (int(samples) + 1.0)), 1.0 - 1.0 / (int(samples) + 1.0))
    z0 = float(stats.norm.ppf(prop))
    alpha = 1.0 - float(confidence)
    z_lo = float(stats.norm.ppf(alpha / 2.0))
    z_hi = float(stats.norm.ppf(1.0 - alpha / 2.0))

    def _endpoint(z_alpha: float) -> float:
        denom = 1.0 - acc * (z0 + z_alpha)
        if abs(denom) < 1e-12:
            return float(np.quantile(boots, 0.5))
        adjusted = stats.norm.cdf(z0 + (z0 + z_alpha) / denom)
        adjusted = min(max(float(adjusted), 0.0), 1.0)
        return float(np.quantile(boots, adjusted))

    return theta, _endpoint(z_lo), _endpoint(z_hi)


def wilcoxon_r_from_z(differences: np.ndarray) -> float:
    """Signed r = z/sqrt(n), with average ranks and tie-corrected variance.

    This is not the paired rank-biserial effect size. No continuity
    correction is used; exact zero differences are excluded.
    """

    values = np.asarray(differences, dtype=float)
    values = values[np.isfinite(values) & (values != 0.0)]
    n = int(values.size)
    if n <= 0:
        return float("nan")
    ranks = stats.rankdata(np.abs(values), method="average")
    t_plus = float(np.sum(ranks[values > 0.0]))
    expected = n * (n + 1) / 4.0
    _, tie_counts = np.unique(np.abs(values), return_counts=True)
    variance = (n * (n + 1) * (2 * n + 1)
                - 0.5 * np.sum(tie_counts**3 - tie_counts)) / 24.0
    if variance <= 0.0:
        return float("nan")
    z_value = (t_plus - expected) / math.sqrt(variance)
    return float(z_value / math.sqrt(n))


def paired_hodges_lehmann(differences: np.ndarray) -> float:
    """Paired Hodges-Lehmann estimator: median of all Walsh averages.

    Includes diagonal pairs (d_i+d_i)/2 and exact zero differences.
    """
    values = np.asarray(differences, dtype=float)
    values = values[np.isfinite(values)]
    if not values.size:
        return math.nan
    i, j = np.triu_indices(values.size)
    return float(np.median((values[i] + values[j]) / 2.0))


def bca_paired_ratio_ci(
    numerator_arm: np.ndarray,
    denominator_arm: np.ndarray,
    *,
    samples: int = 20000,
    confidence: float = 0.95,
    seed: int = 1234,
) -> tuple[float, float, float]:
    """BCa CI for (mean(x)-mean(y))/mean(y), resampling paired units.

    Both means are recomputed in each bootstrap and leave-one-pair-out
    jackknife draw. Missing/unpaired observations are errors, not exclusions.
    The denominator must be strictly positive in every observation, which
    guarantees a defined positive denominator in every resample.
    """
    x = np.asarray(numerator_arm, dtype=float)
    y = np.asarray(denominator_arm, dtype=float)
    if x.ndim != 1 or y.shape != x.shape or x.size < 2:
        raise ValueError("Ratio CI requires at least two paired one-dimensional observations.")
    if not (np.isfinite(x).all() and np.isfinite(y).all()) or np.any(y <= 0):
        raise ValueError("Ratio CI requires finite paired observations and positive denominators.")
    theta = float((np.mean(x) - np.mean(y)) / np.mean(y))
    if np.all(x == x[0]) and np.all(y == y[0]):
        return theta, theta, theta
    result = stats.bootstrap(
        (x, y),
        lambda a, b, axis: (np.mean(a, axis=axis) - np.mean(b, axis=axis))
        / np.mean(b, axis=axis),
        paired=True,
        method="BCa",
        n_resamples=int(samples),
        confidence_level=float(confidence),
        random_state=seed,
    )
    return theta, float(result.confidence_interval.low), float(result.confidence_interval.high)


def add_bootstrap_ci(
    frame: pd.DataFrame,
    metric: str | None = None,
    *,
    group_columns: list[str] | None = None,
    samples: int | None = None,
    group_cols: list[str] | None = None,
    metric_cols: list[str] | str | None = None,
    bootstrap_samples: int | None = None,
    confidence: float = 0.95,
) -> pd.DataFrame:
    groups = group_columns or group_cols or ["method", "scenario", "predefined_time_s"]
    n_samples = int(samples if samples is not None else (bootstrap_samples if bootstrap_samples is not None else 20000))
    if metric is not None:
        metrics = [metric]
    elif isinstance(metric_cols, str):
        metrics = [metric_cols]
    elif metric_cols is not None:
        metrics = list(metric_cols)
    else:
        raise TypeError("add_bootstrap_ci requires metric=... or metric_cols=...")
    records = []
    for metric_name in metrics:
        for group_key, group in frame.groupby(groups, dropna=False):
            mean, low, high = bootstrap_mean_ci(
                group[metric_name].to_numpy(),
                samples=n_samples,
                confidence=confidence,
            )
            if not isinstance(group_key, tuple):
                group_key = (group_key,)
            records.append(
                {
                    **dict(zip(groups, group_key)),
                    "metric": metric_name,
                    "mean": mean,
                    "ci_low": low,
                    "ci_high": high,
                    "n": int(len(group)),
                }
            )
    return pd.DataFrame.from_records(records)


def cliffs_delta(x: np.ndarray, y: np.ndarray) -> float:
    left = np.asarray(x, dtype=float)
    right = np.asarray(y, dtype=float)
    left = left[np.isfinite(left)]
    right = right[np.isfinite(right)]
    if left.size == 0 or right.size == 0:
        return math.nan
    comparisons = np.sign(left[:, None] - right[None, :])
    return float(np.sum(comparisons) / comparisons.size)


def matched_pairs_rank_biserial(differences: np.ndarray) -> float:
    """Rank-biserial correlation for paired differences.

    Positive values mean ``reference - comparator`` tends to be positive;
    negative values mean it tends to be negative. Exact zero differences are
    excluded consistently with Wilcoxon's ``zero_method='wilcox'``.
    """

    values = np.asarray(differences, dtype=float)
    values = values[np.isfinite(values) & (values != 0.0)]
    if values.size == 0:
        return math.nan
    ranks = stats.rankdata(np.abs(values), method="average")
    positive = float(np.sum(ranks[values > 0.0]))
    negative = float(np.sum(ranks[values < 0.0]))
    denominator = positive + negative
    return (positive - negative) / denominator if denominator > 0.0 else math.nan


def holm_adjust(p_values: np.ndarray) -> np.ndarray:
    array = np.asarray(p_values, dtype=float)
    adjusted = np.full(array.shape, np.nan, dtype=float)
    valid = np.where(np.isfinite(array))[0]
    order = valid[np.argsort(array[valid])]
    running = 0.0
    m = len(order)
    for rank, index in enumerate(order):
        value = min((m - rank) * array[index], 1.0)
        running = max(running, value)
        adjusted[index] = running
    return adjusted


def paired_wilcoxon_holm(
    frame: pd.DataFrame,
    *,
    reference_method: str,
    comparator_methods: list[str],
    metrics: list[str],
    pair_columns: list[str],
    lower_is_better: set[str] | None = None,
) -> pd.DataFrame:
    lower = lower_is_better or set()
    records: list[dict[str, object]] = []
    required = set(pair_columns + ["method"])
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Missing paired-test columns: {missing}")

    for comparator in comparator_methods:
        subset = frame[frame["method"].isin([reference_method, comparator])].copy()
        for metric in metrics:
            pivot = subset.pivot_table(index=pair_columns, columns="method", values=metric, aggfunc="mean")
            if reference_method not in pivot or comparator not in pivot:
                paired = pd.DataFrame()
            else:
                paired = pivot[[reference_method, comparator]].dropna()
            wilcoxon_r = math.nan
            ci_low = math.nan
            ci_high = math.nan
            rank_biserial = math.nan
            if len(paired) == 0:
                statistic = math.nan
                p_value = math.nan
                median_delta = math.nan
                delta = math.nan
            else:
                reference_values = paired[reference_method].to_numpy(dtype=float)
                comparator_values = paired[comparator].to_numpy(dtype=float)
                difference = reference_values - comparator_values
                try:
                    result = stats.wilcoxon(reference_values, comparator_values, zero_method="wilcox", alternative="two-sided")
                    statistic = float(result.statistic)
                    p_value = float(result.pvalue)
                except Exception:
                    statistic = math.nan
                    p_value = math.nan
                median_delta = float(np.median(difference))
                delta = cliffs_delta(reference_values, comparator_values)
                rank_biserial = matched_pairs_rank_biserial(difference)
                wilcoxon_r = wilcoxon_r_from_z(difference)
                mean, ci_low, ci_high = bca_mean_ci(difference)
                if metric in lower:
                    reference_win_rate = float(np.mean(difference < 0.0))
                else:
                    reference_win_rate = float(np.mean(difference > 0.0))
            records.append(
                {
                    "comparison": f"{reference_method}_vs_{comparator}",
                    "reference_method": reference_method,
                    "comparator_method": comparator,
                    "metric": metric,
                    "paired_blocks": int(len(paired)),
                    "wilcoxon_statistic": statistic,
                    "p_value": p_value,
                    "holm_adjusted_p": math.nan,
                    "median_reference_minus_comparator": median_delta,
                    "hodges_lehmann": paired_hodges_lehmann(difference) if len(paired) else math.nan,
                    "matched_pairs_rank_biserial": rank_biserial if len(paired) else math.nan,
                    "wilcoxon_r_z": wilcoxon_r if len(paired) else math.nan,
                    "bca95_ci_low": ci_low if len(paired) else math.nan,
                    "bca95_ci_high": ci_high if len(paired) else math.nan,
                    "cliffs_delta": delta,
                    "reference_win_rate": reference_win_rate if len(paired) else math.nan,
                    "preferred_direction": "lower" if metric in lower else "higher",
                    "holm_family": "all_requested_comparator_metric_hypotheses",
                }
            )
    result = pd.DataFrame.from_records(records)
    if not result.empty:
        result["holm_adjusted_p"] = holm_adjust(result["p_value"].to_numpy(dtype=float))
    return result
