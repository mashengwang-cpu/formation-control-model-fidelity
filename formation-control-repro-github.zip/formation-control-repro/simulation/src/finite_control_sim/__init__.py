"""Simulation scaffold for heterogeneous UAV/USV predefined-time MAS studies."""

__all__ = [
    "config",
    "controllers",
    "experiments",
    "metrics",
    "models",
    "quadrotor_6dof",
    "scenarios",
    "simulator",
    "topology",
]

__version__ = "0.1.0"
