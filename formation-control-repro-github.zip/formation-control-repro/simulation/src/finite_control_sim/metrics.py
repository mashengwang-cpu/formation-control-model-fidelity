from __future__ import annotations

import math

import numpy as np


def compute_run_metrics(
    *,
    times: np.ndarray,
    tracking_errors: np.ndarray,
    controls: np.ndarray,
    trigger_events: np.ndarray,
    constraint_violations: np.ndarray,
    predefined_time_s: float,
    error_tolerance: float,
    nominal_integral_error: float,
    computation_time_s: float,
    rdi_baseline_integral_error: float | None = None,
    actual_controls: np.ndarray | None = None,
    sensor_biases: np.ndarray | None = None,
    bias_estimates: np.ndarray | None = None,
    actuator_efficiencies: np.ndarray | None = None,
    actuator_efficiency_estimates: np.ndarray | None = None,
) -> dict[str, float]:
    times = np.asarray(times, dtype=float)
    errors = np.asarray(tracking_errors, dtype=float)
    controls = np.asarray(controls, dtype=float)
    trigger_events = np.asarray(trigger_events, dtype=bool)
    constraint_violations = np.asarray(constraint_violations, dtype=bool)

    if times.ndim != 1:
        raise ValueError("times must be one-dimensional.")
    if errors.shape[0] != times.shape[0]:
        raise ValueError("tracking_errors first dimension must match times.")
    if controls.shape[0] != times.shape[0]:
        raise ValueError("controls first dimension must match times.")

    max_error = np.max(errors, axis=1)
    settling_time = _settling_time(times, max_error, error_tolerance)
    appointed_time_violation = max(0.0, settling_time - predefined_time_s)
    integral_error = _trapz(np.mean(errors, axis=1), times)
    control_power = np.sum(controls**2, axis=(1, 2))
    control_energy = _trapz(control_power, times)
    duration = max(float(times[-1] - times[0]), 1e-9)
    follower_count = max(int(errors.shape[1]), 1)
    control_energy_per_agent_time = control_energy / (duration * follower_count)
    itae = _trapz(times * np.mean(errors, axis=1), times)
    control_norms = np.linalg.norm(controls, axis=2)
    peak_control_input = float(np.max(control_norms)) if control_norms.size else 0.0
    event_count = int(np.sum(trigger_events))
    minimum_inter_event_time = _minimum_inter_event_time(times, trigger_events)
    baseline_source = nominal_integral_error if rdi_baseline_integral_error is None else rdi_baseline_integral_error
    baseline = max(float(baseline_source), 1e-9)
    resilience_degradation = max(0.0, (integral_error - baseline) / baseline)
    if actual_controls is None:
        actual_energy = float("nan")
    else:
        actual_power = np.sum(np.asarray(actual_controls, dtype=float) ** 2, axis=(1, 2))
        actual_energy = float(_trapz(actual_power, times))
    bias_rmse = float("nan")
    if sensor_biases is not None and bias_estimates is not None:
        bias_rmse = float(np.sqrt(np.mean((np.asarray(sensor_biases) - np.asarray(bias_estimates)) ** 2)))
    efficiency_rmse = float("nan")
    if actuator_efficiencies is not None and actuator_efficiency_estimates is not None:
        efficiency_rmse = float(
            np.sqrt(np.mean((np.asarray(actuator_efficiencies) - np.asarray(actuator_efficiency_estimates)) ** 2))
        )

    return {
        "integral_tracking_error": float(integral_error),
        "itae_tracking_error": float(itae),
        "rdi_baseline_integral_error": float(baseline),
        "appointed_time_violation": float(appointed_time_violation),
        "settling_time": float(settling_time),
        "formation_tracking_error": float(np.mean(errors)),
        "prescribed_constraint_violation_rate": float(np.mean(constraint_violations)),
        "constraint_violation_rate": float(np.mean(constraint_violations)),
        "control_energy": float(control_energy),
        "control_energy_per_agent_time": float(control_energy_per_agent_time),
        "peak_control_input": peak_control_input,
        "event_trigger_count": float(event_count),
        "minimum_inter_event_time": float(minimum_inter_event_time),
        "resilience_degradation_index": float(resilience_degradation),
        "computation_time": float(computation_time_s),
        "actual_control_energy": actual_energy,
        "bias_estimate_rmse": bias_rmse,
        "efficiency_estimate_rmse": efficiency_rmse,
    }


def _settling_time(times: np.ndarray, max_error: np.ndarray, tolerance: float) -> float:
    settled = max_error <= tolerance
    if not np.any(settled):
        return float(times[-1])
    for idx in range(len(times)):
        if np.all(settled[idx:]):
            return float(times[idx])
    return float(times[-1])


def _minimum_inter_event_time(times: np.ndarray, trigger_events: np.ndarray) -> float:
    intervals: list[float] = []
    for agent_idx in range(trigger_events.shape[1]):
        event_times = times[trigger_events[:, agent_idx]]
        if len(event_times) >= 2:
            intervals.extend(np.diff(event_times).tolist())
    if not intervals:
        return float(times[-1] - times[0])
    finite = [value for value in intervals if math.isfinite(value) and value > 0.0]
    return float(min(finite)) if finite else float(times[-1] - times[0])


def _trapz(values: np.ndarray, times: np.ndarray) -> float:
    if len(times) < 2:
        return 0.0
    values = np.asarray(values, dtype=float)
    times = np.asarray(times, dtype=float)
    return float(np.sum(0.5 * (values[1:] + values[:-1]) * np.diff(times)))
