"""True-baseline controllers reproduced from published source papers.

This module replaces the self-made ``recent_2025_resilient_fixed_time`` family
baseline with reproductions of the actual comparison papers.  Full provenance
and fidelity grading live in ``Reproduction/true_baseline_requirements.md``.

Methods
-------
``ref36_reproduction`` (fidelity: mixed)
    Niu et al., "Adaptive Fuzzy Resilient Fixed-Time Bipartite Consensus
    Tracking Control for Nonlinear MASs Under Sensor Deception Attacks",
    IEEE Trans. Autom. Sci. Eng. 22:2542-2551, 2025,
    doi:10.1109/TASE.2024.3381568 (closed access; no legal full text found).
    Component-level equation fidelity via the same group's sibling paper
    Xu, Wang, Niu, Li, Liu, Int. J. Adapt. Control Signal Process. 39(6):
    1208-1220, 2025, doi:10.1002/acs.4002 (equation numbers below follow
    that paper's numbering):
    - sensor-attack modeling / compromised-state coordinate design
      (acs.4002 eq. (1)(7)(8), Assumption 2): design in the measured
      (attacked, causally/oracle compensated) coordinates with the
      multiplicative attack gain absorbed into merged unknown constants
      estimated by the two adaptive families below;
    - tuning-function adaptation (acs.4002 eq. (16)-(18)(30)(31)(39)):
      per-step estimates gamma_hat (own channel) and lambda_hat (neighbour
      channel) driven by tuning-function recursions, updated only at the
      final step (delayed update) with the k0 sigma-modification leakage;
    - Nussbaum final-step mechanism (acs.4002 Remark 2 / Step n):
      u = N(theta) * Psi with N(theta) = exp(theta^2) sin(pi theta);
      implemented but disabled by default (pathological on this
      known-direction saturated channel; see the class docstring and the
      ablation record in true_baseline_requirements.md).
    The fixed-time switched fractional-power shell remains a *structural*
    reproduction from the TASE abstract (the exact switching function and all
    numeric parameters are paywalled), so the overall grade is mixed.  The
    paper's partition algorithm for structurally unbalanced signed digraphs
    degenerates to the identity partition on this package's cooperative
    leader-follower topology.

``ref72_reproduction`` (fidelity: structural)
    Niu et al., "Adaptive Fixed-Time Event-Triggered Consensus Tracking
    Control for Robotic Multiagent Systems", IEEE Trans. Syst. Man Cybern.
    Syst. 55(10):7238-7246, 2025, doi:10.1109/TSMC.2025.3582649 (closed
    access; no legal full text found).  Reproduced from the abstract's
    component list: fixed-time backstepping plus the relative-threshold
    event-triggered control (RTETC) mechanism.  The RTETC equations are taken
    from the same group's CC-BY preprint (Cheng, Niu et al., Research Square
    rs-324479, doi:10.21203/rs.3.rs-324479/v1): trigger when
    |p(t) - u(t)| >= delta*|u(t)| + m1, applied control
    p = -(1+delta)*(Delta*tanh(z*Delta/eps) + m1*tanh(z*m1/eps)).

``oa_alternative_baseline`` (fidelity: equation-level, order-reduced)
    Cheng, Niu, Zhang, Wang, Duan, "Event-Triggered Adaptive Asymptotic
    Tracking Control of Flexible Robotic Manipulators: A Command Filtered
    Backstepping Method", Research Square preprint rs-324479 (CC-BY 4.0),
    doi:10.21203/rs.3.rs-324479/v1.  The published control law (command
    filter, compensating signals, norm-form neural adaptive laws, RTETC) is
    ported equation by equation, with the five-step strict-feedback recursion
    reduced to the two integration steps of this package's planar formation
    error channel and gains recalibrated for the formation plant.

All three controllers implement the ``ModularController.step`` contract
(``ControllerState`` in, ``ControllerOutput`` out).  Method-specific memory
(held control, command-filter and compensating states, adaptive scalars) is
kept inside the controller instance because the frozen ``ControllerState``
slots are owned by the simulation loops; each ``simulate_job`` call builds a
fresh controller, so runs stay independent.
"""

from __future__ import annotations

import numpy as np

from .controllers import (
    ControllerInput,
    ControllerOutput,
    ControllerState,
    MethodSpec,
    PrescribedPerformance,
    apply_fault_tolerance,
)

TRUE_BASELINE_METHODS = frozenset(
    {"ref36_reproduction", "ref72_reproduction", "oa_alternative_baseline"}
)


def _switched_power(values: np.ndarray, power: float, epsilon: float) -> np.ndarray:
    """sig^power(x) with a linear continuation inside |x| < epsilon.

    This is the "switching function" device the fixed-time literature uses to
    avoid the singularity of fractional powers (and of their derivatives) at
    the origin.
    """
    magnitude = np.abs(values)
    fractional = np.sign(values) * np.power(np.maximum(magnitude, epsilon), power)
    linear = values * epsilon ** (power - 1.0)
    return np.where(magnitude >= epsilon, fractional, linear)


def _switched_power_slope(values: np.ndarray, power: float, epsilon: float) -> np.ndarray:
    """d/dx of ``_switched_power``; bounded at the origin by construction."""
    magnitude = np.abs(values)
    fractional = power * np.power(np.maximum(magnitude, epsilon), power - 1.0)
    linear = np.full_like(values, epsilon ** (power - 1.0))
    return np.where(magnitude >= epsilon, fractional, linear)


def _gaussian_basis_norm(z1: np.ndarray, z2: np.ndarray) -> np.ndarray:
    """phi(Z)^T phi(Z) per follower for norm-form adaptive laws.

    Gaussian receptive fields over (|z1|, |z2|), the standard fuzzy/RBF basis
    of this method family; only the scalar phi^T phi enters the control and
    adaptive laws in norm form.
    """
    z1_norm = np.linalg.norm(z1, axis=1)
    z2_norm = np.linalg.norm(z2, axis=1)
    centers = np.array([0.0, 0.5, 1.0, 1.5, 2.0])
    width_sq = 1.0
    features = np.stack([z1_norm, z2_norm], axis=1)
    total = np.zeros(z1.shape[0], dtype=float)
    for center in centers:
        distance_sq = np.sum((features - center) ** 2, axis=1)
        total += np.exp(-distance_sq / width_sq) ** 2
    return total


def _held_errors(
    state: ControllerState,
    inputs: ControllerInput,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Latest communicated position/velocity errors (held under DoS)."""
    comm = inputs.communication_available.astype(bool)
    held_position = np.asarray(state.sampled_error, dtype=float).copy()
    if state.sampled_velocity_error is None:
        held_velocity = np.asarray(inputs.velocity_error, dtype=float).copy()
    else:
        held_velocity = np.asarray(state.sampled_velocity_error, dtype=float).copy()
    held_position[comm] = np.asarray(inputs.position_error, dtype=float)[comm]
    held_velocity[comm] = np.asarray(inputs.velocity_error, dtype=float)[comm]
    return held_position, held_velocity, comm


class _TrueBaselineBase:
    """Shared plumbing for the reproduced baselines."""

    basis_size = 7  # keeps ControllerState.zeros shape-compatible

    def __init__(self, spec: MethodSpec, follower_count: int, max_control: float) -> None:
        self.spec = spec
        self.follower_count = int(follower_count)
        self.max_control = float(max_control)
        self.performance = PrescribedPerformance()

    def _output(
        self,
        *,
        inputs: ControllerInput,
        state: ControllerState,
        raw_control: np.ndarray,
        commanded: np.ndarray,
        z1: np.ndarray,
        z2: np.ndarray,
        approximation: np.ndarray,
        triggered: np.ndarray,
        trigger_metric: np.ndarray,
        trigger_threshold: np.ndarray,
        next_sampled_error: np.ndarray,
        next_sampled_velocity: np.ndarray,
    ) -> ControllerOutput:
        bound = self.performance.bounds(
            time_s=inputs.time_s, predefined_time_s=inputs.predefined_time_s
        )
        return ControllerOutput(
            commanded_control=commanded,
            raw_control=raw_control,
            transformed_error=z1,
            control_transformed_error=z1,
            control_position_error=z1,
            control_velocity_error=z2,
            normalized_error=z1 / max(bound, 1e-9),
            performance_bound=bound,
            approximation=approximation,
            observer_estimate=np.zeros_like(z1),
            trigger_metric=trigger_metric,
            trigger_threshold=trigger_threshold,
            triggered=triggered,
            next_state=ControllerState(
                adaptive_weights=state.adaptive_weights,
                observer_state=state.observer_state,
                trigger_filter=state.trigger_filter,
                sampled_error=next_sampled_error,
                sampled_velocity_error=next_sampled_velocity,
            ),
        )


class Ref36FixedTimeResilientController(_TrueBaselineBase):
    """Mixed-fidelity reproduction of ref36 (TASE 2025, sensor deception attacks).

    Equation-level components (per the sibling paper acs.4002,
    doi:10.1002/acs.4002; equation numbers below refer to that paper):

    - compromised-state coordinate design (eq. (7), Assumption 2): the design
      variables ``z1``/``z2`` are built directly from the measured (attacked,
      then causally/oracle compensated) errors supplied by the simulation
      resilience layer; the unknown multiplicative attack gain lambda(t) and
      its bounds are absorbed into the merged unknown constants that the
      adaptive families estimate (the 1/(2*lambda_m^2)-weighted Lyapunov
      bookkeeping of eq. (8)).
    - virtual law (eq. (16)): alpha1 = -k1*z1 - eps1*z1*gamma1_hat*phi1^2
      - eps1*z1*lambda1_hat*phin^2, augmented by the structural fixed-time
      shell (below).  On the identity-partition leader-follower graph the
      own-channel and neighbour-channel envelopes coincide (both are the
      communicated formation-error channel), so phi1 = phin; both adaptive
      families are retained as in the source equations.
    - tuning functions with delayed update (eq. (17)(18)(31)(39)): step-1
      quantities sigma11/pi11 and omega11/tau11 are accumulated only; the
      adaptive laws fire once at the final step, gamma1_hat_dot = pi12,
      lambda1_hat_dot = tau12, gamma2_hat_dot = pi21, lambda2_hat_dot = tau21,
      gamma0_hat_dot = pi01 (gamma0 handles the lambda_dot-related terms of
      eq. (21)(28)), each with the -k0*(.) sigma-modification leakage whose
      provenance is eq. (17).
    - final-step Nussbaum mechanism (Remark 2 / Step n): u = N(theta)*Psi
      with N(theta) = exp(theta^2)*sin(pi*theta) and theta_dot proportional
      to <z2, Psi>.  IMPLEMENTED BUT DISABLED BY DEFAULT
      (``nussbaum_enabled=False``): on this package's known-control-direction,
      saturation-limited channel the sweep of N(theta) is pathological -- it
      either traverses weak/wrong-direction pockets of sin(pi*theta)
      (tracking error degrades ~8x) or walks exp(theta^2) into permanent
      actuator saturation (~13x control energy).  The Nussbaum device exists
      to handle *unknown* control directions, which this plant does not have,
      so N degenerates to a constant; the fallback applies the aggregated
      final-step feedback directly.  Full measurements are recorded in
      ``Reproduction/true_baseline_requirements.md``.  When enabled, theta(0)
      sits inside a stabilizing pocket of N and theta is clipped to +-4.0 as
      a numerical overflow guard only.

    Structural components (TASE 2025 abstract only; exact forms paywalled):

    - fixed-time switched fractional-power shell ``_switched_power`` with
      exponents a1 < 1 < a2 (the paper's "novel switching function" against
      the fractional-power singularity);
    - the theta_{i,n} = 1/lambda^2 estimate of eq. (42) is omitted because
      its exact placement in the control law is not stated in the openly
      available sources; its role (attack-gain magnitude) is covered by the
      merged constants of the gamma/lambda families.
    - partition algorithm: identity on the cooperative leader-follower graph.

    Gains, eps1, k0, initializations and clip ranges are package-calibrated
    (the source papers' numeric parameters are not openly available).
    """

    def __init__(
        self,
        spec: MethodSpec,
        follower_count: int,
        max_control: float,
        *,
        switch_epsilon: float = 0.08,
        epsilon1: float = 0.05,
        leakage_k0: float = 0.15,
        adaptive_initial: float = 0.1,
        adaptive_clip: float = 12.0,
        nussbaum_enabled: bool = False,
        nussbaum_initial: float = 1.1,
        nussbaum_rate: float = 0.05,
        nussbaum_clip: float = 4.0,
    ) -> None:
        super().__init__(spec, follower_count, max_control)
        self.a1 = float(spec.finite_power if spec.finite_power is not None else 0.714)
        self.a2 = float(spec.fixed_power if spec.fixed_power is not None else 1.286)
        self.k1 = float(spec.position_gain)
        self.k2 = 0.45 * float(spec.position_gain)
        self.k3 = float(spec.velocity_gain)
        self.k4 = 0.45 * float(spec.velocity_gain)
        self.switch_epsilon = float(switch_epsilon)
        self.epsilon1 = float(epsilon1)
        self.leakage_k0 = float(leakage_k0)
        self.adaptive_clip = float(adaptive_clip)
        self.nussbaum_enabled = bool(nussbaum_enabled)
        self.nussbaum_rate = float(nussbaum_rate)
        self.nussbaum_clip = float(nussbaum_clip)
        init = float(adaptive_initial)  # paper requires positive initial values
        self.gamma1_hat = np.full(self.follower_count, init, dtype=float)
        self.lambda1_hat = np.full(self.follower_count, init, dtype=float)
        self.gamma2_hat = np.full(self.follower_count, init, dtype=float)
        self.lambda2_hat = np.full(self.follower_count, init, dtype=float)
        self.gamma0_hat = np.full(self.follower_count, init, dtype=float)
        self.nussbaum_theta = np.full(
            self.follower_count, float(nussbaum_initial), dtype=float
        )

    def step(self, state: ControllerState, inputs: ControllerInput) -> ControllerOutput:
        z1, velocity_error, comm = _held_errors(state, inputs)
        eps = self.switch_epsilon
        eps1 = self.epsilon1
        k0 = self.leakage_k0

        # Lemma-1 envelopes (known smooth phi >= 1); neighbour channel
        # coincides with the own channel on the identity-partition graph.
        z1_sq = np.sum(z1**2, axis=1)
        phi1 = 1.0 + z1_sq
        phi1_sq = phi1**2
        phin_sq = phi1_sq

        # Virtual law (16) + structural fixed-time shell.
        envelope_gain = eps1 * (self.gamma1_hat * phi1_sq + self.lambda1_hat * phin_sq)
        alpha1 = (
            -self.k1 * _switched_power(z1, self.a1, eps)
            - self.k2 * _switched_power(z1, self.a2, eps)
            - envelope_gain[:, None] * z1
        )
        z2 = velocity_error - alpha1
        z2_sq = np.sum(z2**2, axis=1)
        phi2 = 1.0 + z1_sq + z2_sq
        phi2_sq = phi2**2

        # Step-1 tuning functions (17)(18): accumulate only, no update yet.
        sigma11 = eps1 * z1_sq * phi1_sq
        pi11 = sigma11 - k0 * self.gamma1_hat
        omega11 = eps1 * z1_sq * phin_sq
        tau11 = omega11 - k0 * self.lambda1_hat

        # d(alpha1)/d(z1) per axis (fixed-time shell + envelope derivative).
        shell_slope = -self.k1 * _switched_power_slope(z1, self.a1, eps) - (
            self.k2 * _switched_power_slope(z1, self.a2, eps)
        )
        envelope_slope = -(
            envelope_gain[:, None]
            + 4.0 * eps1 * ((self.gamma1_hat + self.lambda1_hat) * phi1)[:, None] * z1**2
        )
        s1 = shell_slope + envelope_slope
        feedforward = s1 * velocity_error  # d(alpha1)/d(x1) * x2 term of (30)

        # Step-2 tuning functions (31)/(39).
        sigma12_vec = eps1 * z2 * s1**2 * phi1_sq[:, None]
        pi12 = np.sum(z2 * sigma12_vec, axis=1) + pi11
        omega12_vec = eps1 * z2 * s1**2 * phin_sq[:, None]
        tau12 = np.sum(z2 * omega12_vec, axis=1) + tau11
        pi21 = eps1 * z2_sq * phi2_sq - k0 * self.gamma2_hat
        tau21 = eps1 * z2_sq * phi2_sq - k0 * self.lambda2_hat
        lambda_dot_regressor = alpha1 - s1 * z1  # sigma_{i,0,1} base of (39)
        sigma01_vec = eps1 * z2 * lambda_dot_regressor**2
        pi01 = np.sum(z2 * sigma01_vec, axis=1) - k0 * self.gamma0_hat

        # Delayed-update compensation feedforward of (30):
        # d(alpha1)/d(gamma1_hat)*pi12 + d(alpha1)/d(lambda1_hat)*tau12.
        dalpha_dgamma = -eps1 * phi1_sq[:, None] * z1
        dalpha_dlambda = -eps1 * phin_sq[:, None] * z1
        adaptation_feedforward = (
            dalpha_dgamma * pi12[:, None] + dalpha_dlambda * tau12[:, None]
        )

        approximation = (
            eps1 * ((self.gamma2_hat + self.lambda2_hat) * phi2_sq)[:, None] * z2
        )
        stabilizing = (
            -z1
            - self.k3 * _switched_power(z2, self.a1, eps)
            - self.k4 * _switched_power(z2, self.a2, eps)
            - approximation
            - self.gamma1_hat[:, None] * sigma12_vec
            - self.lambda1_hat[:, None] * omega12_vec
            - self.gamma0_hat[:, None] * sigma01_vec
            + feedforward
            + adaptation_feedforward
        )

        if self.nussbaum_enabled:
            # Final-step law u = N(theta)*Psi, N = exp(theta^2)*sin(pi*theta).
            psi = -stabilizing
            nussbaum_gain = np.exp(self.nussbaum_theta**2) * np.sin(
                np.pi * self.nussbaum_theta
            )
            raw_control = nussbaum_gain[:, None] * psi
            theta_dot = self.nussbaum_rate * np.sum(z2 * psi, axis=1)
            self.nussbaum_theta = np.clip(
                self.nussbaum_theta + inputs.dt_s * theta_dot,
                -self.nussbaum_clip,
                self.nussbaum_clip,
            )
        else:
            # Documented fallback: known control direction, N degenerate.
            raw_control = stabilizing

        commanded = apply_fault_tolerance(
            raw_control,
            actuator_efficiency_estimate=inputs.actuator_efficiency,
            resilience_enabled=self.spec.fault_tolerant,
            max_control=self.max_control,
        )

        # Final-step adaptive laws (delayed update; sigma-leakage inside the
        # tuning functions).
        clip_hi = self.adaptive_clip
        dt = inputs.dt_s
        self.gamma1_hat = np.clip(self.gamma1_hat + dt * pi12, 0.0, clip_hi)
        self.lambda1_hat = np.clip(self.lambda1_hat + dt * tau12, 0.0, clip_hi)
        self.gamma2_hat = np.clip(self.gamma2_hat + dt * pi21, 0.0, clip_hi)
        self.lambda2_hat = np.clip(self.lambda2_hat + dt * tau21, 0.0, clip_hi)
        self.gamma0_hat = np.clip(self.gamma0_hat + dt * pi01, 0.0, clip_hi)

        triggered = comm.copy()
        zeros = np.zeros(self.follower_count, dtype=float)
        return self._output(
            inputs=inputs,
            state=state,
            raw_control=raw_control,
            commanded=commanded,
            z1=z1,
            z2=z2,
            approximation=approximation,
            triggered=triggered,
            trigger_metric=zeros,
            trigger_threshold=zeros,
            next_sampled_error=z1.copy(),
            next_sampled_velocity=velocity_error.copy(),
        )


class Ref72FixedTimeRtetcController(_TrueBaselineBase):
    """Structural reproduction of ref72 (TSMC 2025, fixed-time RTETC).

    Fixed-time backstepping core identical in form to ref36 (same family),
    without the attack-compensation channel, plus the relative-threshold
    event-triggered actuation of the group's CC-BY preprint:

    - continuous law  p = -(1+delta) * (|p_nom| tanh(z2 |p_nom| / eps_w)
                                        + m1 tanh(z2 m1 / eps_w))
    - trigger         ||p - u_held|| >= delta * ||u_held|| + m1
    - held actuation  u(t) = p(t_k) between events (no Zeno: threshold has
      the constant floor m1).
    """

    def __init__(
        self,
        spec: MethodSpec,
        follower_count: int,
        max_control: float,
        *,
        switch_epsilon: float = 0.08,
        fuzzy_gain: float = 1.5,
        fuzzy_leakage: float = 0.15,
        fuzzy_width: float = 1.0,
        trigger_delta: float = 0.2,
        trigger_floor: float = 0.06,
        tanh_boundary: float = 0.12,
    ) -> None:
        super().__init__(spec, follower_count, max_control)
        self.a1 = float(spec.finite_power if spec.finite_power is not None else 0.714)
        self.a2 = float(spec.fixed_power if spec.fixed_power is not None else 1.286)
        self.k1 = float(spec.position_gain)
        self.k2 = 0.45 * float(spec.position_gain)
        self.k3 = float(spec.velocity_gain)
        self.k4 = 0.45 * float(spec.velocity_gain)
        self.switch_epsilon = float(switch_epsilon)
        self.fuzzy_gain = float(fuzzy_gain)
        self.fuzzy_leakage = float(fuzzy_leakage)
        self.fuzzy_scale = float(fuzzy_width)
        self.trigger_delta = float(trigger_delta)
        self.trigger_floor = float(trigger_floor)
        self.tanh_boundary = float(tanh_boundary)
        self.theta_hat = np.zeros(self.follower_count, dtype=float)
        self.held_control = np.zeros((self.follower_count, 2), dtype=float)
        self.initialized = False

    def step(self, state: ControllerState, inputs: ControllerInput) -> ControllerOutput:
        z1, velocity_error, comm = _held_errors(state, inputs)
        eps = self.switch_epsilon
        alpha1 = -self.k1 * _switched_power(z1, self.a1, eps) - self.k2 * _switched_power(
            z1, self.a2, eps
        )
        z2 = velocity_error - alpha1
        alpha1_slope = -self.k1 * _switched_power_slope(z1, self.a1, eps) - (
            self.k2 * _switched_power_slope(z1, self.a2, eps)
        )
        alpha1_dot = alpha1_slope * velocity_error

        phi_sq = _gaussian_basis_norm(z1, z2)
        fuzzy_term = (self.theta_hat * phi_sq)[:, None] * z2 / (2.0 * self.fuzzy_scale**2)
        nominal = (
            -z1
            - self.k3 * _switched_power(z2, self.a1, eps)
            - self.k4 * _switched_power(z2, self.a2, eps)
            - fuzzy_term
            + alpha1_dot
        )
        magnitude = np.abs(nominal)
        continuous_law = -(1.0 + self.trigger_delta) * (
            magnitude * np.tanh(z2 * magnitude / self.tanh_boundary)
            + self.trigger_floor * np.tanh(z2 * self.trigger_floor / self.tanh_boundary)
        )

        if not self.initialized:
            self.held_control = continuous_law.copy()
            self.initialized = True
            triggered = np.ones(self.follower_count, dtype=bool)
        else:
            deviation = np.linalg.norm(continuous_law - self.held_control, axis=1)
            threshold = self.trigger_delta * np.linalg.norm(self.held_control, axis=1) + (
                self.trigger_floor
            )
            interval_ok = np.asarray(inputs.time_since_event, dtype=float) >= max(
                float(inputs.minimum_inter_event_s), 0.0
            )
            triggered = (deviation >= threshold) & comm & interval_ok
            self.held_control[triggered] = continuous_law[triggered]

        deviation_now = np.linalg.norm(continuous_law - self.held_control, axis=1)
        threshold_now = self.trigger_delta * np.linalg.norm(self.held_control, axis=1) + (
            self.trigger_floor
        )
        commanded = apply_fault_tolerance(
            self.held_control,
            actuator_efficiency_estimate=inputs.actuator_efficiency,
            resilience_enabled=self.spec.fault_tolerant,
            max_control=self.max_control,
        )

        z2_sq = np.sum(z2**2, axis=1)
        theta_dot = (
            self.fuzzy_gain * z2_sq * phi_sq / (2.0 * self.fuzzy_scale**2)
            - self.fuzzy_leakage * self.theta_hat
        )
        self.theta_hat = np.clip(self.theta_hat + inputs.dt_s * theta_dot, 0.0, 50.0)

        return self._output(
            inputs=inputs,
            state=state,
            raw_control=self.held_control.copy(),
            commanded=commanded,
            z1=z1,
            z2=z2,
            approximation=fuzzy_term,
            triggered=triggered,
            trigger_metric=deviation_now,
            trigger_threshold=threshold_now,
            next_sampled_error=z1.copy(),
            next_sampled_velocity=velocity_error.copy(),
        )


class OaCommandFilteredRtetcController(_TrueBaselineBase):
    """Equation-level port of the CC-BY preprint rs-324479 (order-reduced).

    Two-step command-filtered backstepping in the planar formation error
    coordinates (the preprint's five-step strict-feedback chain collapses to
    two integrators here; reference-derivative terms vanish in error
    coordinates).  Equation mapping, numbers per the preprint:

    - (9)/(10)  command filter  p2_bar * omega2_dot = alpha2 - omega2
    - (11)      compensated errors v_i = e_i - xi_i
    - (14)/(52) compensating signals xi1_dot, xi2_dot with sign terms
    - (16)      virtual law alpha2 = -c1 e1 - l1 tanh(v1 / w(t))
    - (28)/(68) theta_hat adaptation (norm form, w(t)-leakage)
    - (29)/(69) eps_hat adaptation
    - (58)-(63) RTETC: applied control held between events; trigger
                |p - u| >= delta |u| + m; continuous law
                p = -(1+delta)(Delta tanh(v2 Delta / w) + m tanh(v2 m / w))
    - (65)      Delta = -(nominal adaptive feedback expression), b = 1

    w(t) = w0 exp(-w_decay t) + w_floor; the preprint requires a positive
    uniformly continuous w with bounded integral (the small numerical floor
    contributes 16 ms-scale integral mass over a 16 s run).  Gains are
    recalibrated for this plant; the preprint's manipulator values are
    recorded in true_baseline_requirements.md.
    """

    def __init__(
        self,
        spec: MethodSpec,
        follower_count: int,
        max_control: float,
        *,
        filter_time_constant: float = 0.05,
        sign_gain_1: float = 0.02,
        sign_gain_2: float = 0.01,
        nn_width: float = 1.0,
        theta_gain: float = 0.5,
        eps_gain: float = 1.0,
        trigger_delta: float = 0.2,
        trigger_floor: float = 0.06,
        w_initial: float = 0.5,
        w_decay: float = 0.2,
        w_floor: float = 1e-3,
    ) -> None:
        super().__init__(spec, follower_count, max_control)
        self.c1 = float(spec.position_gain)
        self.c2 = float(spec.velocity_gain)
        self.p2_bar = float(filter_time_constant)
        self.l1 = float(sign_gain_1)
        self.l2 = float(sign_gain_2)
        self.a2 = float(nn_width)
        self.eta2 = float(theta_gain)
        self.gamma2 = float(eps_gain)
        self.trigger_delta = float(trigger_delta)
        self.trigger_floor = float(trigger_floor)
        self.w_initial = float(w_initial)
        self.w_decay = float(w_decay)
        self.w_floor = float(w_floor)
        shape = (self.follower_count, 2)
        self.omega2 = np.zeros(shape, dtype=float)
        self.xi1 = np.zeros(shape, dtype=float)
        self.xi2 = np.zeros(shape, dtype=float)
        self.theta2_hat = np.zeros(self.follower_count, dtype=float)
        self.eps2_hat = np.zeros(self.follower_count, dtype=float)
        self.held_control = np.zeros(shape, dtype=float)
        self.initialized = False

    def _w(self, time_s: float) -> float:
        return self.w_initial * float(np.exp(-self.w_decay * time_s)) + self.w_floor

    def step(self, state: ControllerState, inputs: ControllerInput) -> ControllerOutput:
        e1, velocity_error, comm = _held_errors(state, inputs)
        dt = float(inputs.dt_s)
        w_t = self._w(inputs.time_s)

        v1 = e1 - self.xi1
        alpha2 = -self.c1 * e1 - self.l1 * np.tanh(v1 / w_t)
        if not self.initialized:
            self.omega2 = alpha2.copy()

        e2 = velocity_error - self.omega2
        v2 = e2 - self.xi2

        phi_sq = _gaussian_basis_norm(e1, e2)
        omega2_dot = (alpha2 - self.omega2) / self.p2_bar
        tanh_v2 = np.tanh(v2 / w_t)
        adaptive_magnitude = (
            self.theta2_hat * phi_sq / (2.0 * self.a2**2) + self.a2 + self.eps2_hat
        )[:, None] + self.l2
        delta_term = -(
            tanh_v2 * adaptive_magnitude - omega2_dot + e1 + self.c2 * e2
        )
        continuous_law = -(1.0 + self.trigger_delta) * (
            delta_term * np.tanh(v2 * delta_term / w_t)
            + self.trigger_floor * np.tanh(v2 * self.trigger_floor / w_t)
        )

        if not self.initialized:
            self.held_control = continuous_law.copy()
            self.initialized = True
            triggered = np.ones(self.follower_count, dtype=bool)
        else:
            deviation = np.linalg.norm(continuous_law - self.held_control, axis=1)
            threshold = self.trigger_delta * np.linalg.norm(self.held_control, axis=1) + (
                self.trigger_floor
            )
            interval_ok = np.asarray(inputs.time_since_event, dtype=float) >= max(
                float(inputs.minimum_inter_event_s), 0.0
            )
            triggered = (deviation >= threshold) & comm & interval_ok
            self.held_control[triggered] = continuous_law[triggered]

        deviation_now = np.linalg.norm(continuous_law - self.held_control, axis=1)
        threshold_now = self.trigger_delta * np.linalg.norm(self.held_control, axis=1) + (
            self.trigger_floor
        )
        commanded = apply_fault_tolerance(
            self.held_control,
            actuator_efficiency_estimate=inputs.actuator_efficiency,
            resilience_enabled=self.spec.fault_tolerant,
            max_control=self.max_control,
        )

        xi1_dot = -self.c1 * self.xi1 + self.xi2 + (self.omega2 - alpha2) - (
            self.l1 * np.sign(self.xi1)
        )
        xi2_dot = -self.c2 * self.xi2 - self.l2 * np.sign(self.xi2) - self.xi1
        v2_tanh_sum = np.sum(v2 * tanh_v2, axis=1)
        theta2_dot = (
            self.eta2 * v2_tanh_sum * phi_sq / (2.0 * self.a2**2)
            - self.eta2 * w_t * self.theta2_hat
        )
        eps2_dot = self.gamma2 * v2_tanh_sum - self.gamma2 * w_t * self.eps2_hat

        self.omega2 = self.omega2 + dt * omega2_dot
        self.xi1 = np.clip(self.xi1 + dt * xi1_dot, -5.0, 5.0)
        self.xi2 = np.clip(self.xi2 + dt * xi2_dot, -5.0, 5.0)
        self.theta2_hat = np.clip(self.theta2_hat + dt * theta2_dot, 0.0, 50.0)
        self.eps2_hat = np.clip(self.eps2_hat + dt * eps2_dot, 0.0, 50.0)

        return self._output(
            inputs=inputs,
            state=state,
            raw_control=self.held_control.copy(),
            commanded=commanded,
            z1=e1,
            z2=e2,
            approximation=tanh_v2 * adaptive_magnitude,
            triggered=triggered,
            trigger_metric=deviation_now,
            trigger_threshold=threshold_now,
            next_sampled_error=e1.copy(),
            next_sampled_velocity=velocity_error.copy(),
        )


def build_true_baseline_controller(
    spec: MethodSpec,
    follower_count: int,
    max_control: float,
):
    if spec.name == "ref36_reproduction":
        return Ref36FixedTimeResilientController(spec, follower_count, max_control)
    if spec.name == "ref72_reproduction":
        return Ref72FixedTimeRtetcController(spec, follower_count, max_control)
    if spec.name == "oa_alternative_baseline":
        return OaCommandFilteredRtetcController(spec, follower_count, max_control)
    raise ValueError(f"{spec.name!r} is not a registered true-baseline method.")
