from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter

import numpy as np

from .config import ExperimentConfig
from .controllers import (
    ControllerInput,
    ControllerState,
    DisturbanceAttackObserver,
    DynamicEventTrigger,
    ModularController,
    PrescribedPerformance,
    get_method_spec,
    spec_with_gains,
)
from .estimators import (
    OnlineBiasEstimator,
    OnlineEfficiencyEstimator,
    estimator_config_from_mapping,
)
from .metrics import compute_run_metrics
from .models import (
    apply_usv_underactuation_scale,
    apply_v1000_canonical_point_mass,
    build_agent_dynamics,
    deterministic_disturbance,
    follower_type_mask,
    formation_offsets,
    leader_reference,
    platform_command_response,
    platform_hydrodynamic_drag,
    isotropic_planar_drag,
    explicit_command_lag,
    slice_agent_dynamics,
)
from .quadrotor_6dof import disturbance_3d, initialize_fleet, step_fleet, tilt_angle
from .usv_3dof import initialize_usv_fleet, step_usv_fleet
from .scenarios import build_scenario_profile
from .topology import build_leader_follower_topology
from .topology import dynamic_topology_weight_matrices, topology_consensus_error


@dataclass(frozen=True)
class SimulationJob:
    method: str
    scenario: str
    seed: int
    predefined_time_s: float
    uav_count: int
    usv_count: int
    stress_tag: str = "baseline"
    stress_category: str = "baseline"
    stress_level: str = "baseline"
    topology_name: str = "leader_ring"
    topology_feedback_gain: float = 0.0
    topology_switch_period_s: float = 1.0
    actuator_loss_scale: float = 1.0
    fdi_scale: float = 1.0
    dos_duty_scale: float = 1.0
    disturbance_scale: float = 1.0
    dynamics_uncertainty: float = 0.0
    resilience_information_mode: str = "causal"
    position_gain: float | None = None
    velocity_gain: float | None = None
    dos_model: str = "windows"
    event_hold: bool = True
    integrator: str | None = None
    usv_underactuation_scale: float = 1.0
    plant_model: str = "planar_proxy"
    hover_altitude_m: float = 1.5
    inner_dt_s: float = 0.005
    usv_inner_dt_s: float = 0.005
    uav_attitude_bandwidth_scale: float = 1.0
    uav_tilt_limit_rad: float = 0.70
    uav_thrust_max_frac: float = 2.40
    uav_command_lag_s: float = 0.0
    usv_command_lag_s: float = 0.0
    matched_drag: bool = False


@dataclass(frozen=True)
class SimulationOutput:
    metrics: dict[str, float]
    times: np.ndarray
    tracking_errors: np.ndarray
    controls: np.ndarray
    trigger_events: np.ndarray
    constraint_violations: np.ndarray
    transformed_errors: np.ndarray
    normalized_errors: np.ndarray
    performance_bounds: np.ndarray
    approximations: np.ndarray
    observer_estimates: np.ndarray
    trigger_metrics: np.ndarray
    trigger_thresholds: np.ndarray
    physical_position_errors: np.ndarray
    network_position_errors: np.ndarray
    controller_position_errors: np.ndarray
    held_position_errors: np.ndarray
    sensor_biases: np.ndarray
    bias_estimates: np.ndarray
    actuator_efficiencies: np.ndarray
    actuator_efficiency_estimates: np.ndarray
    actual_controls: np.ndarray | None = None
    uav_altitudes: np.ndarray | None = None
    uav_tilts: np.ndarray | None = None
    uav_attitude_errors: np.ndarray | None = None
    actual_force_interval_effort: np.ndarray | None = None
    usv_yaw_interval_effort: np.ndarray | None = None


def simulate_job(config: ExperimentConfig, job: SimulationJob) -> SimulationOutput:
    backend = str(config.simulation.get("numeric_backend", "numpy"))
    integrator = str(job.integrator or config.simulation.get("integrator", "rk4"))
    state_dtype = str(config.simulation.get("state_dtype", "float64"))
    if backend != "numpy":
        raise ValueError(f"simulate_job requires numeric_backend='numpy', got {backend!r}.")
    if integrator not in {"semi_implicit_euler", "rk4"}:
        raise ValueError(f"Unsupported integrator {integrator!r}.")
    if state_dtype != "float64":
        raise ValueError(f"simulate_job requires state_dtype='float64', got {state_dtype!r}.")
    information_mode = str(job.resilience_information_mode)
    if information_mode not in {"causal", "oracle", "unassisted", "oracle_efficiency", "oracle_bias"}:
        raise ValueError(
            "resilience_information_mode must be 'causal', 'oracle', or "
            f"'unassisted', got {information_mode!r}."
        )
    plant_model = str(job.plant_model)
    if plant_model not in {
        "planar_proxy",
        "course_aligned",
        "quadrotor_6dof",
        "mixed_6dof_3dof",
        "v1000_canonical",
        "matched_point_mass",
        "matched_lagged",
    }:
        raise ValueError(
            "plant_model must be 'planar_proxy', 'course_aligned', "
            "'quadrotor_6dof', 'mixed_6dof_3dof', or 'v1000_canonical', "
            f"got {plant_model!r}."
        )
    if plant_model == "v1000_canonical":
        from .v1000_loop import simulate_v1000_canonical

        return simulate_v1000_canonical(config, job)
    use_matched_planar = plant_model in {"matched_point_mass", "matched_lagged"}
    if use_matched_planar and not job.matched_drag:
        raise ValueError("New matched planar layers require matched_drag=True.")
    if job.inner_dt_s <= 0 or job.usv_inner_dt_s <= 0:
        raise ValueError("UAV and USV inner steps must be positive.")
    rng = np.random.default_rng(job.seed)
    topology = build_leader_follower_topology(
        job.uav_count,
        job.usv_count,
        topology_name=job.topology_name,
        seed=job.seed,
    )
    follower_count = topology.follower_count
    spec = spec_with_gains(
        get_method_spec(job.method),
        position_gain=job.position_gain,
        velocity_gain=job.velocity_gain,
    )

    dt = float(config.simulation["dt_s"])
    duration = float(config.simulation["duration_s"])
    times = np.arange(0.0, duration + 0.5 * dt, dt, dtype=float)
    steps = len(times)
    spacing = float(config.simulation.get("formation_spacing", 1.2))
    max_control = float(config.simulation.get("max_control", 8.0))
    error_tolerance = float(config.simulation.get("error_tolerance", 0.08))
    constraint_radius = float(config.simulation.get("constraint_radius", 1.2))
    performance_initial_radius = float(config.simulation.get("performance_initial_radius", 1.5))
    trigger_threshold = float(config.simulation.get("event_trigger_threshold", 0.035))
    max_hold_s = float(config.simulation.get("max_event_hold_s", 0.55))
    nominal_integral = float(config.simulation.get("nominal_integral_error", 1.0))
    estimator_config = estimator_config_from_mapping(config.simulation)

    dynamics = apply_usv_underactuation_scale(
        build_agent_dynamics(
            topology.agent_types,
            max_control=max_control,
            uncertainty=job.dynamics_uncertainty,
            rng=rng,
        ),
        job.usv_underactuation_scale,
    )
    if plant_model == "v1000_canonical":
        dynamics = apply_v1000_canonical_point_mass(dynamics)
    scenario = build_scenario_profile(
        job.scenario,
        times,
        follower_count,
        rng,
        actuator_loss_scale=job.actuator_loss_scale,
        fdi_scale=job.fdi_scale,
        dos_duty_scale=job.dos_duty_scale,
        dos_model=job.dos_model,
    )
    offsets = formation_offsets(follower_count, spacing=spacing)

    leader_pos0, leader_vel0 = leader_reference(0.0)
    desired0 = leader_pos0[None, :] + offsets
    positions = desired0 + rng.normal(0.0, 0.42, size=(follower_count, 2))
    velocities = np.tile(leader_vel0, (follower_count, 1)) * 0.15
    platform_command_state = np.zeros((follower_count, 2), dtype=float)
    uav_mask = follower_type_mask(dynamics, "UAV")
    usv_mask = follower_type_mask(dynamics, "USV")
    n_uav = int(np.sum(uav_mask))
    n_usv = int(np.sum(usv_mask))
    use_quadrotor = plant_model in {"quadrotor_6dof", "mixed_6dof_3dof"}
    use_usv3 = plant_model == "mixed_6dof_3dof"
    fleet = None
    usv_fleet = None
    if use_quadrotor and n_uav > 0:
        fleet = initialize_fleet(
            mass=dynamics.mass[uav_mask],
            p_xy=positions[uav_mask],
            v_xy=velocities[uav_mask],
            hover_z=float(job.hover_altitude_m),
            inner_dt_s=float(job.inner_dt_s),
            rng=rng,
            attitude_bandwidth_scale=job.uav_attitude_bandwidth_scale,
            tilt_limit_rad=job.uav_tilt_limit_rad,
            thrust_max_frac=job.uav_thrust_max_frac,
            matched_drag=job.matched_drag,
        )
        positions[uav_mask] = fleet.p[:, :2]
        velocities[uav_mask] = fleet.v[:, :2]
    if use_usv3 and n_usv > 0:
        usv_fleet = initialize_usv_fleet(
            mass=dynamics.mass[usv_mask],
            p_xy=positions[usv_mask],
            v_xy=velocities[usv_mask],
            matched_drag=job.matched_drag,
        )
        positions[usv_mask] = usv_fleet.p
        velocities[usv_mask] = usv_fleet.inertial_vxy

    initial_physical_error = positions - desired0
    if plant_model == "v1000_canonical":
        initial_network_error = initial_physical_error.copy()
        initial_controller_error = initial_physical_error.copy()
    else:
        initial_network_error, initial_controller_error = _topology_controller_errors(
            physical_or_measured_error=initial_physical_error,
            topology=topology,
            topology_name=job.topology_name,
            topology_feedback_gain=job.topology_feedback_gain,
            time_s=0.0,
            switch_period_s=job.topology_switch_period_s,
        )
    initial_velocity_error = velocities - np.tile(leader_vel0, (follower_count, 1))
    last_event_time = np.zeros(follower_count, dtype=float)
    controller = ModularController(
        spec=spec,
        follower_count=follower_count,
        dimensions=2,
        max_control=max_control,
        performance=PrescribedPerformance(
            initial_radius=performance_initial_radius,
            final_radius=constraint_radius,
        ),
        observer=DisturbanceAttackObserver(
            gain=float(config.simulation.get("observer_gain", 0.7)),
            leakage=float(config.simulation.get("observer_leakage", 0.25)),
        ),
        trigger=DynamicEventTrigger(
            sigma_1=float(config.simulation.get("trigger_sigma_1", 0.08)),
            filter_decay=float(config.simulation.get("trigger_filter_decay", 1.2)),
            filter_gain=float(config.simulation.get("trigger_filter_gain", 0.015)),
        ),
    )
    controller_state = ControllerState(
        adaptive_weights=np.zeros((follower_count, controller.basis_size, 2), dtype=float),
        observer_state=np.zeros((follower_count, 2), dtype=float),
        trigger_filter=np.zeros(follower_count, dtype=float),
        sampled_error=initial_controller_error.copy(),
        sampled_velocity_error=initial_velocity_error.copy(),
    )
    bias_estimator = OnlineBiasEstimator(follower_count, 2, estimator_config)
    efficiency_estimator = OnlineEfficiencyEstimator(follower_count, estimator_config)
    actual_force_effort = np.zeros(follower_count)
    usv_yaw_effort = np.zeros(n_usv)
    actual_force_interval_effort = np.zeros((steps, follower_count))
    usv_yaw_interval_effort = np.zeros((steps, n_usv))
    rotor_saturation_time = np.zeros(n_uav)
    tilt_saturation_time = np.zeros(n_uav)
    command_tau = np.where(uav_mask, job.uav_command_lag_s, job.usv_command_lag_s).astype(float)
    if plant_model == "matched_lagged":
        command_tau = np.where(command_tau > 0, command_tau, np.where(uav_mask, 0.08, 0.24))

    tracking_errors = np.zeros((steps, follower_count), dtype=float)
    controls = np.zeros((steps, follower_count, 2), dtype=float)
    actual_controls = np.zeros((steps, follower_count, 2), dtype=float)
    trigger_events = np.zeros((steps, follower_count), dtype=bool)
    constraint_violations = np.zeros((steps, follower_count), dtype=bool)
    transformed_errors = np.zeros((steps, follower_count, 2), dtype=float)
    normalized_errors = np.zeros((steps, follower_count, 2), dtype=float)
    performance_bounds = np.zeros(steps, dtype=float)
    approximations = np.zeros((steps, follower_count, 2), dtype=float)
    observer_estimates = np.zeros((steps, follower_count, 2), dtype=float)
    trigger_metrics = np.zeros((steps, follower_count), dtype=float)
    trigger_thresholds = np.zeros((steps, follower_count), dtype=float)
    physical_position_errors = np.zeros((steps, follower_count, 2), dtype=float)
    network_position_errors = np.zeros((steps, follower_count, 2), dtype=float)
    controller_position_errors = np.zeros((steps, follower_count, 2), dtype=float)
    held_position_errors = np.zeros((steps, follower_count, 2), dtype=float)
    sensor_biases = np.zeros((steps, follower_count, 2), dtype=float)
    bias_estimates = np.zeros((steps, follower_count, 2), dtype=float)
    actuator_efficiencies = np.zeros((steps, follower_count), dtype=float)
    actuator_efficiency_estimates = np.ones((steps, follower_count), dtype=float)
    uav_altitudes = np.zeros((steps, n_uav), dtype=float)
    uav_tilts = np.zeros((steps, n_uav), dtype=float)
    uav_attitude_errors = np.zeros((steps, n_uav), dtype=float)

    started = perf_counter()
    for step, time_s in enumerate(times):
        leader_position, leader_velocity = leader_reference(float(time_s))
        desired = leader_position[None, :] + offsets
        desired_velocity = np.tile(leader_velocity, (follower_count, 1))
        current_velocity_error = velocities - desired_velocity

        sensor_bias = scenario.sensor_bias[step]
        raw_measured_positions = positions + sensor_bias
        raw_measured_error = raw_measured_positions - desired
        if spec.resilience and information_mode != "unassisted":
            bias_estimate = (sensor_bias.copy() if information_mode in {"oracle", "oracle_bias"}
                             else bias_estimator.update(raw_measured_error, current_velocity_error, dt))
            actuator_efficiency_estimate = (scenario.actuator_efficiency[step].copy()
                if information_mode in {"oracle", "oracle_efficiency"} else efficiency_estimator.efficiency.copy())
        else:
            bias_estimate = np.zeros_like(sensor_bias)
            actuator_efficiency_estimate = np.ones(follower_count, dtype=float)
        measured_positions = raw_measured_positions - bias_estimate

        measured_error = measured_positions - desired
        network_error, current_error = _topology_controller_errors(
            physical_or_measured_error=measured_error,
            topology=topology,
            topology_name=job.topology_name,
            topology_feedback_gain=job.topology_feedback_gain,
            time_s=float(time_s),
            switch_period_s=job.topology_switch_period_s,
        )
        time_since_event = time_s - last_event_time
        sampled_error_in = current_error if not job.event_hold else controller_state.sampled_error
        sampled_state = ControllerState(
            adaptive_weights=controller_state.adaptive_weights,
            observer_state=controller_state.observer_state,
            trigger_filter=controller_state.trigger_filter,
            sampled_error=sampled_error_in,
            sampled_velocity_error=(
                current_velocity_error if not job.event_hold else controller_state.sampled_velocity_error
            ),
        )
        controller_output = controller.step(
            sampled_state,
            ControllerInput(
                time_s=float(time_s),
                dt_s=dt,
                position_error=current_error,
                velocity_error=current_velocity_error,
                sampled_error=sampled_error_in,
                time_since_event=time_since_event,
                communication_available=scenario.communication_available[step],
                actuator_efficiency=actuator_efficiency_estimate,
                predefined_time_s=job.predefined_time_s,
                constraint_radius=constraint_radius,
                trigger_base_threshold=trigger_threshold,
                trigger_max_hold_s=max_hold_s,
                minimum_inter_event_s=float(config.simulation.get("minimum_inter_event_s", 0.0)),
            ),
        )

        event_mask = controller_output.triggered.copy()
        if step == 0:
            event_mask[:] = True
            controller_state = ControllerState(
                adaptive_weights=controller_output.next_state.adaptive_weights,
                observer_state=controller_output.next_state.observer_state,
                trigger_filter=controller_output.next_state.trigger_filter,
                sampled_error=current_error.copy(),
                sampled_velocity_error=current_velocity_error.copy(),
            )
        else:
            controller_state = controller_output.next_state
        last_event_time[event_mask] = time_s

        commanded = controller_output.commanded_control
        if plant_model == "v1000_canonical":
            platform_control = commanded
            drag = dynamics.damping[:, None] * velocities
        elif use_quadrotor or use_matched_planar:
            platform_command_state = explicit_command_lag(platform_command_state, commanded, command_tau, dt)
            platform_control = platform_command_state.copy()
            drag = isotropic_planar_drag(dynamics, velocities)
            if fleet is not None:
                drag[uav_mask] = fleet.drag_force[:, :2]
            if usv_fleet is not None:
                drag[usv_mask] = usv_fleet.drag_world
        else:
            lag_model = "planar_proxy" if use_quadrotor else plant_model
            platform_command_state, platform_control = platform_command_response(
                dynamics,
                platform_command_state,
                commanded,
                velocities,
                dt,
                plant_model=lag_model,
            )
            drag = platform_hydrodynamic_drag(dynamics, velocities)
        actual_control = scenario.actuator_efficiency[step, :, None] * platform_control
        if fleet is not None:
            uav_altitudes[step] = fleet.p[:, 2]
            uav_tilts[step] = tilt_angle(fleet.R)
            uav_attitude_errors[step] = uav_tilts[step]

        true_error = positions - desired
        error_norm = np.linalg.norm(true_error, axis=1)
        envelope = controller.performance.bounds(
            time_s=float(time_s),
            predefined_time_s=job.predefined_time_s,
            final_radius=constraint_radius,
        )
        tracking_errors[step] = error_norm
        controls[step] = commanded
        actual_controls[step] = actual_control
        trigger_events[step] = event_mask
        constraint_violations[step] = error_norm > envelope
        physical_position_errors[step] = true_error
        network_position_errors[step] = network_error
        controller_position_errors[step] = current_error
        held_position_errors[step] = controller_output.control_position_error
        transformed_errors[step] = controller_output.transformed_error
        normalized_errors[step] = controller_output.normalized_error
        performance_bounds[step] = controller_output.performance_bound
        approximations[step] = controller_output.approximation
        observer_estimates[step] = controller_output.observer_estimate
        trigger_metrics[step] = controller_output.trigger_metric
        trigger_thresholds[step] = controller_output.trigger_threshold
        sensor_biases[step] = sensor_bias
        bias_estimates[step] = bias_estimate
        actuator_efficiencies[step] = scenario.actuator_efficiency[step]
        actuator_efficiency_estimates[step] = actuator_efficiency_estimate

        if step == steps - 1:
            if step > 0 and (use_quadrotor or use_matched_planar):
                actual_controls[step] = actual_controls[step - 1]
            break
        previous_velocity = velocities.copy()
        t0 = float(time_s)
        held_disturbance = deterministic_disturbance(
            t0,
            follower_count,
            seed_scale=0.01 * job.seed,
            disturbance_scale=job.disturbance_scale,
        )

        def acceleration_at(vel: np.ndarray, t_eval: float, dyn=dynamics, force=actual_control) -> np.ndarray:
            if plant_model == "v1000_canonical":
                drag_eval = dyn.damping[:, None] * vel
                disturbance = held_disturbance[: vel.shape[0]]
            else:
                drag_eval = platform_hydrodynamic_drag(dyn, vel)
                disturbance = deterministic_disturbance(
                    t_eval,
                    int(vel.shape[0]),
                    seed_scale=0.01 * job.seed,
                    disturbance_scale=job.disturbance_scale,
                )
            return (force + disturbance - drag_eval) / dyn.mass[:, None]

        if use_quadrotor:
            if fleet is not None:
                extras = step_fleet(
                    fleet,
                    force_xy=platform_control[uav_mask],
                    actuator_efficiency=scenario.actuator_efficiency[step, uav_mask],
                    disturbance_3d=np.column_stack((held_disturbance[uav_mask],
                        disturbance_3d(t0, follower_count, seed_scale=0.01 * job.seed,
                                       disturbance_scale=job.disturbance_scale)[uav_mask, 2])),
                    yaw_des=float(np.arctan2(leader_velocity[1], leader_velocity[0])),
                    outer_dt_s=dt,
                    z_des=float(job.hover_altitude_m),
                )
                positions[uav_mask] = fleet.p[:, :2]
                velocities[uav_mask] = fleet.v[:, :2]
                actual_control[uav_mask] = extras["force_xy"]
                actual_controls[step, uav_mask] = extras["force_xy"]
                uav_attitude_errors[step] = extras["attitude_error"]
                actual_force_effort[uav_mask] += extras["force_effort"]
                actual_force_interval_effort[step, uav_mask] = extras["force_effort"]
                rotor_saturation_time += dt * extras["rotor_saturation_fraction"]
                tilt_saturation_time += dt * extras["tilt_saturation_fraction"]
            if usv_fleet is not None:
                usv_extra = step_usv_fleet(
                    usv_fleet,
                    force_xy=platform_control[usv_mask],
                    actuator_efficiency=scenario.actuator_efficiency[step, usv_mask],
                    disturbance_xy=held_disturbance[usv_mask],
                    dt_s=dt,
                    n_inner=max(1, int(np.ceil(dt / job.usv_inner_dt_s))),
                )
                positions[usv_mask] = usv_fleet.p
                velocities[usv_mask] = usv_fleet.inertial_vxy
                actual_controls[step, usv_mask] = usv_extra["force_xy"]
                actual_force_effort[usv_mask] += usv_extra["force_effort"]
                usv_yaw_effort += usv_extra["yaw_torque_effort"]
                actual_force_interval_effort[step, usv_mask] = usv_extra["force_effort"]
                usv_yaw_interval_effort[step] = usv_extra["yaw_torque_effort"]
            elif np.any(usv_mask):
                usv_dyn = slice_agent_dynamics(dynamics, usv_mask)
                v_usv = velocities[usv_mask]
                p_usv = positions[usv_mask]
                u_usv = actual_control[usv_mask]
                if integrator == "rk4":
                    k1_v = acceleration_at(v_usv, t0, usv_dyn, u_usv)
                    k1_p = v_usv
                    k2_v = acceleration_at(v_usv + 0.5 * dt * k1_v, t0 + 0.5 * dt, usv_dyn, u_usv)
                    k2_p = v_usv + 0.5 * dt * k1_v
                    k3_v = acceleration_at(v_usv + 0.5 * dt * k2_v, t0 + 0.5 * dt, usv_dyn, u_usv)
                    k3_p = v_usv + 0.5 * dt * k2_v
                    k4_v = acceleration_at(v_usv + dt * k3_v, t0 + dt, usv_dyn, u_usv)
                    k4_p = v_usv + dt * k3_v
                    v_usv = v_usv + (dt / 6.0) * (k1_v + 2.0 * k2_v + 2.0 * k3_v + k4_v)
                    p_usv = p_usv + (dt / 6.0) * (k1_p + 2.0 * k2_p + 2.0 * k3_p + k4_p)
                else:
                    acc = acceleration_at(v_usv, t0, usv_dyn, u_usv)
                    v_usv = v_usv + dt * acc
                    p_usv = p_usv + dt * v_usv
                velocities[usv_mask] = v_usv
                positions[usv_mask] = p_usv
                actual_force_effort[usv_mask] += dt * np.sum(u_usv**2, axis=1)
                actual_force_interval_effort[step, usv_mask] = dt * np.sum(u_usv**2, axis=1)
        elif use_matched_planar:
            for species_mask, inner_step in ((uav_mask, job.inner_dt_s), (usv_mask, job.usv_inner_dt_s)):
                if not np.any(species_mask):
                    continue
                dyn = slice_agent_dynamics(dynamics, species_mask)
                inner_count = max(1, int(np.ceil(dt / inner_step)))
                inner_h = dt / inner_count
                v_species = velocities[species_mask].copy()
                p_species = positions[species_mask].copy()
                force = actual_control[species_mask]
                for _ in range(inner_count):
                    acc = (force + held_disturbance[species_mask]
                           - isotropic_planar_drag(dyn, v_species)) / dyn.mass[:, None]
                    v_species += inner_h * acc
                    p_species += inner_h * v_species
                velocities[species_mask] = v_species
                positions[species_mask] = p_species
                actual_force_effort[species_mask] += dt * np.sum(force**2, axis=1)
                actual_force_interval_effort[step, species_mask] = dt * np.sum(force**2, axis=1)
        elif integrator == "rk4":
            k1_v = acceleration_at(velocities, t0)
            k1_p = velocities
            k2_v = acceleration_at(velocities + 0.5 * dt * k1_v, t0 + 0.5 * dt)
            k2_p = velocities + 0.5 * dt * k1_v
            k3_v = acceleration_at(velocities + 0.5 * dt * k2_v, t0 + 0.5 * dt)
            k3_p = velocities + 0.5 * dt * k2_v
            k4_v = acceleration_at(velocities + dt * k3_v, t0 + dt)
            k4_p = velocities + dt * k3_v
            velocities = velocities + (dt / 6.0) * (k1_v + 2.0 * k2_v + 2.0 * k3_v + k4_v)
            positions = positions + (dt / 6.0) * (k1_p + 2.0 * k2_p + 2.0 * k3_p + k4_p)
        else:
            acceleration = acceleration_at(velocities, t0)
            velocities = velocities + dt * acceleration
            positions = positions + dt * velocities
        if spec.resilience and information_mode in {"causal", "oracle_bias"}:
            observed_acceleration = (velocities - previous_velocity) / dt
            efficiency_estimator.update(
                applied_control=platform_control,
                observed_acceleration=observed_acceleration,
                mass=dynamics.mass,
                modelled_drag=drag,
                dt_s=dt,
            )

    elapsed = perf_counter() - started
    metrics = compute_run_metrics(
        times=times,
        tracking_errors=tracking_errors,
        controls=controls,
        trigger_events=trigger_events,
        constraint_violations=constraint_violations,
        predefined_time_s=job.predefined_time_s,
        error_tolerance=error_tolerance,
        nominal_integral_error=nominal_integral,
        computation_time_s=elapsed,
        actual_controls=actual_controls,
        sensor_biases=sensor_biases,
        bias_estimates=bias_estimates,
        actuator_efficiencies=actuator_efficiencies,
        actuator_efficiency_estimates=actuator_efficiency_estimates,
    )
    if use_quadrotor or use_matched_planar:
        metrics["actual_control_energy"] = float(actual_force_effort.sum())
        metrics["actual_uav_force_effort"] = float(actual_force_effort[uav_mask].sum())
        metrics["actual_usv_force_effort"] = float(actual_force_effort[usv_mask].sum())
        metrics["actual_usv_yaw_torque_effort"] = float(usv_yaw_effort.sum())
        metrics["uav_tracking_error"] = float(tracking_errors[:, uav_mask].mean()) if n_uav else 0.0
        metrics["usv_tracking_error"] = float(tracking_errors[:, usv_mask].mean()) if n_usv else 0.0
    if use_quadrotor and n_uav > 0:
        z_err = uav_altitudes - float(job.hover_altitude_m)
        metrics["altitude_rmse"] = float(np.sqrt(np.mean(z_err**2)))
        metrics["tilt_mean_rad"] = float(np.mean(uav_tilts))
        metrics["attitude_error_mean"] = float(np.mean(uav_attitude_errors))
        metrics["uav_altitude_mean"] = float(np.mean(uav_altitudes))
        xy_uav = physical_position_errors[:, uav_mask, :]
        err3 = np.sqrt(np.sum(xy_uav**2, axis=2) + z_err**2)
        metrics["uav_3d_tracking_error"] = float(np.mean(err3))
        metrics["xy_formation_tracking_error"] = float(metrics["formation_tracking_error"])
        metrics["uav_rotor_saturation_fraction"] = float(rotor_saturation_time.sum() / (duration * n_uav))
        metrics["uav_tilt_saturation_fraction"] = float(tilt_saturation_time.sum() / (duration * n_uav))
    return SimulationOutput(
        metrics=metrics,
        times=times,
        tracking_errors=tracking_errors,
        controls=controls,
        trigger_events=trigger_events,
        constraint_violations=constraint_violations,
        transformed_errors=transformed_errors,
        normalized_errors=normalized_errors,
        performance_bounds=performance_bounds,
        approximations=approximations,
        observer_estimates=observer_estimates,
        trigger_metrics=trigger_metrics,
        trigger_thresholds=trigger_thresholds,
        physical_position_errors=physical_position_errors,
        network_position_errors=network_position_errors,
        controller_position_errors=controller_position_errors,
        held_position_errors=held_position_errors,
        sensor_biases=sensor_biases,
        bias_estimates=bias_estimates,
        actuator_efficiencies=actuator_efficiencies,
        actuator_efficiency_estimates=actuator_efficiency_estimates,
        actual_controls=actual_controls,
        uav_altitudes=uav_altitudes if use_quadrotor else None,
        uav_tilts=uav_tilts if use_quadrotor else None,
        uav_attitude_errors=uav_attitude_errors if use_quadrotor else None,
        actual_force_interval_effort=actual_force_interval_effort if (use_quadrotor or use_matched_planar) else None,
        usv_yaw_interval_effort=usv_yaw_interval_effort if (use_quadrotor or use_matched_planar) else None,
    )


def _prescribed_performance_envelope(
    *,
    time_s: float,
    predefined_time_s: float,
    initial_radius: float,
    final_radius: float,
) -> float:
    decay = np.exp(-3.0 * min(time_s, predefined_time_s) / max(predefined_time_s, 1e-9))
    return float(final_radius + max(initial_radius - final_radius, 0.0) * decay)


def _topology_controller_errors(
    *,
    physical_or_measured_error: np.ndarray,
    topology,
    topology_name: str,
    topology_feedback_gain: float,
    time_s: float,
    switch_period_s: float,
) -> tuple[np.ndarray, np.ndarray]:
    measured_error = np.asarray(physical_or_measured_error, dtype=float)
    topology_gain = min(max(float(topology_feedback_gain), 0.0), 1.0)
    if topology_gain <= 0.0:
        return measured_error.copy(), measured_error.copy()
    leader_weights, follower_weights = dynamic_topology_weight_matrices(
        topology,
        topology_name=topology_name,
        time_s=float(time_s),
        switch_period_s=float(switch_period_s),
    )
    network_error = topology_consensus_error(measured_error, leader_weights, follower_weights)
    controller_error = (1.0 - topology_gain) * measured_error + topology_gain * network_error
    return network_error, controller_error
