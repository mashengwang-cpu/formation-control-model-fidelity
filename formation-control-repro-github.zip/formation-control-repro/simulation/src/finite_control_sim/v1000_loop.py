"""Canonical V1000 closed loop.

Faithful port of DRONES V2 ``code/analysis/12_parallel_regenerate.py`` ``run_job``:
linear mass-damping (UAV 0.28, USV 0.42), no command lag, oracle information
for resilient stacks, RK4 with step-held disturbance, topology gain 0.65.
"""

from __future__ import annotations

from time import perf_counter

import numpy as np

from .config import ExperimentConfig
from .controllers import (
    ControllerInput,
    ControllerState,
    ModularController,
    PrescribedPerformance,
    get_method_spec,
    spec_with_gains,
)
from .estimators import OnlineBiasEstimator, OnlineEfficiencyEstimator, estimator_config_from_mapping
from .metrics import compute_run_metrics
from .models import apply_v1000_canonical_point_mass, build_agent_dynamics, deterministic_disturbance, formation_offsets, leader_reference
from .scenarios import build_scenario_profile
from .simulator import SimulationJob, SimulationOutput
from .topology import (
    build_leader_follower_topology,
    dynamic_topology_weight_matrices,
    topology_consensus_error,
)


def _topo(measured_error, topology, gain: float, time_s: float, switch_period_s: float = 0.8):
    if float(gain) <= 0.0:
        return measured_error.copy(), measured_error.copy()
    leader_w, follower_w = dynamic_topology_weight_matrices(
        topology, topology_name="leader_ring", time_s=float(time_s), switch_period_s=float(switch_period_s)
    )
    network = topology_consensus_error(measured_error, leader_w, follower_w)
    mixed = (1.0 - float(gain)) * measured_error + float(gain) * network
    return network, mixed


def simulate_v1000_canonical(config: ExperimentConfig, job: SimulationJob) -> SimulationOutput:
    dt = 0.02
    rng = np.random.default_rng(job.seed)
    topology = build_leader_follower_topology(
        job.uav_count, job.usv_count, topology_name="leader_ring", seed=job.seed
    )
    follower_count = topology.follower_count
    spec = spec_with_gains(
        get_method_spec(job.method),
        position_gain=job.position_gain,
        velocity_gain=job.velocity_gain,
    )
    duration = float(config.simulation["duration_s"])
    times = np.arange(0.0, duration + 0.5 * dt, dt, dtype=float)
    steps = len(times)
    max_control = float(config.simulation.get("max_control", 8.0))
    dynamics = apply_v1000_canonical_point_mass(
        build_agent_dynamics(topology.agent_types, max_control=max_control, uncertainty=0.0, rng=rng)
    )
    scenario = build_scenario_profile(
        job.scenario,
        times,
        follower_count,
        rng,
        actuator_loss_scale=job.actuator_loss_scale,
        fdi_scale=job.fdi_scale,
        dos_duty_scale=job.dos_duty_scale,
        dos_model=job.dos_model,
    )
    offsets = formation_offsets(follower_count, spacing=1.2)
    leader_p0, leader_v0 = leader_reference(0.0)
    desired0 = leader_p0[None, :] + offsets
    positions = desired0 + rng.normal(0.0, 0.42, size=(follower_count, 2))
    velocities = np.tile(leader_v0, (follower_count, 1)) * 0.15
    controller = ModularController(
        spec=spec,
        follower_count=follower_count,
        dimensions=2,
        max_control=max_control,
        performance=PrescribedPerformance(initial_radius=1.6, final_radius=1.0),
    )
    controller_state = ControllerState(
        adaptive_weights=np.zeros((follower_count, controller.basis_size, 2), dtype=float),
        observer_state=np.zeros((follower_count, 2), dtype=float),
        trigger_filter=np.zeros(follower_count, dtype=float),
        sampled_error=(positions - desired0).copy(),
        sampled_velocity_error=(velocities - np.tile(leader_v0, (follower_count, 1))).copy(),
    )
    estimator_config = estimator_config_from_mapping(config.simulation)
    bias_estimator = OnlineBiasEstimator(follower_count, 2, estimator_config)
    efficiency_estimator = OnlineEfficiencyEstimator(follower_count, estimator_config)
    information_mode = str(job.resilience_information_mode)

    tracking_errors = np.zeros((steps, follower_count), dtype=float)
    controls = np.zeros((steps, follower_count, 2), dtype=float)
    actual_controls = np.zeros((steps, follower_count, 2), dtype=float)
    trigger_events = np.zeros((steps, follower_count), dtype=bool)
    constraint_violations = np.zeros((steps, follower_count), dtype=bool)
    physical_position_errors = np.zeros((steps, follower_count, 2), dtype=float)
    sensor_biases = np.zeros((steps, follower_count, 2), dtype=float)
    bias_estimates = np.zeros((steps, follower_count, 2), dtype=float)
    actuator_efficiencies = np.zeros((steps, follower_count), dtype=float)
    actuator_efficiency_estimates = np.ones((steps, follower_count), dtype=float)
    transformed_errors = np.zeros((steps, follower_count, 2), dtype=float)
    held_position_errors = np.zeros((steps, follower_count, 2), dtype=float)
    last_event_time = np.zeros(follower_count, dtype=float)
    topo_gain = 0.65 if job.topology_feedback_gain == 0.0 else float(job.topology_feedback_gain)

    started = perf_counter()
    for step, time_s in enumerate(times):
        leader_p, leader_v = leader_reference(float(time_s))
        desired = leader_p[None, :] + offsets
        velocity_error = velocities - np.tile(leader_v, (follower_count, 1))
        sensor_bias = scenario.sensor_bias[step]
        raw = positions + sensor_bias
        if spec.resilience and information_mode == "oracle":
            bias_hat = sensor_bias.copy()
            eff_hat = scenario.actuator_efficiency[step].copy()
        elif spec.resilience and information_mode == "causal":
            bias_hat = bias_estimator.update(raw - desired, velocity_error, dt)
            eff_hat = efficiency_estimator.efficiency.copy()
        else:
            bias_hat = np.zeros_like(sensor_bias)
            eff_hat = np.ones(follower_count, dtype=float)
        measured = raw - bias_hat
        _, current_error = _topo(measured - desired, topology, topo_gain, float(time_s))
        output = controller.step(
            controller_state,
            ControllerInput(
                time_s=float(time_s),
                dt_s=dt,
                position_error=current_error,
                velocity_error=velocity_error,
                sampled_error=controller_state.sampled_error,
                time_since_event=time_s - last_event_time,
                communication_available=scenario.communication_available[step],
                actuator_efficiency=eff_hat,
                predefined_time_s=job.predefined_time_s,
                constraint_radius=1.0,
                trigger_base_threshold=0.035,
                trigger_max_hold_s=0.55,
                minimum_inter_event_s=float(config.simulation.get("minimum_inter_event_s", 0.0)),
            ),
        )
        event_mask = output.triggered.copy()
        if step == 0:
            event_mask[:] = True
        controller_state = output.next_state
        last_event_time[event_mask] = time_s
        commanded = output.commanded_control
        actual = scenario.actuator_efficiency[step, :, None] * commanded
        true_error = positions - desired
        envelope = controller.performance.bounds(
            time_s=float(time_s), predefined_time_s=job.predefined_time_s, final_radius=1.0
        )
        tracking_errors[step] = np.linalg.norm(true_error, axis=1)
        controls[step] = commanded
        actual_controls[step] = actual
        trigger_events[step] = event_mask
        constraint_violations[step] = tracking_errors[step] > envelope
        physical_position_errors[step] = true_error
        sensor_biases[step] = sensor_bias
        bias_estimates[step] = bias_hat
        actuator_efficiencies[step] = scenario.actuator_efficiency[step]
        actuator_efficiency_estimates[step] = eff_hat
        transformed_errors[step] = output.transformed_error
        held_position_errors[step] = output.control_position_error
        if step == steps - 1:
            break
        previous_velocity = velocities.copy()
        disturbance = deterministic_disturbance(
            float(time_s), follower_count, seed_scale=0.01 * job.seed, disturbance_scale=job.disturbance_scale
        )

        def _deriv(vel: np.ndarray) -> np.ndarray:
            return (actual + disturbance - dynamics.damping[:, None] * vel) / dynamics.mass[:, None]

        k1_a = _deriv(velocities)
        k1_p = velocities
        k2_a = _deriv(velocities + 0.5 * dt * k1_a)
        k2_p = velocities + 0.5 * dt * k1_a
        k3_a = _deriv(velocities + 0.5 * dt * k2_a)
        k3_p = velocities + 0.5 * dt * k2_a
        k4_a = _deriv(velocities + dt * k3_a)
        k4_p = velocities + dt * k3_a
        velocities = velocities + (dt / 6.0) * (k1_a + 2.0 * k2_a + 2.0 * k3_a + k4_a)
        positions = positions + (dt / 6.0) * (k1_p + 2.0 * k2_p + 2.0 * k3_p + k4_p)
        if spec.resilience and information_mode == "causal":
            observed_acceleration = (velocities - previous_velocity) / dt
            efficiency_estimator.update(
                applied_control=commanded,
                observed_acceleration=observed_acceleration,
                mass=dynamics.mass,
                modelled_drag=dynamics.damping[:, None] * previous_velocity,
                dt_s=dt,
            )

    elapsed = perf_counter() - started
    metrics = compute_run_metrics(
        times=times,
        tracking_errors=tracking_errors,
        controls=controls,
        trigger_events=trigger_events,
        constraint_violations=constraint_violations,
        predefined_time_s=job.predefined_time_s,
        error_tolerance=float(config.simulation.get("error_tolerance", 0.08)),
        nominal_integral_error=float(config.simulation.get("nominal_integral_error", 1.0)),
        computation_time_s=elapsed,
        actual_controls=actual_controls,
        sensor_biases=sensor_biases,
        bias_estimates=bias_estimates,
        actuator_efficiencies=actuator_efficiencies,
        actuator_efficiency_estimates=actuator_efficiency_estimates,
    )
    zeros_vec = np.zeros((steps, follower_count), dtype=float)
    zeros_mat = np.zeros((steps, follower_count, 2), dtype=float)
    return SimulationOutput(
        metrics=metrics,
        times=times,
        tracking_errors=tracking_errors,
        controls=controls,
        trigger_events=trigger_events,
        constraint_violations=constraint_violations,
        transformed_errors=transformed_errors,
        normalized_errors=zeros_mat,
        performance_bounds=np.zeros(steps, dtype=float),
        approximations=zeros_mat,
        observer_estimates=zeros_mat,
        trigger_metrics=zeros_vec,
        trigger_thresholds=zeros_vec,
        physical_position_errors=physical_position_errors,
        network_position_errors=physical_position_errors.copy(),
        controller_position_errors=physical_position_errors.copy(),
        held_position_errors=held_position_errors,
        sensor_biases=sensor_biases,
        bias_estimates=bias_estimates,
        actuator_efficiencies=actuator_efficiencies,
        actuator_efficiency_estimates=actuator_efficiency_estimates,
        actual_controls=actual_controls,
    )
