from __future__ import annotations

from dataclasses import dataclass, replace

import numpy as np


@dataclass(frozen=True)
class MethodSpec:
    name: str
    position_gain: float
    velocity_gain: float
    finite_power: float | None
    fixed_power: float | None
    predefined: bool
    event_triggered: bool
    resilience: bool
    constraint_aware: bool
    adaptive_approximation: bool
    disturbance_observer: bool
    fault_tolerant: bool


@dataclass(frozen=True)
class ControllerInput:
    time_s: float
    dt_s: float
    position_error: np.ndarray
    velocity_error: np.ndarray
    sampled_error: np.ndarray
    time_since_event: np.ndarray
    communication_available: np.ndarray
    actuator_efficiency: np.ndarray
    predefined_time_s: float
    constraint_radius: float
    trigger_base_threshold: float
    trigger_max_hold_s: float
    minimum_inter_event_s: float = 0.0


@dataclass(frozen=True)
class ControllerState:
    adaptive_weights: np.ndarray
    observer_state: np.ndarray
    trigger_filter: np.ndarray
    sampled_error: np.ndarray
    sampled_velocity_error: np.ndarray | None = None

    @staticmethod
    def zeros(follower_count: int, dimensions: int, basis_size: int) -> "ControllerState":
        return ControllerState(
            adaptive_weights=np.zeros((follower_count, basis_size, dimensions), dtype=float),
            observer_state=np.zeros((follower_count, dimensions), dtype=float),
            trigger_filter=np.zeros(follower_count, dtype=float),
            sampled_error=np.zeros((follower_count, dimensions), dtype=float),
            sampled_velocity_error=np.zeros((follower_count, dimensions), dtype=float),
        )


@dataclass(frozen=True)
class ControllerOutput:
    commanded_control: np.ndarray
    raw_control: np.ndarray
    transformed_error: np.ndarray
    control_transformed_error: np.ndarray
    control_position_error: np.ndarray
    control_velocity_error: np.ndarray
    normalized_error: np.ndarray
    performance_bound: float
    approximation: np.ndarray
    observer_estimate: np.ndarray
    trigger_metric: np.ndarray
    trigger_threshold: np.ndarray
    triggered: np.ndarray
    next_state: ControllerState


METHOD_SPECS: dict[str, MethodSpec] = {
    "asymptotic_adaptive": MethodSpec(
        name="asymptotic_adaptive",
        position_gain=1.0,
        velocity_gain=1.35,
        finite_power=None,
        fixed_power=None,
        predefined=False,
        event_triggered=False,
        resilience=False,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
    "finite_time_adaptive": MethodSpec(
        name="finite_time_adaptive",
        position_gain=1.45,
        velocity_gain=1.55,
        finite_power=0.65,
        fixed_power=None,
        predefined=False,
        event_triggered=False,
        resilience=False,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
    "fixed_time_adaptive": MethodSpec(
        name="fixed_time_adaptive",
        position_gain=1.75,
        velocity_gain=1.75,
        finite_power=0.65,
        fixed_power=1.35,
        predefined=False,
        event_triggered=False,
        resilience=False,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
    "predefined_time_no_event": MethodSpec(
        name="predefined_time_no_event",
        position_gain=1.9,
        velocity_gain=1.85,
        finite_power=0.65,
        fixed_power=1.35,
        predefined=True,
        event_triggered=False,
        resilience=True,
        constraint_aware=True,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    "predefined_time_no_resilience": MethodSpec(
        name="predefined_time_no_resilience",
        position_gain=1.9,
        velocity_gain=1.85,
        finite_power=0.65,
        fixed_power=1.35,
        predefined=True,
        event_triggered=True,
        resilience=False,
        constraint_aware=True,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
    "event_triggered_fixed_time": MethodSpec(
        name="event_triggered_fixed_time",
        position_gain=1.75,
        velocity_gain=1.75,
        finite_power=0.65,
        fixed_power=1.35,
        predefined=False,
        event_triggered=True,
        resilience=False,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
    "recent_2025_resilient_fixed_time": MethodSpec(
        name="recent_2025_resilient_fixed_time",
        position_gain=1.9,
        velocity_gain=1.9,
        finite_power=0.62,
        fixed_power=1.42,
        predefined=False,
        event_triggered=True,
        resilience=True,
        constraint_aware=True,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    "proposed_full": MethodSpec(
        name="proposed_full",
        position_gain=2.15,
        velocity_gain=2.05,
        finite_power=0.60,
        fixed_power=1.45,
        predefined=True,
        event_triggered=True,
        resilience=True,
        constraint_aware=True,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    "ablation_no_performance": MethodSpec(
        name="ablation_no_performance",
        position_gain=1.45,
        velocity_gain=1.70,
        finite_power=0.65,
        fixed_power=None,
        predefined=True,
        event_triggered=True,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    # Matched-gain PPT ablation for the high-fidelity re-tuning study: identical
    # to proposed_full except the prescribed-performance transform is disabled.
    "proposed_no_ppt": MethodSpec(
        name="proposed_no_ppt",
        position_gain=2.15,
        velocity_gain=2.05,
        finite_power=0.60,
        fixed_power=1.45,
        predefined=True,
        event_triggered=True,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    # One-factor-at-a-time knockouts of proposed_no_ppt at matched gains for the
    # high-fidelity module diagnosis (hifi knockout campaign).
    "hifi_ko_tvg": MethodSpec(
        name="hifi_ko_tvg",
        position_gain=2.15,
        velocity_gain=2.05,
        finite_power=0.60,
        fixed_power=1.45,
        predefined=False,
        event_triggered=True,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    "hifi_ko_powers": MethodSpec(
        name="hifi_ko_powers",
        position_gain=2.15,
        velocity_gain=2.05,
        finite_power=None,
        fixed_power=None,
        predefined=True,
        event_triggered=True,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    "hifi_ko_approximator": MethodSpec(
        name="hifi_ko_approximator",
        position_gain=2.15,
        velocity_gain=2.05,
        finite_power=0.60,
        fixed_power=1.45,
        predefined=True,
        event_triggered=True,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=False,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    "hifi_ko_observer": MethodSpec(
        name="hifi_ko_observer",
        position_gain=2.15,
        velocity_gain=2.05,
        finite_power=0.60,
        fixed_power=1.45,
        predefined=True,
        event_triggered=True,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=True,
    ),
    "hifi_ko_faultcomp": MethodSpec(
        name="hifi_ko_faultcomp",
        position_gain=2.15,
        velocity_gain=2.05,
        finite_power=0.60,
        fixed_power=1.45,
        predefined=True,
        event_triggered=True,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=False,
    ),
    # Lean-stack candidates distilled from the knockout diagnosis.
    "proposed_lean": MethodSpec(
        name="proposed_lean",
        position_gain=2.15,
        velocity_gain=2.05,
        finite_power=None,
        fixed_power=None,
        predefined=False,
        event_triggered=True,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    "proposed_minimal_causal": MethodSpec(
        name="proposed_minimal_causal",
        position_gain=2.15,
        velocity_gain=2.05,
        finite_power=None,
        fixed_power=None,
        predefined=False,
        event_triggered=True,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=False,
        disturbance_observer=False,
        fault_tolerant=True,
    ),
    "ablation_no_approximator": MethodSpec(
        name="ablation_no_approximator",
        position_gain=1.45,
        velocity_gain=1.70,
        finite_power=0.65,
        fixed_power=None,
        predefined=True,
        event_triggered=True,
        resilience=True,
        constraint_aware=True,
        adaptive_approximation=False,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    "ablation_no_fractional": MethodSpec(
        name="ablation_no_fractional",
        position_gain=1.45,
        velocity_gain=1.70,
        finite_power=None,
        fixed_power=None,
        predefined=True,
        event_triggered=True,
        resilience=True,
        constraint_aware=True,
        adaptive_approximation=True,
        disturbance_observer=True,
        fault_tolerant=True,
    ),
    "ablation_no_observer": MethodSpec(
        name="ablation_no_observer",
        position_gain=1.45,
        velocity_gain=1.70,
        finite_power=0.65,
        fixed_power=None,
        predefined=True,
        event_triggered=True,
        resilience=False,
        constraint_aware=True,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
    "ablation_minimal": MethodSpec(
        name="ablation_minimal",
        position_gain=1.45,
        velocity_gain=1.70,
        finite_power=0.65,
        fixed_power=None,
        predefined=True,
        event_triggered=False,
        resilience=False,
        constraint_aware=False,
        adaptive_approximation=False,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
    # True baselines reproduced from published source papers; the control laws
    # live in true_baselines.py and ModularController dispatches to them by
    # name. finite_power/fixed_power carry the fixed-time exponents a1/a2.
    # Provenance and fidelity: Reproduction/true_baseline_requirements.md.
    "ref36_reproduction": MethodSpec(
        name="ref36_reproduction",
        position_gain=1.9,
        velocity_gain=1.9,
        finite_power=0.714,
        fixed_power=1.286,
        predefined=False,
        event_triggered=False,
        resilience=True,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
    "ref72_reproduction": MethodSpec(
        name="ref72_reproduction",
        position_gain=1.9,
        velocity_gain=1.9,
        finite_power=0.714,
        fixed_power=1.286,
        predefined=False,
        event_triggered=True,
        resilience=False,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
    "oa_alternative_baseline": MethodSpec(
        name="oa_alternative_baseline",
        position_gain=2.0,
        velocity_gain=2.2,
        finite_power=None,
        fixed_power=None,
        predefined=False,
        event_triggered=True,
        resilience=False,
        constraint_aware=False,
        adaptive_approximation=True,
        disturbance_observer=False,
        fault_tolerant=False,
    ),
}


class PredefinedTimeSchedule:
    def __init__(self, gain_scale: float = 0.45, boundary_layer: float = 0.35, gain_cap: float = 3.0) -> None:
        self.gain_scale = float(gain_scale)
        self.boundary_layer = float(boundary_layer)
        self.gain_cap = float(gain_cap)

    def gain(self, spec: MethodSpec, time_s: float, predefined_time_s: float) -> float:
        if not spec.predefined:
            return 1.0
        remaining = max(float(predefined_time_s) - float(time_s), 0.0)
        gain = 1.0 + self.gain_scale / (remaining + self.boundary_layer)
        return float(min(self.gain_cap, gain))


class PrescribedPerformance:
    def __init__(
        self,
        initial_radius: float = 1.6,
        final_radius: float = 1.0,
        decay_rate: float = 3.0,
        clip: float = 0.98,
    ) -> None:
        self.initial_radius = float(initial_radius)
        self.final_radius = float(final_radius)
        self.decay_rate = float(decay_rate)
        self.clip = float(clip)

    def bounds(self, time_s: float, predefined_time_s: float, final_radius: float | None = None) -> float:
        target = self.final_radius if final_radius is None else float(final_radius)
        horizon = max(float(predefined_time_s), 1e-9)
        tau = min(max(float(time_s), 0.0), horizon) / horizon
        radius = target + max(self.initial_radius - target, 0.0) * np.exp(-self.decay_rate * tau)
        return float(max(radius, target))

    def normalize(self, error: np.ndarray, bound: float) -> np.ndarray:
        normalized = np.asarray(error, dtype=float) / max(float(bound), 1e-9)
        return np.clip(normalized, -self.clip, self.clip)

    def transform(self, error: np.ndarray, bound: float) -> np.ndarray:
        normalized = self.normalize(error, bound)
        return 0.5 * np.log((1.0 + normalized) / (1.0 - normalized))


class AdaptiveApproximator:
    def __init__(self, adaptation_gain: float = 0.18, leakage: float = 0.02) -> None:
        self.adaptation_gain = float(adaptation_gain)
        self.leakage = float(leakage)

    @property
    def basis_size(self) -> int:
        return 7

    def basis(self, transformed_error: np.ndarray, velocity_error: np.ndarray) -> np.ndarray:
        z = np.asarray(transformed_error, dtype=float)
        v = np.asarray(velocity_error, dtype=float)
        z_norm = np.linalg.norm(z, axis=1)
        v_norm = np.linalg.norm(v, axis=1)
        return np.column_stack(
            [
                np.ones(z.shape[0], dtype=float),
                z[:, 0],
                z[:, 1],
                v[:, 0],
                v[:, 1],
                z_norm,
                v_norm,
            ]
        )

    def estimate(self, weights: np.ndarray, basis: np.ndarray) -> np.ndarray:
        return np.einsum("nbd,nb->nd", weights, basis)

    def update(
        self,
        weights: np.ndarray,
        basis: np.ndarray,
        transformed_error: np.ndarray,
        dt_s: float,
        enabled: bool,
    ) -> np.ndarray:
        if not enabled:
            return weights.copy()
        update = self.adaptation_gain * basis[:, :, None] * transformed_error[:, None, :]
        update -= self.leakage * weights
        return weights + float(dt_s) * update


class DisturbanceAttackObserver:
    """Leaky transformed-error filter (legacy API name).

    This block has no disturbance-estimation error model and its state is not
    claimed to reconstruct a physical disturbance or attack.
    """
    def __init__(self, gain: float = 0.7, leakage: float = 0.25) -> None:
        self.gain = float(gain)
        self.leakage = float(leakage)

    def update(
        self,
        observer_state: np.ndarray,
        transformed_error: np.ndarray,
        dt_s: float,
        enabled: bool,
    ) -> np.ndarray:
        if not enabled:
            return observer_state.copy()
        derivative = self.gain * transformed_error - self.leakage * observer_state
        return observer_state + float(dt_s) * derivative


class DynamicEventTrigger:
    def __init__(self, sigma_1: float = 0.08, filter_decay: float = 1.2, filter_gain: float = 0.015) -> None:
        self.sigma_1 = float(sigma_1)
        self.filter_decay = float(filter_decay)
        self.filter_gain = float(filter_gain)

    def evaluate(
        self,
        spec: MethodSpec,
        transformed_error: np.ndarray,
        transformed_sampled_error: np.ndarray,
        trigger_filter: np.ndarray,
        time_since_event: np.ndarray,
        communication_available: np.ndarray,
        base_threshold: float,
        max_hold_s: float,
        dt_s: float,
        minimum_inter_event_s: float = 0.0,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        metric = np.linalg.norm(transformed_error - transformed_sampled_error, axis=1)
        error_norm = np.linalg.norm(transformed_error, axis=1)
        next_filter = np.maximum(
            0.0,
            trigger_filter
            + float(dt_s)
            * (
                -self.filter_decay * trigger_filter
                + self.filter_gain * error_norm**2
                - 0.5 * self.filter_gain * metric**2
            ),
        )
        threshold = float(base_threshold) + self.sigma_1 * error_norm + next_filter
        if not spec.event_triggered:
            triggered = communication_available.astype(bool)
        else:
            interval_ok = np.asarray(time_since_event, dtype=float) >= max(float(minimum_inter_event_s), 0.0)
            triggered = ((metric >= threshold) | (time_since_event >= max_hold_s)) & communication_available.astype(bool)
            triggered &= interval_ok
        return triggered, metric, threshold, next_filter


class ModularController:
    """Feedback with event-refreshed raw position/velocity error samples.

    The command is recomputed at every detection step. Current PPT bounds,
    adaptation, filters and effectiveness compensation need not be constant
    between refresh events; there is no command zero-order-hold here.
    """
    def __init__(
        self,
        spec: MethodSpec,
        follower_count: int,
        dimensions: int,
        max_control: float,
        performance: PrescribedPerformance | None = None,
        schedule: PredefinedTimeSchedule | None = None,
        approximator: AdaptiveApproximator | None = None,
        observer: DisturbanceAttackObserver | None = None,
        trigger: DynamicEventTrigger | None = None,
    ) -> None:
        if dimensions != 2:
            raise ValueError("The current UAV/USV scaffold expects two-dimensional formation errors.")
        self.spec = spec
        self.follower_count = int(follower_count)
        self.dimensions = int(dimensions)
        self.max_control = float(max_control)
        self.performance = performance or PrescribedPerformance()
        self.schedule = schedule or PredefinedTimeSchedule()
        self.approximator = approximator or AdaptiveApproximator()
        self.observer = observer or DisturbanceAttackObserver()
        self.trigger = trigger or DynamicEventTrigger()
        # True-baseline methods (reproduced from source papers) delegate to
        # dedicated controller classes; every other method keeps the legacy
        # modular path untouched. Lazy import avoids a circular dependency.
        self._delegate = None
        from .true_baselines import TRUE_BASELINE_METHODS

        if spec.name in TRUE_BASELINE_METHODS:
            from .true_baselines import build_true_baseline_controller

            self._delegate = build_true_baseline_controller(
                spec, self.follower_count, self.max_control
            )

    @property
    def basis_size(self) -> int:
        if self._delegate is not None:
            return self._delegate.basis_size
        return self.approximator.basis_size

    def step(self, state: ControllerState, inputs: ControllerInput) -> ControllerOutput:
        if self._delegate is not None:
            return self._delegate.step(state, inputs)
        self._validate_shapes(state, inputs)
        current_position_error = np.asarray(inputs.position_error, dtype=float)
        current_velocity_error = np.asarray(inputs.velocity_error, dtype=float)
        sampled_position_error = np.asarray(state.sampled_error, dtype=float).copy()
        sampled_velocity_error = _sampled_velocity_or_current(state, current_velocity_error)
        bound = self.performance.bounds(
            time_s=inputs.time_s,
            predefined_time_s=inputs.predefined_time_s,
            final_radius=inputs.constraint_radius if self.spec.constraint_aware else None,
        )
        if self.spec.constraint_aware:
            normalized_error = self.performance.normalize(current_position_error, bound)
            transformed_error = self.performance.transform(current_position_error, bound)
            transformed_sampled = self.performance.transform(sampled_position_error, bound)
        else:
            normalized_error = current_position_error / max(bound, 1e-9)
            transformed_error = current_position_error
            transformed_sampled = sampled_position_error

        triggered, trigger_metric, trigger_threshold, next_trigger_filter = self.trigger.evaluate(
            spec=self.spec,
            transformed_error=transformed_error,
            transformed_sampled_error=transformed_sampled,
            trigger_filter=state.trigger_filter,
            time_since_event=inputs.time_since_event,
            communication_available=inputs.communication_available,
            base_threshold=inputs.trigger_base_threshold,
            max_hold_s=inputs.trigger_max_hold_s,
            dt_s=inputs.dt_s,
            minimum_inter_event_s=inputs.minimum_inter_event_s,
        )

        sampled_error = sampled_position_error.copy()
        sampled_error[triggered] = current_position_error[triggered]
        next_sampled_velocity_error = sampled_velocity_error.copy()
        next_sampled_velocity_error[triggered] = current_velocity_error[triggered]

        if self.spec.constraint_aware:
            control_transformed_error = self.performance.transform(sampled_error, bound)
        else:
            control_transformed_error = sampled_error.copy()
        control_position_error = sampled_error.copy()
        control_velocity_error = next_sampled_velocity_error.copy()

        basis = self.approximator.basis(transformed_error, current_velocity_error)
        approximation = (
            self.approximator.estimate(state.adaptive_weights, basis)
            if self.spec.adaptive_approximation
            else np.zeros_like(transformed_error)
        )
        next_weights = self.approximator.update(
            state.adaptive_weights,
            basis,
            transformed_error,
            inputs.dt_s,
            enabled=self.spec.adaptive_approximation,
        )
        next_observer = self.observer.update(
            state.observer_state,
            transformed_error,
            inputs.dt_s,
            enabled=self.spec.disturbance_observer,
        )
        observer_estimate = next_observer if self.spec.disturbance_observer else np.zeros_like(transformed_error)

        gain = self.spec.position_gain * self.schedule.gain(
            self.spec,
            time_s=inputs.time_s,
            predefined_time_s=inputs.predefined_time_s,
        )
        raw_control = -gain * control_transformed_error - self.spec.velocity_gain * control_velocity_error
        if self.spec.finite_power is not None:
            raw_control += -0.6 * _signed_power(control_transformed_error, self.spec.finite_power)
        if self.spec.fixed_power is not None:
            raw_control += -0.25 * _signed_power(control_transformed_error, self.spec.fixed_power)
        raw_control -= approximation
        raw_control -= observer_estimate

        commanded_control = apply_fault_tolerance(
            raw_control,
            actuator_efficiency_estimate=inputs.actuator_efficiency,
            resilience_enabled=self.spec.fault_tolerant,
            max_control=self.max_control,
        )
        return ControllerOutput(
            commanded_control=commanded_control,
            raw_control=raw_control,
            transformed_error=transformed_error,
            control_transformed_error=control_transformed_error,
            control_position_error=control_position_error,
            control_velocity_error=control_velocity_error,
            normalized_error=normalized_error,
            performance_bound=bound,
            approximation=approximation,
            observer_estimate=observer_estimate,
            trigger_metric=trigger_metric,
            trigger_threshold=trigger_threshold,
            triggered=triggered,
            next_state=ControllerState(
                adaptive_weights=next_weights,
                observer_state=next_observer,
                trigger_filter=next_trigger_filter,
                sampled_error=sampled_error,
                sampled_velocity_error=next_sampled_velocity_error,
            ),
        )

    def _validate_shapes(self, state: ControllerState, inputs: ControllerInput) -> None:
        expected_matrix = (self.follower_count, self.dimensions)
        expected_weights = (self.follower_count, self.basis_size, self.dimensions)
        if inputs.position_error.shape != expected_matrix:
            raise ValueError(f"position_error shape must be {expected_matrix}.")
        if inputs.velocity_error.shape != expected_matrix:
            raise ValueError(f"velocity_error shape must be {expected_matrix}.")
        if inputs.sampled_error.shape != expected_matrix:
            raise ValueError(f"sampled_error shape must be {expected_matrix}.")
        if state.sampled_error.shape != expected_matrix:
            raise ValueError(f"state.sampled_error shape must be {expected_matrix}.")
        if state.sampled_velocity_error is not None and state.sampled_velocity_error.shape != expected_matrix:
            raise ValueError(f"state.sampled_velocity_error shape must be {expected_matrix}.")
        if state.observer_state.shape != expected_matrix:
            raise ValueError(f"observer_state shape must be {expected_matrix}.")
        if state.adaptive_weights.shape != expected_weights:
            raise ValueError(f"adaptive_weights shape must be {expected_weights}.")
        if state.trigger_filter.shape != (self.follower_count,):
            raise ValueError(f"trigger_filter shape must be {(self.follower_count,)}.")


def get_method_spec(name: str) -> MethodSpec:
    try:
        return METHOD_SPECS[name]
    except KeyError as exc:
        known = ", ".join(sorted(METHOD_SPECS))
        raise ValueError(f"Unknown method '{name}'. Known methods: {known}") from exc


def spec_with_gains(
    spec: MethodSpec,
    *,
    position_gain: float | None = None,
    velocity_gain: float | None = None,
) -> MethodSpec:
    kwargs = {}
    if position_gain is not None:
        kwargs["position_gain"] = float(position_gain)
    if velocity_gain is not None:
        kwargs["velocity_gain"] = float(velocity_gain)
    return replace(spec, **kwargs) if kwargs else spec


def compute_nominal_control(
    spec: MethodSpec,
    position_error: np.ndarray,
    velocity_error: np.ndarray,
    time_s: float,
    predefined_time_s: float,
    constraint_radius: float,
) -> np.ndarray:
    gain = spec.position_gain * _time_contract_gain(spec, time_s, predefined_time_s)
    error = np.asarray(position_error, dtype=float)
    velocity = np.asarray(velocity_error, dtype=float)

    transformed_error = error.copy()
    if spec.constraint_aware:
        transform = PrescribedPerformance(initial_radius=max(1.6 * constraint_radius, constraint_radius))
        bound = transform.bounds(time_s=time_s, predefined_time_s=predefined_time_s, final_radius=constraint_radius)
        transformed_error = transform.transform(error, bound)

    control = -gain * transformed_error - spec.velocity_gain * velocity
    if spec.finite_power is not None:
        control += -0.6 * _signed_power(transformed_error, spec.finite_power)
    if spec.fixed_power is not None:
        control += -0.25 * _signed_power(transformed_error, spec.fixed_power)
    return control


def event_trigger_mask(
    spec: MethodSpec,
    current_error: np.ndarray,
    sampled_error: np.ndarray,
    time_since_event: np.ndarray,
    communication_available: np.ndarray,
    base_threshold: float,
    max_hold_s: float,
) -> np.ndarray:
    if not spec.event_triggered:
        return communication_available.astype(bool)

    delta = np.linalg.norm(current_error - sampled_error, axis=1)
    error_norm = np.linalg.norm(current_error, axis=1)
    threshold = base_threshold + 0.08 * error_norm
    event = (delta >= threshold) | (time_since_event >= max_hold_s)
    return event & communication_available.astype(bool)


def _sampled_velocity_or_current(state: ControllerState, current_velocity_error: np.ndarray) -> np.ndarray:
    if state.sampled_velocity_error is None:
        return np.asarray(current_velocity_error, dtype=float).copy()
    return np.asarray(state.sampled_velocity_error, dtype=float).copy()


def apply_fault_tolerance(
    control: np.ndarray,
    actuator_efficiency_estimate: np.ndarray,
    resilience_enabled: bool,
    max_control: float,
) -> np.ndarray:
    if resilience_enabled:
        compensated = control / np.maximum(actuator_efficiency_estimate[:, None], 0.35)
    else:
        compensated = control
    norm = np.linalg.norm(compensated, axis=1)
    scale = np.minimum(1.0, max_control / np.maximum(norm, 1e-9))
    return compensated * scale[:, None]


def _time_contract_gain(spec: MethodSpec, time_s: float, predefined_time_s: float) -> float:
    return PredefinedTimeSchedule().gain(spec, time_s=time_s, predefined_time_s=predefined_time_s)


def _signed_power(values: np.ndarray, power: float) -> np.ndarray:
    return np.sign(values) * np.power(np.abs(values) + 1e-9, power)
