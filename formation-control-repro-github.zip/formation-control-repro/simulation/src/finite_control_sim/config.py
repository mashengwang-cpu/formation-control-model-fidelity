from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class FollowerConfig:
    uav: int
    usv: int

    @property
    def total(self) -> int:
        return self.uav + self.usv


@dataclass(frozen=True)
class ExperimentConfig:
    name: str
    followers: FollowerConfig
    predefined_times_s: list[float]
    supplement_predefined_times_s: list[float]
    seeds: list[int]
    methods: list[str]
    scenarios: list[str]
    scalability_agents: list[int]
    simulation: dict[str, Any]
    statistics: dict[str, Any]


def load_config(path: str | Path) -> ExperimentConfig:
    config_path = Path(path)
    with config_path.open("r", encoding="utf-8") as handle:
        raw = json.load(handle)
    return parse_config(raw, source=config_path)


def parse_config(raw: dict[str, Any], source: Path | None = None) -> ExperimentConfig:
    required = {
        "name",
        "followers",
        "predefined_times_s",
        "supplement_predefined_times_s",
        "seeds",
        "methods",
        "scenarios",
        "scalability_agents",
        "simulation",
        "statistics",
    }
    missing = sorted(required - raw.keys())
    if missing:
        where = f" in {source}" if source else ""
        raise ValueError(f"Missing config keys{where}: {', '.join(missing)}")

    followers_raw = raw["followers"]
    followers = FollowerConfig(
        uav=_positive_int(followers_raw.get("uav"), "followers.uav"),
        usv=_positive_int(followers_raw.get("usv"), "followers.usv"),
    )

    config = ExperimentConfig(
        name=str(raw["name"]),
        followers=followers,
        predefined_times_s=_float_list(raw["predefined_times_s"], "predefined_times_s"),
        supplement_predefined_times_s=_float_list(
            raw["supplement_predefined_times_s"], "supplement_predefined_times_s"
        ),
        seeds=_int_list(raw["seeds"], "seeds"),
        methods=_str_list(raw["methods"], "methods"),
        scenarios=_str_list(raw["scenarios"], "scenarios"),
        scalability_agents=_int_list(raw["scalability_agents"], "scalability_agents"),
        simulation=dict(raw["simulation"]),
        statistics=dict(raw["statistics"]),
    )
    _validate_config(config)
    return config


def _validate_config(config: ExperimentConfig) -> None:
    if config.followers.total < 1:
        raise ValueError("At least one follower is required.")
    if not config.methods:
        raise ValueError("At least one control method is required.")
    if not config.scenarios:
        raise ValueError("At least one scenario is required.")
    if not config.predefined_times_s:
        raise ValueError("At least one predefined time is required.")
    dt = float(config.simulation.get("dt_s", 0.0))
    duration = float(config.simulation.get("duration_s", 0.0))
    if dt <= 0.0:
        raise ValueError("simulation.dt_s must be positive.")
    if duration <= 0.0:
        raise ValueError("simulation.duration_s must be positive.")
    if duration <= max(config.predefined_times_s):
        raise ValueError("simulation.duration_s must exceed the largest main predefined time.")


def _positive_int(value: Any, key: str) -> int:
    number = int(value)
    if number < 0:
        raise ValueError(f"{key} must be non-negative.")
    return number


def _int_list(value: Any, key: str) -> list[int]:
    if not isinstance(value, list) or not value:
        raise ValueError(f"{key} must be a non-empty list.")
    return [int(item) for item in value]


def _float_list(value: Any, key: str) -> list[float]:
    if not isinstance(value, list) or not value:
        raise ValueError(f"{key} must be a non-empty list.")
    result = [float(item) for item in value]
    if any(item <= 0.0 for item in result):
        raise ValueError(f"{key} values must be positive.")
    return result


def _str_list(value: Any, key: str) -> list[str]:
    if not isinstance(value, list) or not value:
        raise ValueError(f"{key} must be a non-empty list.")
    result = [str(item) for item in value]
    if any(not item for item in result):
        raise ValueError(f"{key} contains an empty value.")
    return result
