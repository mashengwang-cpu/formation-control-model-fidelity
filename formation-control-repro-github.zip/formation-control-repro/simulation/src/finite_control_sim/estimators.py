from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class OnlineEstimatorConfig:
    bias_gain: float = 0.10
    bias_bandwidth_s_inv: float | None = None
    bias_decay: float = 0.35
    bias_limit: float = 0.40
    efficiency_gain: float = 4.00
    efficiency_decay: float = 0.05
    efficiency_min: float = 0.30
    efficiency_max: float = 1.05
    efficiency_obs_limit: float = 1.50
    efficiency_alignment_min: float = 0.0
    min_command_norm: float = 5e-3


def estimator_config_from_mapping(values: dict[str, Any]) -> OnlineEstimatorConfig:
    return OnlineEstimatorConfig(
        bias_gain=float(values.get("resilience_bias_gain", OnlineEstimatorConfig.bias_gain)),
        bias_bandwidth_s_inv=(
            float(values["resilience_bias_bandwidth_s_inv"])
            if "resilience_bias_bandwidth_s_inv" in values
            else None
        ),
        bias_decay=float(values.get("resilience_bias_decay", OnlineEstimatorConfig.bias_decay)),
        bias_limit=float(values.get("resilience_bias_limit", OnlineEstimatorConfig.bias_limit)),
        efficiency_gain=float(values.get("resilience_efficiency_gain", OnlineEstimatorConfig.efficiency_gain)),
        efficiency_decay=float(values.get("resilience_efficiency_decay", OnlineEstimatorConfig.efficiency_decay)),
        efficiency_min=float(values.get("resilience_efficiency_min", OnlineEstimatorConfig.efficiency_min)),
        efficiency_max=float(values.get("resilience_efficiency_max", OnlineEstimatorConfig.efficiency_max)),
        efficiency_obs_limit=float(
            values.get("resilience_efficiency_obs_limit", OnlineEstimatorConfig.efficiency_obs_limit)
        ),
        efficiency_alignment_min=float(
            values.get("resilience_efficiency_alignment_min", OnlineEstimatorConfig.efficiency_alignment_min)
        ),
        min_command_norm=float(values.get("resilience_min_command_norm", OnlineEstimatorConfig.min_command_norm)),
    )


class OnlineBiasEstimator:
    """Bias estimator using a velocity-propagated error reference.

    Identifiability assumes an initially unbiased position reference and a
    trusted velocity channel. Integration error and velocity bias can accumulate;
    this state is not guaranteed to equal the true unbiased error.

    The state prediction is intentionally not reset to ``measurement-bias_hat``.
    Resetting it creates positive feedback: the prior bias estimate re-enters
    the next innovation and can grow even when the true bias is zero.
    """

    def __init__(self, follower_count: int, dimensions: int, config: OnlineEstimatorConfig | None = None) -> None:
        self.config = config or OnlineEstimatorConfig()
        self.bias = np.zeros((int(follower_count), int(dimensions)), dtype=float)
        self.predicted_unbiased_error: np.ndarray | None = None

    def update(self, measured_error: np.ndarray, velocity_error: np.ndarray, dt_s: float) -> np.ndarray:
        measured = np.asarray(measured_error, dtype=float)
        velocity = np.asarray(velocity_error, dtype=float)
        if self.predicted_unbiased_error is None:
            self.predicted_unbiased_error = measured.copy()
            return self.bias.copy()

        predicted_error = self.predicted_unbiased_error + float(dt_s) * velocity
        innovation = measured - predicted_error
        if self.config.bias_bandwidth_s_inv is None:
            gain = float(np.clip(self.config.bias_gain, 0.0, 1.0))
        else:
            bandwidth = max(float(self.config.bias_bandwidth_s_inv), 0.0)
            gain = 1.0 - float(np.exp(-bandwidth * float(dt_s)))
        leakage = max(0.0, self.config.bias_decay * float(dt_s))
        self.bias = self.bias + gain * (innovation - self.bias) - leakage * self.bias
        self.bias = np.clip(self.bias, -self.config.bias_limit, self.config.bias_limit)
        self.predicted_unbiased_error = predicted_error
        return self.bias.copy()


class OnlineEfficiencyEstimator:
    """Causal actuator-effectiveness identifier from commanded input and observed acceleration.

    Update law (learn-when-excited, forget-otherwise):

    - With persistent excitation (command energy above ``min_command_norm``), the
      estimate low-pass tracks the clipped instantaneous projection estimate at
      bandwidth ``efficiency_gain`` (1/s). No prior pull is applied while excited,
      so, for a constant accepted projection, that projection is the tracking
      equilibrium. The projection need not equal true actuator effectiveness:
      disturbances, model mismatch, clipping and gate selection can bias it.
    - Without excitation the estimate drifts toward the healthy prior 1.0 at the
      slow rate ``efficiency_decay`` (1/s).
    - Alignment gate: when ``efficiency_alignment_min`` > 0, samples whose
      measured net force is directionally inconsistent with the applied command
      (cosine below the threshold) are rejected and the estimate is held. This
      rejects directionally inconsistent samples, which can arise from sway
      dynamics or attitude transients. It neither identifies their cause nor
      removes force disturbances aligned with the command. The gate uses only
      the agent's own command and measured acceleration.
    - Boundedness is guaranteed by projection onto
      [``efficiency_min``, ``efficiency_max``] regardless of the input sequence;
      the instantaneous projection observation is additionally clipped to
      [0, ``efficiency_obs_limit``] to reject near-singular-denominator spikes.
    """

    def __init__(self, follower_count: int, config: OnlineEstimatorConfig | None = None) -> None:
        self.config = config or OnlineEstimatorConfig()
        self.efficiency = np.ones(int(follower_count), dtype=float)

    def update(
        self,
        *,
        applied_control: np.ndarray,
        observed_acceleration: np.ndarray,
        mass: np.ndarray,
        modelled_drag: np.ndarray,
        dt_s: float,
    ) -> np.ndarray:
        applied = np.asarray(applied_control, dtype=float)
        acceleration = np.asarray(observed_acceleration, dtype=float)
        mass = np.asarray(mass, dtype=float)
        drag = np.asarray(modelled_drag, dtype=float)

        # M*a + modelled_drag = rho*u_applied + unmodelled disturbance.
        # No true disturbance trace is supplied to this causal estimate.
        net_force = acceleration * mass[:, None] + drag
        denominator = np.sum(applied**2, axis=1)
        observed = np.sum(net_force * applied, axis=1) / np.maximum(denominator, self.config.min_command_norm)
        observed = np.clip(observed, 0.0, self.config.efficiency_obs_limit)
        excited = denominator > self.config.min_command_norm
        if self.config.efficiency_alignment_min > 0.0:
            force_norm = np.linalg.norm(net_force, axis=1)
            applied_norm = np.linalg.norm(applied, axis=1)
            alignment = np.sum(net_force * applied, axis=1) / np.maximum(force_norm * applied_norm, 1e-12)
            aligned = alignment >= self.config.efficiency_alignment_min
        else:
            aligned = np.ones_like(excited, dtype=bool)
        alpha = np.clip(self.config.efficiency_gain * float(dt_s), 0.0, 1.0)
        recovery = np.clip(self.config.efficiency_decay * float(dt_s), 0.0, 1.0)
        tracked = self.efficiency + alpha * (observed - self.efficiency)
        relaxed = self.efficiency + recovery * (1.0 - self.efficiency)
        # Excited and aligned: learn. Not excited: drift to the healthy prior.
        # Excited but misaligned: hold (the sample is structurally corrupted).
        self.efficiency = np.where(
            excited & aligned, tracked, np.where(excited, self.efficiency, relaxed)
        )
        self.efficiency = np.clip(self.efficiency, self.config.efficiency_min, self.config.efficiency_max)
        return self.efficiency.copy()


def torch_bias_estimator_step(
    torch,
    bias_hat,
    predicted_unbiased_error,
    measured_error,
    velocity_error,
    *,
    dt_s: float,
    config: OnlineEstimatorConfig,
):
    predicted_error = predicted_unbiased_error + float(dt_s) * velocity_error
    innovation = measured_error - predicted_error
    if config.bias_bandwidth_s_inv is None:
        gain = min(max(config.bias_gain, 0.0), 1.0)
    else:
        bandwidth = max(float(config.bias_bandwidth_s_inv), 0.0)
        gain = 1.0 - float(np.exp(-bandwidth * float(dt_s)))
    leakage = max(0.0, config.bias_decay * float(dt_s))
    next_bias = bias_hat + gain * (innovation - bias_hat) - leakage * bias_hat
    next_bias = torch.clamp(next_bias, min=-config.bias_limit, max=config.bias_limit)
    return next_bias, predicted_error


def torch_efficiency_estimator_step(
    torch,
    efficiency_hat,
    *,
    applied_control,
    observed_acceleration,
    mass,
    modelled_drag,
    dt_s: float,
    config: OnlineEstimatorConfig,
):
    net_force = observed_acceleration * mass[:, :, None] + modelled_drag
    denominator = torch.sum(applied_control**2, dim=2)
    observed = torch.sum(net_force * applied_control, dim=2) / torch.clamp(
        denominator,
        min=config.min_command_norm,
    )
    observed = torch.clamp(observed, min=0.0, max=config.efficiency_obs_limit)
    excited = denominator > config.min_command_norm
    if config.efficiency_alignment_min > 0.0:
        force_norm = torch.linalg.vector_norm(net_force, dim=2)
        applied_norm = torch.linalg.vector_norm(applied_control, dim=2)
        alignment = torch.sum(net_force * applied_control, dim=2) / torch.clamp(
            force_norm * applied_norm, min=1e-12
        )
        aligned = alignment >= config.efficiency_alignment_min
    else:
        aligned = torch.ones_like(excited)
    alpha = min(max(config.efficiency_gain * float(dt_s), 0.0), 1.0)
    recovery = min(max(config.efficiency_decay * float(dt_s), 0.0), 1.0)
    tracked = efficiency_hat + alpha * (observed - efficiency_hat)
    relaxed = efficiency_hat + recovery * (1.0 - efficiency_hat)
    next_efficiency = torch.where(
        excited & aligned, tracked, torch.where(excited, efficiency_hat, relaxed)
    )
    return torch.clamp(next_efficiency, min=config.efficiency_min, max=config.efficiency_max)
