"""Prospective design for the corrected, matched-model experiments."""
from __future__ import annotations

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from finite_control_sim.simulator import SimulationJob

SCENARIOS = ["nominal", "actuator_fault", "fdi_attack", "dos_attack", "combined_attack_fault"]
PLANTS = ["matched_point_mass", "matched_lagged", "mixed_6dof_3dof"]
ARMS = {
    "full_no_ppt": "proposed_no_ppt",
    "minimal": "proposed_minimal_causal",
    "family": "recent_2025_resilient_fixed_time",
    "ko_tvg": "hifi_ko_tvg",
    "ko_powers": "hifi_ko_powers",
    "ko_approximator": "hifi_ko_approximator",
    "ko_observer": "hifi_ko_observer",
    "ko_faultcomp": "hifi_ko_faultcomp",
    "ko_topology": "proposed_no_ppt",
    "ppt_added": "proposed_full",
}
CORE = ["full_no_ppt", "minimal", "family"]
MODULES = {"ko_tvg": "tvg", "ko_powers": "powers", "ko_approximator": "approximator",
           "ko_observer": "observer", "ko_faultcomp": "faultcomp", "ko_topology": "topology",
           "ppt_added": "ppt"}
ESTIMATOR = {"resilience_efficiency_gain": 0.25, "resilience_efficiency_alignment_min": 0.8,
             "resilience_efficiency_decay": 0.05, "integrator": "semi_implicit_euler", "state_dtype": "float64",
             "numeric_backend": "numpy"}


def digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def build_design(profile: str = "main") -> list[dict]:
    rows: list[dict] = []

    def add(campaign, arms, plants, seeds, scenarios=SCENARIOS, condition="baseline",
            overrides=None, simulation=None, reference="family", **job_extra):
        for plant in plants:
            for arm in arms:
                for scenario in scenarios:
                    for seed in seeds:
                        values = dict(method=ARMS[arm], scenario=scenario, seed=seed,
                                      predefined_time_s=5.0, uav_count=4, usv_count=4,
                                      topology_name="leader_ring", topology_feedback_gain=0.35,
                                      topology_switch_period_s=0.8, resilience_information_mode="causal",
                                      integrator="semi_implicit_euler", event_hold=True, plant_model=plant,
                                      position_gain=2.15, velocity_gain=2.05, matched_drag=True,
                                      inner_dt_s=0.00125, usv_inner_dt_s=0.00125,
                                      uav_command_lag_s=0.08 if plant == "matched_lagged" else 0.0,
                                      usv_command_lag_s=0.24 if plant == "matched_lagged" else 0.0)
                        values.update(job_extra)
                        if arm == "ko_topology":
                            values["topology_feedback_gain"] = 0.0
                        if overrides:
                            values.update(overrides)
                        job = asdict(SimulationJob(**values))
                        sim = {**ESTIMATOR, **(simulation or {})}
                        job_id = digest({"job": job, "simulation": sim})[:24]
                        design = dict(campaign=campaign, arm_id=arm, reference_arm_id=reference,
                                      reference_method=ARMS[reference], module=MODULES.get(arm, "none"),
                                      condition=condition, replicate_split="test", job_id=job_id,
                                      job=job, simulation_overrides=sim)
                        design["design_id"] = digest(design)[:24]
                        rows.append(design)

    if profile == "numerical":
        for dt in (0.005, 0.0025, 0.00125):
            add("numerical_resolution", CORE, [PLANTS[-1]], range(900, 903),
                ["nominal", "combined_attack_fault"], condition=f"inner_dt_{dt:g}",
                inner_dt_s=dt, usv_inner_dt_s=dt)
        return rows

    seeds = range(1000, 1020)
    add("core_fixed", CORE, PLANTS, seeds)
    add("module_ablation", ["full_no_ppt", *MODULES], PLANTS, seeds, reference="full_no_ppt")
    for scale in (0.5, 1.0, 2.0):
        add("attitude_intervention", ["full_no_ppt", "minimal", "ko_tvg", "ko_powers",
                                      "ko_approximator", "ko_observer"], [PLANTS[-1]], seeds,
            ["nominal", "combined_attack_fault"], condition=f"bandwidth_{scale:g}",
            reference="minimal", usv_count=0, uav_attitude_bandwidth_scale=scale, inner_dt_s=0.00125)
    for kp, kv in ((1.6, 1.55), (1.9, 1.9), (2.15, 2.05), (2.4, 2.3)):
        add("gain_sensitivity", CORE, [PLANTS[-1]], seeds, condition=f"gains_{kp:g}_{kv:g}",
            position_gain=kp, velocity_gain=kv)
    for threshold in (0.015, 0.035, 0.07, 0.14):
        sim = {} if threshold == 0.035 else {"event_trigger_threshold": threshold}
        add("refresh_tradeoff", CORE, [PLANTS[-1]], seeds, condition=f"threshold_{threshold:g}", simulation=sim)
    for condition, extra in (("baseline", {}), ("native_drag", {"matched_drag": False}),
                             ("disturbance_1.5", {"disturbance_scale": 1.5}),
                             ("uncertainty_0.15", {"dynamics_uncertainty": 0.15})):
        add("robustness", CORE, [PLANTS[-1]], range(2000, 2020), condition=condition, overrides=extra)
    for info in ("causal", "oracle", "oracle_efficiency", "oracle_bias"):
        add("information_contract", CORE, [PLANTS[-1]], seeds, condition=info,
            resilience_information_mode=info)
    if len({r["design_id"] for r in rows}) != len(rows):
        raise ValueError("Duplicate design rows")
    return rows


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--profile", choices=["main", "numerical"], default="main")
    args = parser.parse_args()
    rows = build_design(args.profile)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise FileExistsError("Do not overwrite a frozen design")
    args.output.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(json.dumps({"design_rows": len(rows), "unique_jobs": len({r['job_id'] for r in rows}),
                      "design_sha256": digest(rows)}))
