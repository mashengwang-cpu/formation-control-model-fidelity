"""Original source-bound vector diagrams for the implemented control contract."""
import numpy as np
import pandas as pd
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon
from publication_style import *

GUIDE='#D7DEE3'
MUTED='#56616B'
PALE='#F5F7F8'


def box(ax,x,y,w,h,text,color=GUIDE,fill='white',size=8.8):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.003,rounding_size=0.008',ec=color,fc=fill,lw=.8,clip_on=False))
    ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,linespacing=1.2,color=INK)


def arrow(ax,start,end,color=MUTED,style='-|>',lw=.85):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle=style,mutation_scale=7.5,lw=lw,color=color,shrinkA=0,shrinkB=0))


def route(ax,points,color=MUTED,lw=.8):
    p=np.asarray(points)
    ax.plot(p[:-1,0],p[:-1,1],color=color,lw=lw,solid_capstyle='round')
    arrow(ax,p[-2],p[-1],color=color,lw=lw)


def schematic_panel(ax,letter,title):
    ax.text(0,1.05,letter,transform=ax.transAxes,fontsize=12,fontweight='bold',va='bottom')
    ax.text(.045,1.05,title,transform=ax.transAxes,fontsize=10.5,fontweight='bold',va='bottom')


def plain_axis(fig,bounds):
    ax=fig.add_axes(bounds);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
    return ax


def protocol(out):
    source=DATA/'figure_sources/rev_fig1_protocol__topology_edges.csv'
    models_source=DATA/'figure_sources/rev_fig1_protocol__models.csv'
    edges=pd.read_csv(source);models=pd.read_csv(models_source)
    assert set(models.plant_model)==set(PLANTS)
    assert set(edges.source).union(edges.target)==set(range(9))
    fig=plt.figure(figsize=(180*MM,166*MM))
    graph=fig.add_axes([.04,.687,.272,.242]);graph.set_aspect('equal')
    graph.set_xlim(-1.37,1.37);graph.set_ylim(-1.25,1.28);graph.axis('off')
    graph.text(-1.37,1.60,'a',fontsize=12,fontweight='bold')
    graph.text(-1.13,1.60,'Leader-pinned ring',fontsize=10.5,fontweight='bold')
    angles=np.linspace(np.pi/2,np.pi/2-2*np.pi,8,endpoint=False)
    pos={0:np.zeros(2),**{i+1:np.array([np.cos(t),np.sin(t)]) for i,t in enumerate(angles)}}
    for _,e in edges.iterrows():
        u,v=int(e.source),int(e.target)
        if u==0:arrow(graph,pos[v]*.18,pos[v]*.81,color='#B9C2CA',lw=.65)
        elif u<v:
            direction=(pos[v]-pos[u])/np.linalg.norm(pos[v]-pos[u])
            arrow(graph,pos[u]+.19*direction,pos[v]-.19*direction,color=MUTED,style='<->',lw=.8 if e.weight==.35 else 1.15)
    for i in range(1,9):
        graph.scatter(*pos[i],s=226,marker='o' if i<=4 else 's',facecolor='white',edgecolor=INK,linewidth=.85,zorder=4)
        graph.text(*pos[i],f'U{i}' if i<=4 else f'S{i-4}',ha='center',va='center',fontsize=8.5,zorder=5)
    graph.scatter(0,0,s=235,facecolor=PALE,edgecolor=INK,linewidth=.85,zorder=4)
    graph.text(0,0,'L',ha='center',va='center',fontsize=9,fontweight='bold',zorder=5)
    graph.text(0,-1.37,'Pinning: 1.0  ·  Ring: 0.35',ha='center',fontsize=8.5)
    graph.text(0,-1.66,'U1–S4 closing edge: 0.20',ha='center',fontsize=8.5)

    laws=plain_axis(fig,[.365,.646,.60,.295])
    schematic_panel(laws,'b','Three laws at common numerical gains')
    cols=[.515,.705,.905]
    for x,(arm,label) in zip(cols,[('minimal','Minimal'),('family','Family'),('full_no_ppt','Full\n(PPT off)')]):
        laws.plot([x-.064,x+.064],[.965,.965],color=COLOR[arm],lw=2.4)
        laws.text(x,.865,label,ha='center',va='center',fontsize=9,fontweight='bold',linespacing=1.05)
    rows=[('Position shaping',['Raw','PPT','Raw']),('Gain schedule',['Off','Off','On']),
          ('Signed powers',['Off','0.62 / 1.42','0.60 / 1.45']),('Approximation + filter',['Off','On','On'])]
    for j,(name,values) in enumerate(rows):
        y=.67-j*.151
        if j%2==0:laws.add_patch(Polygon([[0,y-.073],[1,y-.073],[1,y+.073],[0,y+.073]],closed=True,fc=PALE,ec='none',zorder=0))
        laws.text(.012,y,name,va='center',fontsize=8.7)
        for x,value in zip(cols,values):laws.text(x,y,value,ha='center',va='center',fontsize=8.7)
    laws.text(.012,.03,'Shared: sampled PD + effectiveness compensation',fontsize=8.5)

    chain=plain_axis(fig,[.04,.296,.92,.287])
    schematic_panel(chain,'c','Implemented signal path and timing')
    entries=[(.00,.17,'Bias correction\n+ topology\nmixing\nγ = 0.35'),(.23,.18,'Hold raw\nposition and\nvelocity errors'),
             (.47,.18,'Feedback\n(panel b)\nPPT: current\nradius'),(.705,.17,'Effectiveness\ncompensation\n+ 8 N norm limit'),(.91,.09,'Plant\n(panel d)')]
    for x,w,label in entries:box(chain,x,.36,w,.32,label,fill=PALE if x==.23 else 'white',size=8.5)
    for x1,x2 in [(.17,.23),(.41,.47),(.65,.705),(.876,.91)]:arrow(chain,(x1,.52),(x2,.52))
    chain.text(.898,.69,'$u^{\\mathrm{cmd}}$',ha='center',fontsize=9)
    box(chain,.225,.815,.44,.15,'Current-radius transform → event test + gate',size=8.5)
    # Both current and retained raw errors use the current PPT radius in the detector.
    route(chain,[(.193,.52),(.193,.89),(.225,.89)])
    chain.plot(.193,.52,'o',ms=2.7,color=MUTED)
    route(chain,[(.383,.68),(.383,.746),(.535,.746),(.535,.815)])
    arrow(chain,(.275,.815),(.275,.68))
    chain.text(.259,.747,'refresh',ha='right',va='center',fontsize=8.5)
    chain.text(.555,.738,'PPT enabled: transform both errors',ha='left',fontsize=8.5)
    # Active approximation and leaky-filter states use current errors between events.
    route(chain,[(.193,.52),(.193,.235),(.56,.235),(.56,.36)])
    chain.text(.374,.14,'Current errors → active approximation / filter',ha='center',fontsize=8.5)
    chain.text(.789,.17,'Command recomputed\nevery 20 ms',ha='center',fontsize=8.7,linespacing=1.15)
    route(chain,[(.965,.36),(.965,.028),(.078,.028),(.078,.36)])
    chain.text(.525,-.062,'Simulated measurements: position + velocity; current neighbor errors supplied centrally',ha='center',fontsize=8.5)

    models_ax=plain_axis(fig,[.04,.03,.92,.195])
    schematic_panel(models_ax,'d','Three matched force realizations')
    for x,w in zip([0,.292,.609],[.266,.291,.394]):
        models_ax.add_patch(FancyBboxPatch((x,.11),w,.865,boxstyle='round,pad=0.003,rounding_size=0.012',ec=GUIDE,fc='white',lw=.8,clip_on=False))
    models_ax.text(.016,.845,'Point mass',fontsize=9.5,fontweight='bold')
    models_ax.text(.016,.645,'Direct world-frame force',fontsize=8.5)
    models_ax.text(.133,.385,'$f^{a}=\\rho u^{\\mathrm{cmd}}$',ha='center',fontsize=11)
    models_ax.text(.133,.17,'Fully actuated in the plane',ha='center',fontsize=8.5)
    models_ax.text(.308,.845,'Command lag',fontsize=9.5,fontweight='bold')
    models_ax.text(.308,.645,'First-order force response',fontsize=8.5)
    models_ax.text(.308,.42,'UAV: 0.08 s   USV: 0.24 s',fontsize=8.5)
    models_ax.text(.437,.17,'Fully actuated in the plane',ha='center',fontsize=8.5)
    models_ax.text(.625,.845,'Rigid body',fontsize=9.5,fontweight='bold')
    models_ax.text(.625,.64,'UAV',fontsize=8.7,fontweight='bold')
    arrow(models_ax,(.692,.67),(.722,.67));models_ax.text(.733,.64,'Thrust + attitude / rotors',fontsize=8.5)
    models_ax.text(.625,.395,'USV',fontsize=8.7,fontweight='bold')
    arrow(models_ax,(.692,.425),(.722,.425));models_ax.text(.733,.395,'Surge + yaw actuation',fontsize=8.5)
    models_ax.text(.806,.17,'Sway has no direct actuator input',ha='center',fontsize=8.5)
    models_ax.text(.5,-.105,'Matched initial states, force disturbances and horizontal drag  ·  Physical step: 1.25 ms',ha='center',fontsize=8.5)
    return save(fig,'Figure_1',out,[source,models_source],
        CAPTIONS['Figure_1'])


def graphical_abstract(out):
    means=select(table('method_means'),campaign='core_fixed',metric='formation_tracking_error',condition='baseline')
    species_source=DATA/'envelope/core_species_means.csv';species=pd.read_csv(species_source)
    assert len(means)==9 and set(means.n_seeds)=={20}
    assert len(select(species,plant_model='mixed_6dof_3dof'))==6
    fig=plt.figure(figsize=(180*MM,100*MM))
    fig.text(.04,.934,'Actuation dynamics change controller rankings',fontsize=12,fontweight='bold')
    fig.text(.04,.865,'Matched native simulations  ·  4 UAVs + 4 USVs  ·  20 seeds × 5 scenarios',fontsize=9.2)
    total=fig.add_axes([.105,.325,.395,.415]);decorate(total)
    total.set_title('Mixed-team tracking',loc='left',fontsize=10,fontweight='bold',pad=13)
    for arm in ARMS:
        rows=select(means,arm_id=arm).set_index('plant_model').loc[PLANTS]
        total.plot(range(3),rows['mean'],color=COLOR[arm],ls=LINESTYLE[arm],lw=1.25)
        mean_ci(total,range(3),rows,arm)
    total.set_xticks(range(3),['Point','Lag','Rigid']);total.set_xlim(-.15,2.16)
    total.set_ylim(.045,2.5);log_axis(total)
    total.set_yticks([.05,.1,.5,1,2],['0.05','0.1','0.5','1','2'])
    total.set_ylabel('Tracking error, $J$ (m)',labelpad=6)
    component=fig.add_axes([.66,.325,.305,.415]);decorate(component,grid='x')
    component.set_title('Rigid-body decomposition',loc='left',fontsize=10,fontweight='bold',pad=13)
    for j,arm in enumerate(ARMS):
        rows=select(species,plant_model='mixed_6dof_3dof',arm_id=arm).set_index('species').loc[['uav','usv']]
        mean_ci(component,[1,0],rows,arm,horizontal=True,offset=(j-1)*.19)
    component.set_yticks([1,0],['UAVs','USVs']);component.set_ylim(-.48,1.47)
    component.set_xlim(.09,4);log_axis(component,'x')
    component.set_xticks([.1,.3,1,3],['0.1','0.3','1','3'])
    component.set_xlabel('Species tracking error (m)',labelpad=6)
    component.spines['left'].set_visible(False);component.tick_params(axis='y',length=0,pad=7)
    component.axhline(.5,color=GUIDE,lw=.65)
    handles=[Line2D([],[],marker=MARKER[arm],color=COLOR[arm],ls=LINESTYLE[arm],lw=1.2,ms=4.2,label=LABEL[arm]) for arm in ARMS]
    fig.legend(handles=handles,loc='center',bbox_to_anchor=(.525,.166),ncol=3,handlelength=1.5,columnspacing=1.65,handletextpad=.55)
    fig.text(.5,.075,'The rigid-body aggregate advantage of Minimal is carried by the USVs.',ha='center',fontsize=9.4)
    fig.text(.5,.027,'Means and pointwise 95% BCa intervals across seeds; each seed averages five scenarios.',ha='center',fontsize=8.5,color=MUTED)
    return save(fig,'Graphical_abstract',out,[STATS/'method_means.csv',species_source],
        CAPTIONS['Graphical_abstract'],panels=False)
