"""Reading-layout contracts for independent publication panels.

These notes describe the frozen experimental units; they never calculate or
modify an endpoint. Every panel uses a 180 mm canvas instead of a raster crop.
"""

COMMON='Means and pointwise 95% BCa intervals; 20 seed blocks; 20,000 bootstrap resamples.'
NARROW='Very narrow intervals retain their true extent and may appear as a single cap.'


def panel_contract(name,index):
    letter=chr(97+index)
    notes={
      'Figure_1':[
        ['One leader, four UAVs and four USVs; directed leader pinning and bidirectional ring links.',
         'Weights come from the frozen topology table; node positions are schematic.'],
        ['Three implemented laws at common numerical gains; Full has PPT disabled.',
         'The family comparator uses PPT with its stated signed-power exponents.'],
        ['Held quantities: raw position and velocity errors. Commands are recomputed every 20 ms.',
         'Current errors drive active approximation/filter states between refresh events.',
         'This is a centralized simulation interface, not a measured packet-communication protocol.'],
        ['Matched initial conditions, horizontal drag and force disturbances; physical step: 1.25 ms.',
         'Rigid-body UAVs use thrust/attitude/rotors; USVs have surge and yaw actuation, not direct sway.']],
      'Figure_2':[
        ['20 paired seed blocks per method and model; each block equally averages five scenarios.',
         'Small symbols: all seed blocks, offset left of summaries. Large symbols / lines: means.',
         'Bars: pointwise 95% BCa intervals; 20,000 seed-block resamples. Logarithmic y-axis.',NARROW],
        [COMMON,'Rigid-body model; UAV and USV errors are averaged separately within each seed block.',
         'Five scenarios per block; species-level planar tracking error. Logarithmic x-axis.',NARROW],
        [COMMON,'Each seed block equally averages five scenarios; small symbols show all 20 block values.',
         'Effort is the time integral of squared commanded team force, not mechanical energy.',NARROW],
        [COMMON,'Each seed block equally averages five scenarios; small symbols show all 20 block values.',
         'Counts are accepted held-error refreshes across the team, not network packets.',NARROW]],
      'Figure_3':[[COMMON,
         'a–c: module-on minus module-off tracking error; d–e: higher-layer minus point-mass effect.',
         'Filled/open symbols: existing Holm rejection/no rejection at 0.05; CI are pointwise.',
         'Holm families: 21 local effects and 14 cross-layer interactions; five scenarios per block.']]*5,
      'Figure_4':[
        [COMMON,'Two scenarios per paired block; open symbols: response scale 0.5; filled symbols: scale 1.',
         'Small symbols show every block in a separate row below its mean and interval.',
         'Both small and large symbol fills encode scale, not statistical significance.'],
        [COMMON,'High-gain scale 2: arithmetic-mean summaries; each seed block averages two scenarios.',
         'Figure S4 retains all 120 block values and the two event counts for each method.',
         '163/240 plane crossings and 200/240 inversions; events can overlap. No ground-contact model.',
         'Numerical convergence is unresolved; these results do not establish usable flight performance.'],
        [COMMON,'Paired interaction: (scale 0.5 minus scale 1) for each arm, relative to Minimal.',
         'Two scenarios per block; these interaction intervals are descriptive.'],
        [COMMON,'Paired interaction: (scale 2 minus scale 1) for each arm, relative to Minimal.',
         'Two scenarios per block; high-gain runs are free-flight stress tests, not feasible-flight evidence.']],
      'Figure_5':[
        [COMMON,'Paired change from the matching causal baseline; each seed averages five scenarios.',
         'Only the indicated synthetic signal is supplied. Known signals do not define an optimal bound.',NARROW],
        [COMMON,'Absolute rigid-body tracking error; each seed averages five scenarios.',
         'Only the indicated synthetic signal is supplied. Known signals do not define an optimal bound.',NARROW]],
      'Figure_6':[
        ['900 fixed designs: 824 complete records, 44 failures before start and 32 failures after start.',
         'All outcomes remain in the design denominator; completeness does not establish flight success.',
         'Required-design failures leave H1, H2 and H3 unevaluated.'],
        ['All 824 complete records only; empirical cumulative distribution of common observed duration.',
         'Dashed line: nominal 16 s target. No confidence interval is estimated in this panel.',
         'The 76 failed designs are retained in panel a, not treated as complete observation windows.'],
        ['All 824 complete records only; each symbol is one complete design.',
         'Blue circles: maximum tilt below 90°; purple triangles: at least 90° (71 designs).',
         'Minimum center distance is geometric separation, not a collision-free or flight-success certificate.']],
      'Figure_S1':[[COMMON,'Rigid-body model; each paired seed block equally averages five scenarios.',
                    'The x-axis lists the tested position/velocity gain pairs as discrete conditions.',NARROW]]*2,
      'Figure_S2':[[COMMON,'Rigid-body model; each paired seed block equally averages five scenarios.',
                    'Actual base thresholds on a logarithmic x-axis; detector quantities differ by controller.',
                    'Family: transformed PPT errors. Minimal/Full: raw error coordinates. No common unit is imposed.',NARROW]]*3,
    }
    height=150 if name=='Figure_3' else 162 if name=='Figure_4' else 142
    horizontal=name in ['Figure_3','Figure_4','Figure_5'] or (name=='Figure_2' and index==1)
    left=.29 if horizontal else .14
    right=.91 if name=='Figure_6' and index==0 else .965
    if name=='Figure_6' and index==0:left=.28;right=.74;height=142
    if name=='Figure_1':
        left=.06;right=.96;height=[145,125,118,112][index]
    bottom=.32 if horizontal else .34 if name in ['Figure_S1','Figure_S2'] else .29
    if name=='Figure_S1':bottom=.40
    if name=='Figure_6' and index==0:bottom=.35
    top=.90
    return {'panel':letter,'width_mm':180,'height_mm':height,
            'bounds':[left,bottom,right-left,top-bottom],
            'notes':notes[name][index]}
