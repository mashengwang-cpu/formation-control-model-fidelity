"""Publication figures regenerated directly from frozen, paired statistical records."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator,ScalarFormatter
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from publication_style import *

J='formation_tracking_error'
E='control_energy'
N='event_trigger_count'
MEANS=table('method_means')
RAW=pd.read_csv(STATS/'runs_snapshot.csv')
SOURCE=STATS/'method_means.csv'


def campaign(name,metric=None):
    d=select(MEANS,campaign=name)
    return d if metric is None else select(d,metric=metric)

def blocks(name):
    required=['campaign','plant_model','arm_id','condition','seed','scenario','status',J,E,N]
    missing=set(required)-set(RAW.columns)
    if missing:raise ValueError(f'Missing native input columns: {sorted(missing)}')
    d=select(RAW,campaign=name)
    keys=['plant_model','arm_id','condition']
    if d.empty:raise ValueError(f'Missing native campaign: {name}')
    if not (d.status=='ok').all():raise ValueError('Incomplete native records')
    if d[keys+['seed','scenario']].isna().any().any():
        raise ValueError('Missing native block identity')
    if not np.isfinite(d[[J,E,N,'seed']].to_numpy(dtype=float)).all():
        raise ValueError('Nonfinite native endpoint or seed identity')
    expected=select(MEANS,campaign=name,metric=J)
    if expected.empty or not expected.n_seeds.eq(20).all():
        raise ValueError('Native figure contract requires 20 seed blocks')
    expected_cells=set(map(tuple,expected[keys].to_numpy()))
    if set(map(tuple,d[keys].drop_duplicates().to_numpy()))!=expected_cells:
        raise ValueError('Missing or unexpected native experimental cell')
    unit=keys+['seed']
    if d.duplicated(unit+['scenario']).any():
        raise ValueError('Duplicate scenario within a native seed block')
    scenarios={'nominal','combined_attack_fault'} if name=='attitude_intervention' else {
        'nominal','actuator_fault','fdi_attack','dos_attack','combined_attack_fault'}
    if not d.groupby(unit)['scenario'].agg(lambda values:set(values)==scenarios).all():
        raise ValueError('Incomplete scenario set in a native seed block')
    seeds=d.groupby(keys)['seed'].agg(lambda values:tuple(sorted(set(values))))
    if not seeds.map(len).eq(20).all() or len(set(seeds))!=1:
        raise ValueError('Incomplete or unpaired native seed blocks')
    # Completeness is checked before pandas.mean can skip a missing endpoint.
    return d.groupby(unit,as_index=False)[[J,E,N]].mean()

def points(ax,x,y,arm,identity=None,horizontal=False,spread=.025,alpha=.9,size=10.5,solid=True):
    y=np.asarray(y,dtype=float);p=float(x)+np.linspace(-spread,spread,len(y))
    if not np.isfinite(y).all():raise ValueError('Nonfinite seed block')
    xx,yy=(y,p) if horizontal else (p,y)
    ax.scatter(xx,yy,s=size,facecolors=COLOR[arm] if solid else 'white',marker=MARKER[arm],alpha=alpha,lw=.45,edgecolors=COLOR[arm],zorder=2)
    register(ax,{'type':'seed_blocks','arm':arm,'identity':identity or {},'x':xx.tolist(),'y':yy.tolist(),'count':len(y)})

def logticks(ax,axis='y',ticks=None):
    log_axis(ax,axis)
    if ticks is not None:
        getattr(ax,f'set_{axis}ticks')(ticks)
        getattr(ax,f'{axis}axis').set_major_formatter(ScalarFormatter())

def span(ax,rows,horizontal=True,zero=True,pad=.14):
    a=min(rows.bca95_low.min(),rows['mean_difference'].min() if 'mean_difference' in rows else rows['mean'].min())
    b=max(rows.bca95_high.max(),rows['mean_difference'].max() if 'mean_difference' in rows else rows['mean'].max())
    if zero:a=min(0,a);b=max(0,b)
    delta=max(b-a,1e-8)*pad
    getattr(ax,'set_xlim' if horizontal else 'set_ylim')(a-delta,b+delta)

def tracking_across_models(ax,means,pts,enlarged=False):
    """Separate seed observations from summaries within each categorical cell."""
    for k,arm in enumerate(ARMS):
        cell=np.arange(3)+(k-1)*.24
        rows=select(means,arm_id=arm,metric=J).set_index('plant_model').loc[PLANTS]
        for x,p in zip(cell,PLANTS):
            points(ax,x-.078,select(pts,arm_id=arm,plant_model=p)[J],arm,
                   {'plant':p,'metric':J},spread=.022)
        xx=cell+.044
        # Lines join discrete means only; no unobserved point is interpolated.
        ax.plot(xx,rows['mean'],color=COLOR[arm],ls=LINESTYLE[arm],lw=1.8,zorder=3)
        mean_ci(ax,xx,rows,arm)
    ax.set_xticks(range(3),['Point mass','Command lag','Rigid body']);ax.set_xlim(-.5,2.5)
    ax.set_ylabel('Tracking error, $J$ (m)',fontsize=10)
    logticks(ax,ticks=[.05,.1,.3,1,3]);fit_records(ax)
    decorate(ax)
    ax.tick_params(axis='both',labelsize=9.5)



def core(out):
    means=campaign('core_fixed');pts=blocks('core_fixed')
    species_path=DATA/'envelope/core_species_means.csv'
    species=select(pd.read_csv(species_path),plant_model=PLANTS[2])
    fig=plt.figure(figsize=(180*MM,184*MM))
    a=fig.add_axes([.11,.575,.42,.285]);b=fig.add_axes([.70,.575,.265,.285])
    c=fig.add_axes([.11,.145,.365,.285]);d=fig.add_axes([.60,.145,.365,.285])
    heading(fig,'Actuation changes the controller ranking')
    legend(fig,y=.943)
    tracking_across_models(a,means,pts)
    for k,arm in enumerate(ARMS):
        sr=select(species,arm_id=arm).set_index('species').loc[['uav','usv']]
        mean_ci(b,np.arange(2)+(k-1)*.19,sr,arm,horizontal=True)
    panel(a,'a','Tracking across models')
    b.set_yticks([0,1],['UAVs','USVs']);b.set_ylim(1.55,-.55);b.set_xlabel('Tracking error, $J$ (m)')
    logticks(b,'x',[.1,.3,1,3]);b.set_xlim(.095,3.6);decorate(b);panel(b,'b','Rigid-body split')
    for ax,metric,title,letter,label in [(c,E,'Commanded force effort','c','Command effort (N² s)'),(d,N,'Accepted error samples','d','Refresh count')]:
        for k,arm in enumerate(ARMS):
            xx=np.arange(3)+(k-1)*.25
            rr=select(means,arm_id=arm,metric=metric).set_index('plant_model').loc[PLANTS]
            for x,p in zip(xx,PLANTS):points(ax,x-.075,select(pts,arm_id=arm,plant_model=p)[metric],arm,{'plant':p,'metric':metric})
            mean_ci(ax,xx+.04,rr,arm)
        ax.set_xticks(range(3),['Point mass','Command lag','Rigid body']);ax.set_xlim(-.5,2.5)
        ax.set_ylabel(label);decorate(ax);panel(ax,letter,title)
        if metric==E:logticks(ax,ticks=[10,100,1000]);fit_records(ax)
        else:fit_records(ax,zero=True);ax.set_yticks([0,250,500,750,1000])
    fig.text(.10,.043,'20 paired seed blocks  ·  5 scenarios per block  ·  95% BCa intervals',fontsize=8.6,color=MUTED)
    sources=[SOURCE,STATS/'runs_snapshot.csv',STATS/'core_fixed.csv',species_path]
    record=save(fig,'Figure_2',out,sources,CAPTIONS['Figure_2'])
    return record

def forest(ax,rows,labels,color,letter,title,short_xlabel):
    row_guides(ax,len(rows));decorate(ax,zero=True)
    for i,(_,r) in enumerate(rows.iterrows()):
        interval(ax,i,r.mean_difference,r.bca95_low,r.bca95_high,color,solid=bool(r.reject_at_0_05),source={**r.to_dict(),'module':str(r.name)},size=5.4)
    ax.set_yticks(range(len(rows)),labels);ax.set_ylim(len(rows)-.45,-.55)
    ax.set_xlabel(short_xlabel);ax.xaxis.set_major_locator(MaxNLocator(4));span(ax,rows)
    ax.ticklabel_format(axis='x',style='sci',scilimits=(-3,3),useMathText=True)
    ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0,pad=5)
    panel(ax,letter,title)

def modules(out):
    effects=table('module_effect');inter=table('cross_fidelity_interaction')
    labels=['Gain schedule','Signed powers','Approximation','Leaky error filter','Effectiveness comp.','PPT','Topology mixing']
    fig=plt.figure(figsize=(180*MM,195*MM))
    axes=[fig.add_axes(v) for v in [[.255,.695,.235,.175],[.735,.695,.235,.175],
                                  [.255,.405,.235,.175],[.735,.405,.235,.175],
                                  [.255,.115,.235,.175]]]
    heading(fig,'Module effects depend on their control background')
    fig.text(.04,.928,'a–c: module on − off     d–e: higher layer − point mass',fontsize=9.5,color=MUTED)
    for i,p in enumerate(PLANTS):
        rr=select(effects,plant_model=p).set_index('module').loc[MODULES]
        forest(axes[i],rr,labels,PLANT_COLOR[i],chr(97+i),PLABEL[i],'ΔJ (m)')
        if i==0:axes[i].xaxis.get_major_formatter().set_powerlimits((-3,-3))
        else:axes[i]._standalone_yticklabels=labels
    for i,p in enumerate(PLANTS[1:]):
        rr=select(inter,high_plant=p).set_index('module').loc[MODULES]
        forest(axes[3+i],rr,labels,PLANT_COLOR[i+1],chr(100+i),['Lag − point','Rigid − point'][i],'ΔΔJ (m)')
        if i==1:axes[3+i]._standalone_yticklabels=labels
    handles=[Line2D([],[],ls='none',marker='o',mfc=INK,mec=INK,label='Holm rejection'),Line2D([],[],ls='none',marker='o',mfc='white',mec=INK,label='No rejection')]
    fig.text(.57,.287,'Reading the estimates',fontsize=10.5,weight='bold')
    fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.55,.273),ncol=1,handletextpad=.6,labelspacing=.7)
    fig.text(.57,.17,'20 paired seed blocks\n5 scenarios per block\nPointwise 95% BCa intervals',fontsize=9.5,linespacing=1.6,va='top')
    fig.text(.57,.073,'Holm: 21 local effects;\n14 cross-layer interactions',fontsize=9,linespacing=1.4,va='top',color=MUTED)
    return save(fig,'Figure_3',out,[STATS/'module_effect.csv',STATS/'cross_fidelity_interaction.csv'],
        CAPTIONS['Figure_3'])

def attitude(out):
    arms=['minimal','full_no_ppt','ko_tvg','ko_powers','ko_approximator','ko_observer']
    labels=['Minimal','Full (PPT off)','No gain schedule','No signed powers','No approximation','No error filter']
    means=campaign('attitude_intervention',J);pts=blocks('attitude_intervention');inter=table('attitude_interaction')
    fig=plt.figure(figsize=(180*MM,190*MM))
    a=fig.add_axes([.245,.56,.30,.30]);b=fig.add_axes([.665,.56,.30,.30])
    c=fig.add_axes([.245,.14,.30,.22]);d=fig.add_axes([.665,.14,.30,.22])
    heading(fig,'Attitude-gain effects within and beyond the flight envelope')
    handles=[Line2D([],[],ls='none',marker='o',mfc='white',mec=INK,label='$s=0.5$'),Line2D([],[],ls='none',marker='o',mfc=INK,mec=INK,label='$s=1$')]
    fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.245,.958),ncol=2,handletextpad=.4)
    for k,arm in enumerate(arms):
        pos=[];mu=[]
        for j,cond in enumerate(['bandwidth_0.5','bandwidth_1']):
            y=k+(j-.5)*.42;rr=select(means,arm_id=arm,condition=cond)
            points(a,y+.16,select(pts,arm_id=arm,condition=cond)[J],arm,{'condition':cond,'metric':J},True,.022,solid=j==1)
            mean_ci(a,[y-.07],rr,arm,horizontal=True,solid=j==1)
            pos.append(y-.07);mu.append(rr['mean'].iloc[0])
        a.plot(mu,pos,color=COLOR[arm],lw=1.15,alpha=1,zorder=1)
        cond='bandwidth_2';rr=select(means,arm_id=arm,condition=cond)
        mean_ci(b,[k-.13],rr,arm,horizontal=True)
    for ax in [a,b]:
        ax.set_yticks(range(6),labels if ax is a else ['']*6);ax.set_ylim(5.55,-.55)
        ax.set_xlabel('Tracking error, $J$ (m)');logticks(ax,'x');row_guides(ax,6);decorate(ax)
        ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0,pad=5)
    a.set_xticks([.1,.3,1,3]);a.xaxis.set_major_formatter(ScalarFormatter());fit_records(a,'x')
    b.set_xticks([.1,1,10],['0.1','1','10'])
    stress_values=select(pts,condition='bandwidth_2')[J].to_numpy()
    loglo,loghi=np.log10([stress_values.min(),stress_values.max()]);margin=(loghi-loglo)*.08
    b.set_xlim(10**(loglo-margin),10**(loghi+margin))
    b._standalone_yticklabels=labels;b._omit_shared_legend=True
    panel(a,'a','Lower and reference scales');panel(b,'b','High-gain stress: $s=2$',subtitle='Convergence unresolved (Fig. S5)')
    fig.text(.245,.466,'$s=2$:  163/240 reference-plane crossings  ·  200/240 inversions',fontsize=8.6,color=INK)
    fig.text(.245,.433,'Free-flight model; no ground contact. Numerical convergence is unresolved.',fontsize=8.5,color=INK)
    for ax,scale,letter in [(c,.5,'c'),(d,2,'d')]:
        rrall=select(inter,attitude_response_scale=scale)
        for k,arm in enumerate(arms[1:]):mean_ci(ax,[k],select(rrall,arm_id=arm),arm,horizontal=True)
        ax.set_yticks(range(5),labels[1:] if ax is c else ['']*5);ax.set_ylim(4.5,-.5)
        ax.set_xlabel('Interaction relative\nto Minimal (m)');span(ax,rrall);row_guides(ax,5);decorate(ax,zero=True)
        ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0,pad=5)
        ax.xaxis.set_major_locator(MaxNLocator(4));ax.ticklabel_format(axis='x',style='sci',scilimits=(-3,4),useMathText=True)
        panel(ax,letter,f'$s={scale:g}$ versus $s=1$')
        ax._omit_shared_legend=True
        if ax is d:ax._standalone_yticklabels=labels[1:]
    fig.text(.245,.035,'20 paired seed blocks per arm  ·  2 scenarios per block  ·  95% BCa intervals',fontsize=8.5,color=MUTED)
    return save(fig,'Figure_4',out,[SOURCE,STATS/'runs_snapshot.csv',STATS/'attitude_interaction.csv',DATA/'envelope/flight_envelope_summary.csv'],
        CAPTIONS['Figure_4'])

def attitude_stress(out):
    """Full stress distribution with nonexclusive task-level envelope counts."""
    arms=['minimal','full_no_ppt','ko_tvg','ko_powers','ko_approximator','ko_observer']
    means=campaign('attitude_intervention',J);pts=blocks('attitude_intervention')
    summary_path=DATA/'envelope/flight_envelope_summary.csv'
    jobs_path=DATA/'envelope/flight_envelope_per_job.csv'
    events=pd.read_csv(summary_path)
    events=select(events,campaign='attitude_intervention',attitude_response_scale=2)
    if set(events.arm_id)!=set(arms) or len(events)!=6:
        raise ValueError('Stress event rows do not match the six declared methods')
    fig=plt.figure(figsize=(180*MM,157*MM))
    ax=fig.add_axes([.275,.325,.445,.50])
    heading(fig,'High-gain stress at $s=2$',
            'Discrete free-flight outcomes; numerical convergence has not been established')
    columns={'crossings':1.10,'inversions':1.43}
    ax.text(columns['crossings'],1.055,'Plane\ncrossing',transform=ax.transAxes,ha='center',va='bottom',fontsize=9)
    ax.text(columns['inversions'],1.055,'Inversion',transform=ax.transAxes,ha='center',va='bottom',fontsize=9)
    for k,arm in enumerate(arms):
        cond='bandwidth_2';rr=select(means,arm_id=arm,condition=cond)
        points(ax,k+.19,select(pts,arm_id=arm,condition=cond)[J],arm,
               {'condition':cond,'metric':J},True,.045)
        mean_ci(ax,[k-.13],rr,arm,horizontal=True)
        row=events[events.arm_id.eq(arm)].iloc[0]
        numbers=[row.tasks,row.reference_plane_crossings,row.inverted_tasks]
        if not np.isfinite(numbers).all() or any(float(v)!=int(v) for v in numbers):
            raise ValueError('Event counts must be finite integers')
        tasks,crossings,inversions=map(int,numbers)
        if tasks!=40 or not (0<=crossings<=tasks and 0<=inversions<=tasks):
            raise ValueError('Invalid stress-event denominator or count')
        labels={'crossings':f'{crossings}/{tasks}','inversions':f'{inversions}/{tasks}'}
        for key,x in columns.items():
            ax.text(x,k,labels[key],transform=ax.get_yaxis_transform(),ha='center',va='center',fontsize=10)
        ax.plot([0,1.54],[k+.5,k+.5],transform=ax.get_yaxis_transform(),color=LIGHT,lw=.65,clip_on=False,zorder=0)
        register(ax,dict(type='envelope_events',arm=arm,campaign='attitude_intervention',scale=2,
            tasks=tasks,crossings=crossings,inversions=inversions,labels=labels,row=k,columns=columns.copy()))
    ax.set_yticks(range(6),[LABEL[a] for a in arms]);ax.set_ylim(5.55,-.55)
    ax.set_xlabel('Tracking error, $J$ (m)',fontsize=11)
    logticks(ax,'x');ax.set_xticks([.1,1,10],['0.1','1','10']);fit_records(ax,'x')
    decorate(ax);ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0,pad=6,labelsize=10)
    fig.text(.065,.206,'Large symbols: arithmetic means and pointwise 95% BCa CIs (20,000 resamples).',fontsize=8.5)
    fig.text(.065,.173,'Small symbols: all 120 seed-block means; vertical offsets separate points from summaries.',fontsize=8.5)
    fig.text(.065,.140,'Each method: 20 paired seeds × 2 scenarios = 40 simulation tasks. Horizontal axis: log scale.',fontsize=8.5)
    fig.text(.065,.107,'Right: tasks with a plane crossing or inversion; these event counts can overlap.',fontsize=8.5)
    fig.text(.065,.065,'No ground-contact model; these outcomes do not establish usable flight performance.',fontsize=8.7,weight='bold')
    return save(fig,'Figure_S4',out,[SOURCE,STATS/'runs_snapshot.csv',summary_path,jobs_path],
                CAPTIONS['Figure_S4'],panels=False)


def information(out):
    means=campaign('information_contract',J)
    dif=select(table('descriptive_contrasts'),campaign='information_contract',metric=J,contrast='condition_minus_registered_reference_descriptive')
    changes=['oracle_efficiency','oracle_bias','oracle'];conditions=['causal',*changes]
    fig=plt.figure(figsize=(180*MM,112*MM))
    a=fig.add_axes([.24,.24,.305,.49]);b=fig.add_axes([.66,.24,.305,.49])
    heading(fig,'Known information has channel-specific effects');legend(fig,y=.925)
    for k,arm in enumerate(ARMS):
        rr=select(dif,arm_id=arm).set_index('condition').loc[changes]
        mean_ci(a,np.arange(1,4),rr,arm,horizontal=True,offset=(k-1)*.20)
        rr=select(means,arm_id=arm).set_index('condition').loc[conditions]
        mean_ci(b,np.arange(4),rr,arm,horizontal=True,offset=(k-1)*.20)
    a.text(.02,0,'Reference: ΔJ = 0',transform=a.get_yaxis_transform(),va='center',fontsize=8.5,color=MUTED)
    for ax in [a,b]:
        ax.set_yticks(range(4),['Causal estimates','Known ρ only','Known bias only','Both known'] if ax is a else ['']*4)
        ax.set_ylim(3.5,-.5);row_guides(ax,4);decorate(ax,zero=ax is a)
        ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0,pad=5);ax.xaxis.set_major_locator(MaxNLocator(4))
    span(a,dif);a.set_xlabel('Change from causal baseline, ΔJ (m)')
    b.set_xlim(0,means.bca95_high.max()*1.08);b.set_xlabel('Tracking error, $J$ (m)')
    panel(a,'a','Paired change');panel(b,'b','Absolute error')
    b._standalone_yticklabels=['Causal estimates','Known ρ only','Known bias only','Both known']
    fig.text(.24,.07,'Each intervention supplies only the indicated synthetic signal.',fontsize=8.6,color=MUTED)
    return save(fig,'Figure_5',out,[SOURCE,STATS/'descriptive_contrasts.csv'],
        CAPTIONS['Figure_5'])

def sensitivity(out,refresh=False):
    camp='refresh_tradeoff' if refresh else 'gain_sensitivity';means=campaign(camp)
    conditions=sorted(means.condition.unique(),key=lambda s:float(s.split('_')[1]))
    metrics=[J,E,N] if refresh else [J,E]
    fig=plt.figure(figsize=(164*MM,(103 if refresh else 102)*MM))
    positions=[[.10,.25,.235,.47],[.425,.25,.235,.47],[.75,.25,.235,.47]] if refresh else [[.105,.25,.36,.47],[.62,.25,.36,.47]]
    axes=[fig.add_axes(p) for p in positions]
    heading(fig,'Error-sample refresh sensitivity' if refresh else 'Matched outer-gain sensitivity');legend(fig,y=.92)
    titles=['Tracking error','Command effort','Error refreshes']
    labels=['Tracking error, $J$ (m)','Command effort (N² s)','Refresh count']
    for i,(ax,metric) in enumerate(zip(axes,metrics)):
        for k,arm in enumerate(ARMS):
            rr=select(means,arm_id=arm,metric=metric).set_index('condition').loc[conditions]
            xx=np.array([float(x.split('_')[1]) for x in conditions]) if refresh else np.arange(len(conditions))+(k-1)*.05
            ax.plot(xx,rr['mean'],color=COLOR[arm],ls=LINESTYLE[arm],lw=1.75,zorder=2)
            mean_ci(ax,xx,rr,arm)
        if refresh:
            ax.set_xscale('log');ax.minorticks_off();xx=np.array([float(x.split('_')[1]) for x in conditions])
            ax.set_xticks(xx,[f'{v:g}' for v in xx]);ax.set_xlim(xx[0]/1.2,xx[-1]*1.2)
            ax.tick_params(axis='x',labelsize=9.5,pad=4)
            ax.set_xlabel('Base threshold, $η_0$')
        else:
            labelsx=[' / '.join(f'{float(x):g}' for x in co.split('_')[1:]) for co in conditions]
            ax.set_xticks(range(4),labelsx,rotation=25,ha='right');ax.set_xlim(-.23,3.23)
            ax.set_xlabel('Position / velocity gain')
        ax.set_ylabel(labels[i]);decorate(ax);panel(ax,chr(97+i),titles[i])
        if metric==E or (refresh and metric==J):logticks(ax)
        elif metric==N:ax.set_ylim(bottom=0);ax.yaxis.set_major_locator(MaxNLocator(4))
        else:ax.yaxis.set_major_locator(MaxNLocator(4))
        if refresh and metric==J:ax.set_yticks([.2,.5,1,2],['0.2','0.5','1','2'])
        if refresh and metric==E:ax.set_yticks([30,100,300,1000,3000])
    fig.text(.105,.055,'Rigid-body model  ·  20 paired seed blocks  ·  5 scenarios per block',fontsize=8.5,color=MUTED)
    
    return save(fig,'Figure_S2' if refresh else 'Figure_S1',out,[SOURCE],CAPTIONS['Figure_S2' if refresh else 'Figure_S1'])

def robustness(out):
    dif=select(table('descriptive_contrasts'),campaign='robustness',metric=J,contrast='condition_minus_registered_reference_descriptive')
    conditions=['disturbance_1.5','uncertainty_0.15','native_drag']
    fig,ax=plt.subplots(figsize=(164*MM,90*MM));fig.subplots_adjust(left=.34,right=.96,bottom=.25,top=.69)
    heading(fig,'Sensitivity under independent test conditions');legend(fig,y=.91)
    for k,arm in enumerate(ARMS):mean_ci(ax,range(3),select(dif,arm_id=arm).set_index('condition').loc[conditions],arm,horizontal=True,offset=(k-1)*.20)
    ax.set_yticks(range(3),['External force × 1.5','Generated mass (15%)','Vehicle-specific drag']);ax.set_ylim(2.5,-.5)
    ax.set_xlabel('Change from matching baseline, ΔJ (m)');span(ax,dif);row_guides(ax,3);decorate(ax,zero=True)
    ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0,pad=5);ax.xaxis.set_major_locator(MaxNLocator(4))
    fig.text(.34,.065,'20 independent seed blocks  ·  95% BCa intervals',fontsize=8.6,color=MUTED)
    return save(fig,'Figure_S3',out,[SOURCE,STATS/'descriptive_contrasts.csv'],
        CAPTIONS['Figure_S3'],panels=False)

def px4(out):
    src=DATA/'figure_sources';paths=[src/f'rev_fig6_px4_pub__{n}.csv' for n in ['group_counts','complete_record_windows','all_attempt_geometry_scope','design_outcomes']]
    groups=pd.read_csv(paths[0]);windows=pd.read_csv(paths[1]);geometry=pd.read_csv(paths[2]);g=geometry[geometry.plotted==True]
    keys=['record_complete','failed_before_release','failed_after_release']
    if len(windows)!=824 or len(g)!=824 or groups.designs.sum()!=900:raise ValueError('PX4 accounting identity changed')
    assert groups[keys].sum().tolist()==[824,44,32]
    expected=[('h1','proposed_minimal_causal','causal'),('h1','recent_2025_resilient_fixed_time','causal'),('h2','proposed_no_ppt','causal'),('h2','hifi_ko_tvg','causal'),('h2','hifi_ko_powers','causal'),('h2','hifi_ko_approximator','causal'),('h2','hifi_ko_observer','causal'),('h3','proposed_minimal_causal','causal'),('h3','proposed_minimal_causal','oracle')]
    groups=groups.set_index(['campaign','method','contract']).loc[expected].reset_index()
    labels=['Minimal','Family comparator','Full (PPT off)','No gain schedule','No signed powers','No approximation','No error filter','Causal estimates','Both known']
    fig=plt.figure(figsize=(180*MM,190*MM))
    a=fig.add_axes([.28,.535,.505,.30]);b=fig.add_axes([.11,.135,.335,.225]);c=fig.add_axes([.64,.135,.325,.225])
    heading(fig,'Record completeness does not establish flight success')
    colors=['#4A788B','#A2B0BA','#B07837']
    fig.legend(handles=[Patch(facecolor=co,edgecolor=INK,linewidth=.35,hatch=ha,label=la) for co,ha,la in zip(colors,['','////','xx'],['Complete: 824','Failed before: 44','Failed after: 32'])],ncol=3,loc='upper center',bbox_to_anchor=(.5,.944),fontsize=10.5,columnspacing=1.2,handlelength=1.2)
    ys=np.array([0,1,2.6,3.6,4.6,5.6,6.6,8.2,9.2]);left=np.zeros(9)
    for col,key,ha in zip(colors,keys,['','////','xx']):
        vals=groups[key].to_numpy();a.barh(ys,vals,left=left,height=.63,color=col,ec=INK,lw=.35,hatch=ha);left+=vals
    for y,(_,r) in zip(ys,groups.iterrows()):
        a.text(103,y,f'{int(r.record_complete):2d} / {int(r.failed_before_release):1d} / {int(r.failed_after_release):1d}',fontsize=8.8,va='center',clip_on=False)
        register(a,{'type':'design_counts','row':r.to_dict()})
    a.text(103,-1,'Complete / pre / post',fontsize=8.5,va='center')
    a.set_yticks(ys,labels);a.set_ylim(9.85,-.75);a.set_xlim(0,100);a.set_xticks([0,25,50,75,100]);a.set_xlabel('Fixed designs per row');decorate(a);a.spines['left'].set_visible(False);a.tick_params(axis='y',length=0,pad=6)
    for title,y1,y2 in [('H1',0,1),('H2',2.6,6.6),('H3',8.2,9.2)]:
        a.text(-.47,(y1+y2)/2,title,transform=a.get_yaxis_transform(),va='center',ha='right',fontsize=9.1,weight='bold')
    panel(a,'a','All 900 fixed designs')
    durations=np.sort(windows.common_window_duration_s.to_numpy());yy=np.arange(1,len(durations)+1)/len(durations)
    b.step(durations,yy,where='post',color=colors[0],lw=1.5)
    register(b,{'type':'ecdf','count':len(durations),'duration_s':durations.tolist(),'fraction':yy.tolist()})
    b.axvline(16,color='#ACB8BF',lw=.8,ls=(0,(3,2)));b.set_xlim(15.935,16.003);b.set_ylim(0,1.035)
    b.set_xticks([15.94,15.96,15.98,16]);b.set_yticks([0,.5,1]);b.set_xlabel('Common observed duration (s)');b.set_ylabel('Fraction of complete records');decorate(b);panel(b,'b','Observed windows')
    normal=g.native_max_tilt_deg<90
    for mask,color,marker,high in [(normal,colors[0],'o',False),(~normal,'#684A98','^',True)]:
        x=g.loc[mask,'native_pair_center_distance_min_m'];y=g.loc[mask,'native_max_tilt_deg']
        c.scatter(x,y,s=12 if high else 10,alpha=.94 if high else .85,color=color,lw=.22,edgecolors=color,marker=marker,label='Tilt ≥90°' if high else 'Tilt <90°')
        register(c,{'type':'geometry','tilt_at_least_90':high,'count':len(x),'separation_m':x.tolist(),'tilt_deg':y.tolist()})
    c.legend(loc='upper right',fontsize=9.5,handlelength=1,handletextpad=.3,borderaxespad=.25)
    c.axhline(90,color='#684A98',ls=(0,(3,2)),lw=.85)
    c.text(.985,92,'90°',transform=c.get_yaxis_transform(),ha='right',va='bottom',fontsize=8.6)
    c.set_ylim(0,186);c.set_yticks([0,45,90,135,180]);c.set_xlim(0,1.4);c.set_xticks([0,.4,.8,1.2])
    c.set_xlabel('Minimum center separation (m)');c.set_ylabel('Maximum tilt (°)');decorate(c);panel(c,'c','Complete-record geometry')
    b._omit_shared_legend=True;c._omit_shared_legend=True
    fig.text(.11,.427,'824 complete records only in (b,c)  ·  71 reach at least 90° tilt',fontsize=8.7,color=MUTED)
    fig.text(.11,.034,'Required-design failures leave H1, H2 and H3 unevaluated.',fontsize=9,weight='bold')
    return save(fig,'Figure_6',out,paths,
        CAPTIONS['Figure_6'])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'figures');parser.add_argument('--only');parser.add_argument('--statistics',type=Path,default=STATS);args=parser.parse_args()
    global MEANS,RAW,SOURCE
    import publication_style
    publication_style.STATS=args.statistics.resolve();globals()['STATS']=publication_style.STATS
    MEANS=table('method_means');RAW=pd.read_csv(STATS/'runs_snapshot.csv');SOURCE=STATS/'method_means.csv'
    if json.loads((STATS/'analysis_status.json').read_text())['status']!='complete':raise ValueError('Native statistics incomplete')
    if set(RAW.campaign)!=set(MEANS.campaign):raise ValueError('Native campaign inventory differs from frozen statistics')
    for name in MEANS.campaign.unique():blocks(name)
    from publication_schematics import protocol,graphical_abstract
    funcs={'Figure_1':protocol,'Figure_2':core,'Figure_3':modules,'Figure_4':attitude,'Figure_5':information,'Figure_6':px4,'Figure_S1':lambda out:sensitivity(out,False),'Figure_S2':lambda out:sensitivity(out,True),'Figure_S3':robustness,'Figure_S4':attitude_stress,'Graphical_abstract':graphical_abstract}
    records={}
    for name,fn in funcs.items():
        if args.only and name!=args.only:continue
        records[name]=fn(args.output);print(name,records[name]['qa'],flush=True)
    args.output.mkdir(exist_ok=True,parents=True);dest=args.output/'FIGURE_MANIFEST.json'
    previous=json.loads(dest.read_text(encoding='utf-8')) if dest.exists() and args.only else {}
    previous.update(records);dest.write_text(json.dumps(previous,ensure_ascii=False,indent=2),encoding='utf-8')
    (args.output/'Figure_captions.txt').write_text('\n\n'.join(k.replace('_',' ')+'. '+v['caption'] for k,v in previous.items()),encoding='utf-8')

if __name__=='__main__':main()
