# Final manuscript figure replay

This directory regenerates all **8 main-text figures and 5 supplementary figures**
from the frozen inputs used in the SMPT final delivery dated 8 September 2026,
13:32:48. The publication numbering and manuscript-size typography are preserved.

From this directory, using Python with the supplied requirements installed:

```bash
python -m pip install -r requirements.txt
python rebuild_publication_figures.py
```

The default produces 150 dpi PNG, vector PDF, editable SVG and plotted-data JSON.
The final numbered files and `REPLAY_VERIFICATION.json` are in
`outputs/publication/`. The entry point automatically compares all 13 generated
ledgers with `reference_ledgers/`; it raises an error if scientific coordinates,
intervals, source bindings or the recorded layout contracts differ.

For the original publication PNG resolution, use:

```bash
python rebuild_publication_figures.py --dpi 1000 --output outputs_publication
```

`--output` accepts any dedicated output directory. PDF and SVG remain vector
outputs at either PNG resolution. Arial is preferred; DejaVu Sans is the declared
fallback. Font availability can change layout, so the automatic checks should be
reviewed if another platform reports a typography mismatch.

## What this reproduces

- Figure plotting from the actual frozen endpoint tables, paired seed blocks,
  confidence intervals and case-level numerical comparisons.
- All 12 registered primary contrasts, including the native retuned
  Full-versus-Minimal interval that crosses zero (approximately -0.000261 to
  0.002893 m). An inconclusive direction is retained as recorded.
- PX4 scope counts for 900 designs: 824 complete records and 76 interface or
  simulator failures. The accompanying table retains all 1,291 attempts, including
  467 attempts excluded from the plotted geometry; failures are not dropped from
  the design accounting.

This command does **not** rerun the controller simulations, repeat the statistical
bootstrap, or regenerate the original PX4 logs. The parent reproduction package
documents those separate levels of reproduction.

## How the directory was reduced

Unused manifest copies and duplicate input tables are excluded. The 486 selected
numerical JSON files are represented for plotting by their original frozen
`numerical_plot_values.csv`: all 1,800 comparison rows were checked exactly against
the JSON-derived table using round-trip float parsing. The selected design and
summary are retained. The 1,800 rows are all classified `resolved` and pass the
recorded criteria; this is a finite numerical check, not a uniform error bound.

Original code is retained apart from the declared export adapter: configurable
PNG resolution, omission of duplicate reading previews, a portable output option,
and loading the numerically identical frozen numerical table. No axis limit,
observation, interval endpoint or scientific plotting rule was changed.

`SOURCE_INPUT_SHA256.csv` records hashes of original archive members; the two
export modules are deliberately adapted, so their original hashes are provenance,
not expected hashes of the adapted files. `SOURCE_PROVENANCE.json` records the
source archive digest and adaptation scope. The parent package's manifest checks
the files actually delivered here. `SOURCE_README.md` preserves the original
addendum's description and license statement; its original 1000 dpi default has
been superseded by this README.

Original code is MIT licensed (`LICENSE_CODE.txt`). Original data and figures are
CC BY 4.0, as stated in the source addendum. Third-party dependencies retain their
own licenses.
