"""Font hierarchy for whole figures at manuscript size; no data changes."""
from matplotlib.text import Text
def apply_typography(fig):
    for text in fig.findobj(match=Text):
        if getattr(text, '_manuscript_typography_applied', False):
            continue
        old = text.get_fontsize()
        if old >= 11.5: new = 10.0
        elif old >= 10.25: new = 9.0
        elif old >= 9.75: new = 8.8
        elif old >= 9.25: new = 8.5
        elif old >= 8.75: new = 8.2
        else: new = 8.0
        text.set_fontsize(new)
        text._manuscript_typography_applied = True
