"""Replay the 13 final SMPT figures and verify their complete plotted-data ledgers.

Only output location, PNG resolution and the numerical table loading adapter
change relative to the archived figure entry point. Scientific plotting code
and frozen input values are retained.
"""
from pathlib import Path
import argparse
import json
import shutil
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parent


def verify_ledgers(publication):
    checks = []
    for reference in sorted((ROOT / 'reference_ledgers').glob('*.plot_data.json')):
        expected = json.loads(reference.read_text(encoding='utf-8'))
        actual = json.loads((publication / reference.name).read_text(encoding='utf-8'))
        # Generator and raster hashes change with the declared export adapter.
        # Scientific data, axis bounds, labels, typography and source bindings do not.
        keys = ('axes', 'clipped_intervals', 'cropped_observations', 'sources') if 'axes' in expected else (
            'data', 'width_mm', 'height_mm', 'caption', 'font_sizes_pt', 'sources',
            'outside_text', 'font_primary', 'font_fallback')
        mismatches = [key for key in keys if actual[key] != expected[key]]
        if mismatches:
            raise ValueError(f'{reference.name}: reference ledger mismatch in {mismatches}')
        checks.append({'figure': reference.name.removesuffix('.plot_data.json'),
                       'checked_keys': list(keys), 'match': True})
    if len(checks) != 13:
        raise ValueError(f'Expected 13 reference figures, found {len(checks)}')
    report = {'reference': 'SMPT final delivery 2026-09-08 13:32:48',
              'figures': len(checks), 'all_match': True, 'checks': checks,
              'scope': 'Frozen-data figure replay; this does not rerun simulations or refit statistics.'}
    (publication / 'REPLAY_VERIFICATION.json').write_text(
        json.dumps(report, indent=2), encoding='utf-8')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'outputs',
                        help='Output directory (default: figure package outputs/).')
    parser.add_argument('--dpi', type=int, default=150,
                        help='PNG resolution; default 150 for a quick replay, 1000 for publication.')
    args = parser.parse_args()
    if not 72 <= args.dpi <= 1200:
        parser.error('--dpi must be between 72 and 1200')
    out = args.output.resolve()
    if out == ROOT or out in ROOT.parents or out == ROOT / 'data':
        parser.error('--output must be a dedicated generated-output directory')

    sys.path.insert(0, str(ROOT / 'tools'))
    import publication_figures as legacy
    import publication_schematics as schematics
    import publication_style
    from enhancement import figures as controlled
    publication_style.PNG_DPI = args.dpi
    controlled.PNG_DPI = args.dpi
    out.mkdir(parents=True, exist_ok=True)
    legacy_out, new_out = out / 'legacy', out / 'controlled'
    original_panel = legacy.panel

    def relabeled_panel(ax, letter, title='', subtitle=None):
        return original_panel(ax, letter, title,
                              subtitle.replace('Fig. S4', 'Fig. S5') if subtitle else subtitle)

    legacy.panel = relabeled_panel
    functions = [('Figure_1', schematics.protocol), ('Figure_2', legacy.core),
                 ('Figure_3', legacy.modules), ('Figure_4', legacy.attitude),
                 ('Figure_5', legacy.information), ('Figure_6', legacy.px4),
                 ('Figure_S1', lambda output: legacy.sensitivity(output, False)),
                 ('Figure_S2', lambda output: legacy.sensitivity(output, True)),
                 ('Figure_S3', legacy.robustness), ('Figure_S4', legacy.attitude_stress)]
    manifest = {}
    for name, function in functions:
        manifest[name] = function(legacy_out)
        print('Rendered source', name, flush=True)
    (legacy_out / 'FIGURE_MANIFEST.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

    original_export = controlled.export

    def whole_export(fig, name, output, records, sources, caption):
        if output.name == 'panels':
            controlled.plt.close(fig)
            return {'figure': name, 'reading_panel_not_regenerated': True}
        return original_export(fig, name, output, records, sources, caption)

    controlled.export = whole_export
    analysis = ROOT / 'data/analysis'
    blocks = analysis / 'paired_seed_blocks.csv'
    summaries = analysis / 'secondary_method_summaries.csv'
    primary = analysis / 'primary_contrasts.csv'
    controlled.performance(pd.read_csv(blocks), pd.read_csv(summaries), new_out, [blocks, summaries])
    print('Rendered controlled performance', flush=True)
    controlled.primary(pd.read_csv(primary), new_out, [primary, analysis / 'primary_family.json'])
    print('Rendered primary contrasts', flush=True)
    numerical_path = analysis / 'numerical_plot_values.csv'
    numerical = pd.read_csv(numerical_path, float_precision='round_trip')
    controlled.numerical(numerical, new_out,
                         [numerical_path, ROOT / 'data/numerical/selected_dd57944609c8/design.json'])
    print('Rendered numerical qualification', flush=True)
    mapping = json.loads((ROOT / 'PUBLICATION_FIGURE_MAPPING.json').read_text(encoding='utf-8'))['mapping']
    publication = out / 'publication'
    publication.mkdir(exist_ok=True)
    for kind, old, new in mapping:
        if old == 'Graphical_abstract':
            continue
        source = legacy_out if kind == 'legacy' else new_out
        for suffix in ('.pdf', '.svg', '.png', '.plot_data.json'):
            shutil.copy2(source / (old + suffix), publication / (new + suffix))
    report = verify_ledgers(publication)
    print(f"Verified {report['figures']} final figure ledgers: {publication}", flush=True)


if __name__ == '__main__':
    main()
