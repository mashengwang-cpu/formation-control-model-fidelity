# 最终稿全部图件重放

本目录使用 2026 年 9 月 8 日 13:32:48 SMPT 最终交付稿的冻结输入，重新生成
**8 张主文图和 5 张补充图**，保留最终图号、坐标范围、区间端点和版面字号。

在本目录打开终端，使用安装了依赖的 Python 运行：

```bash
python -m pip install -r requirements.txt
python rebuild_publication_figures.py
```

默认生成 150 dpi PNG、矢量 PDF、可编辑 SVG 和逐图数值账本。最终图号对应的
文件在 `outputs/publication/`。程序自动核对 13 张图的数值、坐标、来源哈希和
记录的排版属性，结果写入 `REPLAY_VERIFICATION.json`；出现差异时会报错。

需要原投稿 PNG 分辨率时运行：

```bash
python rebuild_publication_figures.py --dpi 1000 --output outputs_publication
```

`--output` 可以指定独立输出目录。PNG 分辨率选项不改变 PDF、SVG 的矢量性质。
优先使用 Arial，备用字体为 DejaVu Sans；其他机器的字体差异可能影响版式，
如自动核对提示字号或排版差异，需要检查该项。

本步骤复现的是**冻结数据到图件**的过程，不会重跑控制器仿真、重新执行统计
自举，也不会生成原始 PX4 日志。完整的仿真与原始证据复核边界见上级复现说明。

精简时保留了 12 个主要对比，包含 native 平台重调参后 Full–Minimal 的跨零
区间（约 -0.000261 至 0.002893 m），不会将其改写为方向明确的结果。PX4 输入
也保留了 900 个设计中的 824 个完整记录、76 个接口或仿真失败，以及全部
1,291 次尝试的范围说明，其中 467 次未进入几何图。

486 个数值案例 JSON 被原有 `numerical_plot_values.csv` 代替，仅用于画图。
交付时已用 round-trip 浮点解析验证其中 1,800 行与原 JSON 计算出的表逐值完全
一致，并保留设计与汇总。它们均通过记录的有限数值检查，不代表统一数学误差界。
其余主要调整是省去未读取的大型清单、重复数据表和重复预览图，并将 PNG 默认
分辨率设为 150 dpi；科学绘图逻辑、观测、区间和坐标均未修改。

来源与修改范围记录在 `SOURCE_PROVENANCE.json`。`SOURCE_INPUT_SHA256.csv`
保存原归档成员哈希，其中两份输出模块经过上述适配，因此原始哈希用于追溯，
不能当成适配后文件的预期哈希。实际交付文件由上级复现包清单校验。
`SOURCE_README.md` 是原始附加包说明，其默认 1000 dpi 设置由本说明更新。

原始代码沿用 MIT（`LICENSE_CODE.txt`）；原始数据与图件沿用源附加包声明的
CC BY 4.0。第三方依赖遵守各自许可证。
