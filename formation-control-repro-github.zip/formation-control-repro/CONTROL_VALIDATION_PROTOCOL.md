# Controlled comparison and independent vehicle validation

This extension asks whether module effects depend on the physical input model
and on where controller parameters were selected. It does not require a
particular method to rank first. The prior experiment files remain frozen.

## Controllers and interfaces

Nino, Patil, Edwards and Dixon's distributed RISE law is implemented from
equations (3)--(8) of IEEE Control Systems Letters 9 (2025), 811--816,
doi:10.1109/LCSYS.2025.3576068. The source is available at
https://ncr.mae.ufl.edu/papers/CSL25.pdf. Its integral has no clipping, leakage,
smooth sign approximation or disabled term. In fixed-offset formation
coordinates, q_i is physical position minus the desired constant offset.
Raw follower/leader positions and velocities enter RISE once; degree-normalized
modular errors are never fed into its graph calculation.

The periodic modular adapter reproduces the original Minimal, Family and Full
PPT-off equations and internal updates. Family retains its own performance
transform and exponents. Full retains its gain schedule and exponents. Positive
gains are tuned, while exponents, basis features and module flags remain fixed.
The legacy API name `observer` denotes a leaky error filter, not a demonstrated
physical disturbance observer. In the common-information design, actuator
effectiveness is one and state refresh is periodic; no true disturbance, hidden
parameter or future state is sent to a controller.

All new main comparisons use an undirected ring with edge weights 0.35 and
unit leader pinning at every node. Outer requests are subject to the same
Euclidean force bound on each platform. Attitude/yaw allocation and physical
actuator bounds are shared deployment mechanisms. RISE's full-row-rank input
assumption is satisfied by the ideal second-order input map. Lagged and
underactuated runs are transfer tests; the source theorem is not asserted for
those deployments, arbitrary tuned gains, sampling, saturation or delays.

## Platforms and clocks

Native runs contain four quadrotors and four planar vessels for 16 s, at
1.2 m formation spacing. Outer, inner and production physics intervals are
20 ms, 1.25 ms and 1.25 ms. New physics uses float64 RK4 with quaternion attitude,
with fixed inner commands throughout each integration interval. This new cohort
does not overwrite the previous semi-implicit Euler cohort or certify the old
attack experiments by association. Numerical checks compare 1.25, 0.625 and
0.3125 ms, then 0.15625 ms where required, against segmented DOP853.

The independent platform uses four Otter vessels for 60 s at 6 m spacing.
The exact upstream revision is 6073346c86180087d3bca608b1aa2bc08be59708 of
https://github.com/cybergalactic/PythonVehicleSimulator. Original source and MIT
license are retained. A mechanically generated compilation view changes NumPy
syntax only and is checked against the original Python class. The dynamics,
payload, added mass, Coriolis terms, restoring terms, cross-flow drag and
asymmetric propeller characteristics are not replaced by the native USV model.

Otter outer and inner clocks are 50 ms and 10 ms. Physics is checked at
10, 5, 2.5 and 1.25 ms; production uses 2.5 ms. The ideal and lag layers are
study-defined controls, using the upstream surge mass M_11, surge damping D_11
isotropically and, for the lag layer, upstream T_n=0.1 s. They do not purport to
be official Fossen model variants. Controller coordinates use L_0=6 m and
T_0=6 s for all four methods, with F_0=M_11 L_0/T_0^2. The dimensionless request
bound is 8. The complete vessel uses upstream signed-square allocation plus a
common yaw PD with natural frequency 0.8 rad/s and damping ratio one. This
outer-to-propeller interface is an explicit study design, not the original
heading autopilot. Propeller commands obey the official physical speed bounds.

The vessel initial heave, roll and pitch are the upstream zero state. Payload
settling is retained. Initial planar velocity follows the reference plus paired
noise; initial heading aligns with that velocity. Initial position and trajectory
phase randomization are identical across methods and model layers for each seed.

## Parameter development and testing

The machine-readable protocol fixes disjoint training, validation, numerical and
test seed groups. Per method and platform, 64 candidates include the frozen
default plus 63 scrambled Sobol points. Stage one uses six training seed blocks,
two scenarios and three models (2,304 evaluations). The eight best candidates
for each model receive 12 new validation blocks and two scenarios (576
evaluations). Every method receives 2,880 tuning evaluations on each platform.
Failed numerical or incomplete evaluations consume budget. Equal evaluation
counts do not imply equal CPU time or control computation cost.

Development trajectories are straight and large-radius arc, with smooth native
disturbances and weak 0.03 m/s Otter current. Tests use ellipse, double-sine and
smooth variable-speed straight paths. Otter crosses these with 0, 0.10 and
0.20 m/s transverse currents. Each platform has 50 new test blocks. Parameters
and the full test design are frozen before testing. Full module deletions use
the same Full point-selected parameter background on every model.

The parameter ordering is failure count, scenario-equal mean J, then actual
force effort for errors within the measured default numerical resolution, then
candidate index. A nonfinite J cannot win a tie or be replaced by zero. Point
parameters are transferred unchanged; separately selected model parameters form
the retuned comparison. Test files are not arguments of either selection stage.

## Numerical and inferential limits

Independent DOP853 integration restarts at each inner update and uses quaternion
attitude, rtol=1e-9 and atol=1e-11. Representative cases are repeated at 1e-11 and
1e-13. Controller sampling is identical between integrators. The numerical
criterion for J is max(0.002 m, 1% of the reference magnitude), with at most 2%
relative force-effort difference. Full state discrepancies, event classifications
and saturation durations are also reported. The physics RHS is shared between
integrators; this is an integration check, whereas Otter supplies independent
physical-model evidence. Unresolved conditions remain in the limitation table.

Twelve primary contrasts are specified: for each platform, Full-minus-Minimal
and Full-minus-Family rigid-minus-point interactions under transfer and retuning
(eight); and schedule and signed-power deletion interactions in a fixed Full
parameter background (four). Paired seed-block means receive 20,000 bootstrap
resamples and simultaneous intervals over the full family. RISE performance,
lag-layer comparisons, force effort and scenario results are secondary. No
claim about prospective power is made for 50 blocks. A required missing or
nonfinite endpoint withholds the primary inference family. Finite large errors
remain in the analysis. Directional interpretation additionally requires a
contrast to exceed the combined numerical error bound of its constituent arms.

Physical boundary crossings, inversions, speed-domain flags, saturation and
unfinished jobs are distinct categories. Native response scale two remains a
pressure diagnostic without a ground-contact model. Original PX4 design counts,
failed attempts and unevaluated hypotheses keep their original status. None of
the new calculations is described as hardware, hardware-in-the-loop or flight
testing.
