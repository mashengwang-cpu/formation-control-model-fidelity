"""Portable entry points for the archived experiment and publication results."""
from pathlib import Path
import argparse,json,subprocess,sys
ROOT=Path(__file__).resolve().parent

def run(args,expected=0):
    result=subprocess.run([sys.executable,'-B',*map(str,args)],cwd=ROOT)
    if result.returncode!=expected:
        raise SystemExit(f'Unexpected return code {result.returncode}; expected {expected}')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['statistics','figures','theory','px4-statistics','simulate-all'])
    parser.add_argument('--workers',type=int,default=4)
    args=parser.parse_args()
    out=ROOT/'outputs';out.mkdir(exist_ok=True)
    if args.action=='statistics':
        run(['tools/revision_stats.py','--input','data/native/runs.csv','--manifest','data/native/planned_jobs.csv',
             '--plan','protocol/REVISION_STATISTICAL_ANALYSIS_PLAN.json','--output','outputs/statistics'])
        import pandas as pd
        names=['core_fixed','module_effect','cross_fidelity_interaction','attitude_scale_effect',
               'attitude_interaction','method_means','descriptive_contrasts']
        for name in names:
            pd.testing.assert_frame_equal(pd.read_csv(ROOT/'data/statistics'/f'{name}.csv'),
                pd.read_csv(out/'statistics'/f'{name}.csv'),check_exact=True)
        print('All seven statistical tables exactly reproduce the frozen numeric tables.')
    elif args.action=='figures':
        stats=out/'statistics'
        if not (stats/'analysis_status.json').exists():
            raise SystemExit('Run python reproduce.py statistics first; figures use those regenerated tables.')
        run(['tools/publication_figures.py','--statistics',stats,'--output',out/'figures'])
    elif args.action=='theory':
        run(['tools/verify_theorem_conditions.py','--output-json',out/'theorem_certificate.json'])
    elif args.action=='px4-statistics':
        cmd=['px4_interface/analysis.py']
        for c in ['h1_px4','h2_px4','h3_px4']:cmd+=['--results',f'data/px4_summary/recomputed/{c}']
        run([*cmd,'--output',out/'px4_statistics'],expected=2)
        status=json.loads((out/'px4_statistics/analysis_status.json').read_text(encoding='utf-8'))
        if set(status)!={'H1','H2','H3'} or any(v['status']!='blocked' for v in status.values()):
            raise SystemExit('The fixed failed-design accounting did not reproduce.')
        print('H1, H2 and H3 remain unevaluated under the frozen completeness rule.')
    elif args.action=='simulate-all':
        run(['simulation/run_revision.py','--design','data/native/design.json','--output','outputs/native_simulations',
             '--workers',args.workers])

if __name__=='__main__':main()
