"""Small, offline reproduction entry point. No full campaign runs by default."""
from pathlib import Path
import argparse, csv, gzip, hashlib, json, os, shutil, subprocess, sys, tarfile

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
os.environ.setdefault('MPLBACKEND', 'Agg')
os.environ['MPLCONFIGDIR'] = str(ROOT/'outputs/matplotlib_cache')
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMBA_NUM_THREADS'):
    os.environ[name] = '1'
SOURCE_DIRS = ('enhancement', 'simulation', 'tools', 'vendor', 'px4_interface', 'design', 'protocol', 'diagnostics', 'source_diagnostics')


def call(args, cwd, expected=0):
    print('+ python ' + ' '.join(map(str, args)), flush=True)
    result = subprocess.run([sys.executable, '-B', *map(str, args)], cwd=cwd)
    if result.returncode != expected:
        raise RuntimeError(f'Exit {result.returncode}; expected {expected}: {args}')


def verify():
    manifest = ROOT/'SHA256SUMS.json'
    if not manifest.exists():
        raise RuntimeError('Missing package SHA256SUMS.json')
    records = json.loads(manifest.read_text(encoding='utf-8'))
    for rel, expected in records.items():
        path=(ROOT/rel).resolve();path.relative_to(ROOT)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError('Package file changed: '+rel)
    print(f'Package SHA-256: {len(records)} files verified.', flush=True)
    return len(records)


def prepare(groups):
    workspace = ROOT/'outputs/workspace'
    workspace.mkdir(parents=True, exist_ok=True)
    # Copy only shipped sources. Scientific source bytes and frozen designs stay
    # untouched in the repository; every generated file is under ignored outputs/.
    for name in SOURCE_DIRS:
        for source in (ROOT/name).rglob('*'):
            if not source.is_file() or '__pycache__' in source.parts: continue
            target=workspace/source.relative_to(ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists() and target.read_bytes()!=source.read_bytes():
                raise RuntimeError(f'Workspace source was edited; use a fresh package extraction: {target}')
            if not target.exists():shutil.copy2(source,target)
    shutil.copy2(ROOT/'legacy_reproduce.py',workspace/'reproduce.py')
    with gzip.open(ROOT/'provenance/INPUT_MEMBERS.csv.gz','rt',encoding='utf-8',newline='') as f:
        expected={r['path']:r for r in csv.DictReader(f) if r['bundle'].removesuffix('.tar.xz') in groups}
    count=0
    for group in groups:
        seen=set()
        with tarfile.open(ROOT/'payloads'/f'{group}.tar.xz','r:xz') as archive:
            for member in archive:
                if not member.isfile() or member.name not in expected or member.name in seen:
                    raise RuntimeError('Unexpected archive member: '+member.name)
                seen.add(member.name)
                target=(workspace/member.name).resolve();target.relative_to(workspace.resolve())
                row=expected[member.name]
                if member.size!=int(row['bytes']):raise RuntimeError('Size mismatch: '+member.name)
                raw=archive.extractfile(member).read()
                if hashlib.sha256(raw).hexdigest()!=row['sha256']:
                    raise RuntimeError('Input hash mismatch: '+member.name)
                if target.exists():
                    if hashlib.sha256(target.read_bytes()).hexdigest()!=row['sha256']:
                        raise RuntimeError('An input was edited: '+member.name)
                else:
                    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
                count+=1
        expected_names={p for p,r in expected.items() if r['bundle']==group+'.tar.xz'}
        if seen!=expected_names:raise RuntimeError('Missing input members: '+group)
        print(f'{group}: {len(seen)} original inputs verified.',flush=True)
    # Original plotting code names this identical input snapshot separately.
    duplicate=workspace/'data/statistics/runs_snapshot.csv'
    if (workspace/'data/native/runs.csv').exists() and not duplicate.exists():
        shutil.copy2(workspace/'data/native/runs.csv',duplicate)
    return workspace, count


def results(workspace):
    import numpy as np
    import pandas as pd
    from coverage_check import check
    coverage=check(workspace)
    (ROOT/'outputs/coverage_verification.json').write_text(json.dumps(coverage,indent=2),encoding='utf-8')
    out=workspace/'outputs';out.mkdir(exist_ok=True)
    campaign='data/campaign/79b3058645f1'
    numerical='data/numerical/selected_dd57944609c8'
    call(['-m','enhancement.analysis','--campaign',campaign,'--numerical',numerical,'--output','outputs/controlled_analysis'],workspace)
    names=['designed_test_outcomes','paired_seed_blocks','primary_contrasts','secondary_method_summaries',
           'secondary_local_module_contrasts','secondary_paired_method_contrasts','secondary_scenario_summaries','failures']
    for name in names:
        pd.testing.assert_frame_equal(pd.read_csv(workspace/'data/analysis'/f'{name}.csv'),
                                      pd.read_csv(out/'controlled_analysis'/f'{name}.csv'),check_exact=True)
    for name in ('primary_family.json','summary.json'):
        assert json.loads((workspace/'data/analysis'/name).read_text())==json.loads((out/'controlled_analysis'/name).read_text()),name
    np.testing.assert_array_equal(np.load(workspace/'data/analysis/primary_contrast_blocks.npy'),
                                  np.load(out/'controlled_analysis/primary_contrast_blocks.npy'))
    call(['reproduce.py','statistics'],workspace)
    call(['reproduce.py','px4-statistics'],workspace)
    call(['reproduce.py','theory'],workspace)
    # Rebuild the eleven controlled-comparison supplement tables from recomputed
    # inferential outputs and the preserved timing / physical-event records.
    table_data=out/'table_inputs'
    (table_data/'campaign/79b3058645f1').mkdir(parents=True,exist_ok=True)
    (table_data/'analysis').mkdir(exist_ok=True)
    for p in (out/'controlled_analysis').iterdir():
        if p.is_file():shutil.copy2(p,table_data/'analysis'/p.name)
    shutil.copy2(workspace/'data/analysis/controller_computation_cost.json',table_data/'analysis/controller_computation_cost.json')
    shutil.copy2(workspace/campaign/'selection.json',table_data/'campaign/79b3058645f1/selection.json')
    (out/'tables/supp_sections').mkdir(parents=True,exist_ok=True)
    call(['-m','enhancement.result_tables','--data-root',table_data,'--submission',out/'tables','--audit','diagnostics'],workspace)
    report={'controlled_tables_exact':names,'controlled_primary_json_exact':True,'legacy_statistical_tables_exact':7,
            'px4_prescheduled_families':'H1/H2/H3 remain blocked; expected outcome',
            'raw_trajectory_reaudit':False,'full_campaign_rerun':False}
    (ROOT/'outputs/results_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('All retained inferential outputs match their frozen numeric references exactly.',flush=True)


def selection(workspace):
    import numpy as np
    sys.path.insert(0,str(workspace))
    from enhancement.campaign import shortlist, choose, testing_rows
    from enhancement.numerical_campaign import digest
    base=workspace/'data/campaign/79b3058645f1'
    protocol=json.loads((base/'protocol.json').read_text())
    train=[json.loads(p.read_text()) for p in sorted((base/'train/jobs').glob('*.json'))]
    validation=[json.loads(p.read_text()) for p in sorted((base/'validation/jobs').glob('*.json'))]
    differences=[]
    def compare(actual, expected, key=''):
        if isinstance(expected, dict):
            assert actual.keys()==expected.keys(),key
            for name in expected:
                if name!='selection_hash':compare(actual[name],expected[name],name)
        elif isinstance(expected,list):
            assert len(actual)==len(expected),key
            for a,b in zip(actual,expected):compare(a,b,key)
        elif key in {'mean_J_m','mean_force_effort_N2s'} and expected is not None:
            # Original parallel completion order is not a scientific factor.
            # Sorted replay can change reduction roundoff, not chosen parameters.
            np.testing.assert_allclose(actual,expected,rtol=1e-12,atol=1e-12,err_msg=key)
            differences.append(abs(actual-expected))
        else:assert actual==expected,key
    compare(shortlist(train,protocol),json.loads((base/'shortlist.json').read_text()))
    selected=choose(validation,protocol)
    archived=json.loads((base/'selection.json').read_text())
    assert archived['selection_hash']==digest({k:v for k,v in archived.items() if k!='selection_hash'})
    compare(selected,archived)
    frozen=json.loads((base/'test_design_frozen.json').read_text())
    assert frozen['design_hash']==digest({k:v for k,v in frozen.items() if k!='design_hash'})
    assert list(testing_rows(selected))==frozen['rows']
    report={'development_executions':len(train)+len(validation),'shortlist_candidate_order_exact':True,
            'selected_candidate_ids_and_parameters_exact':True,'independent_test_design_exact':True,
            'aggregate_tolerance':{'rtol':1e-12,'atol':1e-12},
            'maximum_aggregate_absolute_difference':max(differences),
            'note':'Sorted records change floating-point reduction order relative to historical parallel completion; decisions and full-precision parameters are exact.'}
    (ROOT/'outputs/selection_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report),flush=True)


def smoke(workspace):
    import numpy as np
    sys.path.insert(0,str(workspace))
    from enhancement.experiment import Job, run
    base=workspace/'data/campaign/79b3058645f1/test'
    design=json.loads((base/'design.json').read_text())
    sample={}
    for row in design['rows']:
        job=row['job'];key=(job['platform'],job['method'],job['model'])
        sample.setdefault(key,row)
    out=ROOT/'outputs/smoke';out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for key,row in sorted(sample.items()):
        expected=json.loads((base/'jobs'/(row['job_id']+'.json')).read_text())['metrics']
        actual,arrays=run(Job(**row['job']),row['parameters'],detailed=True)
        assert actual['complete']==expected['complete'],key
        errors={}
        for metric in ('J_m','force_effort_N2s','outer_updates','inner_updates','physics_steps'):
            np.testing.assert_allclose(actual[metric],expected[metric],rtol=1e-10,atol=1e-10,err_msg=str(key)+' '+metric)
            errors[metric]=abs(float(actual[metric])-float(expected[metric]))
        name='_'.join(key)
        np.savez_compressed(out/(name+'.npz'),**arrays)
        result={'group':key,'job_id':row['job_id'],'job':row['job'],'parameters':row['parameters'],
                'actual':actual,'reference':expected,'absolute_errors':errors}
        (out/(name+'.json')).write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
        rows.append(result)
        print(f'Smoke {len(rows)}/{len(sample)}: {name}, J={actual["J_m"]:.10g}',flush=True)
    report={'full_duration_simulations':len(rows),'platforms':2,'comparison_tolerance':{'atol':1e-10,'rtol':1e-10},
            'scope':'One archived condition per platform/method/model, including both deletions. This is not a full scientific rerun.',
            'maximum_absolute_J_difference':max(r['absolute_errors']['J_m'] for r in rows)}
    (ROOT/'outputs/smoke_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['verify','results','selection','smoke','test','figures','all'])
    parser.add_argument('--dpi',type=int,default=150,help='PNG export dpi; 150 for reading, 1000 for publication')
    args=parser.parse_args()
    verify()
    if args.action=='verify':return
    if args.action=='figures':
        call(['figure_reproduction/rebuild_publication_figures.py','--output',ROOT/'outputs/figures','--dpi',args.dpi],ROOT);return
    groups=['controlled','numerical','legacy','summaries']
    if args.action in {'selection','all'}:groups.append('development')
    if args.action=='test':groups=[]
    if args.action=='smoke':groups=['controlled']
    workspace,_=prepare(groups)
    if args.action in {'test','all'}:
        call(['-m','pytest','enhancement','-q'],workspace)
        call(['-c',"import sys; from pathlib import Path; sys.path.insert(0,'source_diagnostics/code'); import test_source as t; t.v.ROOT=Path('outputs/source_diagnostics_test'); (t.v.ROOT/'reports').mkdir(parents=True,exist_ok=True); t.main()"],workspace)
    if args.action in {'results','all'}:results(workspace)
    if args.action in {'selection','all'}:selection(workspace)
    if args.action in {'smoke','all'}:smoke(workspace)
    if args.action=='all':call(['figure_reproduction/rebuild_publication_figures.py','--output',ROOT/'outputs/figures','--dpi',args.dpi],ROOT)


if __name__=='__main__':main()
