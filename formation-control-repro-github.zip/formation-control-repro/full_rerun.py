"""Recompute the controlled cohort in a new, isolated workspace.

Place this helper in the compact repository root. The original frozen source
files are copied byte for byte; only the new workspace can receive rerun data
or a newly selected parameter vector. This is an expensive full experiment,
not the compact package's quick results replay or smoke test.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")


def checked_sources(repo):
    protocol = json.loads((repo / "design/protocol.json").read_text(encoding="utf-8"))
    body = {key: value for key, value in protocol.items() if key != "protocol_hash"}
    if digest(body) != protocol["protocol_hash"]:
        raise ValueError("Frozen protocol checksum does not match its contents")
    for group in ["dynamics_sources", "selection_sources"]:
        for name, expected in protocol[group].items():
            if Path(name).name != name:
                raise ValueError("Unexpected source filename in frozen protocol")
            actual = hashlib.sha256((repo / "enhancement" / name).read_bytes()).hexdigest()
            if actual != expected:
                raise ValueError("Frozen source differs: " + name)
    for name in ["enhancement", "design", "vendor", "simulation"]:
        source = repo / name
        if not source.is_dir():
            raise FileNotFoundError(source)
        for path in [source, *source.rglob("*")]:
            if path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction()):
                raise ValueError("Source tree contains a link or junction: " + str(path))
    return protocol


def serial_reference_tightening(workspace, numerical, output):
    """Use the original check function serially; its CLI otherwise fixes two workers."""
    sys.path.insert(0, str(workspace))
    from enhancement.reference_tightening import check

    output.mkdir(parents=True, exist_ok=False)
    records = []
    for path in sorted(numerical.glob("*.json")):
        if path.name in {"summary.json", "design.json"}:
            continue
        record = json.loads(path.read_text(encoding="utf-8"))
        job = record["job"]
        if (job["model"] == "rigid" and job["method"] in ["minimal", "rise"]
                and job["trajectory"] == "double_sine" and job["seed"] in [39002, 39102]
                and job["current"] == (0.0 if job["platform"] == "native" else 0.2)):
            records.append(record)
    if not 4 <= len(records) <= 8:
        raise ValueError("Unexpected number of reference-tightening cases: " + str(len(records)))
    results = [check((record, str(numerical), str(output))) for record in records]
    summary = {"cases": len(results),
               "passed": all(row["reference_comparison"]["pass"] for row in results),
               "results": results}
    write_json(output / "summary.json", summary)
    print(json.dumps({"reference_tightening_cases": len(results), "passed": summary["passed"]}), flush=True)
    # Failed scientific criteria stay in the result; only execution errors abort.


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("outputs/full_rerun"),
                        help="New output directory; an existing path is never reused")
    parser.add_argument("--workers", type=int, default=1,
                        help="Parallel simulation workers (default: 1)")
    parser.add_argument("--prepare-only", action="store_true",
                        help="Copy frozen sources and save the command plan without running experiments")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be at least 1")
    repo = Path(__file__).resolve().parent
    destination = args.output.expanduser().resolve()
    if destination.exists() or destination.is_symlink():
        parser.error("Output already exists; choose a new directory: " + str(destination))
    for source_name in ["enhancement", "design", "vendor", "simulation", "data"]:
        protected = (repo / source_name).resolve()
        if destination == protected or protected in destination.parents:
            parser.error("Output must be outside input/source directories")
    protocol = checked_sources(repo)
    destination.mkdir(parents=True, exist_ok=False)
    workspace = destination / "workspace"
    workspace.mkdir()
    ignored = shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", "*.nbc", "*.nbi", ".pytest_cache")
    for name in ["enhancement", "design", "vendor", "simulation"]:
        shutil.copytree(repo / name, workspace / name, ignore=ignored)
    for name in ["LICENSE_CODE.txt", "LICENSES.md", "SOFTWARE_SOURCES.md", "requirements.txt"]:
        if (repo / name).is_file():
            shutil.copy2(repo / name, workspace / name)
    checked_sources(workspace)
    (workspace / "tables/supp_sections").mkdir(parents=True)
    logs = destination / "logs"
    logs.mkdir()

    source_id = digest(protocol["dynamics_sources"])[:12]
    campaign = "data/campaign/" + protocol["protocol_hash"][:12]
    defaults = "data/numerical/defaults_" + source_id
    selected = "data/numerical/selected_" + source_id
    workers = str(args.workers)
    python = sys.executable
    steps = [
        ("contracts", [python, "-m", "pytest", "enhancement", "-q"]),
        ("default_numerics", [python, "-m", "enhancement.numerical_campaign", "--workers", workers, "--data-root", "data"]),
        ("development", [python, "-m", "enhancement.campaign", "develop", "--workers", workers, "--data-root", "data", "--numerical-folder", defaults]),
        ("selected_numerics", [python, "-m", "enhancement.numerical_campaign", "--workers", workers, "--data-root", "data", "--selection", campaign + "/selection.json"]),
        ("formal_test", [python, "-m", "enhancement.campaign", "test", "--workers", workers, "--data-root", "data", "--selected-numerical-folder", selected]),
        ("reference_tightening", None),
        ("analysis", [python, "-m", "enhancement.analysis", "--campaign", campaign, "--numerical", selected, "--output", "data/analysis"]),
        ("raw_audit", [python, "-m", "enhancement.audit_results", "--campaign", campaign, "--output", "diagnostics", "--workers", workers]),
        ("controller_timing", [python, "-m", "enhancement.computation_cost", "--selection", campaign + "/selection.json", "--output", "data/analysis/controller_computation_cost_refined.json"]),
        ("result_tables", [python, "-m", "enhancement.result_tables", "--data-root", "data", "--submission", "tables", "--audit", "diagnostics"]),
        ("figures", [python, "-m", "enhancement.figures", "--analysis", "data/analysis", "--numerical", selected, "--output", "figures"]),
    ]
    plan = {"created_utc": datetime.now(timezone.utc).isoformat(), "workspace": str(workspace),
            "protocol_hash": protocol["protocol_hash"], "source_id": source_id,
            "workers": args.workers, "status": "prepared",
            "scope": "23,040 development evaluations, 12,150 original unique formal-test executions, numerical checks, raw audit, analysis, timing, tables and controlled figures; no PX4 or legacy campaign",
            "scientific_note": "Execution completion is separate from numerical qualification and agreement with the archived paper; retain adverse or unresolved results. Newly computed timing is machine specific.",
            "steps": [{"name": name, "argv": command,
                       "call": None if command else "serial_reference_tightening(workspace, selected, data/numerical/selected_reference_tightening)"}
                      for name, command in steps]}
    plan_path = destination / "full_rerun_plan.json"
    write_json(plan_path, plan)
    print("Prepared isolated workspace: " + str(workspace), flush=True)
    print("This full computation can run for many hours and create tens of GB of raw arrays.", flush=True)
    if args.prepare_only:
        print("No experiment was run. Command plan: " + str(plan_path), flush=True)
        return
    env = os.environ.copy()
    for name in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]:
        env[name] = "1"
        os.environ[name] = "1"
    plan["status"] = "running"
    write_json(plan_path, plan)
    try:
        for index, (name, command) in enumerate(steps, 1):
            started = time.perf_counter()
            print(f"[{index}/{len(steps)}] {name}", flush=True)
            if command is None:
                serial_reference_tightening(workspace, workspace / selected,
                                           workspace / "data/numerical/selected_reference_tightening")
            else:
                with (logs / (name + ".log")).open("w", encoding="utf-8") as log:
                    process = subprocess.Popen(command, cwd=workspace, env=env,
                                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                               text=True, encoding="utf-8", errors="replace")
                    try:
                        for line in process.stdout:
                            log.write(line)
                            log.flush()
                            print(line, end="", flush=True)
                        returncode = process.wait()
                    except BaseException:
                        process.terminate()
                        process.wait()
                        raise
                    if returncode:
                        raise subprocess.CalledProcessError(returncode, command)
            plan["steps"][index - 1].update(status="executed", elapsed_seconds=time.perf_counter() - started)
            write_json(plan_path, plan)
    except BaseException as error:
        plan.update(status="interrupted_or_failed", error=type(error).__name__ + ": " + str(error))
        write_json(plan_path, plan)
        raise
    plan["status"] = "executed_all_steps"
    write_json(plan_path, plan)
    print("Full computation finished. Inspect data/analysis, diagnostics, tables and figures in " + str(workspace), flush=True)
    print("The compact repository's frozen inputs were preserved.", flush=True)


if __name__ == "__main__":
    main()
