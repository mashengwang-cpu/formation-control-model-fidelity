#!/usr/bin/env bash
# =============================================================================
# From-zero provisioning of the PX4 confirmatory environment inside WSL2.
#
# Target stack (PROTOCOL.md "Confirmatory phase"):
#   Ubuntu 22.04 (WSL2) + ROS2 Humble + PX4 v1.15 SITL + Gazebo Harmonic
#   + Micro XRCE-DDS Agent + px4_msgs (release/1.15)
#
# IMPORTANT - run this INSIDE an Ubuntu 22.04 WSL2 guest. If your default WSL
# distro is another release (ROS2 Humble has NO packages for newer Ubuntu
# releases), first create a dedicated distro from Windows PowerShell:
#
#   wsl --install -d Ubuntu-22.04
#   wsl -d Ubuntu-22.04
#   bash /path/to/package/Reproduction/px4_confirmatory/setup_wsl.sh
#
# Expected wall time: 45-90 min (network-dominated). Disk: ~15 GB.
# The script is re-runnable; completed steps are skipped where cheap to detect.
# =============================================================================
set -euo pipefail

step() { echo -e "\n\033[1;36m=== $* ===\033[0m"; }

if ! grep -q "22.04" /etc/os-release; then
    echo "ERROR: this script targets Ubuntu 22.04 (found: $(. /etc/os-release && echo "$PRETTY_NAME"))."
    echo "ROS2 Humble has no packages for other releases. See header for instructions."
    exit 1
fi

step "0/7 Base packages and UTF-8 locale (ROS2 requires it)"
sudo apt-get update
sudo apt-get install -y locales curl gnupg lsb-release git build-essential cmake \
    python3-pip python3-venv software-properties-common
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8

step "1/7 ROS2 Humble (desktop) + colcon"
if [ ! -f /opt/ros/humble/setup.bash ]; then
    sudo add-apt-repository -y universe
    sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
        -o /usr/share/keyrings/ros-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo "$UBUNTU_CODENAME") main" \
        | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
    sudo apt-get update
    sudo apt-get install -y ros-humble-desktop python3-colcon-common-extensions python3-rosdep
fi

step "2/7 Gazebo Harmonic (protocol-pinned simulator)"
# PITFALL: PX4 v1.15's Tools/setup/ubuntu.sh installs gz-garden by default on
# 22.04. The protocol pins Gazebo HARMONIC; install it explicitly and export
# GZ_VERSION=harmonic before every PX4 build/run.
if ! dpkg -s gz-harmonic >/dev/null 2>&1; then
    sudo curl -sSL https://packages.osrfoundation.org/gazebo.gpg \
        -o /usr/share/keyrings/pkgs-osrf-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/pkgs-osrf-archive-keyring.gpg] \
http://packages.osrfoundation.org/gazebo/ubuntu-stable $(lsb_release -cs) main" \
        | sudo tee /etc/apt/sources.list.d/gazebo-stable.list > /dev/null
    sudo apt-get update
    sudo apt-get install -y gz-harmonic
fi

step "3/7 Micro XRCE-DDS Agent (PX4 <-> ROS2 bridge)"
if ! command -v MicroXRCEAgent >/dev/null 2>&1; then
    cd "$HOME"
    git clone -b v2.4.3 https://github.com/eProsima/Micro-XRCE-DDS-Agent.git || true
    cd Micro-XRCE-DDS-Agent && mkdir -p build && cd build
    # PITFALL: fastdds version pinning; v2.4.3 builds cleanly on 22.04. If CMake
    # fails on fastcdr, delete build/ and retry after 'sudo apt install libasio-dev'.
    cmake .. && make -j"$(nproc)" && sudo make install && sudo ldconfig /usr/local/lib/
fi

step "4/7 PX4-Autopilot v1.15 + SITL toolchain"
if [ ! -d "$HOME/PX4-Autopilot" ]; then
    cd "$HOME"
    # PITFALL: --recursive is mandatory (50+ submodules); a shallow clone of a
    # release TAG keeps this ~2 GB instead of ~6 GB.
    git clone --branch v1.15.4 --recursive --shallow-submodules --depth 1 \
        https://github.com/PX4/PX4-Autopilot.git
fi
cd "$HOME/PX4-Autopilot"
# --no-nuttx: SITL only, skips the ARM cross-toolchain (saves ~10 min / 3 GB).
bash ./Tools/setup/ubuntu.sh --no-nuttx --no-sim-tools
# PITFALL: newer setuptools breaks kconfiglib/menuconfig on some images.
pip3 install --user "setuptools<70" kconfiglib jinja2 pyros-genmsg jsonschema

step "5/7 Build PX4 SITL (gz_x500 target)"
export GZ_VERSION=harmonic
make px4_sitl gz_x500 -j"$(nproc)" || {
    echo "Build failed. Common fixes: 'make distclean' then rebuild; ensure"
    echo "GZ_VERSION=harmonic; check free disk (need ~5 GB in ~/PX4-Autopilot)."
    exit 1
}
# Kill the interactive SITL instance the first build may leave running.
pkill -f "px4 -i" 2>/dev/null || true
pkill -f "gz sim" 2>/dev/null || true

step "6/7 ROS2 workspace with px4_msgs (release/1.15 = firmware-matched)"
# PITFALL: px4_msgs message hashes MUST match the firmware version, or every
# subscription silently receives nothing. v1.15 firmware <-> branch release/1.15.
mkdir -p "$HOME/px4_ros_ws/src"
cd "$HOME/px4_ros_ws/src"
[ -d px4_msgs ] || git clone -b release/1.15 https://github.com/PX4/px4_msgs.git
cd "$HOME/px4_ros_ws"
# shellcheck disable=SC1091
source /opt/ros/humble/setup.bash
colcon build --symlink-install
sudo apt-get install -y python3-numpy python3-pandas python3-scipy

step "7/7 Shell profile"
PROFILE_BLOCK='# --- px4_confirmatory environment ---
source /opt/ros/humble/setup.bash
source $HOME/px4_ros_ws/install/setup.bash
export GZ_VERSION=harmonic
export ROS_DOMAIN_ID=0'
grep -q "px4_confirmatory environment" "$HOME/.bashrc" || echo "$PROFILE_BLOCK" >> "$HOME/.bashrc"

cat <<'EOF'

=============================================================================
Setup complete. Smoke test (three terminals, or rely on mission_runner):

  # A) manual check
  MicroXRCEAgent udp4 -p 8888
  cd ~/PX4-Autopilot && HEADLESS=1 make px4_sitl gz_x500
  ros2 topic echo /fmu/out/vehicle_local_position   # data => bridge OK

  # B) automated smoke mission (writes ../px4_confirmatory/smoke_log.txt)
  cd /path/to/package/Reproduction/px4_confirmatory
  python3 mission_runner.py --backend px4 --smoke --px4-dir ~/PX4-Autopilot

Known WSL2 pitfalls (also in README.md):
  * WSLg provides Wayland/X11; HEADLESS=1 avoids GPU issues entirely.
  * If DNS fails in WSL: echo "nameserver 8.8.8.8" | sudo tee /etc/resolv.conf
  * uXRCE uses UDP 8888 on localhost inside WSL; no Windows firewall rule
    needed unless the agent runs on the Windows side.
  * Low real-time factor: check 'lockstep' is active (default for SITL); a
    slow RTF only stretches wall time, sim-time consistency is preserved.
  * 'ros2 topic list' empty: the px4_msgs workspace was not sourced in THIS
    shell, or message hashes mismatch (wrong px4_msgs branch).
  * Repeated runs: stray gz/px4 processes block ports; mission_runner kills
    them, manual runs may need 'pkill -f "gz sim"; pkill -f px4'.
=============================================================================
EOF
