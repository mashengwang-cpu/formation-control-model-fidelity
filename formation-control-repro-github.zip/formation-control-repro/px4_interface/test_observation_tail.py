import unittest
from interface_runtime import ClockGate,ObservationLogGate,InterfaceViolation
class ObservationTailTests(unittest.TestCase):
    def test_real_endpoint_bag_sequence_keeps_state_without_extra_command(self):
        epoch=33.176;obs=ObservationLogGate();control=ClockGate();control.observe_clock(epoch-1);control.release(epoch)
        # Actual sample/publication values from preserved v2 endpoint diagnosis.
        values=[(49.12,49.148,49.152),(49.128,49.156,49.160),(49.136,49.164,49.172),(49.144,49.172,49.180),(49.160,49.188,49.192),(49.168,49.196,49.212)]
        control.observe_clock(epoch+.01);control.step(epoch+.008,epoch+.008,16.)
        control.last_sample=49.12
        accepted=[];commands=[]
        for sample,publication,arrival_clock in values:
            self.assertTrue(obs.accept(publication,sample,arrival_clock,epoch,16.));accepted.append(sample-epoch)
            control.observe_clock(arrival_clock)
            tick=control.step(publication,sample,16.)
            if tick:commands.append(tick)
        self.assertEqual(len(accepted),6);self.assertAlmostEqual(accepted[-1],15.992)
        self.assertEqual(len(commands),0)
    def test_duplicates_counted_and_post_T_samples_excluded_without_relabel(self):
        g=ObservationLogGate();self.assertTrue(g.accept(26.008,25.992,26.032,10.,16.))
        self.assertFalse(g.accept(26.016,25.992,26.040,10.,16.));self.assertFalse(g.accept(26.024,26.004,26.044,10.,16.))
        self.assertEqual((g.receipts,g.duplicates,g.out_of_order),(2,1,0))
        self.assertAlmostEqual(g.last_sample,25.992)
    def test_out_of_order_and_epoch_domain_are_not_silently_removed(self):
        g=ObservationLogGate();g.accept(10.10,10.08,10.12,10.,16.)
        with self.assertRaises(InterfaceViolation):g.accept(10.11,10.07,10.13,10.,16.)
        self.assertEqual(g.out_of_order,1)
        with self.assertRaises(InterfaceViolation):g.accept(1788658763.,1788658762.,26.,10.,16.)
if __name__=='__main__':unittest.main()
