"""Isolate blocking native service calls from clock/pose callback Python GIL."""
import argparse,json,time
from gz.transport13 import Node
from gz.msgs10.world_control_pb2 import WorldControl
from gz.msgs10.boolean_pb2 import Boolean

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pause',choices=['true','false'],required=True);args=parser.parse_args()
    node=Node();msg=WorldControl();msg.pause=args.pause=='true'
    start=time.monotonic()
    ok,response=node.request('/world/default/control',msg,WorldControl,Boolean,2000)
    result={'service_success':bool(ok and response.data),'pause':msg.pause,'request_wall_s':start,'response_wall_s':time.monotonic()}
    print(json.dumps(result),flush=True)
    return 0 if result['service_success'] else 3

if __name__=='__main__':raise SystemExit(main())
