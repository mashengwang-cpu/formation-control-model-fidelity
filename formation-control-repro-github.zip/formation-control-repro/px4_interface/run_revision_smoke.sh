#!/usr/bin/env bash
set -e
REV_SRC="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REV_GUEST=/home/px4/px4_interface_revision_20260906/v21_runtime
mkdir -p "$REV_GUEST"
cp "$REV_SRC/"*.py "$REV_GUEST/"
source /opt/ros/humble/setup.bash
source /home/px4/px4_ros_ws/install/setup.bash
export GZ_VERSION=harmonic
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
cd "$REV_GUEST"
python3 -m unittest -v test_interface_runtime.py
python3 mission_runner.py --backend px4 --smoke --num-agents "${1:-1}" --seed-start 3900 \
  --px4-dir /home/px4/PX4-Autopilot --run-timeout-s 180 --instance-offset "${3:-60}" \
  --xrce-port "${4:-8898}" --ros-domain-id "${5:-82}" --max-retries 0 \
  --output "$REV_GUEST/${2:-smoke_single_v2}"
