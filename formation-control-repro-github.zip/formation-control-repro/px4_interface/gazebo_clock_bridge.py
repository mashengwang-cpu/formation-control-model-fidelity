"""Native gz-transport Clock -> ROS /clock; preserves original protobuf times.

Uses the installed Harmonic gz.transport13 and gz.msgs10 bindings. No CLI text
polling or wall-clock-derived simulation timestamps are used.
"""
import csv,json,sys,time,threading
from pathlib import Path

def main():
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import QoSProfile,ReliabilityPolicy,DurabilityPolicy,HistoryPolicy
    from rosgraph_msgs.msg import Clock as RosClock
    from gz.transport13 import Node as GzNode
    from gz.msgs10.clock_pb2 import Clock as GzClock
    from gz.msgs10.pose_v_pb2 import Pose_V
    from interface_runtime import atomic_json,read_json
    rclpy.init();node=Node('native_gazebo_clock_bridge_v2')
    node.declare_parameter('record_dir','clock_record')
    directory=Path(node.get_parameter('record_dir').value);directory.mkdir(parents=True,exist_ok=True)
    pub=node.create_publisher(RosClock,'/clock',QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT,durability=DurabilityPolicy.VOLATILE,history=HistoryPolicy.KEEP_LAST,depth=20))
    f=(directory/'gazebo_native_clock.csv').open('w',newline='');writer=csv.writer(f)
    writer.writerow(['sequence','gz_sim_s','gz_real_s','gz_system_s','wall_monotonic_s'])
    pose=(directory/'gazebo_world_poses.jsonl').open('w')
    lock=threading.Lock();state={'count':0,'pose_messages':0,'closed':False,'failure':None,'last_sim_s':None,'last_change_wall':time.monotonic()}
    gz=GzNode()
    def seconds(stamp):return float(stamp.sec)+float(stamp.nsec)*1e-9
    def clock_cb(msg):
        with lock:
            if state['closed'] or not rclpy.ok():return
            try:
                m=RosClock();m.clock.sec=int(msg.sim.sec);m.clock.nanosec=int(msg.sim.nsec)
                pub.publish(m)
                writer.writerow([state['count'],seconds(msg.sim),seconds(msg.real),seconds(msg.system),time.monotonic()])
                state['count']+=1
                sim=seconds(msg.sim)
                if state['last_sim_s']!=sim:state['last_change_wall']=time.monotonic()
                state['last_sim_s']=sim
                if state['count']%50==0:f.flush()
            except Exception as exc:state['failure']=str(exc)
    def pose_cb(msg):
        with lock:
            if state['closed']:return
            state['pose_messages']+=1
            payload={'gz_stamp_s':seconds(msg.header.stamp),'wall_monotonic_s':time.monotonic(),
                     'scope':'top_level_x500_world_poses',
                     'poses':[{'name':p.name,'id':p.id,'position':[p.position.x,p.position.y,p.position.z],
                               'quaternion_wxyz':[p.orientation.w,p.orientation.x,p.orientation.y,p.orientation.z]} for p in msg.pose if p.name.startswith('x500_') and p.name[5:].isdigit()]}
            pose.write(json.dumps(payload)+'\n')
    gz.subscribe(GzClock,'/clock',clock_cb)
    gz.subscribe(Pose_V,'/world/default/pose/info',pose_cb)
    gz.subscribe(Pose_V,'/world/default/dynamic_pose/info',pose_cb)
    handled=None
    try:
        while rclpy.ok() and state['failure'] is None:
            rclpy.spin_once(node,timeout_sec=.02)
            request=read_json(directory/'rendezvous'/'native_snapshot_request.json')
            if request and request['request_id']!=handled:
                with lock:
                    stable=state['last_sim_s'] is not None and time.monotonic()-state['last_change_wall']>=.15
                    sim=state['last_sim_s'];last_change=state['last_change_wall']
                if request['require_paused'] and not stable:continue
                handled=request['request_id']
                with lock:f.flush()
                result={**request,'gz_s':sim,'native_clock_stable':stable,'last_native_change_wall_s':last_change,'snapshot_wall_s':time.monotonic()}
                atomic_json(directory/'rendezvous'/f'native_snapshot_{handled}.json',result)
    except KeyboardInterrupt:pass
    finally:
        for topic in ('/clock','/world/default/pose/info','/world/default/dynamic_pose/info'):
            gz.unsubscribe(topic)
        del gz
        with lock:
            state['closed']=True;f.close();pose.close()
        (directory/'clock_bridge_summary.json').write_text(json.dumps(state,indent=2))
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()
    return 3 if state['failure'] else 0

if __name__=='__main__':raise SystemExit(main())
