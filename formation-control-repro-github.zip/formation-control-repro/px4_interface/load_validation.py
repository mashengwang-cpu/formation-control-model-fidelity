"""Bounded real SITL load validation; all missions use a technical pilot seed."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
def main():
    p=argparse.ArgumentParser();p.add_argument('--parallel',type=int,choices=[1,2,4,8],required=True)
    p.add_argument('--speed',type=float,default=1.);p.add_argument('--label',required=True);a=p.parse_args()
    root=Path(__file__).resolve().parent;out=root/a.label;out.mkdir(exist_ok=False)
    start=time.monotonic();record={'parallel':a.parallel,'speed_requested':a.speed,'pilot_seed':3900,'cpu_count':os.cpu_count(),'load_start':os.getloadavg(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'workers':[]}
    jobs=[]
    for i in range(a.parallel):
        cmd=[sys.executable,str(root/'mission_runner.py'),'--backend','px4','--smoke','--num-agents','3','--seed-start','3900','--px4-dir','/home/px4/PX4-Autopilot','--run-timeout-s','300','--instance-offset',str(60+i*10),'--xrce-port',str(8898+i),'--ros-domain-id',str(82+i),'--max-retries','0','--simulation-speed',str(a.speed),'--output',str(out/f'worker_{i}')]
        log=(out/f'worker_{i}.log').open('w');proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
        jobs.append((proc,log));record['workers'].append({'index':i,'command':cmd,'pid':proc.pid})
    (out/'load_started.json').write_text(json.dumps(record,indent=2))
    for i,(proc,log) in enumerate(jobs):
        record['workers'][i]['returncode']=proc.wait();log.close()
    record.update(wall_elapsed_s=time.monotonic()-start,load_end=os.getloadavg(),finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    (out/'load_completed.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2),flush=True)
    return 0 if all(w['returncode']==0 for w in record['workers']) else 3
if __name__=='__main__':raise SystemExit(main())
