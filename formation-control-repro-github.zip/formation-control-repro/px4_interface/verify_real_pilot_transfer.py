from pathlib import Path
import json
from transfer_archive import transfer_attempt
root=Path('/home/px4/px4_interface_revision_20260906/load_two_fresh_i/worker_0')
src=next(root.rglob('attempt_result.json')).parent
dest=Path(__file__).resolve().parents[2]/'evidence'/'px4_validation_transfer_test_v2'/src.name
report=transfer_attempt(src,dest,False)
print(json.dumps({k:v for k,v in report.items() if k!='files'},indent=2))
