"""Confirmatory-phase analysis per Reproduction/PROTOCOL.md (H1-H3).

Requires numpy + pandas and scipy for scientific inference. No ROS2 imports.

Frozen hypotheses (PROTOCOL.md, "Confirmatory phase"):

- H1 (primary): the distilled minimal stack (proposed_minimal_causal)
  attains lower pooled J than the family baseline
  (recent_2025_resilient_fixed_time) across the five protocol scenarios at
  matched controller gains and measurement thresholds. Seed-paired two-sided Wilcoxon on seed-block means,
  n = 20 seeds, alpha 0.05 Holm-adjusted over {J, commanded energy,
  update count}. BCa 95% intervals on paired mean differences; win rates.
- H2: knockout fidelity ordering (TVG worst, then signed powers,
  approximator, observer; "worst" = largest error reduction when the module is
  removed, i.e. the most negative knockout delta) preserved in sign;
  descriptive Kendall tau with bootstrap CI, no significance claim.
- H3: gated causal estimator within 10% pooled J of the oracle contract.

Interface-v2.1 metrics use separate complete authentic state streams, actual
command-publication rows, and independently counted transport events. J and
ZOH effort share their observed intersection; no state extrapolation occurs.
The final command is held only within the declared mission stop. New scientific
inference requires all seeds 5000..5019 and the five scenarios. Older cohorts,
technical pilots, failures and incomplete blocks cannot support this inference.

Usage:
  py -3.12 analysis.py --results results/h1_px4 [--results results/h3_px4 ...]
  py -3.12 analysis.py --metrics results/h1_stub/metrics.csv
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from scipy import stats as _scipy_stats

    SCIPY_AVAILABLE = True
except ImportError:  # pragma: no cover
    _scipy_stats = None
    SCIPY_AVAILABLE = False

H1_REFERENCE = "proposed_minimal_causal"
H1_COMPARATOR = "recent_2025_resilient_fixed_time"
H1_METRICS = ["J", "control_energy", "event_trigger_count"]
H2_BASE = "proposed_no_ppt"
# PROTOCOL.md H2 frozen numpy ordering, worst knockout first.
H2_REFERENCE_ORDER = ["hifi_ko_tvg", "hifi_ko_powers", "hifi_ko_approximator", "hifi_ko_observer"]
H3_METHOD = "proposed_minimal_causal"
H3_TOLERANCE = 0.10
ALPHA = 0.05
ERROR_TOLERANCE = 0.08  # settling tolerance, stage2_final.json
SCENARIOS = {"nominal", "actuator_fault", "fdi_attack", "dos_attack", "combined_attack_fault"}
V21_SCIENTIFIC_SEEDS = set(range(5000, 5020))


# ----------------------------------------------------------------------------
# Per-run metrics from mission CSV logs
# ----------------------------------------------------------------------------
from v21_metrics import load_run_log, metrics_from_agent_logs, SCHEMA


def build_metrics_table(manifest_path: Path | str) -> pd.DataFrame:
    """Retain failed missions and missing streams without replacement or deletion."""
    manifest = pd.read_csv(manifest_path)
    records = []
    for _, row in manifest.iterrows():
        record = {key: row[key] for key in
                  ["run_id", "method", "scenario", "seed", "contract", "num_agents", "backend", "status"]}
        record["metrics_schema_version"] = SCHEMA
        paths = [Path(p) for p in str(row["csv_paths"]).split(";") if p and p != "nan"]
        if str(row["status"]) == "ok":
            try:
                if len(paths) != int(row["num_agents"]):
                    raise ValueError("Missing per-agent command log paths")
                record.update(metrics_from_agent_logs([load_run_log(path) for path in paths]))
                if not record["protocol_window_complete"]:
                    record["status"] = "incomplete_observation_window"
            except (ValueError, KeyError, FileNotFoundError) as exc:
                record["status"] = "analysis_failure"
                record["metrics_error"] = str(exc)
        records.append(record)
    return pd.DataFrame.from_records(records)


# ----------------------------------------------------------------------------
# Inference primitives (ports of finite_control_sim/statistics.py)
# ----------------------------------------------------------------------------
def wilcoxon_signed_rank(x: np.ndarray, y: np.ndarray) -> tuple[float, float, str]:
    """Two-sided paired Wilcoxon, zero_method='wilcox'. Returns
    (statistic, p, engine)."""
    if np.all(np.asarray(x) == np.asarray(y)):
        return 0.0, 1.0, "all_zero_paired_differences"
    if SCIPY_AVAILABLE:
        try:
            result = _scipy_stats.wilcoxon(x, y, zero_method="wilcox", alternative="two-sided")
            return float(result.statistic), float(result.pvalue), "scipy"
        except Exception:
            return math.nan, math.nan, "scipy_failed"
    diff = np.asarray(x, dtype=float) - np.asarray(y, dtype=float)
    diff = diff[np.isfinite(diff) & (diff != 0.0)]
    n = diff.size
    if n < 6:
        return math.nan, math.nan, "fallback_too_small"
    order = np.argsort(np.abs(diff))
    ranks = np.empty(n, dtype=float)
    sorted_abs = np.abs(diff)[order]
    i = 0
    while i < n:  # average ranks over ties
        j = i
        while j + 1 < n and sorted_abs[j + 1] == sorted_abs[i]:
            j += 1
        ranks[order[i : j + 1]] = 0.5 * (i + j) + 1.0
        i = j + 1
    w_plus = float(np.sum(ranks[diff > 0.0]))
    mean = n * (n + 1) / 4.0
    variance = n * (n + 1) * (2 * n + 1) / 24.0
    z = (w_plus - mean) / math.sqrt(variance)
    p = 2.0 * (1.0 - 0.5 * (1.0 + math.erf(abs(z) / math.sqrt(2.0))))
    return w_plus, min(p, 1.0), "normal_approx_fallback"


def holm_adjust(p_values: np.ndarray) -> np.ndarray:
    array = np.asarray(p_values, dtype=float)
    adjusted = np.full(array.shape, np.nan, dtype=float)
    valid = np.where(np.isfinite(array))[0]
    order = valid[np.argsort(array[valid])]
    running = 0.0
    m = len(order)
    for rank, index in enumerate(order):
        value = min((m - rank) * array[index], 1.0)
        running = max(running, value)
        adjusted[index] = running
    return adjusted


def bca_mean_ci(values: np.ndarray, samples: int = 20000, confidence: float = 0.95,
                seed: int = 1234) -> tuple[float, float, float]:
    array = np.asarray(values, dtype=float)
    array = array[np.isfinite(array)]
    n = array.size
    if n == 0:
        return math.nan, math.nan, math.nan
    theta = float(np.mean(array))
    if n == 1:
        return theta, theta, theta
    rng = np.random.default_rng(seed)
    boots = np.mean(rng.choice(array, size=(samples, n), replace=True), axis=1)
    alpha = 1.0 - confidence
    if not SCIPY_AVAILABLE:  # percentile fallback, flagged by caller
        return theta, float(np.quantile(boots, alpha / 2)), float(np.quantile(boots, 1 - alpha / 2))
    jack = (np.sum(array) - array) / (n - 1)
    d = float(np.mean(jack)) - jack
    den = float(np.sum(d**2))
    acc = float(np.sum(d**3) / (6.0 * den**1.5)) if den > 0.0 else 0.0
    prop = float(np.mean(boots < theta))
    prop = min(max(prop, 1.0 / (samples + 1.0)), 1.0 - 1.0 / (samples + 1.0))
    z0 = float(_scipy_stats.norm.ppf(prop))
    z_lo = float(_scipy_stats.norm.ppf(alpha / 2))
    z_hi = float(_scipy_stats.norm.ppf(1 - alpha / 2))

    def _endpoint(z_alpha: float) -> float:
        denom = 1.0 - acc * (z0 + z_alpha)
        if abs(denom) < 1e-12:
            return float(np.quantile(boots, 0.5))
        adjusted = float(_scipy_stats.norm.cdf(z0 + (z0 + z_alpha) / denom))
        return float(np.quantile(boots, min(max(adjusted, 0.0), 1.0)))

    return theta, _endpoint(z_lo), _endpoint(z_hi)


def kendall_tau(observed_order: list[str], reference_order: list[str]) -> float:
    """Kendall tau between two rankings of the same items."""
    ref_rank = {name: i for i, name in enumerate(reference_order)}
    obs_rank = {name: i for i, name in enumerate(observed_order)}
    items = list(reference_order)
    concordant = discordant = 0
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            a, b = items[i], items[j]
            s1 = np.sign(ref_rank[a] - ref_rank[b])
            s2 = np.sign(obs_rank[a] - obs_rank[b])
            if s1 * s2 > 0:
                concordant += 1
            elif s1 * s2 < 0:
                discordant += 1
    pairs = len(items) * (len(items) - 1) / 2
    return (concordant - discordant) / pairs if pairs else math.nan


# ----------------------------------------------------------------------------
# Hypothesis evaluations
# ----------------------------------------------------------------------------
def seed_block_means(frame: pd.DataFrame, metrics: list[str]) -> pd.DataFrame:
    """Seed-block means pooled over scenarios (the protocol pairing unit)."""
    if "protocol_window_complete" in frame and not frame["protocol_window_complete"].map(lambda value: str(value).lower() == "true").all():
        raise ValueError("Incomplete observed mission windows block inference; do not silently drop them.")
    if not frame["status"].astype(str).str.startswith("ok").all() or not np.isfinite(frame[metrics].to_numpy(float)).all():
        raise ValueError("Failed or missing mission metrics block inference; preserve failure rows.")
    keys = ["method", "contract", "seed", "scenario"]
    if frame.duplicated(keys).any():
        raise ValueError("Duplicate method/contract/seed/scenario observations block pairing.")
    scenario_sets = frame.groupby(["method", "contract", "seed"]).scenario.agg(set)
    if any(value != SCENARIOS for value in scenario_sets):
        raise ValueError("Every seed block must contain exactly the five prespecified scenarios.")
    return frame.groupby(["method", "contract", "seed"], as_index=False)[metrics].mean()


def is_interface_v21(frame: pd.DataFrame) -> bool:
    return "metrics_schema_version" in frame and frame.metrics_schema_version.eq("px4-interface-v2.1").any()


def require_complete_protocol(frame: pd.DataFrame, arms: list[tuple[str, str]]) -> pd.DataFrame:
    """Only complete, successful v2.1 seed blocks can enter new inference."""
    scope = frame[[pair in arms for pair in zip(frame.method, frame.contract)]].copy()
    if scope.empty:
        raise ValueError("Required hypothesis arms are absent")
    if not SCIPY_AVAILABLE:
        raise ValueError("New interface-v2.1 inference requires scipy; no fallback test or CI")
    required = ["metrics_schema_version", "backend", "num_agents", "status",
                "protocol_window_complete", "event_streams_validated"]
    if set(required)-set(scope.columns):
        raise ValueError("Required v2.1 identity or metric-validation fields are missing")
    if not scope.metrics_schema_version.eq(SCHEMA).all():
        raise ValueError("Older or mixed cohorts cannot enter v2.1 inference")
    if not scope.backend.eq("px4").all() or not scope.num_agents.eq(3).all():
        raise ValueError("New inference requires real three-UAV PX4 missions")
    if not scope.status.eq("ok").all():
        raise ValueError("Failed missions are retained and block the affected hypothesis")
    for field in ["protocol_window_complete", "event_streams_validated"]:
        if not scope[field].map(lambda value: str(value).lower() == "true").all():
            raise ValueError("Incomplete or unvalidated real streams block inference")
    actual = set(zip(scope.method, scope.contract, scope.seed, scope.scenario))
    expected = {(method, contract, seed, scenario) for method, contract in arms
                for seed in V21_SCIENTIFIC_SEEDS for scenario in SCENARIOS}
    if len(scope) != len(expected) or actual != expected:
        raise ValueError(f"Incomplete or unexpected paired design: expected {len(expected)} rows, observed {len(scope)}; missing {len(expected-actual)}, extra {len(actual-expected)}")
    return scope


def paired_effect_labels(diff: np.ndarray) -> dict[str, float]:
    values = np.asarray(diff, dtype=float)
    walsh = (values[:, None] + values[None, :])[np.triu_indices(len(values))] / 2
    nonzero = values[values != 0]
    if len(nonzero):
        ranks = _scipy_stats.rankdata(np.abs(nonzero), method="average")
        rank_biserial = float(np.sum(ranks * np.sign(nonzero)) / ranks.sum())
    else:
        rank_biserial = 0.0
    return {"median_difference": float(np.median(values)),
            "hodges_lehmann_walsh": float(np.median(walsh)),
            "paired_rank_biserial": rank_biserial}


def evaluate_h1(frame: pd.DataFrame) -> tuple[pd.DataFrame, str]:
    frame = _campaign_rows(frame, "h1")
    frame = require_complete_protocol(frame, [(H1_REFERENCE, "causal"), (H1_COMPARATOR, "causal")])
    blocks = seed_block_means(frame, H1_METRICS)
    records = []
    for metric in H1_METRICS:
        pivot = blocks.pivot_table(index="seed", columns="method", values=metric)
        if H1_REFERENCE not in pivot.columns or H1_COMPARATOR not in pivot.columns:
            return pd.DataFrame(), "H1: required arms missing from the metrics table."
        paired = pivot[[H1_REFERENCE, H1_COMPARATOR]].dropna()
        ref = paired[H1_REFERENCE].to_numpy(dtype=float)
        comp = paired[H1_COMPARATOR].to_numpy(dtype=float)
        diff = ref - comp
        statistic, p_value, engine = wilcoxon_signed_rank(ref, comp)
        if not np.isfinite(p_value):
            raise ValueError("Wilcoxon failed; the Holm family is blocked rather than shortened.")
        mean_diff, ci_low, ci_high = bca_mean_ci(diff)
        records.append({
            "hypothesis": "H1", "metric": metric, "paired_seeds": int(len(paired)),
            "wilcoxon_statistic": statistic, "p_value": p_value,
            "mean_diff_ref_minus_comp": mean_diff,
            "bca95_low": ci_low, "bca95_high": ci_high,
            "reference_win_rate": float(np.mean(diff < 0.0)),
            "engine": engine,
            **(paired_effect_labels(diff) if SCIPY_AVAILABLE else {}),
        })
    table = pd.DataFrame.from_records(records)
    table["holm_adjusted_p"] = holm_adjust(table["p_value"].to_numpy(dtype=float))
    j_row = table[table["metric"] == "J"].iloc[0]
    n_seeds = int(j_row["paired_seeds"])
    if n_seeds < 6:
        verdict = f"H1: INSUFFICIENT DATA ({n_seeds} paired seeds; protocol requires 20)."
    elif j_row["holm_adjusted_p"] < ALPHA and j_row["mean_diff_ref_minus_comp"] < 0.0:
        verdict = (f"H1 SUPPORTED: minimal stack pooled J lower than family baseline "
                   f"(Holm-adjusted p = {j_row['holm_adjusted_p']:.4g}, n = {n_seeds}).")
    elif j_row["holm_adjusted_p"] < ALPHA:
        verdict = (f"H1 REVERSED: significant difference in the WRONG direction "
                   f"(Holm-adjusted p = {j_row['holm_adjusted_p']:.4g}).")
    else:
        verdict = (f"H1 NOT SUPPORTED at alpha={ALPHA} "
                   f"(Holm-adjusted p = {j_row['holm_adjusted_p']:.4g}, n = {n_seeds}).")
    if n_seeds != 20:
        verdict += f" [deviation: {n_seeds} seeds instead of the prespecified 20]"
    return table, verdict


def evaluate_h2(frame: pd.DataFrame, bootstrap_samples: int = 20000, seed: int = 1234) -> tuple[pd.DataFrame, str]:
    frame = _campaign_rows(frame, "h2")
    frame = require_complete_protocol(frame, [(method, "causal") for method in [H2_BASE, *H2_REFERENCE_ORDER]])
    blocks = seed_block_means(frame, ["J"])
    have = set(blocks["method"])
    needed = set(H2_REFERENCE_ORDER) | {H2_BASE}
    if not needed.issubset(have):
        return pd.DataFrame(), f"H2: knockout arms missing ({sorted(needed - have)}); run --campaign h2."
    pivot = blocks.pivot_table(index="seed", columns="method", values="J").dropna()
    # delta = J(knockout) - J(full stack without PPT): NEGATIVE when removing the
    # module lowers the error, i.e. when the module is harmful on this plant.
    deltas = {ko: (pivot[ko] - pivot[H2_BASE]).to_numpy(dtype=float) for ko in H2_REFERENCE_ORDER}
    pooled = {ko: float(np.mean(v)) for ko, v in deltas.items()}
    # PROTOCOL.md H2: "TVG worst, then signed powers, approximator, observer" is
    # the numpy rigid-body ordering by the improvement obtained when the module
    # is removed (numpy deltas -0.507, -0.362, -0.290, -0.260 m). "Worst module
    # first" therefore means the MOST NEGATIVE delta first. (The pre-campaign
    # version of this function sorted in the opposite direction, which would
    # have scored the numpy reference data itself at tau = -1; corrected after
    # the campaign, documented in README.md and Supplementary Note S14.)
    observed_order = sorted(H2_REFERENCE_ORDER, key=lambda ko: pooled[ko])
    tau = kendall_tau(observed_order, H2_REFERENCE_ORDER)

    rng = np.random.default_rng(seed)
    n_seeds = len(pivot)
    taus = []
    for _ in range(bootstrap_samples):
        idx = rng.integers(0, n_seeds, size=n_seeds)
        boot_pooled = {ko: float(np.mean(deltas[ko][idx])) for ko in H2_REFERENCE_ORDER}
        boot_order = sorted(H2_REFERENCE_ORDER, key=lambda ko: boot_pooled[ko])
        taus.append(kendall_tau(boot_order, H2_REFERENCE_ORDER))
    ci_low, ci_high = float(np.quantile(taus, 0.025)), float(np.quantile(taus, 0.975))

    table = pd.DataFrame({
        "hypothesis": "H2",
        "knockout": H2_REFERENCE_ORDER,
        "pooled_J_delta_vs_base": [pooled[ko] for ko in H2_REFERENCE_ORDER],
        "observed_rank_worst_first": [observed_order.index(ko) + 1 for ko in H2_REFERENCE_ORDER],
        "reference_rank_worst_first": list(range(1, len(H2_REFERENCE_ORDER) + 1)),
    })
    table["kendall_tau"] = tau
    table["tau_bootstrap95_low"] = ci_low
    table["tau_bootstrap95_high"] = ci_high
    signs_ok = all(pooled[ko] < 0.0 for ko in H2_REFERENCE_ORDER)
    verdict = (f"H2 (descriptive): Kendall tau = {tau:.3f} "
               f"[bootstrap 95% CI {ci_low:.3f}, {ci_high:.3f}] vs frozen numpy ordering "
               f"(worst module = most negative knockout delta first); "
               f"all knockout deltas negative as on the numpy plant (every module's removal lowers J): {signs_ok}. "
               "No significance claim.")
    return table, verdict


def evaluate_h3(frame: pd.DataFrame) -> tuple[pd.DataFrame, str]:
    frame = _campaign_rows(frame, "h3")
    subset = require_complete_protocol(frame, [(H3_METHOD, "causal"), (H3_METHOD, "oracle")])
    blocks = seed_block_means(subset, ["J"])
    pivot = blocks.pivot_table(index="seed", columns="contract", values="J")
    if "causal" not in pivot.columns or "oracle" not in pivot.columns:
        return pd.DataFrame(), "H3: causal and oracle contract runs required; run --campaign h3."
    paired = pivot[["causal", "oracle"]].dropna()
    j_causal = float(paired["causal"].mean())
    j_oracle = float(paired["oracle"].mean())
    if not SCIPY_AVAILABLE:
        raise RuntimeError("Correct paired-ratio BCa analysis requires scipy; no silent CI fallback.")
    x = paired["causal"].to_numpy(float)
    y = paired["oracle"].to_numpy(float)
    if len(x) < 2 or not (np.isfinite(x).all() and np.isfinite(y).all()) or np.any(y <= 0):
        raise ValueError("H3 requires finite paired seed blocks and positive oracle denominators.")
    gap = (j_causal - j_oracle) / j_oracle
    ratio_ci = _scipy_stats.bootstrap(
        (x, y), lambda a, b, axis: (np.mean(a, axis=axis)-np.mean(b, axis=axis))/np.mean(b, axis=axis),
        paired=True, method="BCa", confidence_level=0.95, n_resamples=20000, random_state=1234,
    )
    ci_low = float(ratio_ci.confidence_interval.low)
    ci_high = float(ratio_ci.confidence_interval.high)
    if not np.isfinite([ci_low, ci_high]).all():
        raise ValueError("H3 BCa interval is undefined; no tolerance conclusion is issued")
    table = pd.DataFrame.from_records([{
        "hypothesis": "H3", "paired_seeds": int(len(paired)),
        "pooled_J_causal": j_causal, "pooled_J_oracle": j_oracle,
        "relative_gap": gap, "gap_bca95_low": ci_low, "gap_bca95_high": ci_high,
        "tolerance": H3_TOLERANCE,
        "interval_method": "BCa_ratio_of_paired_seed_block_means",
        "bootstrap_samples": 20000, "bootstrap_seed": 1234,
        "point_estimate_within_tolerance": gap <= H3_TOLERANCE,
        "upper95_within_tolerance": ci_high <= H3_TOLERANCE,
        "analysis_version": "revision_20260906_new_locally_frozen_interface_v21" if is_interface_v21(subset) else "revision_20260906_historical_reanalysis",
    }])
    verdict = (f"H3 corrected descriptive analysis: pooled J gap = {100 * gap:.2f}% "
               f"[paired-ratio BCa 95% CI {100*ci_low:.2f}%, {100*ci_high:.2f}%], "
               f"n = {len(paired)} seeds; point estimate within 10%: {gap <= H3_TOLERANCE}; "
               f"95% upper limit within 10%: {ci_high <= H3_TOLERANCE}. "
               + ("New locally frozen interface-v2.1 design; the pointwise interval and tolerance check are reported separately."
                if is_interface_v21(subset) else "The corrected interval is a disclosed reanalysis, not a retroactive preregistration."))
    return table, verdict


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
def _collect_metrics(results_dirs: list[Path], metrics_files: list[Path]) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for directory in results_dirs:
        # A campaign may have been executed by several sharded runners, each
        # writing metrics_<k>_of_<n>.csv; concatenate whatever is present.
        # Files named firstpass_* are superseded manifests kept for the record.
        metrics_files_here = sorted(p for p in directory.glob("metrics*.csv"))
        manifests_here = sorted(p for p in directory.glob("runs_index*.csv"))
        if metrics_files_here:
            loaded = [pd.read_csv(p) for p in metrics_files_here]
        elif manifests_here:
            loaded = [build_metrics_table(p) for p in manifests_here]
        else:
            raise FileNotFoundError(f"No metrics*.csv or runs_index*.csv under {directory}")
        for frame in loaded:
            # Tag the campaign directory: H1 and H3 both contain causal missions
            # of the minimal stack, so when several campaigns are analysed in
            # one call each hypothesis must be evaluated on its own campaign.
            frame["source_dir"] = directory.name
        frames.extend(loaded)
    for file in metrics_files:
        frame = pd.read_csv(file)
        frame["source_dir"] = file.parent.name
        frames.append(frame)
    if not frames:
        raise ValueError("Provide at least one --results directory or --metrics file.")
    return pd.concat(frames, ignore_index=True)


def _campaign_rows(frame: pd.DataFrame, campaign: str) -> pd.DataFrame:
    """Rows of the given campaign ('h1' | 'h2' | 'h3') when the frame carries a
    source_dir tag and such a directory is present; otherwise the whole frame
    (single-campaign analyses are unaffected)."""
    if "source_dir" not in frame.columns:
        return frame
    mask = frame["source_dir"].astype(str).str.lower().str.startswith(campaign)
    return frame[mask] if mask.any() else frame


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--results", action="append", default=[],
                        help="campaign output directory (repeatable)")
    parser.add_argument("--metrics", action="append", default=[],
                        help="pre-built metrics.csv (repeatable)")
    parser.add_argument("--output", default=None, help="directory for conclusions (default: first --results)")
    args = parser.parse_args()

    results_dirs = [Path(p) for p in args.results]
    metrics_files = [Path(p) for p in args.metrics]
    frame = _collect_metrics(results_dirs, metrics_files)
    v2 = is_interface_v21(frame)
    out_dir = Path(args.output) if args.output else Path(__file__).resolve().parents[1] / "data" / "revision_statistics" / ("px4_interface_v21" if v2 else "px4_historical")
    out_dir.mkdir(parents=True, exist_ok=True)

    backends = sorted(set(frame["backend"].astype(str)))
    warnings: list[str] = []
    if backends != ["px4"]:
        warnings.append(
            f"WARNING: backends present = {backends}. Only backend=px4 runs constitute "
            "confirmatory evidence; stub runs are pipeline self-tests."
        )
    if not SCIPY_AVAILABLE:
        warnings.append("WARNING: scipy unavailable -> Wilcoxon uses a normal approximation "
                        "and CIs are percentile bootstrap, both flagged in the tables.")
    excluded = frame[~frame["status"].astype(str).str.startswith("ok")]
    if len(excluded):
        warnings.append(f"NOTE: {len(excluded)} failed run(s) retained; affected hypotheses are blocked "
                        "without seed replacement or incomplete-block averaging.")
    sources = sorted(set(frame["source_dir"].astype(str))) if "source_dir" in frame.columns else []
    if len(sources) > 1:
        warnings.append(
            f"CROSS-CHECK MODE: {len(sources)} campaign directories pooled ({', '.join(sources)}). "
            "Each hypothesis is evaluated on its own campaign directory (H1 -> h1*, H2 -> h2*, H3 -> h3*), "
            "so the verdicts below must equal the per-campaign conclusions.md files."
        )

    tables: list[pd.DataFrame] = []
    verdicts: list[str] = []
    evaluation_status = {}
    present_campaigns = {name for name in ("h1", "h2", "h3")
                         if any(source.lower().startswith(name) for source in sources)}
    for name, evaluator in (("H1", evaluate_h1), ("H2", evaluate_h2), ("H3", evaluate_h3)):
        if present_campaigns and name.lower() not in present_campaigns:
            continue
        try:
            table, verdict = evaluator(frame)
            evaluation_status[name] = {"status": "complete" if len(table) else "blocked", "verdict": verdict}
        except (ValueError, KeyError) as exc:
            verdict = f"{name}: BLOCKED. {exc}"
            table = pd.DataFrame([{"hypothesis": name, "status": "blocked", "reason": str(exc)}])
            evaluation_status[name] = {"status": "blocked", "reason": str(exc)}
        verdicts.append(verdict)
        if not table.empty:
            tables.append(table)

    group_keys = (["source_dir"] if len(sources) > 1 else []) + ["method", "contract", "scenario"]
    descriptive = (
        frame[frame["status"].astype(str).str.startswith("ok")]
        .groupby(group_keys, dropna=False)[
            [c for c in ("J", "control_energy", "event_trigger_count") if c in frame.columns]
        ]
        .mean()
        .reset_index()
    )

    lines = ["# PX4 interface-v2.1 statistical analysis" if v2 else "# PX4 corrected statistical reanalysis", "",
             ("New locally frozen design; technical pilots and incomplete hypotheses cannot support inference."
              if v2 else "Historical data are preserved. This output is not a new experiment or an independent confirmation."),
             "Intervals: 95%; 20000 bootstrap resamples; seed 1234. H3 resamples both paired numerator and denominator.", ""]
    lines += [f"- {w}" for w in warnings]
    lines.append("")
    for verdict in verdicts:
        lines.append(f"- {verdict}")
    lines += ["", "## Per-scenario descriptive means", "", descriptive.to_string(index=False), ""]
    for table in tables:
        lines += [f"## {table['hypothesis'].iloc[0]} table", "", table.to_string(index=False), ""]
    report = "\n".join(lines)
    (out_dir / "conclusions.md").write_text(report, encoding="utf-8")
    if tables:
        pd.concat(tables, ignore_index=True).to_csv(out_dir / "hypothesis_tests.csv", index=False)
    frame.to_csv(out_dir / "metrics_snapshot.csv", index=False)
    (out_dir / "analysis_status.json").write_text(json.dumps(evaluation_status, indent=2), encoding="utf-8")
    provenance = {"analysis_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  "metrics_source_sha256": hashlib.sha256(Path(__file__).with_name("v21_metrics.py").read_bytes()).hexdigest(),
                  "numpy_version": np.__version__, "pandas_version": pd.__version__,
                  "scipy_version": __import__("scipy").__version__ if SCIPY_AVAILABLE else None,
                  "metrics_snapshot_sha256": hashlib.sha256((out_dir / "metrics_snapshot.csv").read_bytes()).hexdigest(),
                  "evidence_type": "new_locally_frozen_interface_v21" if v2 else "historical_reanalysis",
                  "scientific_seeds": sorted(V21_SCIENTIFIC_SEEDS) if v2 else "historical campaign-specific seeds",
                  "intervals": "pointwise 95%; BCa mean and ratio; percentile Kendall tau; not simultaneous"}
    (out_dir / "analysis_provenance.json").write_text(json.dumps(provenance, indent=2), encoding="utf-8")
    print(report)
    print(f"\n[analysis] wrote {out_dir / 'conclusions.md'}")
    return 0 if all(item["status"] == "complete" for item in evaluation_status.values()) else 2


if __name__ == "__main__":
    raise SystemExit(main())
