#!/usr/bin/env bash
set -e
REV_SRC="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REV_GUEST=/home/px4/px4_interface_revision_20260906/v21_runtime
mkdir -p "$REV_GUEST"
cp "$REV_SRC/"*.py "$REV_GUEST/"
source /opt/ros/humble/setup.bash
source /home/px4/px4_ros_ws/install/setup.bash
export GZ_VERSION=harmonic RMW_IMPLEMENTATION=rmw_fastrtps_cpp
cd "$REV_GUEST"
python3 load_validation.py --parallel "$1" --speed "$2" --label "$3"
