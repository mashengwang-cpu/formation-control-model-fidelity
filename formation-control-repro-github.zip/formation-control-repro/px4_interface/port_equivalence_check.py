"""Numerical equivalence check: SampledDataController vs ModularController.

Drives both the PX4-node port and the frozen reference implementation
(finite_control_sim.controllers.ModularController) with identical input
sequences (errors, communication dropouts, rho estimates) and asserts the
commanded controls and trigger decisions coincide to machine precision for
every method used in the confirmatory phase.

Run on any host with the repository checked out:
  py -3.12 port_equivalence_check.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[0] / "simulation" / "src"))

from finite_control_sim.controllers import (  # noqa: E402
    ControllerInput,
    ControllerState,
    ModularController,
    PrescribedPerformance,
    get_method_spec,
)
from offboard_controller import METHOD_SPECS, SampledDataController  # noqa: E402

METHODS = list(METHOD_SPECS)
DT = 0.02
STEPS = 801  # 16 s mission
PREDEFINED_TIME_S = 5.0


def run_check(method: str, seed: int = 42) -> float:
    rng = np.random.default_rng(seed)
    errors = np.cumsum(rng.normal(0.0, 0.02, (STEPS, 2)), axis=0) + rng.normal(0.0, 0.4, (1, 2))
    velocity_errors = np.vstack([np.zeros((1, 2)), np.diff(errors, axis=0) / DT])
    comm = rng.random(STEPS) > 0.12
    rho_hat = np.clip(1.0 - 0.4 * rng.random(STEPS), 0.30, 1.05)

    reference = ModularController(
        get_method_spec(method), follower_count=1, dimensions=2, max_control=8.0,
        performance=PrescribedPerformance(initial_radius=1.6, final_radius=1.0),
    )
    state = ControllerState(
        adaptive_weights=np.zeros((1, 7, 2)),
        observer_state=np.zeros((1, 2)),
        trigger_filter=np.zeros(1),
        sampled_error=errors[0][None, :].copy(),
        sampled_velocity_error=velocity_errors[0][None, :].copy(),
    )
    last_event_time = np.zeros(1)
    port = SampledDataController(METHOD_SPECS[method], predefined_time_s=PREDEFINED_TIME_S)

    worst = 0.0
    for k in range(STEPS):
        t = k * DT
        output = reference.step(
            state,
            ControllerInput(
                time_s=t, dt_s=DT,
                position_error=errors[k][None, :],
                velocity_error=velocity_errors[k][None, :],
                sampled_error=state.sampled_error,
                time_since_event=t - last_event_time,
                communication_available=np.array([comm[k]]),
                actuator_efficiency=np.array([rho_hat[k]]),
                predefined_time_s=PREDEFINED_TIME_S,
                constraint_radius=1.0,
                trigger_base_threshold=0.035,
                trigger_max_hold_s=0.55,
                minimum_inter_event_s=0.02,
            ),
        )
        event_mask = output.triggered.copy()
        if k == 0:  # v1000_loop forces the step-0 event
            event_mask[:] = True
        state = output.next_state
        last_event_time[event_mask] = t

        u_port, diag = port.step(
            t, DT, errors[k], velocity_errors[k], bool(comm[k]), float(rho_hat[k])
        )
        if bool(event_mask[0]) != diag.triggered:
            raise AssertionError(f"{method}: trigger mismatch at step {k}")
        worst = max(worst, float(np.max(np.abs(output.commanded_control[0] - u_port))))
    return worst


def main() -> int:
    failures = 0
    for method in METHODS:
        worst = max(run_check(method, seed) for seed in (7, 42, 1234))
        status = "OK " if worst < 1e-10 else "FAIL"
        if worst >= 1e-10:
            failures += 1
        print(f"[{status}] {method:36s} max |u_ref - u_port| = {worst:.3e}")
    if failures:
        print(f"{failures} method(s) FAILED equivalence.")
        return 1
    print("All confirmatory-phase methods numerically equivalent to the frozen stack.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
