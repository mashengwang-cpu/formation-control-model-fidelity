"""PX4 offboard formation agent for the confirmatory phase (PROTOCOL.md).

One process controls one PX4 SITL vehicle through px4_msgs over uXRCE-DDS.
The control mathematics is a line-faithful single-agent port of the frozen
numpy stack in ``Reproduction/simulation/src/finite_control_sim``:

- controllers.py::ModularController      -> SampledDataController
- controllers.py::DynamicEventTrigger    -> identical trigger (sigma1 0.08,
  filter decay 1.2, filter gain 0.015, base threshold 0.035, max hold 0.55 s,
  minimum inter-event 0.02 s)
- controllers.py::PrescribedPerformance  -> identical PPT transform
  (initial radius 1.6, final 1.0, decay 3.0, clip 0.98; baseline stack only)
- controllers.py::PredefinedTimeSchedule -> identical TVG (0.45/0.35/cap 3.0)
- controllers.py::apply_fault_tolerance  -> identical causal rho compensation
  (u / max(rho_hat, 0.35), norm clip max_control 8.0)
- estimators.py::OnlineBiasEstimator / OnlineEfficiencyEstimator with the
  high-fidelity settings frozen in simulation/run_hifi_primary.py
  (efficiency gain 0.25, alignment gate 0.80, decay 0.05,
  projection [0.30, 1.05], observation clip 1.50, min command norm 0.005;
  bias gain 0.10, decay 0.35, limit 0.40)
- models.py::leader_reference / formation_offsets -> identical trajectory
  (leader position [0.55 t, 1.4 sin 0.28 t]) and wedge offsets (spacing 1.2)

Methods exposed (subset of controllers.py::METHOD_SPECS needed for H1-H3):
proposed_minimal_causal (Kp 2.15, Kv 2.05), recent_2025_resilient_fixed_time
(family baseline, Kp/Kv 1.9, powers 0.62/1.42, PPT + approximator + observer),
proposed_no_ppt and the four H2 knockouts (hifi_ko_tvg / _powers /
_approximator / _observer) at matched gains 2.15/2.05.

ROS2 interface (px4_msgs):
  publishes  /fmu/in/offboard_control_mode   (OffboardControlMode)
             /fmu/in/trajectory_setpoint     (TrajectorySetpoint)
             /fmu/in/vehicle_command         (VehicleCommand)
  subscribes /fmu/out/vehicle_local_position (VehicleLocalPosition)
             /fmu/out/vehicle_status         (VehicleStatus)

During the 16 s mission the node publishes planar ACCELERATION setpoints
(the numpy stack commands planar force on a unit-mass plant) plus a PD
altitude-hold acceleration on z. Attacks are injected node-side through
attack_injection.AttackInjector; LOE multiplies the published planar
acceleration (software thrust-scaling proxy), FDI biases the measured
position fed to the controller, DoS gates the event trigger so the ZOH
sample cannot refresh.

The module imports cleanly WITHOUT ROS2: rclpy/px4_msgs are guarded, and the
pure-python controller/estimator classes are reused by mission_runner.py's
stub backend and by unit checks on any host.
"""

from __future__ import annotations

import csv
import math
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

try:  # ROS2 import guard: keep the control core importable everywhere.
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

    ROS2_AVAILABLE = True
except ImportError:  # pragma: no cover - Windows host / analysis-only env
    rclpy = None
    Node = object
    ROS2_AVAILABLE = False

try:
    from px4_msgs.msg import (
        OffboardControlMode,
        TrajectorySetpoint,
        VehicleCommand,
        VehicleLocalPosition,
        VehicleStatus,
    )

    PX4_MSGS_AVAILABLE = True
except ImportError:  # pragma: no cover
    PX4_MSGS_AVAILABLE = False

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from attack_injection import AttackInjector
else:  # pragma: no cover
    from .attack_injection import AttackInjector


# ----------------------------------------------------------------------------
# Frozen protocol constants (stage2_final.json + run_hifi_primary.py)
# ----------------------------------------------------------------------------
CONTROL_DT_S = 0.02
MISSION_DURATION_S = 16.0
MAX_CONTROL = 8.0
FORMATION_SPACING = 1.2
PREDEFINED_TIME_S = 5.0  # hifi primary matrix default (run_hifi_primary.py)
CONSTRAINT_RADIUS = 1.0
TRIGGER_BASE_THRESHOLD = 0.035
TRIGGER_MAX_HOLD_S = 0.55
MINIMUM_INTER_EVENT_S = 0.02
TRIGGER_SIGMA_1 = 0.08
TRIGGER_FILTER_DECAY = 1.2
TRIGGER_FILTER_GAIN = 0.015
OBSERVER_GAIN = 0.7
OBSERVER_LEAKAGE = 0.25
APPROXIMATOR_GAIN = 0.18
APPROXIMATOR_LEAKAGE = 0.02
FINITE_POWER_WEIGHT = 0.6
FIXED_POWER_WEIGHT = 0.25
FAULT_COMP_FLOOR = 0.35
PPT_INITIAL_RADIUS = 1.6
PPT_DECAY_RATE = 3.0
PPT_CLIP = 0.98
TVG_GAIN_SCALE = 0.45
TVG_BOUNDARY_LAYER = 0.35
TVG_GAIN_CAP = 3.0


# ----------------------------------------------------------------------------
# Reference trajectory and formation geometry (models.py port)
# ----------------------------------------------------------------------------
def leader_reference(time_s: float) -> tuple[np.ndarray, np.ndarray]:
    position = np.array([0.55 * time_s, 1.4 * math.sin(0.28 * time_s)], dtype=float)
    velocity = np.array([0.55, 1.4 * 0.28 * math.cos(0.28 * time_s)], dtype=float)
    return position, velocity


def formation_offsets(follower_count: int, spacing: float = FORMATION_SPACING) -> np.ndarray:
    if follower_count < 1:
        raise ValueError("follower_count must be positive.")
    offsets = np.zeros((follower_count, 2), dtype=float)
    for idx in range(follower_count):
        column = idx // 2 + 1
        row = -0.5 if idx % 2 == 0 else 0.5
        offsets[idx] = np.array([-spacing * column, spacing * row], dtype=float)
    return offsets


def initial_perturbation(seed: int, scenario: str, num_agents: int, agent_index: int) -> np.ndarray:
    """Replicates the v1000_loop initial-position draw order exactly.

    For FDI-bearing scenarios the generator first yields the FDI phases
    (inside build_scenario_profile), then the N(0, 0.42) start dispersion.
    """
    rng = np.random.default_rng(int(seed))
    if scenario in {"fdi_attack", "combined_attack_fault"}:
        rng.uniform(0.0, 2.0 * np.pi, size=num_agents)
    perturbation = rng.normal(0.0, 0.42, size=(num_agents, 2))
    return perturbation[agent_index].copy()


# ----------------------------------------------------------------------------
# Method table (controllers.py::METHOD_SPECS subset, values copied verbatim)
# ----------------------------------------------------------------------------
@dataclass(frozen=True)
class MethodSpec:
    name: str
    position_gain: float
    velocity_gain: float
    finite_power: float | None
    fixed_power: float | None
    predefined: bool
    event_triggered: bool
    resilience: bool
    constraint_aware: bool
    adaptive_approximation: bool
    disturbance_observer: bool
    fault_tolerant: bool


METHOD_SPECS: dict[str, MethodSpec] = {
    "proposed_minimal_causal": MethodSpec(
        "proposed_minimal_causal", 2.15, 2.05, None, None,
        predefined=False, event_triggered=True, resilience=True,
        constraint_aware=False, adaptive_approximation=False,
        disturbance_observer=False, fault_tolerant=True,
    ),
    "recent_2025_resilient_fixed_time": MethodSpec(
        "recent_2025_resilient_fixed_time", 1.9, 1.9, 0.62, 1.42,
        predefined=False, event_triggered=True, resilience=True,
        constraint_aware=True, adaptive_approximation=True,
        disturbance_observer=True, fault_tolerant=True,
    ),
    "proposed_no_ppt": MethodSpec(
        "proposed_no_ppt", 2.15, 2.05, 0.60, 1.45,
        predefined=True, event_triggered=True, resilience=True,
        constraint_aware=False, adaptive_approximation=True,
        disturbance_observer=True, fault_tolerant=True,
    ),
    "hifi_ko_tvg": MethodSpec(
        "hifi_ko_tvg", 2.15, 2.05, 0.60, 1.45,
        predefined=False, event_triggered=True, resilience=True,
        constraint_aware=False, adaptive_approximation=True,
        disturbance_observer=True, fault_tolerant=True,
    ),
    "hifi_ko_powers": MethodSpec(
        "hifi_ko_powers", 2.15, 2.05, None, None,
        predefined=True, event_triggered=True, resilience=True,
        constraint_aware=False, adaptive_approximation=True,
        disturbance_observer=True, fault_tolerant=True,
    ),
    "hifi_ko_approximator": MethodSpec(
        "hifi_ko_approximator", 2.15, 2.05, 0.60, 1.45,
        predefined=True, event_triggered=True, resilience=True,
        constraint_aware=False, adaptive_approximation=False,
        disturbance_observer=True, fault_tolerant=True,
    ),
    "hifi_ko_observer": MethodSpec(
        "hifi_ko_observer", 2.15, 2.05, 0.60, 1.45,
        predefined=True, event_triggered=True, resilience=True,
        constraint_aware=False, adaptive_approximation=True,
        disturbance_observer=False, fault_tolerant=True,
    ),
}


def _signed_power(values: np.ndarray, power: float) -> np.ndarray:
    return np.sign(values) * np.power(np.abs(values) + 1e-9, power)


# ----------------------------------------------------------------------------
# Causal estimators (estimators.py single-agent port, hifi-frozen settings)
# ----------------------------------------------------------------------------
@dataclass(frozen=True)
class EstimatorConfig:
    bias_gain: float = 0.10
    bias_decay: float = 0.35
    bias_limit: float = 0.40
    efficiency_gain: float = 0.25          # hifi setting (point-mass used 4.0)
    efficiency_decay: float = 0.05
    efficiency_min: float = 0.30
    efficiency_max: float = 1.05
    efficiency_obs_limit: float = 1.50
    efficiency_alignment_min: float = 0.80  # hifi alignment gate (point-mass 0.0)
    min_command_norm: float = 5e-3


class CausalBiasEstimator:
    """Velocity-propagated bias observer; see estimators.py docstring."""

    def __init__(self, config: EstimatorConfig | None = None) -> None:
        self.config = config or EstimatorConfig()
        self.bias = np.zeros(2, dtype=float)
        self._predicted_unbiased_error: np.ndarray | None = None

    def update(self, measured_error: np.ndarray, velocity_error: np.ndarray, dt_s: float) -> np.ndarray:
        measured = np.asarray(measured_error, dtype=float)
        if self._predicted_unbiased_error is None:
            self._predicted_unbiased_error = measured.copy()
            return self.bias.copy()
        predicted = self._predicted_unbiased_error + float(dt_s) * np.asarray(velocity_error, dtype=float)
        innovation = measured - predicted
        gain = float(np.clip(self.config.bias_gain, 0.0, 1.0))
        leakage = max(0.0, self.config.bias_decay * float(dt_s))
        self.bias = self.bias + gain * (innovation - self.bias) - leakage * self.bias
        self.bias = np.clip(self.bias, -self.config.bias_limit, self.config.bias_limit)
        self._predicted_unbiased_error = predicted
        return self.bias.copy()


class CausalEfficiencyEstimator:
    """Projection-based actuator-effectiveness identifier with alignment gate."""

    def __init__(self, config: EstimatorConfig | None = None) -> None:
        self.config = config or EstimatorConfig()
        self.efficiency = 1.0

    def update(
        self,
        *,
        applied_control: np.ndarray,
        observed_acceleration: np.ndarray,
        mass: float,
        modelled_drag: np.ndarray,
        dt_s: float,
    ) -> float:
        applied = np.asarray(applied_control, dtype=float)
        net_force = np.asarray(observed_acceleration, dtype=float) * float(mass) + np.asarray(
            modelled_drag, dtype=float
        )
        denominator = float(np.sum(applied**2))
        observed = float(np.sum(net_force * applied)) / max(denominator, self.config.min_command_norm)
        observed = float(np.clip(observed, 0.0, self.config.efficiency_obs_limit))
        excited = denominator > self.config.min_command_norm
        if self.config.efficiency_alignment_min > 0.0:
            norms = float(np.linalg.norm(net_force) * np.linalg.norm(applied))
            alignment = float(np.sum(net_force * applied)) / max(norms, 1e-12)
            aligned = alignment >= self.config.efficiency_alignment_min
        else:
            aligned = True
        alpha = float(np.clip(self.config.efficiency_gain * float(dt_s), 0.0, 1.0))
        recovery = float(np.clip(self.config.efficiency_decay * float(dt_s), 0.0, 1.0))
        if excited and aligned:
            self.efficiency = self.efficiency + alpha * (observed - self.efficiency)
        elif not excited:
            self.efficiency = self.efficiency + recovery * (1.0 - self.efficiency)
        # excited but misaligned: hold (structurally corrupted sample)
        self.efficiency = float(
            np.clip(self.efficiency, self.config.efficiency_min, self.config.efficiency_max)
        )
        return self.efficiency


# ----------------------------------------------------------------------------
# Sampled-data controller (ModularController single-agent port)
# ----------------------------------------------------------------------------
@dataclass
class StepDiagnostics:
    triggered: bool
    trigger_metric: float
    trigger_threshold: float
    raw_control: np.ndarray = field(default_factory=lambda: np.zeros(2))
    performance_bound: float = 1.0


class SampledDataController:
    """Event-triggered sampled-data stack for one follower.

    step() reproduces ModularController.step() with follower_count == 1:
    trigger evaluation on transformed current-vs-held error, ZOH refresh,
    control from the HELD sample, adaptive/observer updates from the CURRENT
    transformed error, gated causal rho compensation, norm saturation.
    """

    def __init__(
        self,
        spec: MethodSpec,
        *,
        predefined_time_s: float = PREDEFINED_TIME_S,
        max_control: float = MAX_CONTROL,
    ) -> None:
        self.spec = spec
        self.predefined_time_s = float(predefined_time_s)
        self.max_control = float(max_control)
        self.held_error: np.ndarray | None = None
        self.held_velocity_error: np.ndarray | None = None
        self.trigger_filter = 0.0
        self.weights = np.zeros((7, 2), dtype=float)
        self.observer_state = np.zeros(2, dtype=float)
        self.last_event_time = 0.0
        self.event_count = 0
        self._first_step_done = False

    # -- PPT transform (PrescribedPerformance port) -------------------------
    def _bound(self, time_s: float) -> float:
        horizon = max(self.predefined_time_s, 1e-9)
        tau = min(max(time_s, 0.0), horizon) / horizon
        radius = CONSTRAINT_RADIUS + max(PPT_INITIAL_RADIUS - CONSTRAINT_RADIUS, 0.0) * math.exp(
            -PPT_DECAY_RATE * tau
        )
        return max(radius, CONSTRAINT_RADIUS)

    @staticmethod
    def _transform(error: np.ndarray, bound: float) -> np.ndarray:
        normalized = np.clip(np.asarray(error, dtype=float) / max(bound, 1e-9), -PPT_CLIP, PPT_CLIP)
        return 0.5 * np.log((1.0 + normalized) / (1.0 - normalized))

    # -- TVG schedule (PredefinedTimeSchedule port) --------------------------
    def _schedule_gain(self, time_s: float) -> float:
        if not self.spec.predefined:
            return 1.0
        remaining = max(self.predefined_time_s - time_s, 0.0)
        return min(TVG_GAIN_CAP, 1.0 + TVG_GAIN_SCALE / (remaining + TVG_BOUNDARY_LAYER))

    def step(
        self,
        time_s: float,
        dt_s: float,
        position_error: np.ndarray,
        velocity_error: np.ndarray,
        communication_available: bool,
        rho_hat: float,
    ) -> tuple[np.ndarray, StepDiagnostics]:
        error = np.asarray(position_error, dtype=float)
        velocity = np.asarray(velocity_error, dtype=float)
        if self.held_error is None:
            self.held_error = error.copy()
            self.held_velocity_error = velocity.copy()

        bound = self._bound(time_s)
        if self.spec.constraint_aware:
            z = self._transform(error, bound)
            z_held = self._transform(self.held_error, bound)
        else:
            z = error.copy()
            z_held = self.held_error.copy()

        # Dynamic event trigger (DynamicEventTrigger.evaluate port).
        metric = float(np.linalg.norm(z - z_held))
        error_norm = float(np.linalg.norm(z))
        next_filter = max(
            0.0,
            self.trigger_filter
            + dt_s
            * (
                -TRIGGER_FILTER_DECAY * self.trigger_filter
                + TRIGGER_FILTER_GAIN * error_norm**2
                - 0.5 * TRIGGER_FILTER_GAIN * metric**2
            ),
        )
        threshold = TRIGGER_BASE_THRESHOLD + TRIGGER_SIGMA_1 * error_norm + next_filter
        time_since_event = time_s - self.last_event_time
        if not self.spec.event_triggered:
            triggered = bool(communication_available)
        else:
            triggered = (
                (metric >= threshold or time_since_event >= TRIGGER_MAX_HOLD_S)
                and bool(communication_available)
                and time_since_event >= MINIMUM_INTER_EVENT_S
            )
        if not self._first_step_done:  # v1000_loop forces an event at step 0
            triggered = True
            self._first_step_done = True
        self.trigger_filter = next_filter

        if triggered:
            self.held_error = error.copy()
            self.held_velocity_error = velocity.copy()
            self.last_event_time = time_s
            self.event_count += 1

        z_ctrl = (
            self._transform(self.held_error, bound)
            if self.spec.constraint_aware
            else self.held_error.copy()
        )
        held_velocity = self.held_velocity_error.copy()

        # Adaptive approximator (basis on CURRENT transformed error).
        basis = np.array(
            [1.0, z[0], z[1], velocity[0], velocity[1],
             float(np.linalg.norm(z)), float(np.linalg.norm(velocity))],
            dtype=float,
        )
        if self.spec.adaptive_approximation:
            approximation = self.weights.T @ basis
            self.weights = self.weights + dt_s * (
                APPROXIMATOR_GAIN * np.outer(basis, z) - APPROXIMATOR_LEAKAGE * self.weights
            )
        else:
            approximation = np.zeros(2, dtype=float)

        # Disturbance/attack observer (post-update value enters the control).
        if self.spec.disturbance_observer:
            self.observer_state = self.observer_state + dt_s * (
                OBSERVER_GAIN * z - OBSERVER_LEAKAGE * self.observer_state
            )
            observer_estimate = self.observer_state.copy()
        else:
            observer_estimate = np.zeros(2, dtype=float)

        gain = self.spec.position_gain * self._schedule_gain(time_s)
        raw = -gain * z_ctrl - self.spec.velocity_gain * held_velocity
        if self.spec.finite_power is not None:
            raw += -FINITE_POWER_WEIGHT * _signed_power(z_ctrl, self.spec.finite_power)
        if self.spec.fixed_power is not None:
            raw += -FIXED_POWER_WEIGHT * _signed_power(z_ctrl, self.spec.fixed_power)
        raw -= approximation
        raw -= observer_estimate

        # Gated causal fault compensation + saturation (apply_fault_tolerance).
        if self.spec.fault_tolerant:
            compensated = raw / max(float(rho_hat), FAULT_COMP_FLOOR)
        else:
            compensated = raw.copy()
        norm = float(np.linalg.norm(compensated))
        commanded = compensated * min(1.0, self.max_control / max(norm, 1e-9))

        return commanded, StepDiagnostics(
            triggered=triggered,
            trigger_metric=metric,
            trigger_threshold=threshold,
            raw_control=raw,
            performance_bound=bound,
        )


LOG_COLUMNS = [
    "t", "ex_true", "ey_true", "err_norm", "ex_ctrl", "ey_ctrl",
    "ux_cmd", "uy_cmd", "ux_applied", "uy_applied",
    "event", "comm", "rho_true", "rho_hat",
    "bias_x_true", "bias_y_true", "bias_x_hat", "bias_y_hat",
    "trigger_metric", "trigger_threshold",
]


# ----------------------------------------------------------------------------
# ROS2 offboard node
# ----------------------------------------------------------------------------
if ROS2_AVAILABLE and PX4_MSGS_AVAILABLE:

    class OffboardFormationAgent(Node):  # type: ignore[misc]
        """Arms, enters offboard, climbs to the formation slot, runs the
        16 s protocol mission with acceleration setpoints, lands, writes CSV.
        """

        PHASE_WAIT = 0
        PHASE_ASCEND = 1
        PHASE_MISSION = 2
        PHASE_LAND = 3
        PHASE_DONE = 4

        def __init__(self) -> None:
            super().__init__("offboard_formation_agent")
            self.declare_parameter("method", "proposed_minimal_causal")
            self.declare_parameter("scenario", "nominal")
            self.declare_parameter("seed", 0)
            self.declare_parameter("agent_index", 0)
            self.declare_parameter("num_agents", 1)
            self.declare_parameter("contract", "causal")  # causal|oracle|unassisted
            self.declare_parameter("duration_s", MISSION_DURATION_S)
            self.declare_parameter("altitude_m", 5.0)
            self.declare_parameter("output_csv", "run_log.csv")
            self.declare_parameter("topic_prefix", "")  # "/px4_1" for instance 1...
            self.declare_parameter("ascend_timeout_s", 40.0)
            self.declare_parameter("apply_initial_perturbation", True)
            # MAV_SYS_ID of the PX4 instance this node commands (PX4 -i N =>
            # N+1). Defaults to agent_index+1, i.e. instances 0..n-1.
            self.declare_parameter("mav_sys_id", -1)

            g = lambda name: self.get_parameter(name).value  # noqa: E731
            self.method = str(g("method"))
            self.scenario = str(g("scenario"))
            self.seed = int(g("seed"))
            self.agent_index = int(g("agent_index"))
            self.num_agents = int(g("num_agents"))
            self.contract = str(g("contract"))
            self.duration_s = float(g("duration_s"))
            self.altitude_m = float(g("altitude_m"))
            self.output_csv = Path(str(g("output_csv")))
            prefix = str(g("topic_prefix"))
            self.ascend_timeout_s = float(g("ascend_timeout_s"))
            sys_id = int(g("mav_sys_id"))
            self.mav_sys_id = sys_id if sys_id > 0 else self.agent_index + 1

            spec = METHOD_SPECS[self.method]
            self.controller = SampledDataController(spec)
            self.injector = AttackInjector(
                self.scenario, self.agent_index, self.num_agents, self.seed, self.duration_s
            )
            self.bias_estimator = CausalBiasEstimator()
            self.efficiency_estimator = CausalEfficiencyEstimator()
            self.offset = formation_offsets(self.num_agents)[self.agent_index]
            self.start_perturbation = (
                initial_perturbation(self.seed, self.scenario, self.num_agents, self.agent_index)
                if bool(g("apply_initial_perturbation"))
                else np.zeros(2)
            )

            qos = QoSProfile(
                reliability=ReliabilityPolicy.BEST_EFFORT,
                durability=DurabilityPolicy.VOLATILE,
                history=HistoryPolicy.KEEP_LAST,
                depth=1,
            )
            self.mode_pub = self.create_publisher(
                OffboardControlMode, f"{prefix}/fmu/in/offboard_control_mode", qos
            )
            self.setpoint_pub = self.create_publisher(
                TrajectorySetpoint, f"{prefix}/fmu/in/trajectory_setpoint", qos
            )
            self.command_pub = self.create_publisher(
                VehicleCommand, f"{prefix}/fmu/in/vehicle_command", qos
            )
            self.create_subscription(
                VehicleLocalPosition, f"{prefix}/fmu/out/vehicle_local_position",
                self._on_local_position, qos,
            )
            self.create_subscription(
                VehicleStatus, f"{prefix}/fmu/out/vehicle_status", self._on_status, qos
            )

            self.local_position: VehicleLocalPosition | None = None
            self.nav_state = -1
            self.arming_state = -1
            self.phase = self.PHASE_WAIT
            self.setpoint_counter = 0
            self.phase_started_s = 0.0
            self.mission_step = 0
            self.mission_steps_total = int(round(self.duration_s / CONTROL_DT_S)) + 1
            self.prev_velocity: np.ndarray | None = None
            self.prev_commanded: np.ndarray | None = None
            self.rows: list[list[float]] = []
            self.sim_time_s: float | None = None      # PX4 simulation clock (s)
            self.mission_sim_t0: float | None = None  # sim time of mission step 0
            self.mission_wall_t0: float | None = None
            self.last_step_wall_s: float | None = None
            self.timer = self.create_timer(CONTROL_DT_S, self._on_timer)
            self.get_logger().info(
                f"agent {self.agent_index}/{self.num_agents} method={self.method} "
                f"scenario={self.scenario} seed={self.seed} contract={self.contract}"
            )

        # -------------------------------------------------------------- io
        def _on_local_position(self, msg: VehicleLocalPosition) -> None:
            self.local_position = msg
            # PX4 stamps in simulation microseconds (lockstep). The mission is
            # stepped on this clock, so a real-time factor below one (loaded
            # host, several concurrent Gazebo servers) stretches wall time but
            # leaves the 50 Hz sampled-data loop and the 16 s horizon intact.
            self.sim_time_s = float(msg.timestamp) * 1e-6
            if self.phase == self.PHASE_MISSION:
                self._mission_step_if_due()

        def _on_status(self, msg: VehicleStatus) -> None:
            self.nav_state = int(msg.nav_state)
            self.arming_state = int(msg.arming_state)

        def _now_s(self) -> float:
            return self.get_clock().now().nanoseconds * 1e-9

        def _stamp_us(self) -> int:
            return int(self.get_clock().now().nanoseconds / 1000)

        def _send_command(self, command: int, param1: float = 0.0, param2: float = 0.0) -> None:
            msg = VehicleCommand()
            msg.command = command
            msg.param1 = float(param1)
            msg.param2 = float(param2)
            msg.target_system = self.mav_sys_id  # PX4 -i N => MAV_SYS_ID N+1
            msg.target_component = 1
            msg.source_system = 1
            msg.source_component = 1
            msg.from_external = True
            msg.timestamp = self._stamp_us()
            self.command_pub.publish(msg)

        def _publish_mode(self, *, position: bool, acceleration: bool) -> None:
            msg = OffboardControlMode()
            msg.position = position
            msg.velocity = False
            msg.acceleration = acceleration
            msg.attitude = False
            msg.body_rate = False
            msg.timestamp = self._stamp_us()
            self.mode_pub.publish(msg)

        def _publish_position_setpoint(self, north: float, east: float, down: float) -> None:
            msg = TrajectorySetpoint()
            msg.position = [float(north), float(east), float(down)]
            msg.velocity = [math.nan] * 3
            msg.acceleration = [math.nan] * 3
            msg.yaw = 0.0
            msg.timestamp = self._stamp_us()
            self.setpoint_pub.publish(msg)

        def _publish_acceleration_setpoint(self, ax: float, ay: float, az: float) -> None:
            msg = TrajectorySetpoint()
            msg.position = [math.nan] * 3
            msg.velocity = [math.nan] * 3
            msg.acceleration = [float(ax), float(ay), float(az)]
            msg.yaw = 0.0
            msg.timestamp = self._stamp_us()
            self.setpoint_pub.publish(msg)

        # ------------------------------------------------------------ phases
        def _on_timer(self) -> None:
            if self.phase == self.PHASE_WAIT:
                self._phase_wait()
            elif self.phase == self.PHASE_ASCEND:
                self._phase_ascend()
            elif self.phase == self.PHASE_MISSION:
                self._phase_mission()
            elif self.phase == self.PHASE_LAND:
                self._phase_land()

        def _mission_start_waypoint(self) -> np.ndarray:
            leader_p0, _ = leader_reference(0.0)
            return leader_p0 + self.offset + self.start_perturbation

        def _phase_wait(self) -> None:
            self._publish_mode(position=True, acceleration=False)
            wp = self._mission_start_waypoint()
            self._publish_position_setpoint(wp[0], wp[1], -self.altitude_m)
            self.setpoint_counter += 1
            if self.local_position is None:
                if self.setpoint_counter % 250 == 0:  # every 5 s at 50 Hz
                    self.get_logger().warning(
                        f"waiting for vehicle_local_position ({self.setpoint_counter * CONTROL_DT_S:.0f}s); "
                        f"status seen: nav_state={self.nav_state} arming_state={self.arming_state}"
                    )
                return
            # PX4 requires a setpoint stream before accepting offboard; arm as
            # soon as >= 15 setpoints have been streamed AND local position is
            # available (the original '== 15' test silently never armed when
            # the first position message arrived after the 15th tick).
            if self.setpoint_counter >= 15:
                # PX4 requires a setpoint stream before accepting offboard.
                self._send_command(VehicleCommand.VEHICLE_CMD_DO_SET_MODE, 1.0, 6.0)
                self._send_command(VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0)
                self.phase = self.PHASE_ASCEND
                self.phase_started_s = self._now_s()
                self.get_logger().info("offboard+arm requested; ascending to slot")

        def _phase_ascend(self) -> None:
            self._publish_mode(position=True, acceleration=False)
            wp = self._mission_start_waypoint()
            self._publish_position_setpoint(wp[0], wp[1], -self.altitude_m)
            if self.local_position is None:
                return
            pos = np.array([self.local_position.x, self.local_position.y], dtype=float)
            alt_err = abs(-self.local_position.z - self.altitude_m)
            slot_err = float(np.linalg.norm(pos - wp))
            elapsed = self._now_s() - self.phase_started_s
            # Re-request offboard + arm every 2 s until PX4 reports both
            # (ARMING_STATE_ARMED = 2, NAVIGATION_STATE_OFFBOARD = 14); the
            # first request can be rejected by a still-settling preflight check.
            self.setpoint_counter += 1
            if (self.arming_state != 2 or self.nav_state != 14) and self.setpoint_counter % 100 == 0:
                self._send_command(VehicleCommand.VEHICLE_CMD_DO_SET_MODE, 1.0, 6.0)
                self._send_command(VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0)
                self.get_logger().info(
                    f"re-requesting offboard/arm (nav_state={self.nav_state}, arming_state={self.arming_state}, "
                    f"slot_err={slot_err:.2f}, alt_err={alt_err:.2f})"
                )
            if (slot_err < 0.35 and alt_err < 0.35) or elapsed > self.ascend_timeout_s:
                if elapsed > self.ascend_timeout_s:
                    # Take-off failure (PX4 kept rejecting arming/offboard, or the
                    # vehicle never reached its slot): this is a simulator-side
                    # failure of the mission, not controller data. Record it and
                    # exit non-zero so that the runner logs a crash and the
                    # mission is re-run under the registered stopping rule.
                    if self.arming_state != 2 or self.nav_state != 14 or slot_err > 1.0 or alt_err > 1.0:
                        self.get_logger().error(
                            f"take-off failure after {elapsed:.1f}s: nav_state={self.nav_state} "
                            f"arming_state={self.arming_state} slot_err={slot_err:.2f} alt_err={alt_err:.2f}; "
                            "aborting mission (exit 3)"
                        )
                        marker = self.output_csv.with_suffix(".takeoff_failure.txt")
                        marker.parent.mkdir(parents=True, exist_ok=True)
                        marker.write_text(
                            f"nav_state={self.nav_state} arming_state={self.arming_state} "
                            f"slot_err={slot_err:.3f} alt_err={alt_err:.3f} elapsed_s={elapsed:.1f}\n"
                        )
                        os._exit(3)
                    self.get_logger().warning(
                        f"ascend timeout ({elapsed:.1f}s) but armed, offboard and near the slot; starting mission with "
                        f"slot_err={slot_err:.2f} alt_err={alt_err:.2f}"
                    )
                self.phase = self.PHASE_MISSION
                self.phase_started_s = self._now_s()
                self.mission_step = 0
                self.mission_sim_t0 = self.sim_time_s
                self.mission_wall_t0 = self._now_s()
                self.last_step_wall_s = self._now_s()
                self.get_logger().info(f"mission started (sim t0 = {self.sim_time_s:.3f} s)")

        def _phase_mission(self) -> None:
            # Wall-clock duties only: keep the offboard heartbeat alive and
            # detect a stalled simulation clock. The control step itself is
            # driven by the PX4 simulation clock in _mission_step_if_due.
            self._publish_mode(position=False, acceleration=True)
            if self.last_step_wall_s is not None and self._now_s() - self.last_step_wall_s > 5.0:
                self.get_logger().warning("no simulation-clock progress for 5 s; waiting for vehicle_local_position")
                self.last_step_wall_s = self._now_s()

        def _mission_step_if_due(self) -> None:
            if self.local_position is None or self.sim_time_s is None or self.mission_sim_t0 is None:
                return
            # one 50 Hz sampled-data step per 0.02 s of SIMULATION time
            if self.sim_time_s - self.mission_sim_t0 < self.mission_step * CONTROL_DT_S - 1e-6:
                return
            self.last_step_wall_s = self._now_s()
            t = self.mission_step * CONTROL_DT_S
            dt = CONTROL_DT_S
            leader_p, leader_v = leader_reference(t)
            desired = leader_p + self.offset

            position = np.array([self.local_position.x, self.local_position.y], dtype=float)
            velocity = np.array([self.local_position.vx, self.local_position.vy], dtype=float)
            true_error = position - desired
            velocity_error = velocity - leader_v

            # Efficiency estimator learns from the PREVIOUS commanded control
            # and the observed acceleration (finite difference, as in numpy).
            if (
                self.prev_velocity is not None
                and self.prev_commanded is not None
                and self.contract == "causal"
                and self.controller.spec.resilience
            ):
                observed_acceleration = (velocity - self.prev_velocity) / dt
                self.efficiency_estimator.update(
                    applied_control=self.prev_commanded,
                    observed_acceleration=observed_acceleration,
                    mass=1.0,
                    modelled_drag=np.zeros(2),
                    dt_s=dt,
                )

            bias_true = self.injector.sensor_bias(t)
            rho_true = self.injector.actuator_efficiency(t)
            comm = self.injector.communication_available(t)
            raw_error = true_error + bias_true

            if self.controller.spec.resilience and self.contract == "oracle":
                bias_hat = bias_true.copy()
                rho_hat = rho_true
            elif self.controller.spec.resilience and self.contract == "causal":
                bias_hat = self.bias_estimator.update(raw_error, velocity_error, dt)
                rho_hat = self.efficiency_estimator.efficiency
            else:
                bias_hat = np.zeros(2)
                rho_hat = 1.0
            controller_error = raw_error - bias_hat

            commanded, diag = self.controller.step(
                t, dt, controller_error, velocity_error, comm, rho_hat
            )
            applied = rho_true * commanded  # LOE software thrust-scaling proxy

            # PD altitude hold in NED (z positive down).
            z_err = (-self.altitude_m) - self.local_position.z
            az = 1.5 * z_err - 1.2 * self.local_position.vz
            self._publish_acceleration_setpoint(applied[0], applied[1], az)

            self.prev_velocity = velocity.copy()
            self.prev_commanded = commanded.copy()
            self.rows.append([
                t, true_error[0], true_error[1], float(np.linalg.norm(true_error)),
                controller_error[0], controller_error[1],
                commanded[0], commanded[1], applied[0], applied[1],
                float(diag.triggered), float(comm), rho_true, rho_hat,
                bias_true[0], bias_true[1], bias_hat[0], bias_hat[1],
                diag.trigger_metric, diag.trigger_threshold,
            ])
            self.mission_step += 1
            if self.mission_step >= self.mission_steps_total:
                self._write_log()
                self.phase = self.PHASE_LAND
                self.phase_started_s = self._now_s()
                self.get_logger().info("mission complete; landing")

        def _phase_land(self) -> None:
            self._send_command(VehicleCommand.VEHICLE_CMD_NAV_LAND)
            if self._now_s() - self.phase_started_s > 3.0:
                self.phase = self.PHASE_DONE
                self.get_logger().info("done; shutting down node")
                self.timer.cancel()
                rclpy.try_shutdown()

        def _write_log(self) -> None:
            self.output_csv.parent.mkdir(parents=True, exist_ok=True)
            wall = self._now_s() - (self.mission_wall_t0 or self._now_s())
            sim = (self.sim_time_s or 0.0) - (self.mission_sim_t0 or 0.0)
            rtf = sim / wall if wall > 0 else float("nan")
            with self.output_csv.open("w", newline="", encoding="utf-8") as handle:
                handle.write(f"# method={self.method} scenario={self.scenario} seed={self.seed}\n")
                handle.write(
                    f"# agent_index={self.agent_index} num_agents={self.num_agents} "
                    f"contract={self.contract} duration_s={self.duration_s} dt_s={CONTROL_DT_S} "
                    f"clock=px4_sim_time mission_wall_s={wall:.2f} mission_sim_s={sim:.2f} rtf={rtf:.3f}\n"
                )
                writer = csv.writer(handle)
                writer.writerow(LOG_COLUMNS)
                writer.writerows(self.rows)
            self.get_logger().info(f"wrote {len(self.rows)} rows to {self.output_csv}")


def main() -> int:
    # The historical runtime above is retained as provenance only. All CLI
    # execution now uses the independently clocked, barrier-controlled v2 node.
    from offboard_runtime_v2 import main_v2
    return main_v2()


if __name__ == "__main__":
    raise SystemExit(main())
