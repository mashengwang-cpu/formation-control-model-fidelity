#!/usr/bin/env bash
set -e
REV_SRC="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REV_GUEST=/home/px4/px4_interface_revision_20260906/v21_runtime
mkdir -p "$REV_GUEST"
cp "$REV_SRC/"*.py "$REV_GUEST/"
cp "$REV_SRC/PROTOCOL_V21.md" "$REV_GUEST/"
source /opt/ros/humble/setup.bash
source /home/px4/px4_ros_ws/install/setup.bash
export GZ_VERSION=harmonic RMW_IMPLEMENTATION=rmw_fastrtps_cpp
cd "$REV_GUEST"
python3 -m pytest -q test_interface_runtime.py test_transfer_archive.py test_observation_tail.py test_paused_epoch.py test_v21_analysis.py --basetemp "$REV_GUEST/pytest_before_science"
python3 campaign_manager_v2.py --archive-root "$REV_SRC/../../evidence/px4_campaign_v21" --initial-parallel "${1:-2}" "${@:2}"
