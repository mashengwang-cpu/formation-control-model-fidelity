"""Confirmatory-campaign orchestrator: 5 scenarios x 20 seeds x 2 methods.

Per PROTOCOL.md ("Confirmatory phase"): identical seed lists across arms,
20 mission seeds, no interim analysis, no seed exclusion except documented
simulator crashes (captured verbatim under results/<campaign>/logs/).

Two backends:

- ``px4``  (Linux/WSL2 only): per run, launches the Micro XRCE-DDS agent,
  one PX4 SITL instance per agent (Gazebo headless), and one
  offboard_controller.py node per agent; waits for the mission CSV; tears
  everything down; records crash logs verbatim. Requires a sourced ROS2
  Humble + px4_msgs workspace and a built PX4 v1.15 tree (see setup_wsl.sh).

- ``stub`` (any host, including Windows ``py -3.12``): closes the loop
  in-process around the SAME controller/estimator/attack classes used by the
  PX4 node, on the v1000-canonical point-mass plant (UAV damping 0.28, unit
  mass, RK4, step-held deterministic disturbance). This validates the whole
  runner -> CSV -> analysis pipeline end to end. Stub outputs are pipeline
  self-tests, NOT confirmatory evidence, and are tagged backend=stub in every
  artifact. Known deviation from the numpy campaigns: no leader_ring
  consensus mixing (topology gain 0), because the per-vehicle PX4 node
  measures only its own error.

Examples (inside WSL, workspace sourced):
  python3 mission_runner.py --backend px4 --smoke --px4-dir ~/PX4-Autopilot
  python3 mission_runner.py --backend px4 --campaign h1 --px4-dir ~/PX4-Autopilot
  python3 mission_runner.py --backend stub --campaign h1 --seeds 20
  python3 mission_runner.py --backend stub --campaign h2 --seeds 20
  python3 mission_runner.py --backend stub --campaign h3 --seeds 20
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import os
import shutil
import signal
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from attack_injection import AttackInjector  # noqa: E402
from offboard_controller import (  # noqa: E402
    CONTROL_DT_S,
    LOG_COLUMNS,
    MISSION_DURATION_S,
    METHOD_SPECS,
    CausalBiasEstimator,
    CausalEfficiencyEstimator,
    SampledDataController,
    formation_offsets,
    initial_perturbation,
    leader_reference,
)
import analysis  # noqa: E402

SCENARIOS = ["nominal", "actuator_fault", "fdi_attack", "dos_attack", "combined_attack_fault"]
H1_METHODS = ["proposed_minimal_causal", "recent_2025_resilient_fixed_time"]
H2_METHODS = ["proposed_no_ppt", "hifi_ko_tvg", "hifi_ko_powers", "hifi_ko_approximator", "hifi_ko_observer"]

# v1000-canonical UAV point-mass constants (models.py + v1000_loop.py).
STUB_DAMPING = 0.28
STUB_MASS = 1.0


@dataclass(frozen=True)
class RunSpec:
    method: str
    scenario: str
    seed: int
    contract: str  # causal | oracle | unassisted
    num_agents: int

    @property
    def run_id(self) -> str:
        return f"{self.method}__{self.scenario}__s{self.seed:02d}__{self.contract}"


def campaign_runs(campaign: str, seeds: list[int], num_agents: int) -> list[RunSpec]:
    runs: list[RunSpec] = []
    if campaign == "h1":
        for method in H1_METHODS:
            for scenario in SCENARIOS:
                for seed in seeds:
                    runs.append(RunSpec(method, scenario, seed, "causal", num_agents))
    elif campaign == "h2":
        for method in H2_METHODS:
            for scenario in SCENARIOS:
                for seed in seeds:
                    runs.append(RunSpec(method, scenario, seed, "causal", num_agents))
    elif campaign == "h3":
        for contract in ("causal", "oracle"):
            for scenario in SCENARIOS:
                for seed in seeds:
                    runs.append(RunSpec("proposed_minimal_causal", scenario, seed, contract, num_agents))
    elif campaign == "smoke":
        runs.append(RunSpec("proposed_minimal_causal", "nominal", seeds[0], "causal", num_agents))
    else:
        raise ValueError(f"Unknown campaign {campaign!r} (use h1 | h2 | h3 | smoke).")
    return runs


def randomized_blocks(runs, schedule_seed, campaign):
    """Randomize blocks and arm order, independent of physical perturbation seed."""
    groups={}
    for run in runs:groups.setdefault((run.scenario,run.seed),[]).append(run)
    rng=random.Random(f'{schedule_seed}:{campaign}')
    blocks=list(groups.values());rng.shuffle(blocks)
    for block in blocks:rng.shuffle(block)
    return blocks


# ----------------------------------------------------------------------------
# Stub backend: in-process v1000-canonical closed loop (pipeline self-test)
# ----------------------------------------------------------------------------
def deterministic_disturbance(t: float, agent_index: int, seed: int) -> np.ndarray:
    """models.py::deterministic_disturbance for one follower (idx is 1-based)."""
    idx = float(agent_index + 1)
    seed_scale = 0.01 * float(seed)
    return np.array(
        [
            0.035 * np.sin(0.7 * t + 0.31 * idx + seed_scale),
            0.03 * np.cos(0.5 * t + 0.17 * idx + 0.5 * seed_scale),
        ],
        dtype=float,
    )


def run_stub_episode(spec: RunSpec, output_dir: Path, duration_s: float = MISSION_DURATION_S) -> list[Path]:
    """Closes the loop for all agents of one run; one CSV per agent."""
    dt = CONTROL_DT_S
    steps = int(round(duration_s / dt)) + 1
    n = spec.num_agents
    offsets = formation_offsets(n)
    leader_p0, leader_v0 = leader_reference(0.0)

    controllers = [SampledDataController(METHOD_SPECS[spec.method]) for _ in range(n)]
    injectors = [AttackInjector(spec.scenario, i, n, spec.seed, duration_s) for i in range(n)]
    bias_estimators = [CausalBiasEstimator() for _ in range(n)]
    efficiency_estimators = [CausalEfficiencyEstimator() for _ in range(n)]

    positions = np.array(
        [leader_p0 + offsets[i] + initial_perturbation(spec.seed, spec.scenario, n, i) for i in range(n)]
    )
    velocities = np.tile(leader_v0, (n, 1)) * 0.15
    resilient = METHOD_SPECS[spec.method].resilience

    rows: list[list[list[float]]] = [[] for _ in range(n)]
    prev_velocities = velocities.copy()
    prev_commanded = np.zeros((n, 2))

    for step in range(steps):
        t = step * dt
        leader_p, leader_v = leader_reference(t)
        commanded = np.zeros((n, 2))
        actual = np.zeros((n, 2))
        for i in range(n):
            desired = leader_p + offsets[i]
            true_error = positions[i] - desired
            velocity_error = velocities[i] - leader_v

            if step > 0 and resilient and spec.contract == "causal":
                observed_acc = (velocities[i] - prev_velocities[i]) / dt
                efficiency_estimators[i].update(
                    applied_control=prev_commanded[i],
                    observed_acceleration=observed_acc,
                    mass=STUB_MASS,
                    modelled_drag=STUB_DAMPING * prev_velocities[i],
                    dt_s=dt,
                )

            bias_true = injectors[i].sensor_bias(t)
            rho_true = injectors[i].actuator_efficiency(t)
            comm = injectors[i].communication_available(t)
            raw_error = true_error + bias_true
            if resilient and spec.contract == "oracle":
                bias_hat, rho_hat = bias_true.copy(), rho_true
            elif resilient and spec.contract == "causal":
                bias_hat = bias_estimators[i].update(raw_error, velocity_error, dt)
                rho_hat = efficiency_estimators[i].efficiency
            else:
                bias_hat, rho_hat = np.zeros(2), 1.0
            controller_error = raw_error - bias_hat

            u_cmd, diag = controllers[i].step(t, dt, controller_error, velocity_error, comm, rho_hat)
            commanded[i] = u_cmd
            actual[i] = rho_true * u_cmd
            rows[i].append([
                t, true_error[0], true_error[1], float(np.linalg.norm(true_error)),
                controller_error[0], controller_error[1],
                u_cmd[0], u_cmd[1], actual[i][0], actual[i][1],
                float(diag.triggered), float(comm), rho_true, rho_hat,
                bias_true[0], bias_true[1], bias_hat[0], bias_hat[1],
                diag.trigger_metric, diag.trigger_threshold,
            ])

        if step == steps - 1:
            break
        prev_velocities = velocities.copy()
        prev_commanded = commanded.copy()
        disturbance = np.array([deterministic_disturbance(t, i, spec.seed) for i in range(n)])

        def _deriv(vel: np.ndarray) -> np.ndarray:
            return (actual + disturbance - STUB_DAMPING * vel) / STUB_MASS

        k1_a, k1_p = _deriv(velocities), velocities
        k2_a, k2_p = _deriv(velocities + 0.5 * dt * k1_a), velocities + 0.5 * dt * k1_a
        k3_a, k3_p = _deriv(velocities + 0.5 * dt * k2_a), velocities + 0.5 * dt * k2_a
        k4_a, k4_p = _deriv(velocities + dt * k3_a), velocities + dt * k3_a
        velocities = velocities + (dt / 6.0) * (k1_a + 2 * k2_a + 2 * k3_a + k4_a)
        positions = positions + (dt / 6.0) * (k1_p + 2 * k2_p + 2 * k3_p + k4_p)

    paths: list[Path] = []
    output_dir.mkdir(parents=True, exist_ok=True)
    for i in range(n):
        path = output_dir / f"{spec.run_id}__agent{i}.csv"
        with path.open("w", newline="", encoding="utf-8") as handle:
            handle.write(f"# method={spec.method} scenario={spec.scenario} seed={spec.seed}\n")
            handle.write(
                f"# agent_index={i} num_agents={n} contract={spec.contract} "
                f"duration_s={duration_s} dt_s={dt} backend=stub\n"
            )
            writer = csv.writer(handle)
            writer.writerow(LOG_COLUMNS)
            writer.writerows(rows[i])
        paths.append(path)
    return paths


# ----------------------------------------------------------------------------
# PX4 backend: process orchestration (Linux/WSL2)
# ----------------------------------------------------------------------------
class Px4Backend:
    def __init__(
        self,
        px4_dir: Path,
        logs_dir: Path,
        headless: bool = True,
        instance_offset: int = 0,
        xrce_port: int = 8888,
        gz_partition: str | None = None,
    ) -> None:
        """instance_offset / xrce_port / gz_partition isolate concurrent runners
        on one host (each runner gets its own gz server, uXRCE agent port and
        PX4 instance ids); they do not change the mission or the controllers."""
        self.px4_dir = px4_dir.expanduser()
        self.px4_bin = self.px4_dir / "build" / "px4_sitl_default" / "bin" / "px4"
        self.logs_dir = logs_dir
        self.headless = headless
        self.instance_offset = int(instance_offset)
        self.xrce_port = int(xrce_port)
        self.gz_partition = gz_partition
        self.agent_proc: subprocess.Popen | None = None
        if os.name == "nt":
            raise RuntimeError(
                "The px4 backend must run inside Linux/WSL2 (PX4 SITL does not run "
                "natively on Windows). Use --backend stub on this host, or run this "
                "script inside WSL per setup_wsl.sh."
            )
        if not self.px4_bin.exists():
            raise RuntimeError(
                f"PX4 SITL binary not found at {self.px4_bin}. Build it first: "
                "cd ~/PX4-Autopilot && make px4_sitl gz_x500 (see setup_wsl.sh)."
            )
        if shutil.which("MicroXRCEAgent") is None:
            raise RuntimeError("MicroXRCEAgent not on PATH (see setup_wsl.sh step 3).")

    def start_xrce_agent(self, log_dir: Path | None = None) -> None:
        log = ((log_dir or self.logs_dir) / "xrce_agent.log").open("w")
        self.agent_proc = subprocess.Popen(
            ["MicroXRCEAgent", "udp4", "-p", str(self.xrce_port)],
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
        )
        time.sleep(1.0)

    def stop_xrce_agent(self) -> None:
        if self.agent_proc is not None:
            _terminate_tree(self.agent_proc)
            self.agent_proc = None

    @staticmethod
    def _wait_for_topics(
        topics: list[str], timeout_s: float, poll_s: float = 2.0,
        procs: list[subprocess.Popen] | None = None,
    ) -> bool:
        """Polls `ros2 topic list` until all topics are advertised (bridge up);
        returns False early if one of the PX4 processes has exited."""
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            if procs and any(p.poll() is not None for p in procs):
                return False
            try:
                out = subprocess.run(
                    ["ros2", "topic", "list"], capture_output=True, text=True, timeout=20
                ).stdout
            except Exception:
                out = ""
            visible = set(out.split())
            if all(t in visible for t in topics):
                time.sleep(1.0)  # let the remaining writers settle
                return True
            time.sleep(poll_s)
        return False

    def run(self, spec: RunSpec, output_dir: Path, timeout_s: float) -> tuple[str, list[Path]]:
        """Executes one mission; returns (status, agent_csv_paths)."""
        run_logs = self.logs_dir / spec.run_id
        run_logs.mkdir(parents=True, exist_ok=True)
        px4_procs: list[subprocess.Popen] = []
        node_procs: list[subprocess.Popen] = []
        csv_paths = [output_dir / f"{spec.run_id}__agent{i}.csv" for i in range(spec.num_agents)]
        # A fresh agent per run: otherwise the writers of the previous PX4
        # session stay advertised until the agent notices the client is gone,
        # which lets the readiness check below pass on stale topics.
        self.stop_xrce_agent()
        self.start_xrce_agent(run_logs)
        try:
            instances = [self.instance_offset + i for i in range(spec.num_agents)]
            for i, inst in enumerate(instances):
                env = os.environ.copy()
                env.update({
                    "PX4_SYS_AUTOSTART": "4001",          # gz_x500 airframe
                    "PX4_SIM_MODEL": "gz_x500",
                    "PX4_GZ_MODEL_POSE": f"0,{3 * i}",    # separate spawn rows
                    "PX4_UXRCE_DDS_PORT": str(self.xrce_port),
                })
                if self.gz_partition:
                    env["GZ_PARTITION"] = self.gz_partition
                if self.headless:
                    env["HEADLESS"] = "1"
                log = (run_logs / f"px4_instance_{i}.log").open("w")
                # stdin is an open pipe that is never written: with DEVNULL the
                # px4 shell sees EOF and floods the log with prompts.
                px4_procs.append(subprocess.Popen(
                    [str(self.px4_bin), "-i", str(inst)],
                    cwd=str(self.px4_dir), env=env,
                    stdout=log, stderr=subprocess.STDOUT,
                    stdin=subprocess.PIPE, start_new_session=True,
                ))
                time.sleep(6.0 if i == 0 else 3.0)  # first instance boots gz server

            # PX4 multi-instance uXRCE namespace: instance 0 has none, instance
            # k>0 publishes under /px4_{k} by default.
            prefixes = ["" if inst == 0 else f"/px4_{inst}" for inst in instances]

            # Wait until every instance's uXRCE-DDS client has created its
            # topics; starting the ROS2 nodes earlier leaves them without
            # matched endpoints for the whole run (observed in the smoke test).
            expected = [p + "/fmu/out/vehicle_status" for p in prefixes]
            if not self._wait_for_topics(expected, timeout_s=min(90.0, timeout_s / 2), procs=px4_procs):
                dead = [i for i, p in enumerate(px4_procs) if p.poll() is not None]
                (run_logs / "readiness_timeout.txt").write_text(
                    "PX4 topics not visible before node start: " + ", ".join(expected)
                    + (f"; PX4 instance(s) exited early: {dead}" if dead else "") + "\n"
                )
                return "crash", []

            for i, inst in enumerate(instances):
                # rcl cannot parse an empty override value, so the empty prefix
                # is passed as the YAML empty string ''.
                prefix = prefixes[i] if prefixes[i] else "''"
                log = (run_logs / f"controller_agent_{i}.log").open("w")
                node_procs.append(subprocess.Popen(
                    [
                        sys.executable, str(HERE / "offboard_controller.py"), "--ros-args",
                        "-p", f"method:={spec.method}",
                        "-p", f"scenario:={spec.scenario}",
                        "-p", f"seed:={spec.seed}",
                        "-p", f"agent_index:={i}",
                        "-p", f"num_agents:={spec.num_agents}",
                        "-p", f"contract:={spec.contract}",
                        "-p", f"output_csv:={csv_paths[i]}",
                        "-p", f"topic_prefix:={prefix}",
                        "-p", f"mav_sys_id:={inst + 1}",   # PX4 -i N => MAV_SYS_ID N+1
                    ],
                    stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                ))

            deadline = time.monotonic() + timeout_s
            while time.monotonic() < deadline:
                if all(path.exists() for path in csv_paths):
                    return "ok", csv_paths
                if any(proc.poll() not in (None, 0) for proc in node_procs):
                    return "crash", [p for p in csv_paths if p.exists()]
                if any(proc.poll() is not None for proc in px4_procs):
                    # a PX4 instance died mid-mission: fail fast, keep logs
                    (run_logs / "px4_exit.txt").write_text(
                        "PX4 instance exited during the mission: "
                        + ", ".join(str(i) for i, p in enumerate(px4_procs) if p.poll() is not None) + "\n"
                    )
                    return "crash", [p for p in csv_paths if p.exists()]
                time.sleep(1.0)
            return "timeout", [p for p in csv_paths if p.exists()]
        finally:
            for proc in node_procs + px4_procs:
                _terminate_tree(proc)
            # Kill only this runner's gz server: with a partition the server
            # process carries GZ_PARTITION in its environment; without one,
            # fall back to the historical global pkill.
            if self.gz_partition:
                subprocess.run(
                    ["bash", "-c",
                     f"for p in $(pgrep -f 'gz sim'); do "
                     f"tr '\\0' '\\n' < /proc/$p/environ 2>/dev/null | grep -qx 'GZ_PARTITION={self.gz_partition}' "
                     f"&& kill -9 $p; done"],
                    check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                )
            else:
                subprocess.run(["pkill", "-f", "gz sim"], check=False,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(2.0)


def _terminate_tree(proc: subprocess.Popen) -> None:
    if proc.poll() is not None:
        return
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGINT)
        proc.wait(timeout=8)
    except Exception:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except Exception:
            pass


# ----------------------------------------------------------------------------
# Campaign driver
# ----------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--backend", choices=["px4", "stub"], required=True)
    parser.add_argument("--campaign", choices=["h1", "h2", "h3", "smoke"], default="h1")
    parser.add_argument("--smoke", action="store_true", help="shortcut for --campaign smoke")
    parser.add_argument("--seeds", type=int, default=20, help="seed count (protocol: 20)")
    parser.add_argument("--seed-start", type=int, default=5000, help="v2 confirmatory seeds 5000..5019; technical pilot seeds 3000/3900 are separate")
    parser.add_argument("--num-agents", type=int, default=3,
                        help="PX4 vehicles per run; use 1 for first smoke and 3 for barrier smoke")
    parser.add_argument("--px4-dir", default="~/PX4-Autopilot")
    parser.add_argument("--output", default=str(HERE / "results_v2"))
    parser.add_argument("--run-timeout-s", type=float, default=180.0)
    parser.add_argument("--resume", action="store_true", help="skip runs whose CSVs already exist")
    parser.add_argument("--instance-offset", type=int, default=0,
                        help="first PX4 instance id (use distinct offsets for concurrent runners)")
    parser.add_argument("--xrce-port", type=int, default=8888, help="Micro XRCE-DDS agent UDP port")
    parser.add_argument("--ros-domain-id", type=int, default=42, help="isolated ROS domain; distinct value per concurrent runner")
    parser.add_argument("--max-retries", type=int, default=0, help="preparation-only retries before any common epoch release; maximum two, all attempts retained; never replace an epoch-released mission")
    parser.add_argument("--schedule-seed", type=int, default=9062026, help="fixed independent seed for block and within-block arm execution order")
    parser.add_argument("--simulation-speed", type=float, default=1., help="Gazebo requested real-time factor; original source world remains unchanged")
    parser.add_argument("--archive-root", default=None, help="complete raw destination plus verified tar.gz backup for every attempt")
    parser.add_argument("--prune-archived-duplicates", action="store_true", help="only after both G raw copy and backup verification, remove heavy duplicate guest files from the new scientific tree")
    parser.add_argument("--dispatch-control", default=None, help="operational JSON; pause_between_missions never interrupts an active physical mission")
    parser.add_argument("--freeze-only", action="store_true", help="write execution plan with source hashes, without starting PX4")
    parser.add_argument("--continue-frozen", action="store_true", help="continue only unattempted rows from the identical frozen plan; preserve prior successes AND failures")
    parser.add_argument("--gz-partition", default=None,
                        help="GZ_PARTITION for this runner's Gazebo server (isolates concurrent runners)")
    parser.add_argument("--shard", default=None,
                        help="k/n: assign complete scenario/seed blocks by block index modulo n; all arms in a block run on the same worker")
    args = parser.parse_args()

    try:  # progress lines are useful when stdout is redirected to a log file
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:
        pass
    campaign = "smoke" if args.smoke else args.campaign
    seeds = list(range(args.seed_start, args.seed_start + args.seeds))
    if args.backend == 'px4' and args.resume:
        parser.error('v2 never adopts historical/existing CSVs through --resume; use a fresh output and preserved attempt ledger')
    blocks = randomized_blocks(campaign_runs(campaign, seeds, args.num_agents),args.schedule_seed,campaign)
    shard_k, shard_n = 0, 1
    if args.shard:
        shard_k, shard_n = (int(v) for v in args.shard.split("/"))
        if not 0<=shard_k<shard_n:parser.error('shard must satisfy 0 <= k < n')
    runs = [r for idx,block in enumerate(blocks) if idx%shard_n==shard_k for r in block]
    output_root = Path(args.output) / f"{campaign}_{args.backend}"
    runs_dir = output_root / "runs"
    logs_dir = output_root / "logs"
    runs_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)

    print(f"[runner] campaign={campaign} backend={args.backend} runs={len(runs)}"
          + (f" shard={shard_k}/{shard_n}" if args.shard else ""))
    suffix = f"_{shard_k}_of_{shard_n}" if args.shard else ""
    plan_path=output_root/f'execution_plan{suffix}.json'
    plan={'schema_version':'px4-interface-v2.1','campaign':campaign,'schedule_seed':args.schedule_seed,
          'seeds':seeds,'num_agents':args.num_agents,'shard':[shard_k,shard_n],
          'max_retries':args.max_retries,'simulation_speed':args.simulation_speed,'seed_scope':'initial_waypoint_and_synthetic_FDI_phase_only',
          'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
          'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.glob('*.py'))},
          'ordered_runs':[dict(run_id=r.run_id,method=r.method,scenario=r.scenario,seed=r.seed,contract=r.contract) for r in runs]}
    if plan_path.exists():
        existing=json.loads(plan_path.read_text())
        for field in ('ordered_runs','source_sha256','max_retries','shard','simulation_speed'):
            if existing.get(field)!=plan[field]:parser.error(f'frozen execution plan mismatch: {field}')
    else:plan_path.write_text(json.dumps(plan,indent=2),encoding='utf8')
    if args.freeze_only:
        print(f'[runner] locally frozen execution plan -> {plan_path}');return 0
    manifest_path = output_root / f"runs_index{suffix}.csv"
    if args.backend=='px4' and not args.continue_frozen and (manifest_path.exists() or any((logs_dir/r.run_id).exists() for r in runs)):
        parser.error('existing scientific attempts cannot be overwritten or implicitly resumed; choose a fresh output or an explicitly audited recovery plan')
    manifest_rows: list[dict[str, object]] = []
    if args.continue_frozen and manifest_path.exists():
        with manifest_path.open(newline='',encoding='utf8') as f:manifest_rows=list(csv.DictReader(f))
        expected_ids={r.run_id for r in runs};seen=[r['run_id'] for r in manifest_rows]
        if len(seen)!=len(set(seen)) or not set(seen)<=expected_ids:parser.error('invalid or duplicate durable manifest entries')
        for row in manifest_rows:
            if row['status'].startswith('ok') and not all(Path(v).is_file() for v in row['csv_paths'].split(';')):parser.error('previous successful mission has missing raw CSV; refuse continuation')
    attempted_ids={r['run_id'] for r in manifest_rows}
    if args.continue_frozen and any((logs_dir/r.run_id).exists() and r.run_id not in attempted_ids for r in runs):
        parser.error('unindexed attempt found; explicitly reconcile its immutable attempt_result.json before continuation, never silently rerun it')
    def persist_manifest():
        temp=manifest_path.with_suffix('.writing.csv')
        with temp.open('w',newline='',encoding='utf8') as f:
            writer=csv.DictWriter(f,fieldnames=list(manifest_rows[0]));writer.writeheader();writer.writerows(manifest_rows)
        temp.replace(manifest_path)
    smoke_log_lines: list[str] = []

    backend: Px4Backend | None = None
    if args.backend == "px4":
        from backend_runtime_v2 import Px4BackendV2
        backend = Px4BackendV2(
            Path(args.px4_dir), logs_dir,
            instance_offset=args.instance_offset, xrce_port=args.xrce_port,
            gz_partition=args.gz_partition,
            ros_domain_id=args.ros_domain_id,max_retries=args.max_retries,
            simulation_speed=args.simulation_speed,
            archive_root=(Path(args.archive_root)/f'{campaign}_{args.backend}') if args.archive_root else None,
            prune_archived_duplicates=args.prune_archived_duplicates,
        )
        backend.start_xrce_agent()

    try:
        for index, spec in enumerate(runs):
            if spec.run_id in attempted_ids:continue
            if args.dispatch_control:
                control_path=Path(args.dispatch_control)
                while control_path.exists() and json.loads(control_path.read_text()).get('pause_between_missions',False):
                    (output_root/f'paused{suffix}.json').write_text(json.dumps({'next_run_id':spec.run_id,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}))
                    time.sleep(1.)
                (output_root/f'paused{suffix}.json').unlink(missing_ok=True)
            expected = [runs_dir / f"{spec.run_id}__agent{i}.csv" for i in range(spec.num_agents)]
            if args.resume and all(p.exists() for p in expected):
                status, paths = "ok(resumed)", expected
            elif args.backend == "stub":
                started = time.perf_counter()
                paths = run_stub_episode(spec, runs_dir)
                status = "ok"
                print(f"[{index + 1}/{len(runs)}] {spec.run_id}: {status} "
                      f"({time.perf_counter() - started:.1f}s)")
            else:
                assert backend is not None
                started = time.perf_counter()
                status, paths = backend.run(spec, runs_dir, args.run_timeout_s)
                line = (f"[{index + 1}/{len(runs)}] {spec.run_id}: {status} "
                        f"({time.perf_counter() - started:.1f}s)")
                print(line)
                smoke_log_lines.append(line)
                if status != "ok":
                    # Preserve every failure. The campaign continues but its
                    # paired inference is incomplete; no seed is replaced.
                    print(f"    logs kept verbatim under {logs_dir / spec.run_id}")
            manifest_rows.append({
                "run_id": spec.run_id, "method": spec.method, "scenario": spec.scenario,
                "seed": spec.seed, "contract": spec.contract, "num_agents": spec.num_agents,
                "backend": args.backend, "status": status,
                "attempt_count":getattr(backend,'last_attempt_count',1) if backend else 1,
                "csv_paths": ";".join(str(p) for p in paths),
            })
            persist_manifest()
            if args.archive_root:
                archive_campaign=Path(args.archive_root)/f'{campaign}_{args.backend}';archive_campaign.mkdir(parents=True,exist_ok=True)
                shutil.copy2(manifest_path,archive_campaign/manifest_path.name)
                shutil.copy2(plan_path,archive_campaign/plan_path.name)
    finally:
        if backend is not None:
            backend.stop_xrce_agent()

    persist_manifest()
    print(f"[runner] manifest -> {manifest_path}")

    metrics_frame = analysis.build_metrics_table(manifest_path)
    metrics_path = output_root / f"metrics{suffix}.csv"
    metrics_frame.to_csv(metrics_path, index=False)
    if args.archive_root:shutil.copy2(metrics_path,Path(args.archive_root)/f'{campaign}_{args.backend}'/metrics_path.name)
    print(f"[runner] per-run metrics -> {metrics_path}")

    if campaign == "smoke" and args.backend == "px4":
        smoke_path = output_root / "smoke_log.txt"
        ok = manifest_rows and all(str(r["status"]).startswith("ok") for r in manifest_rows)
        with smoke_path.open("w", encoding="utf-8") as handle:
            handle.write(f"PX4 SITL smoke mission ({args.num_agents} UAV, proposed_minimal_causal, nominal, 16 s)\n")
            handle.write("\n".join(smoke_log_lines) + "\n")
            handle.write(f"status: {'PASS' if ok else 'FAIL'}\n")
            if not metrics_frame.empty:
                handle.write(metrics_frame.to_string(index=False) + "\n")
        print(f"[runner] smoke log -> {smoke_path}")

    return 0 if manifest_rows and all(str(r['status']).startswith('ok') for r in manifest_rows) else 3


if __name__ == "__main__":
    raise SystemExit(main())
