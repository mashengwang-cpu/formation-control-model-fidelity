"""ROS-independent v2 clock, frame and rendezvous contracts."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json, math, os
import numpy as np

SCHEMA_VERSION='px4-interface-v2.1'
MAX_STATE_AGE_S=.05
MAX_STATE_GAP_S=.10
MIN_COVERAGE_S=15.9

class InterfaceViolation(RuntimeError):
    pass

class ObservationLogGate:
    """Independent, unique physical state observations, including a bounded tail."""
    def __init__(self):
        self.last_sample=None;self.receipts=0;self.duplicates=0;self.out_of_order=0
    def accept(self,publication_s,sample_s,receipt_gz_s,epoch,duration):
        if not all(math.isfinite(v) for v in (publication_s,sample_s,receipt_gz_s)) or sample_s<0 or sample_s>publication_s+.001 or publication_s>receipt_gz_s+.1:
            raise InterfaceViolation('observation_clock_domain_mismatch')
        t=sample_s-epoch
        if t< -1e-8 or t>duration+1e-8:return False
        self.receipts+=1
        if self.last_sample is not None:
            if abs(sample_s-self.last_sample)<1e-8:self.duplicates+=1;return False
            if sample_s<self.last_sample:self.out_of_order+=1;raise InterfaceViolation('observation_sample_moved_backwards')
        self.last_sample=sample_s
        return True

def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(data,allow_nan=False,sort_keys=True,indent=2),encoding='utf8')
    os.replace(tmp,path)

def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding='utf8'))
    except FileNotFoundError:
        return None

@dataclass(frozen=True)
class GeoOrigin:
    lat_deg: float
    lon_deg: float
    alt_m: float
    ref_timestamp: int

    def __post_init__(self):
        if not all(math.isfinite(v) for v in (self.lat_deg,self.lon_deg,self.alt_m)) or not -90<=self.lat_deg<=90 or not -180<=self.lon_deg<=180 or self.ref_timestamp<=0:
            raise InterfaceViolation('invalid_geodetic_reference')

    def ecef(self):
        lat,lon=np.radians([self.lat_deg,self.lon_deg])
        a=6378137.; e2=6.6943799901413165e-3
        n=a/math.sqrt(1-e2*math.sin(lat)**2)
        return np.array([(n+self.alt_m)*math.cos(lat)*math.cos(lon),(n+self.alt_m)*math.cos(lat)*math.sin(lon),(n*(1-e2)+self.alt_m)*math.sin(lat)])

    def ned_rotation(self):
        p,l=np.radians([self.lat_deg,self.lon_deg]); sp,cp,sl,cl=math.sin(p),math.cos(p),math.sin(l),math.cos(l)
        return np.array([[-sp*cl,-sp*sl,cp],[-sl,cl,0],[-cp*cl,-cp*sl,-sp]])

class SharedFrame:
    def __init__(self,anchor: GeoOrigin,local: GeoOrigin):
        self.anchor,self.local=anchor,local
        self.rotation=anchor.ned_rotation()@local.ned_rotation().T
        self.translation=anchor.ned_rotation()@(local.ecef()-anchor.ecef())
        if np.linalg.norm(self.translation)>1000:
            raise InterfaceViolation('origin_separation_exceeds_1km')

    def position_to_shared(self,p):
        return self.rotation@np.asarray(p,float)+self.translation

    def position_to_local(self,p):
        return self.rotation.T@(np.asarray(p,float)-self.translation)

    def vector_to_shared(self,v):
        return self.rotation@np.asarray(v,float)

    def vector_to_local(self,v):
        return self.rotation.T@np.asarray(v,float)

@dataclass(frozen=True)
class ControlTick:
    t: float
    dt: float
    sample_s: float
    publication_s: float
    gz_s: float
    age_s: float
    skipped_periods: int

class ClockGate:
    """Consume each physical state at most once; never manufacture catch-up ticks."""
    def __init__(self,period=.02,max_age=MAX_STATE_AGE_S,max_gap=MAX_STATE_GAP_S):
        self.period,self.max_age,self.max_gap=period,max_age,max_gap
        self.last_clock=None; self.last_sample=None
        self.epoch=None; self.first_sample=None

    def observe_clock(self,gz_s):
        if not math.isfinite(gz_s) or gz_s<0:
            raise InterfaceViolation('invalid_gazebo_clock')
        if self.last_clock is not None and gz_s<self.last_clock-1e-8:
            raise InterfaceViolation('gazebo_clock_moved_backwards')
        self.last_clock=gz_s

    def release(self,epoch):
        if self.epoch is not None and abs(self.epoch-epoch)>1e-9:
            raise InterfaceViolation('mission_epoch_changed')
        if self.last_clock is None or epoch-self.last_clock<.25:
            raise InterfaceViolation('late_barrier_release')
        self.epoch=float(epoch)

    def commit_paused(self,epoch):
        """Commit an observed, stationary native simulation clock, never wall time."""
        if self.epoch is not None or self.last_clock is None or abs(epoch-self.last_clock)>.0040001:
            raise InterfaceViolation('paused_epoch_clock_mismatch_or_recommit')
        self.epoch=float(epoch)

    def validate_state(self,publication_s,sample_s):
        if self.last_clock is None:
            return False
        if not all(math.isfinite(v) and v>=0 for v in (publication_s,sample_s)):
            raise InterfaceViolation('invalid_state_timestamp')
        if publication_s>self.last_clock+.1 or sample_s>publication_s+.001:
            raise InterfaceViolation('state_clock_domain_mismatch')
        if self.last_clock-sample_s>self.max_age:
            return False
        # A fresh message may precede the corresponding /clock callback.
        return sample_s<=self.last_clock+1e-8

    def step(self,publication_s,sample_s,duration):
        if self.epoch is None or self.last_clock>=self.epoch+duration or not self.validate_state(publication_s,sample_s):
            return None
        t=sample_s-self.epoch
        if t<0 or t>duration+1e-9:
            return None
        if self.last_sample is not None:
            delta=sample_s-self.last_sample
            if delta< -1e-8:
                raise InterfaceViolation('state_sample_moved_backwards')
            if delta<self.period-1e-6:
                return None
            if delta>self.max_gap:
                raise InterfaceViolation('state_sampling_gap_exceeds_limit')
            dt=delta
        else:
            if t>self.max_age:
                raise InterfaceViolation('first_sample_misses_common_epoch')
            dt=0.0
            self.first_sample=sample_s
        self.last_sample=sample_s
        return ControlTick(t,dt,sample_s,publication_s,self.last_clock,self.last_clock-sample_s,max(0,int(round(dt/self.period))-1))

def release_barrier(records: list[dict],num_agents: int,nonce: str,lead_s=.5):
    if len(records)!=num_agents or {r['agent_index'] for r in records}!=set(range(num_agents)):
        raise InterfaceViolation('incomplete_ready_barrier')
    if any(r.get('nonce')!=nonce or not r.get('ready') for r in records):
        raise InterfaceViolation('stale_or_invalid_ready_record')
    clocks=[r['gz_s'] for r in records]
    if max(clocks)-min(clocks)>.1:
        raise InterfaceViolation('ready_clocks_not_current')
    return {'schema_version':SCHEMA_VERSION,'nonce':nonce,'epoch_s':max(clocks)+lead_s,'agent_count':num_agents}
