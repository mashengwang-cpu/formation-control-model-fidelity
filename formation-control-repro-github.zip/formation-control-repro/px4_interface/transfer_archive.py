"""Verified transfer plus an independent lossless archive of new attempt data."""
import hashlib,json,shutil,tarfile,time
from pathlib import Path
SCIENCE_ROOT=Path('/home/px4/px4_interface_revision_20260906/scientific_5000_5019_v21')
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def inventory(root):
    rows=[]
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root).as_posix()
        if p.is_symlink():rows.append({'path':rel,'symlink':str(p.readlink())})
        elif p.is_file():rows.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
    return rows
def transfer_attempt(source,destination,prune_verified_duplicates=False):
    source=Path(source).resolve();destination=Path(destination)
    if destination.exists():raise RuntimeError('archive destination already exists; explicit reconciliation required')
    entries=inventory(source);started=time.monotonic()
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(source,destination,symlinks=True)
    if inventory(destination)!=entries:raise RuntimeError('transferred raw file inventory/hash mismatch; original retained')
    archive=destination.parent/(destination.name+'.tar.gz')
    # Build and verify on native guest storage, then byte-verify its G copy.
    # This avoids thousands of small compressed writes through the WSL mount.
    tmp=source.parent/(source.name+'.backup.writing.tar.gz')
    with tarfile.open(tmp,'w:gz',compresslevel=1) as tar:tar.add(source,arcname=source.name,recursive=True)
    expected={r['path']:r for r in entries};checked=set()
    with tarfile.open(tmp,'r:gz') as tar:
        for member in tar:
            rel=Path(member.name).relative_to(source.name).as_posix()
            if rel=='.' or member.isdir():continue
            row=expected[rel]
            if member.issym():
                if row.get('symlink')!=member.linkname:raise RuntimeError('backup symlink mismatch')
            elif member.isfile():
                h=hashlib.sha256();f=tar.extractfile(member)
                for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
                if h.hexdigest()!=row['sha256'] or member.size!=row['bytes']:raise RuntimeError('backup file hash mismatch')
            else:raise RuntimeError('unexpected backup member type')
            checked.add(rel)
    if checked!=set(expected):raise RuntimeError('backup membership mismatch; original retained')
    archive_writing=archive.with_suffix('.writing.tar.gz');shutil.copy2(tmp,archive_writing)
    if sha(tmp)!=sha(archive_writing):raise RuntimeError('verified backup transfer byte hash mismatch')
    archive_writing.replace(archive);tmp.unlink()
    report={'source':str(source),'destination':str(destination),'archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'files':entries,'copied_and_backup_hashes_verified':True,'pruned_guest_paths':[],'elapsed_s':time.monotonic()-started}
    if prune_verified_duplicates:
        # User-authorized cleanup is restricted to this new scientific tree.
        source.relative_to(SCIENCE_ROOT.resolve())
        if not source.name.startswith('attempt_'):raise RuntimeError('cleanup target is not an attempt directory')
        targets=[*source.glob('runtime_agent*'),source/'ulog',source/'rosbag',source/'gazebo_world_poses.jsonl']
        for target in targets:
            target.resolve().relative_to(source)
            if target.is_symlink():raise RuntimeError('cleanup target cannot be a symlink')
        for target in targets:
            if target.is_dir():shutil.rmtree(target);report['pruned_guest_paths'].append(str(target))
            elif target.is_file():target.unlink();report['pruned_guest_paths'].append(str(target))
    (destination.parent/(destination.name+'.transfer.json')).write_text(json.dumps(report,indent=2))
    (source/'verified_transfer.json').write_text(json.dumps({k:v for k,v in report.items() if k!='files'},indent=2))
    return report
