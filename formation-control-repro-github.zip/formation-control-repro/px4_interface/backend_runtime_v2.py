"""Attempt-preserving Gazebo/PX4 launcher for the corrected interface layer."""
from __future__ import annotations
import hashlib,json,os,shutil,signal,subprocess,sys,time,uuid
from pathlib import Path
from interface_runtime import SCHEMA_VERSION,atomic_json,read_json,InterfaceViolation

HERE=Path(__file__).resolve().parent

def stop_process(p):
    if p.poll() is not None:return
    try:os.killpg(os.getpgid(p.pid),signal.SIGINT);p.wait(timeout=6)
    except (OSError,subprocess.TimeoutExpired):
        try:os.killpg(os.getpgid(p.pid),signal.SIGKILL);p.wait(timeout=3)
        except (OSError,subprocess.TimeoutExpired):pass

def stop_partition(partition):
    # Match an exact environment entry, never a shell interpolated process name.
    for d in Path('/proc').iterdir():
        if not d.name.isdigit():continue
        try:
            env=(d/'environ').read_bytes().split(b'\0')
            cmd=(d/'cmdline').read_bytes()
            if f'GZ_PARTITION={partition}'.encode() in env and (b'gz' in cmd or b'ign' in cmd):
                os.kill(int(d.name),signal.SIGTERM)
        except (OSError,PermissionError):pass

def source_hashes():
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.glob('*.py'))}

class Px4BackendV2:
    def __init__(self,px4_dir,logs_dir,headless=True,instance_offset=0,xrce_port=8888,gz_partition=None,ros_domain_id=42,max_retries=0,simulation_speed=1.,archive_root=None,prune_archived_duplicates=False):
        self.px4_dir=Path(px4_dir).expanduser().resolve();self.logs_dir=Path(logs_dir)
        self.bin=self.px4_dir/'build/px4_sitl_default/bin/px4'
        self.offset=int(instance_offset);self.port=int(xrce_port);self.partition=gz_partition
        self.domain=int(ros_domain_id);self.max_retries=int(max_retries);self.headless=headless
        self.simulation_speed=float(simulation_speed)
        self.archive_root=Path(archive_root) if archive_root else None;self.prune_archived_duplicates=bool(prune_archived_duplicates)
        if not .1<=self.simulation_speed<=2.:raise ValueError('validation simulation speed must be .1..2')
        if os.name=='nt':raise RuntimeError('PX4 requires an existing provisioned Linux/WSL guest; no installation is performed.')
        if not self.bin.is_file():raise RuntimeError(f'PX4 binary missing: {self.bin}')
        if not 0<=self.domain<=232:raise ValueError('ROS domain must be 0..232')
        if not 0<=self.max_retries<=2:raise ValueError('predefined retry cap is two')
        for exe in ('ros2','gz','MicroXRCEAgent'):
            if shutil.which(exe) is None:raise RuntimeError(f'required executable missing: {exe}')
        probe=subprocess.run([sys.executable,'-c','from gz.transport13 import Node; from gz.msgs10.clock_pb2 import Clock; from rosgraph_msgs.msg import Clock as RosClock'],capture_output=True,text=True,timeout=15)
        if probe.returncode:raise RuntimeError('native Harmonic transport clock binding missing: '+probe.stderr)
        self.params_source=self.px4_dir/'ROMFS/px4fmu_common/init.d-posix/px4-rc.params'
        self.rcs_source=self.px4_dir/'ROMFS/px4fmu_common/init.d-posix/rcS'
        if not self.params_source.exists() or not self.rcs_source.exists():raise RuntimeError('PX4 source startup files required for versioned parameter hook')
        rcs=self.rcs_source.read_text()
        if '. px4-rc.params' not in rcs or rcs.index('. px4-rc.params')>rcs.index('uxrce_dds_client start'):
            raise RuntimeError('PX4 startup no longer supports pre-XRCE parameter hook; inspect version')

    def start_xrce_agent(self):pass # Each isolated attempt starts its own process.
    def stop_xrce_agent(self):pass

    def run(self,spec,output_dir,timeout_s):
        records=[]
        for attempt in range(self.max_retries+1):
            status,paths,record=self.run_attempt(spec,Path(output_dir),timeout_s,attempt)
            records.append(record)
            self.last_attempt_count=len(records)
            with (self.logs_dir/'attempts.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(record,sort_keys=True)+'\n')
            if status=='ok':return status,paths
            # Retry only preparation attempts with no common epoch released.
            # Once an epoch is released no failed attempt is replaced, even if
            # its first state sample never arrives. Never inspect J or energy.
            if record.get('common_epoch_released',False):break
        return records[-1]['verdict'],[]

    def run_attempt(self,spec,output_dir,timeout_s,attempt):
        nonce=uuid.uuid4().hex;part=self.partition or f'px4v2_{nonce}'
        attempt_dir=self.logs_dir/spec.run_id/f'attempt_{attempt:02d}_{nonce}'
        attempt_dir.mkdir(parents=True,exist_ok=False)
        rendezvous=attempt_dir/'rendezvous';rendezvous.mkdir()
        paths=[attempt_dir/f'{spec.run_id}__agent{i}.csv' for i in range(spec.num_agents)]
        record={'schema_version':SCHEMA_VERSION,'run_id':spec.run_id,'nonce':nonce,'attempt_index':attempt,'common_epoch_released':False,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source_sha256':source_hashes(),'ros_domain_id':self.domain,'gz_partition':part,'seed_scope':'initial_waypoint_and_synthetic_FDI_phase_only','verdict':'not_started'}
        atomic_json(attempt_dir/'attempt_started.json',record)
        models=self.px4_dir/'Tools/simulation/gz/models';worlds=self.px4_dir/'Tools/simulation/gz/worlds'
        env=os.environ.copy();env.update({'GZ_PARTITION':part,'ROS_DOMAIN_ID':str(self.domain),'RMW_IMPLEMENTATION':'rmw_fastrtps_cpp','PX4_SYS_AUTOSTART':'4001','PX4_SIM_MODEL':'gz_x500','PX4_UXRCE_DDS_PORT':str(self.port),'PX4_GZ_STANDALONE':'1','PX4_GZ_WORLD':'default','PX4_GZ_MODELS':str(models),'PX4_GZ_WORLDS':str(worlds),'GZ_SIM_RESOURCE_PATH':str(models)+os.pathsep+str(worlds)+os.pathsep+env.get('GZ_SIM_RESOURCE_PATH','')})
        if self.headless:env['HEADLESS']='1'
        procs=[];files=[];px4=[];nodes=[];bridge=None
        def launch(args,log,penv=env,cwd=None,stdin=None):
            h=(attempt_dir/log).open('w');files.append(h)
            p=subprocess.Popen(args,env=penv,cwd=cwd,stdin=stdin,stdout=h,stderr=subprocess.STDOUT,start_new_session=True)
            procs.append(p);return p
        try:
            # Record exact environment/version and model/source state before launch.
            checks=[['git','-C',str(self.px4_dir),'rev-parse','HEAD'],['git','-C',str(self.px4_dir),'status','--porcelain'],['gz','sim','--version']]
            versions=[]
            for cmd in checks:
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=20);versions.append({'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
            atomic_json(attempt_dir/'environment.json',{'checks':versions,'python':sys.version,'clock_contract':'Gazebo /clock; raw PX4 timestamps; SYNCT=0','source_rcS_sha256':hashlib.sha256(self.rcs_source.read_bytes()).hexdigest()})
            launch(['MicroXRCEAgent','udp4','-p',str(self.port)],'xrce_agent.log')
            import xml.etree.ElementTree as ET
            world_tree=ET.parse(worlds/'default.sdf');physics=world_tree.find('world/physics')
            step=float(physics.findtext('max_step_size'))
            physics.find('real_time_factor').text=str(self.simulation_speed)
            physics.find('real_time_update_rate').text=str(self.simulation_speed/step)
            world_copy=attempt_dir/'world_used.sdf';world_tree.write(world_copy,encoding='utf-8',xml_declaration=True)
            model_files=[worlds/'default.sdf',models/'x500/model.sdf',models/'x500_base/model.sdf']
            atomic_json(attempt_dir/'simulation_contract.json',{'requested_real_time_factor':self.simulation_speed,'max_step_size_s':step,'world_used_sha256':hashlib.sha256(world_copy.read_bytes()).hexdigest(),'input_files_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in model_files if p.exists()},'PX4_SIM_SPEED_FACTOR_inherited':env.get('PX4_SIM_SPEED_FACTOR'),'rate_authority':'explicit Gazebo SDF physics configuration; actual rate measured in native clock log'})
            server=launch(['gz','sim','-r','-s','--verbose=2',str(world_copy)],'gazebo_server.log')
            bridge=launch([sys.executable,str(HERE/'gazebo_clock_bridge.py'),'--ros-args','-p',f'record_dir:={attempt_dir}'],'gazebo_clock_bridge.log')
            clock_deadline=time.monotonic()+45
            while time.monotonic()<clock_deadline:
                clock_csv=attempt_dir/'gazebo_native_clock.csv'
                if clock_csv.exists() and clock_csv.stat().st_size>100:break
                if server.poll() is not None or bridge.poll() is not None:raise InterfaceViolation('gazebo_start_or_native_clock_bridge_failed')
                time.sleep(.2)
            else:raise InterfaceViolation('no_native_gazebo_clock_before_PX4_launch')
            for i in range(spec.num_agents):
                inst=self.offset+i;hook_dir=attempt_dir/f'params_hook_{i}';hook_dir.mkdir()
                # v1.15 rcS sources px4-rc.params via PATH before starting XRCE.
                # Use a wrapper; never edit the installed PX4 source or old parameters.
                def sq(v):return "'"+str(v).replace("'","'\"'\"'")+"'"
                hook=(f'. {sq(self.params_source)}\nparam set UXRCE_DDS_SYNCT 0\nparam set UXRCE_DDS_SYNCC 0\n'
                      f'param show -a > {sq(attempt_dir/f"parameters_agent{i}.txt")}\n'
                      f'param compare UXRCE_DDS_SYNCT 0 || exit 3\necho PX4_INTERFACE_V2_SYNCT_ZERO\n')
                (hook_dir/'px4-rc.params').write_text(hook)
                ie=env.copy();ie['PATH']=str(hook_dir)+os.pathsep+env.get('PATH','');ie['PX4_GZ_MODEL_POSE']=f'0,{3*i}'
                runtime=attempt_dir/f'runtime_agent{i}';runtime.mkdir()
                px4.append(launch([str(self.bin),'-i',str(inst),'-w',str(runtime),str(self.px4_dir/'build/px4_sitl_default/etc')],f'px4_instance_{i}.log',ie,str(self.px4_dir),subprocess.PIPE))
                time.sleep(6 if i==0 else 3)
            # A separate independent recorder preserves original Gazebo clock and
            # truth/state topics, enabling clock and response re-audits.
            prefixes=['' if self.offset+i==0 else f'/px4_{self.offset+i}' for i in range(spec.num_agents)]
            topics=['/clock']+[pre+'/fmu/out/'+topic for pre in prefixes for topic in ('vehicle_local_position','vehicle_status','vehicle_odometry','timesync_status','vehicle_attitude','battery_status')]
            topics += [pre+'/fmu/in/'+topic for pre in prefixes for topic in ('trajectory_setpoint','offboard_control_mode','vehicle_command')]
            launch(['ros2','bag','record','-o',str(attempt_dir/'rosbag'),'--include-hidden-topics',*topics],'rosbag_recorder.log')
            for i,pre in enumerate(prefixes):
                cmd=[sys.executable,str(HERE/'offboard_runtime_v2.py'),'--ros-args','-p','use_sim_time:=true',
                     '-p',f'method:={spec.method}','-p',f'scenario:={spec.scenario}','-p',f'seed:={spec.seed}',
                     '-p',f'agent_index:={i}','-p',f'num_agents:={spec.num_agents}','-p',f'contract:={spec.contract}',
                     '-p',f'output_csv:={paths[i]}','-p',f'topic_prefix:={pre or chr(39)+chr(39)}',
                     '-p',f'mav_sys_id:={self.offset+i+1}','-p',f'rendezvous_dir:={rendezvous}','-p',f'run_nonce:={nonce}']
                nodes.append(launch(cmd,f'controller_agent_{i}.log'))
            deadline=time.monotonic()+timeout_s;frame_set=False;released=False;probe_count=0;last_resume_wall=0.
            def world_control(pause):
                request_id=uuid.uuid4().hex
                request={'nonce':nonce,'request_id':request_id,'pause':pause}
                atomic_json(rendezvous/f'world_control_request_{request_id}.json',request)
                # Native service bindings can hold their Python process GIL.
                # Never invoke them in the process publishing physical /clock.
                call=subprocess.run([sys.executable,str(HERE/'world_control_service.py'),'--pause','true' if pause else 'false'],env=env,capture_output=True,text=True,timeout=5.)
                try:service=json.loads(call.stdout)
                except ValueError:raise InterfaceViolation('world_control_helper_failure:'+call.stderr)
                atomic_json(rendezvous/f'world_control_response_{request_id}.json',{**request,**service})
                if call.returncode or not service['service_success']:raise InterfaceViolation('native_world_control_service_failed')
                atomic_json(rendezvous/'native_snapshot_request.json',{'nonce':nonce,'request_id':request_id,'require_paused':pause})
                limit=time.monotonic()+5.
                while time.monotonic()<limit:
                    response=read_json(rendezvous/f'native_snapshot_{request_id}.json')
                    if response:
                        return {**request,**service,**response}
                    if bridge.poll() is not None:raise InterfaceViolation('native_clock_bridge_exited_during_barrier')
                    time.sleep(.02)
                raise InterfaceViolation('native_world_control_service_timeout')
            while time.monotonic()<deadline:
                if any(p.poll() is not None for p in px4) or bridge.poll() is not None:
                    raise InterfaceViolation('simulator_or_clock_bridge_exited')
                failures=[read_json(p.with_suffix('.failed.json')) for p in paths]
                if any(failures):raise InterfaceViolation('node_failure:'+json.dumps([f for f in failures if f]))
                if any(p.poll() not in (None,0) for p in nodes):raise InterfaceViolation('node_process_failed')
                origins=[read_json(rendezvous/f'origin_{i}.json') for i in range(spec.num_agents)]
                if not frame_set and all(origins):
                    if any(o['nonce']!=nonce for o in origins):raise InterfaceViolation('origin_nonce_mismatch')
                    atomic_json(rendezvous/'frame.json',{'nonce':nonce,'anchor':origins[0]['origin'],'origins':origins});frame_set=True
                ready=[read_json(rendezvous/f'ready_{i}.json') for i in range(spec.num_agents)]
                if frame_set and not released and all(ready) and all(r['nonce']==nonce and r['ready'] and r['wall_monotonic_s']>last_resume_wall and time.monotonic()-r['wall_monotonic_s']<2. for r in ready):
                    probe_count+=1
                    if probe_count>20:raise InterfaceViolation('paused_initial_state_probe_limit')
                    paused=world_control(True);epoch=paused['gz_s'];probe_id=f'{probe_count:02d}'
                    atomic_json(rendezvous/f'ready_set_{probe_id}.json',{'nonce':nonce,'records':ready})
                    payload={'schema_version':SCHEMA_VERSION,'nonce':nonce,'probe_id':probe_id,'epoch_s':epoch,'agent_count':spec.num_agents,'protocol':'native_pause_snapshot_commit_resume'}
                    atomic_json(rendezvous/'pause_snapshot.json',payload)
                    limit=time.monotonic()+3.
                    while time.monotonic()<limit:
                        acks=[read_json(rendezvous/f'pause_ack_{probe_id}_{i}.json') for i in range(spec.num_agents)]
                        if all(acks):break
                        time.sleep(.02)
                    if not all(acks):raise InterfaceViolation('paused_initial_snapshot_ack_timeout')
                    if not all(a['ready'] and a['nonce']==nonce and a['epoch_s']==epoch for a in acks):
                        world_control(False);last_resume_wall=time.monotonic();continue
                    record['common_epoch_released']=True;record['common_epoch_s']=epoch
                    record['initial_snapshot_probe_id']=probe_id;record['pause_probe_count']=probe_count
                    atomic_json(rendezvous/'epoch.json',payload);released=True
                    limit=time.monotonic()+3.
                    while time.monotonic()<limit:
                        commits=[read_json(rendezvous/f'commit_ack_{i}.json') for i in range(spec.num_agents)]
                        if all(commits):break
                        time.sleep(.02)
                    if not all(commits) or not all(c['nonce']==nonce and c['epoch_s']==epoch for c in commits):raise InterfaceViolation('paused_epoch_commit_ack_timeout')
                    resumed=world_control(False)
                    atomic_json(rendezvous/'barrier_complete.json',{'nonce':nonce,'epoch_s':epoch,'paused':paused,'resume':resumed,'initial_states':acks,'commit_acks':commits})
                complete=[read_json(p.with_suffix('.complete.json')) for p in paths]
                if all(complete):
                    if any(c['nonce']!=nonce for c in complete):raise InterfaceViolation('completed_nonce_mismatch')
                    if len({c['common_epoch_s'] for c in complete})!=1:raise InterfaceViolation('inconsistent_common_epoch')
                    if max(c['first_t'] for c in complete)-min(c['first_t'] for c in complete)>.05:raise InterfaceViolation('first_sample_skew')
                    for i in range(spec.num_agents):
                        if 'PX4_INTERFACE_V2_SYNCT_ZERO' not in (attempt_dir/f'px4_instance_{i}.log').read_text(errors='replace'):
                            raise InterfaceViolation('SYNCT_zero_not_confirmed_in_PX4_startup')
                    # Allow landing requests and log flush before terminating.
                    limit=time.monotonic()+10
                    while time.monotonic()<limit and any(p.poll() is None for p in nodes):time.sleep(.2)
                    record['verdict']='ok';record['csv_paths']=[str(p) for p in paths]
                    break
                time.sleep(.05)
            else:raise InterfaceViolation('attempt_wall_timeout')
        except Exception as exc:
            record['verdict']='interface_or_simulator_failure';record['reason']=str(exc)
        finally:
            for p in reversed(procs):stop_process(p)
            stop_partition(part)
            for h in files:h.close()
            # PX4 logs identify the instance rootfs. Copy its generated ULogs into
            # this attempt; never remove or overwrite the installed log directory.
            import re
            for i in range(spec.num_agents):
                log=attempt_dir/f'px4_instance_{i}.log'
                if not log.exists():continue
                content=log.read_text(errors='replace')
                wd=re.search(r'working directory (.+)',content)
                rootfs=Path(wd[1].strip()) if wd else attempt_dir/f'runtime_agent{i}'
                if rootfs.exists():
                    for rel in re.findall(r'Opened full log file: (\S+\.ulg)',content):
                        src=(rootfs/rel).resolve()
                        if src.is_file():
                            import gzip
                            dest=attempt_dir/'ulog'/f'agent{i}_{src.name}.gz';dest.parent.mkdir(exist_ok=True)
                            # Lossless compression, original source ULog intact.
                            with src.open('rb') as fi,gzip.open(dest,'wb',compresslevel=1) as fo:shutil.copyfileobj(fi,fo)
            record['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
            atomic_json(attempt_dir/'attempt_result.json',record)
        if self.archive_root is not None:
            from transfer_archive import transfer_attempt
            transfer_attempt(attempt_dir,self.archive_root/attempt_dir.relative_to(self.logs_dir.parent),self.prune_archived_duplicates)
        return ('ok',paths,record) if record['verdict']=='ok' else (record['verdict'],[],record)
