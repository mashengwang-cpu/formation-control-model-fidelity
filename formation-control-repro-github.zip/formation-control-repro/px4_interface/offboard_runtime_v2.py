"""Gazebo-clock-driven offboard runtime. No historical result is produced here."""
from __future__ import annotations
import csv,json,math,time,sys
from dataclasses import asdict,replace
from pathlib import Path
import numpy as np
from interface_runtime import (ClockGate,ObservationLogGate,GeoOrigin,SharedFrame,InterfaceViolation,SCHEMA_VERSION,atomic_json,read_json,MIN_COVERAGE_S)
from offboard_controller import (CONTROL_DT_S,LOG_COLUMNS,METHOD_SPECS,SampledDataController,CausalBiasEstimator,CausalEfficiencyEstimator,formation_offsets,initial_perturbation,leader_reference,AttackInjector)

EXTRA_COLUMNS=['clock_gz_s','state_timestamp_s','state_sample_s','dt_state_s','state_age_s',
 'wall_monotonic_s','common_epoch_s','x_shared','y_shared','z_shared','vx_shared','vy_shared','vz_shared',
 'setpoint_ax_local','setpoint_ay_local','setpoint_az_local','setpoint_published','skipped_periods',
 'command_publish_count','measurement_refresh_count','offboard_heartbeat_count','px4_status_nav','px4_status_armed']
STATE_COLUMNS=['t','err_x','err_y','err_norm','clock_receipt_gz_s','state_timestamp_s','state_sample_s','wall_monotonic_s','common_epoch_s','x_shared','y_shared','z_shared','vx_shared','vy_shared','vz_shared','receipt_phase']
EVENT_COLUMNS=['event_type','clock_gz_s','common_epoch_s','wall_monotonic_s','state_sample_s','cumulative_count']

def main_v2():
    try:
        import rclpy
        from rclpy.node import Node
        from rclpy.clock import Clock as RclClock
        from rclpy.clock import ClockType
        from rclpy.qos import QoSProfile,ReliabilityPolicy,DurabilityPolicy,HistoryPolicy
        from rosgraph_msgs.msg import Clock
        from px4_msgs.msg import OffboardControlMode,TrajectorySetpoint,VehicleCommand,VehicleLocalPosition,VehicleStatus
    except ImportError as exc:
        print(f'PX4 v2 runtime unavailable: {exc}',file=sys.stderr)
        return 2

    class Agent(Node):
        def __init__(self):
            super().__init__('offboard_interface_v2')
            defaults={'method':'proposed_minimal_causal','scenario':'nominal','seed':0,'agent_index':0,
                      'num_agents':3,'contract':'causal','duration_s':16.,'altitude_m':5.,
                      'output_csv':'run.csv','topic_prefix':'','mav_sys_id':1,'rendezvous_dir':'',
                      'run_nonce':'','clock_topic':'/clock','ascend_timeout_s':60.,'position_gain':2.15,'velocity_gain':2.05}
            for k,v in defaults.items(): self.declare_parameter(k,v)
            g=lambda k:self.get_parameter(k).value
            if not self.get_parameter('use_sim_time').value:
                raise InterfaceViolation('use_sim_time_must_be_true')
            self.method,self.scenario,self.contract=str(g('method')),str(g('scenario')),str(g('contract'))
            self.seed,self.index,self.n=int(g('seed')),int(g('agent_index')),int(g('num_agents'))
            self.duration,self.altitude=float(g('duration_s')),float(g('altitude_m'))
            self.output=Path(str(g('output_csv'))); self.rendezvous=Path(str(g('rendezvous_dir')))
            self.nonce=str(g('run_nonce')); self.sys_id=int(g('mav_sys_id'))
            if not self.nonce or not str(g('rendezvous_dir')):
                raise InterfaceViolation('runner_rendezvous_required')
            self.timeout=float(g('ascend_timeout_s'))
            self.position_gain,self.velocity_gain=float(g('position_gain')),float(g('velocity_gain'))
            self.controller=SampledDataController(replace(METHOD_SPECS[self.method],position_gain=self.position_gain,velocity_gain=self.velocity_gain))
            self.bias_estimator=CausalBiasEstimator(); self.efficiency_estimator=CausalEfficiencyEstimator()
            self.injector=AttackInjector(self.scenario,self.index,self.n,self.seed,self.duration)
            self.offset=formation_offsets(self.n)[self.index]
            self.perturb=initial_perturbation(self.seed,self.scenario,self.n,self.index)
            self.start_target=np.r_[self.offset+self.perturb,-self.altitude]
            self.gate=ClockGate(); self.frame=None; self.origin=None; self.state=None
            self.armed=-1; self.nav=-1; self.phase='wait_frame'; self.failed=None
            self.rows=[]; self.prev_vel=None; self.prev_cmd=None
            self.state_rows=[];self.event_rows=[];self.observation_gate=ObservationLogGate()
            self.stop_observed_gz=None;self.stop_wall=None;self.drain_complete=False;self.drain_limit_sim=.20;self.drain_limit_wall=2.
            self.total_commands=0; self.total_heartbeats=0; self.total_refreshes=0
            self.mission_commands=0; self.mission_heartbeats=0
            self.last_hb=None; self.last_coord=None; self.first_stream=None; self.ascend_t0=None; self.stable_t0=None
            self.last_arm=None; self.land_t0=None; self.start_wall=time.monotonic(); self.clock_wall=self.start_wall
            self.mission_wall_start=None; self.last_state_used=None
            self.state_origin=None; self.reference_reset_counters=None
            self.initial_snapshot=None;self.pause_probe=None
            qos=QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT,durability=DurabilityPolicy.VOLATILE,history=HistoryPolicy.KEEP_LAST,depth=5)
            pre=str(g('topic_prefix'))
            self.mode_pub=self.create_publisher(OffboardControlMode,pre+'/fmu/in/offboard_control_mode',qos)
            self.sp_pub=self.create_publisher(TrajectorySetpoint,pre+'/fmu/in/trajectory_setpoint',qos)
            self.cmd_pub=self.create_publisher(VehicleCommand,pre+'/fmu/in/vehicle_command',qos)
            self.create_subscription(VehicleLocalPosition,pre+'/fmu/out/vehicle_local_position',self.on_state,qos)
            self.create_subscription(VehicleStatus,pre+'/fmu/out/vehicle_status',self.on_status,qos)
            self.create_subscription(Clock,str(g('clock_topic')),self.on_clock,qos)
            self.create_timer(.5,self.watchdog,clock=RclClock(clock_type=ClockType.STEADY_TIME))
            self.create_timer(.02,self.coordinate_paused,clock=RclClock(clock_type=ClockType.STEADY_TIME))
            self.get_logger().info(f'v2 nonce={self.nonce} agent={self.index} method={self.method}; awaiting independent Gazebo clock and frame')

        def stamp(self):
            if self.gate.last_clock is None: raise InterfaceViolation('no_gazebo_clock')
            return int(round(self.gate.last_clock*1e6))

        def fail(self,reason):
            if self.failed: return
            self.failed=str(reason)
            atomic_json(self.output.with_suffix('.failed.json'),{'schema_version':SCHEMA_VERSION,'nonce':self.nonce,'agent_index':self.index,'verdict':'interface_failure','reason':self.failed,'phase':self.phase,'gz_s':self.gate.last_clock,'wall_monotonic_s':time.monotonic()})
            self.get_logger().error(self.failed)
            if self.rows or self.state_rows:
                self.write_csv(self.output.with_suffix('.partial.csv'));self.write_sidecars()
            if self.armed==2 and self.gate.last_clock is not None:
                self.send_command(VehicleCommand.VEHICLE_CMD_NAV_LAND)
            self.phase='failed'

        def on_status(self,m): self.armed,self.nav=int(m.arming_state),int(m.nav_state)

        def on_state(self,m):
            try:
                if not (m.xy_valid and m.z_valid and m.v_xy_valid and m.v_z_valid): return
                if not (m.xy_global and m.z_global): return
                if self.phase in ('land','done','failed'):return
                if self.phase=='drain' and m.timestamp_sample*1e-6>self.gate.epoch+self.duration+1e-8:return
                origin=GeoOrigin(float(m.ref_lat),float(m.ref_lon),float(m.ref_alt),int(m.ref_timestamp))
                counters=(int(m.xy_reset_counter),int(m.z_reset_counter),int(m.vxy_reset_counter),int(m.vz_reset_counter))
                if self.frame and (origin!=self.origin or counters!=self.reference_reset_counters):
                    raise InterfaceViolation('ekf_reference_or_state_reset_after_frame_lock')
                if not self.frame:
                    self.origin=origin; self.reference_reset_counters=counters
                self.state=m
                self.log_observation(m)
            except Exception as exc: self.fail(exc)

        def log_observation(self,m):
            if self.gate.epoch is None or self.frame is None or self.gate.last_clock is None:return
            if not self.observation_gate.accept(m.timestamp*1e-6,m.timestamp_sample*1e-6,self.gate.last_clock,self.gate.epoch,self.duration):return
            t=m.timestamp_sample*1e-6-self.gate.epoch
            p=self.frame.position_to_shared([m.x,m.y,m.z]);v=self.frame.vector_to_shared([m.vx,m.vy,m.vz]);lp,_=leader_reference(t)
            err=p[:2]-lp-self.offset
            self.state_rows.append([t,*err,float(np.linalg.norm(err)),self.gate.last_clock,m.timestamp*1e-6,m.timestamp_sample*1e-6,time.monotonic(),self.gate.epoch,*p,*v,self.phase])

        def log_event(self,kind,count):
            self.event_rows.append([kind,self.gate.last_clock,self.gate.epoch,time.monotonic(),self.state.timestamp_sample*1e-6 if self.state is not None else math.nan,count])

        def fresh(self):
            if self.state is None: return False
            return self.gate.validate_state(self.state.timestamp*1e-6,self.state.timestamp_sample*1e-6)

        def shared_state(self):
            m=self.state
            return self.frame.position_to_shared([m.x,m.y,m.z]),self.frame.vector_to_shared([m.vx,m.vy,m.vz])

        def send_command(self,command,p1=0.,p2=0.):
            m=VehicleCommand();m.timestamp=self.stamp();m.command=command;m.param1=float(p1);m.param2=float(p2)
            m.target_system=self.sys_id;m.target_component=1;m.source_system=1;m.source_component=1;m.from_external=True
            self.cmd_pub.publish(m)

        def heartbeat(self,position):
            if self.phase=='mission' and self.gate.last_clock>=self.gate.epoch+self.duration:return
            m=OffboardControlMode();m.timestamp=self.stamp();m.position=position;m.velocity=False;m.acceleration=not position
            self.mode_pub.publish(m);self.total_heartbeats+=1
            if self.phase=='mission': self.mission_heartbeats+=1;self.log_event('heartbeat',self.mission_heartbeats)

        def hold_position(self):
            target=self.frame.position_to_local(self.start_target)
            m=TrajectorySetpoint();m.timestamp=self.stamp();m.position=target.tolist();m.velocity=[math.nan]*3;m.acceleration=[math.nan]*3;m.yaw=0.
            self.sp_pub.publish(m);self.total_commands+=1

        def on_clock(self,m):
            try:
                now=float(m.clock.sec)+float(m.clock.nanosec)*1e-9
                self.gate.observe_clock(now);self.clock_wall=time.monotonic()
                if self.phase in ('failed','done'): return
                if self.phase=='committed' and now>self.gate.epoch+1e-8:
                    self.phase='mission_pending';self.mission_wall_start=time.monotonic()
                if self.phase=='mission_pending':
                    if now-self.gate.epoch>.05:raise InterfaceViolation('first_command_misses_common_epoch')
                    if self.fresh() and self.state.timestamp_sample*1e-6>=self.gate.epoch-1e-8:
                        self.phase='mission';self.heartbeat(False);self.last_hb=now
                        self.mission_step()
                # The endpoint gate precedes every task heartbeat and command.
                if self.phase=='mission' and now>=self.gate.epoch+self.duration:
                    self.stop_mission()
                if self.last_hb is None or now-self.last_hb>=CONTROL_DT_S-1e-8:
                    if self.frame is not None and self.phase in ('ascend','ready','mission'):
                        self.heartbeat(self.phase!='mission')
                        if self.phase!='mission': self.hold_position()
                    self.last_hb=now
                coord_due=self.last_coord is None or now-self.last_coord>=CONTROL_DT_S-1e-8
                if coord_due and self.phase=='wait_frame': self.prepare_frame();self.last_coord=now
                elif coord_due and self.phase in ('ascend','ready'): self.prepare_ready();self.last_coord=now
                elif self.phase=='mission':
                    self.mission_step()
                elif self.phase=='drain':
                    if now>=self.gate.epoch+self.duration+self.drain_limit_sim:self.finish()
                elif self.phase=='land':
                    if now-self.land_t0>3:
                        self.phase='done'
            except Exception as exc: self.fail(exc)

        def prepare_frame(self):
            if not self.fresh() or self.origin is None:return
            atomic_json(self.rendezvous/f'origin_{self.index}.json',{'nonce':self.nonce,'agent_index':self.index,'origin':asdict(self.origin),'gz_s':self.gate.last_clock,'wall_monotonic_s':time.monotonic()})
            record=read_json(self.rendezvous/'frame.json')
            if not record:return
            if record['nonce']!=self.nonce:raise InterfaceViolation('stale_frame_nonce')
            self.frame=SharedFrame(GeoOrigin(**record['anchor']),self.origin)
            atomic_json(self.output.with_suffix('.frame.json'),{'nonce':self.nonce,'anchor':record['anchor'],'local_origin':asdict(self.origin),'translation_ned':self.frame.translation.tolist(),'rotation':self.frame.rotation.tolist(),'start_target_shared':self.start_target.tolist(),'reference_reset_counters':self.reference_reset_counters})
            self.phase='ascend';self.ascend_t0=self.gate.last_clock;self.first_stream=self.gate.last_clock

        def prepare_ready(self):
            now=self.gate.last_clock
            if now-self.ascend_t0>self.timeout:raise InterfaceViolation('takeoff_or_barrier_timeout')
            if now-self.first_stream>=1.2 and (self.last_arm is None or now-self.last_arm>=2) and (self.armed!=2 or self.nav!=14):
                self.send_command(VehicleCommand.VEHICLE_CMD_DO_SET_MODE,1.,6.)
                self.send_command(VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM,1.);self.last_arm=now
            ready=False;fresh=self.fresh();quality={}
            if fresh:
                p,v=self.shared_state()
                ready=self.armed==2 and self.nav==14 and np.linalg.norm(p[:2]-self.start_target[:2])<.25 and abs(p[2]-self.start_target[2])<.25 and np.linalg.norm(v)<.2
                quality={'position_shared':p.tolist(),'velocity_shared':v.tolist(),'xy_slot_error':float(np.linalg.norm(p[:2]-self.start_target[:2])),'z_slot_error':float(abs(p[2]-self.start_target[2])),'state_age_s':now-self.state.timestamp_sample*1e-6}
                # A clock callback with no fresh observation is not evidence of
                # a physical departure from the slot. Evaluate stability only
                # on actual state evidence; start still requires fresh data.
                if not ready:self.stable_t0=None
                elif self.stable_t0 is None:self.stable_t0=self.state.timestamp_sample*1e-6
            instantaneous_ready=ready
            ready=ready and self.state.timestamp_sample*1e-6-self.stable_t0>=1.
            atomic_json(self.rendezvous/f'ready_{self.index}.json',{'nonce':self.nonce,'agent_index':self.index,'ready':bool(ready),'gz_s':now,'wall_monotonic_s':time.monotonic(),'fresh':fresh,'quality':quality})

        def coordinate_paused(self):
            # A steady timer only coordinates a stationary physics barrier. No
            # controller update, reference advance, or virtual state is made.
            if self.phase not in ('ascend','ready','committed'):return
            try:
                probe=read_json(self.rendezvous/'pause_snapshot.json')
                if probe and probe['probe_id']!=self.pause_probe:
                    if probe['nonce']!=self.nonce:raise InterfaceViolation('pause_nonce_mismatch')
                    epoch=float(probe['epoch_s'])
                    if self.state is None or self.gate.last_clock is None:return
                    sample=self.state.timestamp_sample*1e-6
                    if abs(self.gate.last_clock-epoch)>.0040001 or sample>epoch+1e-8:return
                    p,v=self.shared_state();xy=float(np.linalg.norm(p[:2]-self.start_target[:2]));z=float(abs(p[2]-self.start_target[2]));speed=float(np.linalg.norm(v));age=epoch-sample
                    good=self.armed==2 and self.nav==14 and 0<=age<=.05 and xy<.25 and z<.25 and speed<.2 and self.stable_t0 is not None
                    ack={'nonce':self.nonce,'probe_id':probe['probe_id'],'agent_index':self.index,'epoch_s':epoch,'ready':bool(good),'state_sample_s':sample,'state_timestamp_s':self.state.timestamp*1e-6,'clock_gz_s':self.gate.last_clock,'state_age_s':age,'position_shared':p.tolist(),'velocity_shared':v.tolist(),'start_target_shared':self.start_target.tolist(),'xy_slot_error':xy,'z_slot_error':z,'speed_m_s':speed,'armed':self.armed,'nav':self.nav,'wall_monotonic_s':time.monotonic()}
                    atomic_json(self.rendezvous/f'pause_ack_{probe["probe_id"]}_{self.index}.json',ack)
                    self.pause_probe=probe['probe_id']
                    if good:self.initial_snapshot=ack
                    else:self.stable_t0=None
                commit=read_json(self.rendezvous/'epoch.json')
                if commit and self.gate.epoch is None:
                    if commit['nonce']!=self.nonce or self.initial_snapshot is None or commit['probe_id']!=self.initial_snapshot['probe_id'] or not self.initial_snapshot['ready']:
                        raise InterfaceViolation('commit_without_valid_paused_initial_snapshot')
                    self.gate.commit_paused(float(commit['epoch_s']));self.phase='committed'
                    atomic_json(self.rendezvous/f'commit_ack_{self.index}.json',{'nonce':self.nonce,'probe_id':commit['probe_id'],'agent_index':self.index,'epoch_s':self.gate.epoch,'clock_gz_s':self.gate.last_clock,'wall_monotonic_s':time.monotonic()})
            except Exception as exc:self.fail(exc)

        def mission_step(self):
            if self.gate.last_clock>=self.gate.epoch+self.duration:return
            if self.armed!=2 or self.nav!=14:raise InterfaceViolation('left_armed_offboard_during_mission')
            if self.state is None:return
            tick=self.gate.step(self.state.timestamp*1e-6,self.state.timestamp_sample*1e-6,self.duration)
            if tick is None:return
            p,v=self.shared_state();lp,lv=leader_reference(tick.t)
            err=p[:2]-lp-self.offset;verr=v[:2]-lv
            if self.prev_vel is not None and self.contract=='causal' and self.controller.spec.resilience:
                self.efficiency_estimator.update(applied_control=self.prev_cmd,observed_acceleration=(v[:2]-self.prev_vel)/tick.dt,mass=1.,modelled_drag=np.zeros(2),dt_s=tick.dt)
            bias=self.injector.sensor_bias(tick.t);rho=self.injector.actuator_efficiency(tick.t);comm=self.injector.communication_available(tick.t)
            raw=err+bias
            if self.contract=='oracle': bh=bias.copy();rh=rho
            elif self.contract=='causal':bh=self.bias_estimator.update(raw,verr,tick.dt);rh=self.efficiency_estimator.efficiency
            else:bh=np.zeros(2);rh=1.
            ctrlerr=raw-bh
            command,diag=self.controller.step(tick.t,tick.dt,ctrlerr,verr,comm,rh)
            applied=rho*command
            az=1.5*(-self.altitude-p[2])-1.2*v[2]
            actual=self.frame.vector_to_local(np.r_[applied,az])
            m=TrajectorySetpoint();m.timestamp=self.stamp();m.position=[math.nan]*3;m.velocity=[math.nan]*3;m.acceleration=actual.tolist();m.yaw=0.
            self.sp_pub.publish(m);self.total_commands+=1;self.mission_commands+=1;self.total_refreshes+=int(diag.triggered)
            self.log_event('command',self.mission_commands)
            if diag.triggered:self.log_event('refresh',self.total_refreshes)
            self.rows.append([tick.t,err[0],err[1],float(np.linalg.norm(err)),ctrlerr[0],ctrlerr[1],*command,*applied,float(diag.triggered),float(comm),rho,rh,*bias,*bh,diag.trigger_metric,diag.trigger_threshold,
                              tick.gz_s,tick.publication_s,tick.sample_s,tick.dt,tick.age_s,time.monotonic(),self.gate.epoch,*p,*v,*actual,1,tick.skipped_periods,self.mission_commands,self.total_refreshes,self.mission_heartbeats,self.nav,self.armed])
            self.prev_vel=v[:2].copy();self.prev_cmd=command.copy()

        def write_csv(self,path):
            path.parent.mkdir(parents=True,exist_ok=True)
            with path.open('w',newline='',encoding='utf8') as f:
                f.write(f'# schema_version={SCHEMA_VERSION} method={self.method} scenario={self.scenario} seed={self.seed}\n')
                f.write(f'# agent_index={self.index} num_agents={self.n} contract={self.contract} duration_s={self.duration} clock=gazebo_clock_raw_px4 error_source=px4_state_estimate gamma=0 position_gain={self.position_gain} velocity_gain={self.velocity_gain} rho_gain=0.25 rho_alignment=0.8 run_nonce={self.nonce}\n')
                f.write(f'# final_command_publish_count={self.mission_commands} final_measurement_refresh_count={self.total_refreshes} final_offboard_heartbeat_count={self.mission_heartbeats} counter_scope=mission_epoch_through_completion_callback command_time=clock_gz_s-common_epoch_s command_hold=zero_order\n')
                f.write(f'# command_stop_gz_s={self.gate.epoch+self.duration if self.gate.epoch is not None else math.nan} stop_observed_gz_s={self.stop_observed_gz if self.stop_observed_gz is not None else math.nan} drain_complete={str(self.drain_complete).lower()} raw_state_receipts={self.observation_gate.receipts} duplicate_state_samples={self.observation_gate.duplicates} out_of_order_state_samples={self.observation_gate.out_of_order} state_receipt_scope=valid_framed_DDS_samples_with_source_in_0_T\n')
                if self.initial_snapshot:f.write(f'# initial_state_sample_s={self.initial_snapshot["state_sample_s"]} initial_epoch_age_s={self.initial_snapshot["state_age_s"]} initial_speed_m_s={self.initial_snapshot["speed_m_s"]} initial_xy_error_m={self.initial_snapshot["xy_slot_error"]} start_protocol=native_pause_snapshot_commit_resume\n')
                writer=csv.writer(f);writer.writerow(LOG_COLUMNS+EXTRA_COLUMNS);writer.writerows(self.rows)

        def write_sidecars(self):
            for suffix,columns,rows in [('.states.csv',STATE_COLUMNS,self.state_rows),('.events.csv',EVENT_COLUMNS,self.event_rows)]:
                with self.output.with_suffix(suffix).open('w',newline='',encoding='utf8') as f:
                    f.write(f'# schema_version={SCHEMA_VERSION} run_nonce={self.nonce} agent_index={self.index}\n')
                    writer=csv.writer(f);writer.writerow(columns);writer.writerows(rows)

        def stop_mission(self):
            self.stop_observed_gz=self.gate.last_clock;self.stop_wall=time.monotonic();self.phase='drain'
            self.log_event('mission_stop',1)
            self.send_command(VehicleCommand.VEHICLE_CMD_NAV_LAND)

        def finish(self):
            if len(self.rows)<2 or len(self.state_rows)<2:raise InterfaceViolation('no_mission_command_or_state_samples')
            self.drain_complete=True
            start,end=self.state_rows[0][0],self.state_rows[-1][0]
            if start>.05+1e-8 or end<self.duration-.05-1e-8 or end-start<MIN_COVERAGE_S-1e-8:
                raise InterfaceViolation(f'insufficient_physical_time_coverage:{start:.6f},{end:.6f}')
            temp=self.output.with_suffix('.writing.csv');self.write_csv(temp);temp.replace(self.output)
            self.write_sidecars()
            atomic_json(self.output.with_suffix('.complete.json'),{'schema_version':SCHEMA_VERSION,'nonce':self.nonce,'agent_index':self.index,'verdict':'completed','common_epoch_s':self.gate.epoch,'first_t':start,'last_t':end,'coverage_s':end-start,'rows':len(self.rows),'state_rows':len(self.state_rows),'event_rows':len(self.event_rows),'command_stop_gz_s':self.gate.epoch+self.duration,'stop_observed_gz_s':self.stop_observed_gz,'drain_complete':self.drain_complete,'raw_state_receipts':self.observation_gate.receipts,'duplicate_state_samples':self.observation_gate.duplicates,'out_of_order_state_samples':self.observation_gate.out_of_order,'last_gz_s':self.gate.last_clock,'wall_elapsed_s':self.stop_wall-self.mission_wall_start,'drain_wall_elapsed_s':time.monotonic()-self.stop_wall,'command_publish_count':self.mission_commands,'measurement_refresh_count':self.total_refreshes,'offboard_heartbeat_count':self.mission_heartbeats,'all_phase_command_count':self.total_commands,'all_phase_heartbeat_count':self.total_heartbeats})
            self.phase='land';self.land_t0=self.gate.last_clock

        def watchdog(self):
            if self.phase=='drain' and time.monotonic()-self.stop_wall>=self.drain_limit_wall:
                try:self.finish()
                except Exception as exc:self.fail(exc)
            elif time.monotonic()-self.clock_wall>20:self.fail('gazebo_clock_stalled_wall_timeout')
            elif self.phase in ('wait_frame','ascend','ready','committed','mission_pending') and time.monotonic()-self.start_wall>240:self.fail('preparation_wall_timeout')
            elif self.phase=='mission' and self.gate.last_sample is not None and self.gate.last_clock-self.gate.last_sample>.1:self.fail('mission_state_stream_stalled')

    rclpy.init();node=None
    try:
        node=Agent()
        while rclpy.ok() and node.phase not in ('done','failed'):
            rclpy.spin_once(node,timeout_sec=.1)
        return 3 if node.failed else 0
    except KeyboardInterrupt:return 130
    except Exception as exc:
        if node:node.fail(exc)
        else:print(f'PX4 v2 initialization failed: {exc}',file=sys.stderr)
        return 3
    finally:
        if node:node.destroy_node()
        if rclpy.ok():rclpy.shutdown()

if __name__=='__main__':raise SystemExit(main_v2())
