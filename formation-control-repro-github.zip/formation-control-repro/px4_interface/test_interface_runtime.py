"""Behavioral tests for time-domain rejection, sample use, barrier and frames."""
import unittest
import numpy as np
from interface_runtime import ClockGate,GeoOrigin,SharedFrame,InterfaceViolation,release_barrier

class ClockTests(unittest.TestCase):
    def gate(self):
        g=ClockGate();g.observe_clock(10.);g.release(12.);return g

    def test_bridge_epoch_timestamp_is_rejected(self):
        g=self.gate();g.observe_clock(12.02)
        with self.assertRaisesRegex(InterfaceViolation,'clock_domain'):g.step(1_788_000_000.,1_788_000_000.,16.)

    def test_actual_dt_and_no_catch_up(self):
        g=self.gate();g.observe_clock(12.02);a=g.step(12.019,12.015,16.)
        self.assertAlmostEqual(a.t,.015);self.assertEqual(a.dt,0.)
        g.observe_clock(12.08);b=g.step(12.077,12.075,16.)
        self.assertAlmostEqual(b.dt,.06);self.assertEqual(b.skipped_periods,2)
        self.assertIsNone(g.step(12.077,12.075,16.))
        g.observe_clock(12.081)
        self.assertIsNone(g.step(12.077,12.075,16.))

    def test_stale_state_does_not_become_new_control(self):
        g=self.gate();g.observe_clock(12.20)
        self.assertIsNone(g.step(12.01,12.,16.))

    def test_clock_reversal_and_gap_fail(self):
        g=self.gate();g.observe_clock(12.01);g.step(12.009,12.005,16.)
        g.observe_clock(12.20)
        with self.assertRaisesRegex(InterfaceViolation,'gap'):g.step(12.19,12.19,16.)
        with self.assertRaisesRegex(InterfaceViolation,'backwards'):g.observe_clock(11.9)

    def test_repeated_clock_and_post_endpoint_never_manufacture_ticks(self):
        g=self.gate();g.observe_clock(28.04)
        self.assertIsNone(g.step(28.03,28.02,16.))

    def test_two_arrival_speeds_give_same_physical_ticks(self):
        # Wall-arrival rate does not enter the core. Repeated clock delivery
        # changes callback count but cannot create repeated controller updates.
        outputs=[]
        for repeats in (1,4):
            g=self.gate();ticks=[]
            for sample in (12.,12.02,12.04,12.065):
                for _ in range(repeats):
                    g.observe_clock(sample+.002)
                    tick=g.step(sample+.001,sample,16.)
                    if tick:ticks.append((tick.t,tick.dt))
            outputs.append(ticks)
        self.assertEqual(outputs[0],outputs[1])

class BarrierTests(unittest.TestCase):
    def ready(self):return [{'agent_index':i,'nonce':'n','ready':True,'gz_s':10+i*.01} for i in range(3)]
    def test_single_common_future_epoch(self):
        result=release_barrier(self.ready(),3,'n')
        self.assertAlmostEqual(result['epoch_s'],10.52)

    def test_missing_unready_stale_or_duplicate_agent_rejected(self):
        cases=[self.ready()[:2],self.ready(),self.ready(),self.ready()]
        cases[1][1]['ready']=False;cases[2][2]['nonce']='previous';cases[3][2]['agent_index']=1
        for records in cases:
            with self.subTest(records=records),self.assertRaises(InterfaceViolation):release_barrier(records,3,'n')

    def test_asynchronous_readiness_cannot_release(self):
        records=self.ready();records[1]['gz_s']=14.
        with self.assertRaisesRegex(InterfaceViolation,'not_current'):release_barrier(records,3,'n')

class FrameTests(unittest.TestCase):
    def test_same_physical_point_from_different_origins_and_round_trip(self):
        anchor=GeoOrigin(47.397742,8.545594,488.,1)
        local=GeoOrigin(47.397769,8.545634,488.3,2)
        f=SharedFrame(anchor,local)
        target=np.array([7.,-4.,-5.])
        np.testing.assert_allclose(f.position_to_shared(f.position_to_local(target)),target,atol=1e-8)
        shared_ecef=anchor.ecef()+anchor.ned_rotation().T@target
        local_ecef=local.ecef()+local.ned_rotation().T@f.position_to_local(target)
        np.testing.assert_allclose(shared_ecef,local_ecef,atol=1e-8)
        v=np.array([1.,2.,3.])
        np.testing.assert_allclose(f.vector_to_shared(f.vector_to_local(v)),v,atol=1e-12)

    def test_distant_origin_and_invalid_reference_are_rejected(self):
        a=GeoOrigin(47.,8.,500.,1)
        with self.assertRaises(InterfaceViolation):SharedFrame(a,GeoOrigin(48.,8.,500.,2))
        with self.assertRaises(InterfaceViolation):GeoOrigin(float('nan'),8.,500.,1)

if __name__=='__main__':unittest.main(verbosity=2)
