import pytest
from interface_runtime import ClockGate,InterfaceViolation

def test_paused_commit_consumes_only_real_post_epoch_samples():
    gate=ClockGate();gate.observe_clock(12.);gate.commit_paused(12.)
    assert gate.step(11.996,11.996,16.) is None
    gate.observe_clock(12.012)
    tick=gate.step(12.008,12.008,16.)
    assert tick.t==pytest.approx(.008)
    assert tick.dt==0.
    assert gate.step(12.008,12.008,16.) is None

def test_paused_epoch_cannot_invent_future_clock_or_recommit():
    gate=ClockGate();gate.observe_clock(12.)
    with pytest.raises(InterfaceViolation):gate.commit_paused(12.5)
    gate.commit_paused(12.)
    with pytest.raises(InterfaceViolation):gate.commit_paused(12.)
