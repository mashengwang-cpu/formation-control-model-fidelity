"""Node-side attack/fault injection for the PX4 confirmatory phase.

Faithful port of ``Reproduction/simulation/src/finite_control_sim/scenarios.py``
to a per-agent, continuous-time interface. The profiles are evaluated at
mission time t in [0, duration_s] and reproduce the frozen protocol
(Reproduction/PROTOCOL.md, "Design invariants"):

- actuator loss of effectiveness (LOE): rho(t) = 0.55 + 0.08 sin(1.7 t) on
  agents with index i % 3 == 0, active from 0.42 * T;
- sensor FDI: additive position bias on odd agents (i % 2 == 1) from 0.35 * T,
  bias = [0.16 sin(0.9 t + phi_i), 0.13 cos(0.7 t + phi_i)];
- windowed DoS: communication blocked on even agents (i % 2 == 0) inside the
  three fractional windows (0.28, 0.35), (0.52, 0.59), (0.73, 0.80) of T
  (~21% duty). While DoS is active the event trigger cannot fire, so the
  controller keeps actuating from the last held (ZOH) sample -- setpoint
  updates are blocked, actuation is not.

Random-phase reproduction: in ``v1000_loop.simulate_v1000_canonical`` the FDI
phases are the FIRST draw from ``np.random.default_rng(seed)`` (topology and
dynamics construction do not consume the generator for the frozen
leader_ring / zero-uncertainty configuration). ``AttackInjector`` replicates
that draw order so seed s produces identical phases in numpy and on PX4.

This module has no ROS2 dependency and is importable on any host.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

SCENARIOS = (
    "nominal",
    "actuator_fault",
    "fdi_attack",
    "dos_attack",
    "combined_attack_fault",
)

# Fractional DoS windows of the mission span (scenarios.py::_apply_dos_attack).
DOS_WINDOWS = ((0.28, 0.35), (0.52, 0.59), (0.73, 0.80))


def loe_affected(agent_index: int) -> bool:
    return agent_index % 3 == 0


def fdi_affected(agent_index: int) -> bool:
    return agent_index % 2 == 1


def dos_affected(agent_index: int) -> bool:
    return agent_index % 2 == 0


@dataclass
class AttackInjector:
    """Continuous-time attack profile for one follower agent.

    Parameters mirror the numpy scenario builder: ``seed`` fixes the FDI
    phases (drawn once for all ``num_agents`` so multi-agent phase assignment
    matches the vectorized campaign), scale factors default to the frozen
    protocol levels (1.0).
    """

    scenario: str
    agent_index: int
    num_agents: int
    seed: int
    duration_s: float
    actuator_loss_scale: float = 1.0
    fdi_scale: float = 1.0
    dos_duty_scale: float = 1.0
    _phase: float = field(init=False, default=0.0)

    def __post_init__(self) -> None:
        if self.scenario not in SCENARIOS:
            raise ValueError(f"Unknown scenario {self.scenario!r}. Known: {SCENARIOS}")
        if not 0 <= self.agent_index < self.num_agents:
            raise ValueError("agent_index must lie in [0, num_agents).")
        # First draw from default_rng(seed), matching v1000_loop draw order.
        phases = np.random.default_rng(int(self.seed)).uniform(0.0, 2.0 * np.pi, size=self.num_agents)
        self._phase = float(phases[self.agent_index])

    # ------------------------------------------------------------------ LOE
    def actuator_efficiency(self, t: float) -> float:
        """Multiplicative thrust-command effectiveness rho(t) in (0, 1]."""
        if self.scenario not in {"actuator_fault", "combined_attack_fault"}:
            return 1.0
        if not loe_affected(self.agent_index):
            return 1.0
        start = 0.42 * self.duration_s
        if t < start:
            return 1.0
        nominal_curve = 0.55 + 0.08 * np.sin(1.7 * t)
        curve = 1.0 - float(self.actuator_loss_scale) * (1.0 - nominal_curve)
        return float(np.clip(curve, 0.2, 1.0))

    # ------------------------------------------------------------------ FDI
    def sensor_bias(self, t: float) -> np.ndarray:
        """Additive position-measurement bias (2,) in the formation plane."""
        if self.scenario not in {"fdi_attack", "combined_attack_fault"}:
            return np.zeros(2, dtype=float)
        if not fdi_affected(self.agent_index):
            return np.zeros(2, dtype=float)
        start = 0.35 * self.duration_s
        if t < start:
            return np.zeros(2, dtype=float)
        return np.array(
            [
                0.16 * float(self.fdi_scale) * np.sin(0.9 * t + self._phase),
                0.13 * float(self.fdi_scale) * np.cos(0.7 * t + self._phase),
            ],
            dtype=float,
        )

    # ------------------------------------------------------------------ DoS
    def communication_available(self, t: float) -> bool:
        """False while a DoS window blocks this agent's measurement channel."""
        if self.scenario not in {"dos_attack", "combined_attack_fault"}:
            return True
        if not dos_affected(self.agent_index):
            return True
        fraction = t / max(self.duration_s, 1e-9)
        for left, right in DOS_WINDOWS:
            center = 0.5 * (left + right)
            half_width = 0.5 * (right - left) * float(self.dos_duty_scale)
            if max(0.0, center - half_width) <= fraction <= min(1.0, center + half_width):
                return False
        return True

    # ---------------------------------------------------------------- audit
    def profile_summary(self) -> dict[str, object]:
        return {
            "scenario": self.scenario,
            "agent_index": self.agent_index,
            "seed": self.seed,
            "duration_s": self.duration_s,
            "loe_role": loe_affected(self.agent_index),
            "fdi_role": fdi_affected(self.agent_index),
            "dos_role": dos_affected(self.agent_index),
            "fdi_phase_rad": self._phase,
        }


def _self_test() -> None:
    """Cross-check the port against the vectorized numpy scenario builder."""
    try:
        import sys
        from pathlib import Path

        sim_src = Path(__file__).resolve().parents[1] / "simulation" / "src"
        sys.path.insert(0, str(sim_src))
        from finite_control_sim.scenarios import build_scenario_profile  # type: ignore
    except Exception as exc:  # pragma: no cover - reference impl not on path
        print(f"[self-test] reference scenarios.py unavailable ({exc}); skipped.")
        return

    duration, dt, agents, seed = 16.0, 0.02, 3, 7
    times = np.arange(0.0, duration + 0.5 * dt, dt)
    for scenario in SCENARIOS:
        if scenario == "nominal":
            continue
        reference = build_scenario_profile(scenario, times, agents, np.random.default_rng(seed))
        for idx in range(agents):
            injector = AttackInjector(scenario, idx, agents, seed, duration)
            rho = np.array([injector.actuator_efficiency(t) for t in times])
            bias = np.array([injector.sensor_bias(t) for t in times])
            comm = np.array([injector.communication_available(t) for t in times])
            assert np.allclose(rho, reference.actuator_efficiency[:, idx], atol=1e-12), (scenario, idx, "rho")
            assert np.allclose(bias, reference.sensor_bias[:, idx, :], atol=1e-12), (scenario, idx, "bias")
            assert np.array_equal(comm, reference.communication_available[:, idx]), (scenario, idx, "comm")
    print("[self-test] attack profiles match finite_control_sim.scenarios exactly.")


if __name__ == "__main__":
    _self_test()
