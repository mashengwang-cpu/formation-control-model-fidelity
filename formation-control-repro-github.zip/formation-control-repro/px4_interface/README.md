# PX4 acceleration interface v2.1

This directory contains the frozen three-UAV acceleration-setpoint implementation and its tests. PX4 downstream attitude and actuator control is distinct from the heterogeneous force-command native model. The scientific manifest contains seeds 5000–5019 and 900 fixed designs.

Use the main reproduction entry point for the archived results:

```bash
python reproduce.py px4-statistics
```

Run that command from the parent Reproduction directory. All three hypotheses remain blocked by failed required designs. Archive validation, raw reconstruction and ROS bag decoding are described in ../px4/README.md.

PROTOCOL_V21.md records the exact interface and timing contract. Runtime and installation shell scripts preserve the original environment and machine assumptions; they are not a portable default installer. Obtain the recorded PX4/ROS/Gazebo versions from their upstream distributions before any new interface experiment. The original cohort can be independently checked without rerunning it.
