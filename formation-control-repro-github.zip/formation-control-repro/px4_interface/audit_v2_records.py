"""Independent timestamp/frame/transport audit of recorded real v2 attempts."""
import argparse,json,re
from pathlib import Path
import numpy as np
import pandas as pd
def audit_attempt(d):
    result=json.loads((d/'attempt_result.json').read_text());out={'attempt':str(d),'verdict':result['verdict'],'reason':result.get('reason'),'agents':[]}
    if result['verdict']!='ok':
        out['node_failures']=[json.loads(p.read_text()) for p in d.glob('*.failed.json')]
        return out
    paths=sorted(d.glob('*__agent*.csv'));paths=[p for p in paths if '.partial.' not in p.name]
    if not paths:return out
    frames=[pd.read_csv(p,comment='#') for p in paths];epoch=float(frames[0].common_epoch_s.iloc[0])
    out.update(common_epoch_s=epoch,epochs_equal=all(np.allclose(f.common_epoch_s,epoch) for f in frames),first_sample_skew_s=max(f.t.iloc[0] for f in frames)-min(f.t.iloc[0] for f in frames),common_start_s=max(float(f.t.iloc[0]) for f in frames),common_end_s=min(float(f.t.iloc[-1]) for f in frames))
    for i,(p,f) in enumerate(zip(paths,frames)):
        log=(d/f'controller_agent_{i}.log').read_text(errors='replace');px=(d/f'px4_instance_{i}.log').read_text(errors='replace')
        out['agents'].append({'agent':i,'rows':len(f),'first_t':float(f.t.iloc[0]),'last_t':float(f.t.iloc[-1]),'state_age_max_s':float(f.state_age_s.max()),'dt_min_s':float(np.diff(f.t).min()),'dt_max_s':float(np.diff(f.t).max()),'dt_median_s':float(np.median(np.diff(f.t))),'zero_or_negative_dt':int((np.diff(f.t)<=0).sum()),'timestamp_domain_max_abs_s':float(abs(f.state_timestamp_s-f.clock_gz_s).max()),'SYNCT_zero_marker':'PX4_INTERFACE_V2_SYNCT_ZERO' in px,'time_jump_messages':px.count('time jump'),'traceback':('Traceback' in log),'completion':json.loads(p.with_suffix('.complete.json').read_text())})
    c=pd.read_csv(d/'gazebo_native_clock.csv');c=c[(c.gz_sim_s>=epoch)&(c.gz_sim_s<=epoch+16)]
    out['native_clock']={'rows_during_mission':len(c),'sim_elapsed_s':float(c.gz_sim_s.iloc[-1]-c.gz_sim_s.iloc[0]),'wall_elapsed_s':float(c.wall_monotonic_s.iloc[-1]-c.wall_monotonic_s.iloc[0]),'gazebo_real_elapsed_s':float(c.gz_real_s.iloc[-1]-c.gz_real_s.iloc[0]),'observed_RTF_sim_over_wall':float((c.gz_sim_s.iloc[-1]-c.gz_sim_s.iloc[0])/(c.wall_monotonic_s.iloc[-1]-c.wall_monotonic_s.iloc[0])),'max_clock_callback_wall_gap_s':float(np.diff(c.wall_monotonic_s).max()),'negative_sim_steps':int((np.diff(c.gz_sim_s)<0).sum())}
    # Independent native Gazebo world positions. Relative positions remove the
    # fixed map-anchor translation; ENU->NED is [y,x,-z]. No outcome fitting.
    insts=[]
    for i in range(len(frames)):
        text=(d/f'px4_instance_{i}.log').read_text(errors='replace');match=re.search(r'x500_(\d+)',text);insts.append(int(match[1]) if match else None)
    poses={i:[] for i in range(len(frames))}
    for line in (d/'gazebo_world_poses.jsonl').open():
        rec=json.loads(line);t=rec['gz_stamp_s']-epoch
        if -.1<=t<=16.1:
            for p in rec['poses']:
                for i,inst in enumerate(insts):
                    if p['name']==f'x500_{inst}':poses[i].append([t,*p['position']])
    truth={};out['gazebo_pose_models']={str(i):{'model':f'x500_{insts[i]}','samples':len(v)} for i,v in poses.items()}
    for i,vals in poses.items():
        if vals:
            arr=np.asarray(vals);_,idx=np.unique(arr[:,0],return_index=True);truth[i]=arr[np.sort(idx)]
    if len(truth)==len(frames) and len(frames)>1:
        lo=max(out['common_start_s'],*(v[0,0] for v in truth.values()));hi=min(out['common_end_s'],*(v[-1,0] for v in truth.values()));grid=np.arange(lo,hi,.05)
        estimates=[np.column_stack([np.interp(grid,f.t,f[k]) for k in ('x_shared','y_shared','z_shared')]) for f in frames]
        gt=[np.column_stack([np.interp(grid,truth[i][:,0],truth[i][:,k]) for k in (2,1,3)])*np.array([1,1,-1]) for i in range(len(frames))]
        residual=np.concatenate([(estimates[i]-estimates[0])-(gt[i]-gt[0]) for i in range(1,len(frames))])
        out['shared_frame_truth_check']={'quantity':'pairwise estimated relative NED minus independent Gazebo relative NED','samples':len(residual),'rms_3d_m':float(np.sqrt(np.mean(np.sum(residual**2,axis=1)))),'max_3d_m':float(np.linalg.norm(residual,axis=1).max()),'rms_planar_m':float(np.sqrt(np.mean(np.sum(residual[:,:2]**2,axis=1))))}
    out['ulog_files']=[p.name for p in (d/'ulog').glob('*.ulg*')]
    return out
def main():
    p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('--output',required=True);a=p.parse_args()
    records=[audit_attempt(v.parent) for v in sorted(Path(a.root).rglob('attempt_result.json'))]
    Path(a.output).write_text(json.dumps(records,indent=2),encoding='utf8');print(json.dumps(records,indent=2))
if __name__=='__main__':main()
