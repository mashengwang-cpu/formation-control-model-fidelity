"""Finite tests for stream semantics; fixtures are explicitly synthetic."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location("new_v21_analysis", ROOT / "analysis.py")
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)
from v21_metrics import metrics_from_agent_logs, load_run_log


def synthetic_agent(times=(.01, 3., 9., 15.98), multiplier=1., agent_index=0, num_agents=1):
    epoch = 100.
    t = np.asarray(times)
    command_t = np.array([.02, 1.02, 8.])
    commands = pd.DataFrame(dict(clock_gz_s=epoch+command_t, common_epoch_s=epoch,
                                 ux_cmd=[1., 2., 0.], uy_cmd=0., ux_applied=[.5, 1., 0.], uy_applied=0.,
                                 event=[1, 0, 1], command_publish_count=[1, 2, 3], measurement_refresh_count=[1, 1, 2],
                                 err_norm=[999., 999., 999.]))
    states = pd.DataFrame(dict(t=t, state_sample_s=epoch+t, state_timestamp_s=epoch+t+.005, common_epoch_s=epoch,
                               clock_receipt_gz_s=epoch+t+.03, err_x=multiplier*(1+t), err_y=0., err_norm=multiplier*(1+t)))
    records = []
    for kind, event_t in {"command":command_t, "refresh":command_t[[0, 2]],
                           "heartbeat":[.005, .5, 15.9], "mission_stop":[16.005]}.items():
        for count, instant in enumerate(event_t, 1):
            records.append(dict(event_type=kind, clock_gz_s=epoch+instant, common_epoch_s=epoch, cumulative_count=count))
    events = pd.DataFrame(records).sort_values("clock_gz_s", kind="stable").reset_index(drop=True)
    for stream in [states, events]:
        stream.attrs.update(schema_version="px4-interface-v2.1", run_nonce="synthetic_fixture", agent_index=agent_index)
    commands.attrs.update(schema_version="px4-interface-v2.1", state_stream=states, event_stream=events,
                          run_nonce="synthetic_fixture", agent_index=agent_index, num_agents=num_agents,
                          command_stop_gz_s=116., stop_observed_gz_s=116.005, drain_complete="true",
                          final_command_publish_count=3, final_measurement_refresh_count=2, final_offboard_heartbeat_count=3,
                          raw_state_receipts=len(states), duplicate_state_samples=0, out_of_order_state_samples=0,
                          state_receipt_scope="valid_framed_DDS_samples_with_source_in_0_T")
    return commands


def test_all_states_not_controller_decimated_rows_define_j():
    first = synthetic_agent(num_agents=2)
    second = synthetic_agent((.005, 4., 11., 15.99), 2., agent_index=1, num_agents=2)
    metrics = metrics_from_agent_logs([first, second])
    assert metrics["J"] == pytest.approx(13.5)
    assert metrics["state_samples_total"] == 8
    assert metrics["common_window_start_s"] == pytest.approx(.02)
    assert metrics["common_window_end_s"] == pytest.approx(15.98)
    assert metrics["protocol_window_complete"]


def test_commands_hold_from_real_publication_through_observed_window():
    metrics = metrics_from_agent_logs([synthetic_agent()])
    # Last publication is at t=8, yet the command remains defined until T=16.
    assert metrics["control_energy"] == pytest.approx(1.+4.*6.98)
    assert metrics["actual_control_energy"] == pytest.approx((1.+4.*6.98)/4.)
    assert metrics["event_trigger_count"] == 2
    assert metrics["command_publish_count"] == 3
    assert metrics["offboard_heartbeat_count"] == 3
    assert metrics["offboard_heartbeat_count_in_common_window"] == 2


def test_late_received_real_endpoint_allowed_without_virtual_state():
    frame = synthetic_agent()
    frame.attrs["state_stream"].loc[3,"clock_receipt_gz_s"] = 116.15
    result = metrics_from_agent_logs([frame])
    assert result["common_window_end_s"] == pytest.approx(15.98)
    assert result["state_samples_total"] == 4


def test_missing_real_endpoint_is_incomplete_even_with_complete_commands():
    frame = synthetic_agent((.01, 3., 9., 15.94))
    result = metrics_from_agent_logs([frame])
    assert not result["protocol_window_complete"]
    assert result["common_window_end_s"] == pytest.approx(15.94)


def set_state_column(frame, column, values):
    states = frame.attrs["state_stream"]
    states[column] = values


@pytest.mark.parametrize("mutate", [
    lambda f: f.attrs.update(drain_complete="false"),
    lambda f: f.attrs.update(final_measurement_refresh_count=3),
    lambda f: f.attrs.update(command_stop_gz_s=116.02),
    lambda f: f.attrs.update(schema_version="px4-interface-v2"),
    lambda f: set_state_column(f, "t", [.01,3.,3.,15.98]),
    lambda f: set_state_column(f, "err_norm", [1.,2.,3.,4.]),
    lambda f: f.attrs["event_stream"].loc.__setitem__((0,"cumulative_count"), 2),
    lambda f: f.attrs.update(raw_state_receipts=5),
    lambda f: f.attrs.update(out_of_order_state_samples=1),
    lambda f: f.attrs.update(run_nonce="different_attempt"),
    lambda f: f.attrs.update(num_agents=3),
])
def test_invalid_streams_block_instead_of_being_repaired(mutate):
    frame = synthetic_agent()
    mutate(frame)
    with pytest.raises(ValueError):
        metrics_from_agent_logs([frame])


def test_last_received_clock_may_lag_state_due_to_cross_topic_arrival_order():
    frame = synthetic_agent()
    states = frame.attrs["state_stream"]
    states["clock_receipt_gz_s"] = states.state_sample_s - .005
    assert metrics_from_agent_logs([frame])["protocol_window_complete"]
    states["clock_receipt_gz_s"] = states.state_sample_s - .2
    with pytest.raises(ValueError):
        metrics_from_agent_logs([frame])


def test_scientific_protocol_rejects_old_cohort_missing_seed_and_failed_mission():
    arms = [(analysis.H1_REFERENCE,"causal"),(analysis.H1_COMPARATOR,"causal")]
    frame = pd.DataFrame([dict(method=method, contract=contract, seed=seed, scenario=scenario,
                               metrics_schema_version="px4-interface-v2.1", backend="px4", num_agents=3,
                               status="ok", protocol_window_complete=True, event_streams_validated=True)
                          for method,contract in arms for seed in range(5000,5020) for scenario in analysis.SCENARIOS])
    assert len(analysis.require_complete_protocol(frame,arms)) == 200
    for bad in [frame.assign(seed=frame.seed-1000), frame[frame.seed!=5019],
                frame.assign(status="interface_failure"), frame.assign(metrics_schema_version="px4-interface-v2")]:
        with pytest.raises(ValueError):
            analysis.require_complete_protocol(bad,arms)


def test_missing_sidecars_preserve_manifest_row_as_analysis_failure(tmp_path):
    command = tmp_path/"run__agent0.csv"
    command.write_text("clock_gz_s\n100.02\n",encoding="utf-8")
    manifest = tmp_path/"runs_index.csv"
    pd.DataFrame([dict(run_id="pilot",method="m",scenario="nominal",seed=4900,contract="causal",
                       num_agents=1,backend="px4",status="ok",csv_paths=str(command))]).to_csv(manifest,index=False)
    result = analysis.build_metrics_table(manifest)
    assert len(result) == 1
    assert result.status.iloc[0] == "analysis_failure"
    assert "states.csv" in result.metrics_error.iloc[0]
