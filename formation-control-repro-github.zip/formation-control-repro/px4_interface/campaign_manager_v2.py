"""Freeze all 900 jobs, then execute 24 fixed block shards with operational concurrency."""
import argparse,csv,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
from interface_runtime import atomic_json
def main():
    p=argparse.ArgumentParser();p.add_argument('--archive-root',required=True);p.add_argument('--initial-parallel',type=int,choices=[1,2,4,8],default=4);p.add_argument('--simulation-speed',type=float,choices=[1.,2.],default=2.);p.add_argument('--freeze-only',action='store_true');a=p.parse_args()
    root=Path('/home/px4/px4_interface_revision_20260906/scientific_5000_5019_v21');root.mkdir(exist_ok=True)
    archive=Path(a.archive_root);archive.mkdir(parents=True,exist_ok=True)
    frozen=root/'source_frozen';frozen.mkdir(exist_ok=True)
    for source in Path(__file__).resolve().parent.glob('*.py'):
        target=frozen/source.name
        if target.exists() and target.read_bytes()!=source.read_bytes():raise RuntimeError('source freeze already exists with different bytes: '+source.name)
        if not target.exists():shutil.copy2(source,target)
    source_hashes={v.name:hashlib.sha256(v.read_bytes()).hexdigest() for v in sorted(frozen.glob('*.py'))}
    protocol_source=Path(__file__).resolve().parent/'PROTOCOL_V21.md'
    protocol_hash=hashlib.sha256(protocol_source.read_bytes()).hexdigest()
    protocol_target=frozen/protocol_source.name
    if protocol_target.exists() and protocol_target.read_bytes()!=protocol_source.read_bytes():raise RuntimeError('protocol freeze bytes changed')
    if not protocol_target.exists():shutil.copy2(protocol_source,protocol_target)
    if not (archive/'source_frozen').exists():shutil.copytree(frozen,archive/'source_frozen')
    control=root/'dispatch_control.json'
    if not control.exists():atomic_json(control,{'max_parallel':a.initial_parallel,'pause_between_missions':False})
    jobs=[];full=[]
    for campaign in ('h1','h2','h3'):
        for shard in range(8):
            out=root/f'shard_{shard}';dst=archive/f'shard_{shard}'
            cmd=[sys.executable,str(frozen/'mission_runner.py'),'--backend','px4','--campaign',campaign,'--num-agents','3','--seeds','20','--seed-start','5000','--schedule-seed','9062026','--shard',f'{shard}/8','--px4-dir','/home/px4/PX4-Autopilot','--run-timeout-s','300','--instance-offset',str(60+10*shard),'--xrce-port',str(8898+shard),'--ros-domain-id',str(82+shard),'--max-retries','2','--simulation-speed',str(a.simulation_speed),'--output',str(out),'--archive-root',str(dst),'--prune-archived-duplicates','--dispatch-control',str(control)]
            subprocess.run(cmd+['--freeze-only'],check=True,stdout=subprocess.DEVNULL)
            plan=out/f'{campaign}_px4'/f'execution_plan_{shard}_of_8.json';data=json.loads(plan.read_text())
            for index,row in enumerate(data['ordered_runs']):full.append(dict(campaign=campaign,shard=shard,within_shard_order=index,**row))
            jobs.append({'campaign':campaign,'shard':shard,'command':cmd,'plan_sha256':hashlib.sha256(plan.read_bytes()).hexdigest(),'state':'pending'})
            (dst/f'{campaign}_px4').mkdir(parents=True,exist_ok=True);shutil.copy2(plan,dst/f'{campaign}_px4'/plan.name)
    if len(full)!=900 or len({(r['campaign'],r['run_id']) for r in full})!=900:raise RuntimeError('900-job manifest cardinality/uniqueness failure')
    manifest=root/'FROZEN_900_JOBS.csv'
    with manifest.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(full[0]));w.writeheader();w.writerows(full)
    shutil.copy2(manifest,archive/manifest.name)
    freeze={'schema_version':'px4-interface-v2.1','frozen_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'local_plan_not_public_registration':True,'mission_count':900,'uav_flights':2700,'seeds':list(range(5000,5020)),'schedule_seed':9062026,'simulation_speed_requested':a.simulation_speed,'source_sha256':source_hashes,'protocol_sha256':protocol_hash,'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'preparation_retries_max':2,'retry_eligibility':'no common epoch ever committed','released_epoch_replacements':0,'logical_shards':8,'initial_parallel':a.initial_parallel,'operational_concurrency_changes_require_separate_pilot':True,'scientific_settings':{'gamma':0,'position_gain':2.15,'velocity_gain':2.05,'rho_gain':.25,'rho_alignment':.8,'duration_s':16.,'formation_spacing_m':1.2,'state_source':'PX4 state estimate','command_interface':'acceleration-only','H2_background':'full PPT-off','H3_oracle':'joint bias and efficiency','hold':'sample-held accepted error and velocity error'},'initial_state_gate':{'xy_m':.25,'z_m':.25,'speed_m_s':.2,'max_source_age_s':.05,'dwell_sim_s':1.,'pause_probe_max':20},'recording':{'stop_control_at_sim_s':16.,'drain_sim_limit_s':.2,'drain_wall_limit_s':2.,'common_coverage_min_s':15.9,'max_state_age_s':.05,'max_control_state_gap_s':.1}}
    if not (root/'FREEZE.json').exists():atomic_json(root/'FREEZE.json',freeze);atomic_json(archive/'FREEZE.json',freeze)
    if a.freeze_only:print(json.dumps(freeze,indent=2));return 0
    active=[];finished=[]
    while jobs or active:
        ctl=json.loads(control.read_text());limit=int(ctl.get('max_parallel',a.initial_parallel))
        if limit not in (1,2,4,8):raise RuntimeError('invalid operational concurrency')
        busy_shards={j['shard'] for j,p,h in active}
        while len(active)<limit and jobs and not ctl.get('pause_between_missions',False):
            choices=[i for i,j in enumerate(jobs) if j['shard'] not in busy_shards]
            if not choices:break
            job=jobs.pop(choices[0]);log=(root/f"{job['campaign']}_shard_{job['shard']}.log").open('a')
            proc=subprocess.Popen(job['command']+['--continue-frozen'],stdout=log,stderr=subprocess.STDOUT)
            job.update(state='running',pid=proc.pid,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));active.append((job,proc,log));busy_shards.add(job['shard'])
        remaining=[]
        for job,proc,log in active:
            if proc.poll() is None:remaining.append((job,proc,log))
            else:log.close();job.update(state='finished',returncode=proc.returncode,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));finished.append(job)
        active=remaining
        status={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'active':[j for j,p,h in active],'pending_count':len(jobs),'finished':finished,'control':ctl,'load':os.getloadavg()}
        atomic_json(root/'campaign_status.json',status);atomic_json(archive/'campaign_status.json',status)
        time.sleep(2.)
    return 0 if all(j['returncode']==0 for j in finished) else 3
if __name__=='__main__':raise SystemExit(main())
