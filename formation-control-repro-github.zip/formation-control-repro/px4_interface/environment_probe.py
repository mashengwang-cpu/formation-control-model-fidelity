"""Read-only environment inventory. Does not install or start a simulator."""
import json, os, shutil, subprocess, sys
from pathlib import Path

def decode(data):
    if not data:
        return ''
    if data.startswith((b'\xff\xfe', b'\xfe\xff')):
        return data.decode('utf-16', errors='replace').strip()
    if b'\x00' in data[:200]:
        return data.decode('utf-16-le', errors='replace').strip()
    try:
        return data.decode('utf-8').strip()
    except UnicodeDecodeError:
        return data.decode('gb18030',errors='replace').strip()

def run(args):
    try:
        p=subprocess.run(args,capture_output=True,timeout=25)
        return {'command':args,'returncode':p.returncode,'stdout':decode(p.stdout),'stderr':decode(p.stderr)}
    except Exception as exc:
        return {'command':args,'error':str(exc)}

def probe():
    result={'platform':sys.platform,'python':sys.executable,'checks':[]}
    if os.name=='nt':
        candidates=[shutil.which('wsl.exe'),str(Path(os.environ.get('WINDIR','C:/Windows'))/'System32/wsl.exe'),str(Path(os.environ.get('WINDIR','C:/Windows'))/'Sysnative/wsl.exe')]
        wsl=next((p for p in candidates if p and Path(p).exists()),None)
        result['wsl_path']=wsl
        if wsl:
            listing=run([wsl,'--list','--quiet'])
            result['checks']=[listing,run([wsl,'--status'])]
            distros=[s.strip() for s in listing.get('stdout','').splitlines() if s.strip() and 'Ubuntu' in s]
            for distro in distros:
                result['checks'].append(run([wsl,'-d',distro,'--','sh','-lc',"uname -a; command -v gz; command -v MicroXRCEAgent; test -f /opt/ros/humble/setup.sh && echo ROS_HUMBLE_PRESENT; find /home -maxdepth 5 -path '*/px4_sitl_default/bin/px4' -type f 2>/dev/null | head -10"]))
    else:
        result['checks']=[run(['sh','-lc',"uname -a; command -v ros2; command -v gz; command -v MicroXRCEAgent; test -f /opt/ros/humble/setup.sh && echo ROS_HUMBLE_PRESENT"])]
    return result

if __name__=='__main__':
    payload=json.dumps(probe(),ensure_ascii=False,indent=2)
    print(payload)
    if len(sys.argv)>1:
        Path(sys.argv[1]).write_text(payload,encoding='utf-8')
