"""Read-only, independent ROS-bag corroboration of v2.1 pilot streams.

Run in the ROS2 environment that knows the recorded PX4 message definitions.
Bag receipt ordering is an independent subscriber, not controller callback
ordering. Refresh events are internal controller events, not a DDS topic.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3

import numpy as np
import pandas as pd


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def trapz(times, values, start, end):
    grid = np.r_[start, times[(times > start) & (times < end)], end]
    values = np.interp(grid, times, values)
    return float(np.sum((values[:-1]+values[1:])*.5*np.diff(grid)))


def held(times, values, start, end):
    grid = np.r_[start, times[(times > start) & (times < end)], end]
    indices = np.searchsorted(times, grid[:-1], side="right")-1
    if (indices < 0).any():
        raise ValueError("Bag has no held command at the analysis start")
    return float(np.sum(values[indices]*np.diff(grid)))


def main():
    from rclpy.serialization import deserialize_message
    from rosidl_runtime_py.utilities import get_message
    from v21_metrics import load_run_log, metrics_from_agent_logs
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", type=Path, required=True)
    parser.add_argument("--prefix", action="append", required=True,
                        help="One actual ROS namespace per agent, in ascending agent_index order")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    directory = args.attempt.resolve()
    command_paths = sorted(directory.glob("*__agent[0-9].csv"), key=lambda path:int(path.stem.rsplit("agent",1)[1]))
    if len(command_paths) != len(args.prefix):
        raise ValueError("Actual command logs and explicitly supplied namespace mapping disagree")
    frames = [load_run_log(path) for path in command_paths]
    metrics = metrics_from_agent_logs(frames)
    start, end = metrics["common_window_start_s"], metrics["common_window_end_s"]
    barrier_path=directory/"rendezvous/barrier_complete.json"
    barrier=json.loads(barrier_path.read_text())
    dbs = sorted((directory/"rosbag").glob("*.db3"))
    if not dbs:
        raise ValueError("No ROS bag database")
    topics_wanted = {prefix+suffix for prefix in args.prefix for suffix in
                     ["/fmu/out/vehicle_local_position", "/fmu/in/trajectory_setpoint", "/fmu/in/offboard_control_mode"]}
    recorded = {topic:[] for topic in topics_wanted}
    types = {}
    for db in dbs:
        connection = sqlite3.connect(db.as_uri()+"?mode=ro", uri=True)
        topic_map = {int(key):(name,type_name) for key,name,type_name in
                     connection.execute("SELECT id,name,type FROM topics") if name in topics_wanted}
        for tid, stamp, payload in connection.execute("SELECT topic_id,timestamp,data FROM messages ORDER BY timestamp"):
            if tid not in topic_map:
                continue
            name,type_name = topic_map[tid]
            if type_name not in types:
                types[type_name] = get_message(type_name)
            recorded[name].append((int(stamp), deserialize_message(payload, types[type_name])))
        connection.close()
    issues=[]; agents=[]; total_integral=0.; applied_effort=0.
    for index,(path,commands,prefix) in enumerate(zip(command_paths,frames,args.prefix)):
        states=commands.attrs["state_stream"];events=commands.attrs["event_stream"]
        epoch=float(commands.common_epoch_s.iloc[0]); stop=epoch+16.
        transform=json.loads(path.with_suffix(".frame.json").read_text())
        rotation=np.asarray(transform["rotation"],float);translation=np.asarray(transform["translation_ned"],float)
        by_sample={};all_valid_samples={};bag_state_receipts=0
        for _,message in recorded[prefix+"/fmu/out/vehicle_local_position"]:
            sample=message.timestamp_sample*1e-6
            valid=all(getattr(message,flag) for flag in ["xy_valid","z_valid","v_xy_valid","v_z_valid","xy_global","z_global"])
            if valid:
                all_valid_samples.setdefault(int(message.timestamp_sample),message)
            if valid and epoch-1e-8<=sample<=stop+1e-8:
                bag_state_receipts+=1
                by_sample.setdefault(int(message.timestamp_sample),message)
        initial=next(item for item in barrier["initial_states"] if item["agent_index"]==index)
        initial_key=int(round(initial["state_sample_s"]*1e6))
        initial_check={"source_sample_s":initial["state_sample_s"],"source_is_at_or_before_epoch":initial["state_sample_s"]<=epoch,
                       "source_sample_present_in_bag":initial_key in all_valid_samples}
        if initial_key not in all_valid_samples:
            issues.append(f"agent{index}: paused initial source state absent from independent bag")
        else:
            message=all_valid_samples[initial_key]
            initial_position=rotation@np.array([message.x,message.y,message.z])+translation
            initial_velocity=rotation@np.array([message.vx,message.vy,message.vz])
            initial_target=np.asarray(initial["start_target_shared"],float)
            xy_error=float(np.linalg.norm(initial_position[:2]-initial_target[:2]))
            z_error=float(abs(initial_position[2]-initial_target[2]));speed=float(np.linalg.norm(initial_velocity))
            age=epoch-message.timestamp_sample*1e-6
            difference=max(float(np.max(np.abs(initial_position-np.asarray(initial["position_shared"])))),
                           float(np.max(np.abs(initial_velocity-np.asarray(initial["velocity_shared"])))) )
            ready=(initial["ready"] is True and initial["armed"]==2 and initial["nav"]==14 and
                   0<=age<=.05 and xy_error<.25 and z_error<.25 and speed<.2 and difference<1e-7)
            metadata_equal=np.allclose([xy_error,z_error,speed,age],
                                       [initial["xy_slot_error"],initial["z_slot_error"],initial["speed_m_s"],initial["state_age_s"]],rtol=0,atol=1e-7)
            initial_check.update(xy_error_m=xy_error,z_error_m=z_error,speed_m_s=speed,age_s=age,
                                 shared_state_max_abs_difference=difference,ready_conditions_verified=bool(ready),metadata_equal=bool(metadata_equal))
            if not ready or not metadata_equal:
                issues.append(f"agent{index}: paused initial bag state fails the fixed ready conditions")
        keys=np.rint(states.state_sample_s.to_numpy(float)*1e6).astype(np.int64)
        absent=[int(key) for key in keys if int(key) not in by_sample]
        max_position=max_velocity=max_error=0.;errors=[]
        if absent:
            issues.append(f"agent{index}: {len(absent)} logged source samples absent from independent bag")
        else:
            for (_,row),key in zip(states.iterrows(),keys):
                message=by_sample[int(key)]
                position=rotation@np.array([message.x,message.y,message.z])+translation
                velocity=rotation@np.array([message.vx,message.vy,message.vz])
                t=float(row.t)
                # Independently restated frozen reference, spacing 1.2 m.
                reference=np.array([.55*t,1.4*np.sin(.28*t)])
                offset=np.array([-1.2*(index//2+1),1.2*(-.5 if index%2==0 else .5)])
                error=position[:2]-reference-offset
                max_position=max(max_position,float(np.max(np.abs(position-row[["x_shared","y_shared","z_shared"]].to_numpy(float)))))
                max_velocity=max(max_velocity,float(np.max(np.abs(velocity-row[["vx_shared","vy_shared","vz_shared"]].to_numpy(float)))))
                max_error=max(max_error,float(np.max(np.abs(error-row[["err_x","err_y"]].to_numpy(float)))))
                errors.append(float(np.linalg.norm(error)))
            if max(max_position,max_velocity,max_error)>1e-7:
                issues.append(f"agent{index}: bag state/frame/source-time reference reconstruction differs")
            total_integral+=trapz(states.t.to_numpy(float),np.array(errors),start,end)
        setpoints=[]
        for _,message in recorded[prefix+"/fmu/in/trajectory_setpoint"]:
            stamp=message.timestamp*1e-6
            if epoch<=stamp<stop and np.isfinite(message.acceleration).all():
                setpoints.append((int(message.timestamp),np.asarray(message.acceleration,float)))
        expected=np.rint(commands.clock_gz_s.to_numpy(float)*1e6).astype(np.int64)
        stamps=[stamp for stamp,_ in setpoints]
        commands_match=Counter(stamps)==Counter(map(int,expected))
        acceleration_difference=None
        if not commands_match:
            issues.append(f"agent{index}: command timestamp multiset differs between bag and CSV")
        elif len(set(stamps))!=len(stamps):
            issues.append(f"agent{index}: duplicate publication timestamps require explicit resolution")
        else:
            lookup=dict(setpoints);local=np.vstack([lookup[int(stamp)] for stamp in expected])
            acceleration_difference=float(np.max(np.abs(local-commands[["setpoint_ax_local","setpoint_ay_local","setpoint_az_local"]].to_numpy(float))))
            if acceleration_difference>2e-6:
                issues.append(f"agent{index}: published acceleration payload differs beyond float32 tolerance")
            shared=local@rotation.T
            applied_effort+=held(commands.clock_gz_s.to_numpy(float)-epoch,np.sum(shared[:,:2]**2,axis=1),start,end)
        heartbeats=[]
        for _,message in recorded[prefix+"/fmu/in/offboard_control_mode"]:
            stamp=message.timestamp*1e-6
            if epoch<=stamp<stop and message.acceleration and not message.position:
                heartbeats.append(int(message.timestamp))
        logged_heartbeats=np.rint(events.loc[events.event_type.eq("heartbeat"),"clock_gz_s"].to_numpy(float)*1e6).astype(np.int64)
        heartbeats_match=Counter(heartbeats)==Counter(map(int,logged_heartbeats))
        if not heartbeats_match:
            issues.append(f"agent{index}: heartbeat timestamp multiset differs between bag and event stream")
        agents.append({"agent_index":index,"namespace":prefix,"initial_snapshot_bag_check":initial_check,
                       "state_rows":len(states),"bag_valid_state_receipts":bag_state_receipts,
                       "bag_unique_valid_source_samples":len(by_sample),"logged_source_samples_absent_in_bag":len(absent),
                       "bag_unique_samples_not_received_or_logged_by_controller":len(set(by_sample)-set(map(int,keys))),
                       "max_shared_position_difference":max_position,"max_shared_velocity_difference":max_velocity,
                       "max_source_time_error_difference":max_error,"command_payload_max_abs_difference":acceleration_difference,
                       "command_timestamp_multiset_equal":commands_match,"heartbeat_timestamp_multiset_equal":heartbeats_match})
    reconstructed_j=total_integral/(len(frames)*(end-start))
    if not np.isclose(reconstructed_j,metrics["J"],rtol=1e-8,atol=1e-8):
        issues.append("Bag-authenticated source-state J differs from CSV-based J")
    if not np.isclose(applied_effort,metrics["actual_control_energy"],rtol=1e-6,atol=1e-6):
        issues.append("Published bag acceleration ZOH effort differs from CSV-based applied setpoint effort")
    report={"status":"PASS" if not issues else "NOT_PASSED","issues":issues,"agents":agents,
            "csv_metrics":metrics,"independent_bag_authenticated_J":reconstructed_j,
            "independent_bag_published_acceleration_effort":applied_effort,
            "script_sha256":sha(Path(__file__)),"paused_barrier_sha256":sha(barrier_path),
            "bag_database_sha256":{db.name:sha(db) for db in dbs},
            "qualification":"Bag and controller are independent DDS subscribers. Refreshes are internal events cross-checked against command flags, not a separately observed DDS topic. All exported states must have bag support; extra bag observations are reported explicitly and do not create virtual controller receipts."}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))
    return 0 if not issues else 2


if __name__=="__main__":
    raise SystemExit(main())
