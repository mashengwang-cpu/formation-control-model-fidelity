"""Metrics from separate, authentic state, command, and transport-event streams.

This module has no ROS imports and never creates a boundary observation. The
last published setpoint is held in the interface model up to the protocol stop;
that convention does not assert the PX4 receipt or physical actuation time.
"""
from pathlib import Path
import re

import numpy as np
import pandas as pd

SCHEMA = "px4-interface-v2.1"
EVENT_COUNTERS = {
    "command": "command_publish_count",
    "refresh": "measurement_refresh_count",
    "heartbeat": "offboard_heartbeat_count",
}


def read_csv_with_metadata(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, comment="#")
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if not line.startswith("#"):
                break
            frame.attrs.update(dict(re.findall(r"([A-Za-z0-9_]+)=([^\s]+)", line)))
    return frame


def load_run_log(path: Path) -> pd.DataFrame:
    """Load one command log and both required real-stream sidecars."""
    path = Path(path)
    commands = read_csv_with_metadata(path)
    commands.attrs["state_stream"] = read_csv_with_metadata(path.with_suffix(".states.csv"))
    commands.attrs["event_stream"] = read_csv_with_metadata(path.with_suffix(".events.csv"))
    commands.attrs["source_path"] = str(path)
    return commands


def _finite(frame, columns, label):
    missing = set(columns) - set(frame.columns)
    if missing:
        raise ValueError(f"{label}: missing columns {sorted(missing)}")
    values = frame[columns].to_numpy(float)
    if not np.isfinite(values).all():
        raise ValueError(f"{label}: nonfinite required values")
    return values


def _one_epoch(frame, label):
    epoch = _finite(frame, ["common_epoch_s"], label)[:, 0]
    if not len(epoch) or not np.allclose(epoch, epoch[0], rtol=0, atol=1e-9):
        raise ValueError(f"{label}: missing or inconsistent mission epoch")
    return float(epoch[0])


def _strict_times(values, label):
    if not len(values) or not np.isfinite(values).all() or np.any(np.diff(values) <= 0):
        raise ValueError(f"{label}: timestamps must be finite and strictly increasing")


def _metadata_float(frame, key):
    try:
        value = float(frame.attrs[key])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"Missing/invalid completion metadata: {key}") from exc
    if not np.isfinite(value):
        raise ValueError(f"Nonfinite completion metadata: {key}")
    return value


def _validate_agent(commands, expected_duration):
    if commands.attrs.get("schema_version") != SCHEMA:
        raise ValueError("Only interface-v2.1 streams are admitted; old cohorts remain separate")
    states = commands.attrs.get("state_stream")
    events = commands.attrs.get("event_stream")
    if not isinstance(states, pd.DataFrame) or not isinstance(events, pd.DataFrame):
        raise ValueError("Complete state and event sidecars are required")
    nonce = commands.attrs.get("run_nonce")
    agent_index = commands.attrs.get("agent_index")
    if not nonce or agent_index is None:
        raise ValueError("Command stream lacks its actual attempt nonce or agent identity")
    for stream in [states, events]:
        if (stream.attrs.get("schema_version") != SCHEMA or stream.attrs.get("run_nonce") != nonce or
                str(stream.attrs.get("agent_index")) != str(agent_index)):
            raise ValueError("State/event sidecars do not belong to the same vehicle and attempt")
    epoch = _one_epoch(commands, "commands")
    if not np.allclose([_one_epoch(states, "states"), _one_epoch(events, "events")], epoch, rtol=0, atol=1e-9):
        raise ValueError("State, command and event streams disagree on the common epoch")
    command_t = _finite(commands, ["clock_gz_s"], "commands")[:, 0] - epoch
    _strict_times(command_t, "commands")
    _finite(commands, ["ux_cmd", "uy_cmd", "ux_applied", "uy_applied", "event"], "commands")
    if not commands.event.isin([0, 1]).all():
        raise ValueError("Refresh flag must be binary")
    if np.any(command_t < 0) or np.any(command_t >= expected_duration):
        raise ValueError("Mission commands must be published within [0,T)")
    state_t = _finite(states, ["t"], "states")[:, 0]
    _strict_times(state_t, "states")
    _finite(states, ["state_sample_s", "state_timestamp_s", "clock_receipt_gz_s", "err_x", "err_y", "err_norm"], "states")
    if len(state_t) < 2 or np.any(state_t < -1e-8) or np.any(state_t > expected_duration + 1e-8):
        raise ValueError("Need at least two real state samples with source time in [0,T]")
    if not np.allclose(state_t, states.state_sample_s.to_numpy(float) - epoch, rtol=0, atol=1e-8):
        raise ValueError("State time is not the actual source sample timestamp minus epoch")
    # receipt_gz is the last /clock seen by this subscriber, not an independent
    # simulator timestamp attached to the receipt callback. Cross-topic arrival
    # order can put the state publication slightly ahead of this last clock.
    if (np.any(states.state_sample_s.to_numpy(float) > states.state_timestamp_s.to_numpy(float) + .001) or
            np.any(states.state_timestamp_s.to_numpy(float) > states.clock_receipt_gz_s.to_numpy(float) + .1)):
        raise ValueError("State sample/publication/latest-clock domains exceed the runtime bounds")
    if not np.allclose(states.err_norm, np.hypot(states.err_x, states.err_y), rtol=1e-7, atol=1e-8):
        raise ValueError("State error norm disagrees with its planar error components")
    stop = _metadata_float(commands, "command_stop_gz_s")
    observed_stop = _metadata_float(commands, "stop_observed_gz_s")
    if not np.isclose(stop, epoch + expected_duration, rtol=0, atol=1e-8) or observed_stop + 1e-8 < stop:
        raise ValueError("Protocol stop or actually observed stop metadata is inconsistent")
    if str(commands.attrs.get("drain_complete", "false")).lower() != "true":
        raise ValueError("Real-state endpoint draining did not complete")
    receipts = _metadata_float(commands, "raw_state_receipts")
    duplicates = _metadata_float(commands, "duplicate_state_samples")
    out_of_order = _metadata_float(commands, "out_of_order_state_samples")
    if receipts != len(states) + duplicates or duplicates < 0 or not duplicates.is_integer() or out_of_order != 0:
        raise ValueError("Unique state rows do not reconcile with raw receipts, duplicates and ordering")
    if commands.attrs.get("state_receipt_scope") != "valid_framed_DDS_samples_with_source_in_0_T":
        raise ValueError("The state receipt counter scope is not the mission source-time interval")
    event_clock = _finite(events, ["clock_gz_s", "cumulative_count"], "events")[:, 0]
    if np.any(np.diff(event_clock) < 0):
        raise ValueError("Event receipt/publication clock regresses")
    if not set(events.event_type).issubset(set(EVENT_COUNTERS) | {"mission_stop"}):
        raise ValueError("Unknown event type in the mission event stream")
    stop_events = events.loc[events.event_type.eq("mission_stop")]
    if len(stop_events) != 1 or not np.isclose(stop_events.clock_gz_s.iloc[0], observed_stop, rtol=0, atol=1e-8):
        raise ValueError("Exactly one actual mission-stop event must match completion metadata")
    per_type = {}
    for event_type, counter in EVENT_COUNTERS.items():
        stream = events.loc[events.event_type.eq(event_type)]
        times = stream.clock_gz_s.to_numpy(float) - epoch
        if np.any(times < 0) or np.any(times >= expected_duration):
            raise ValueError(f"{event_type}: transport outside the mission [0,T) interval")
        if not np.array_equal(stream.cumulative_count.to_numpy(float), np.arange(1, len(stream) + 1)):
            raise ValueError(f"{event_type}: independent event counter is incomplete or duplicated")
        if _metadata_float(commands, "final_" + counter) != len(stream):
            raise ValueError(f"{event_type}: final counter does not equal the authentic event stream")
        per_type[event_type] = times
    if len(per_type["command"]) != len(commands) or not np.allclose(per_type["command"], command_t, rtol=0, atol=1e-8):
        raise ValueError("Command publication events do not match the command CSV")
    refresh_t = command_t[commands.event.to_numpy(float) == 1]
    if len(per_type["refresh"]) != len(refresh_t) or not np.allclose(per_type["refresh"], refresh_t, rtol=0, atol=1e-8):
        raise ValueError("Independent refresh events do not match accepted controller refreshes")
    for event_type, counter in EVENT_COUNTERS.items():
        if counter in commands:
            recorded = _finite(commands, [counter], "commands")[:, 0]
            # Heartbeats can occur after a command at the same Gazebo timestamp;
            # a publication clock alone does not establish callback ordering.
            expected = (np.arange(1, len(commands)+1) if event_type == "command" else
                        np.cumsum(commands.event.to_numpy(float)) if event_type == "refresh" else None)
            if expected is not None and not np.array_equal(recorded, expected):
                raise ValueError(f"{counter}: command-row snapshot differs from independent events")
            if event_type == "heartbeat" and (np.any(np.diff(recorded) < 0) or recorded[-1] > len(per_type[event_type])):
                raise ValueError("Heartbeat row snapshots regress or exceed the independent final total")
    return states, command_t, state_t, per_type, epoch


def _trapz_supported(times, values, start, end):
    """Interpolate only within observed support; never invent an endpoint row."""
    if start < times[0] - 1e-10 or end > times[-1] + 1e-10:
        raise ValueError("State integration would extrapolate beyond observed support")
    grid = np.r_[start, times[(times > start) & (times < end)], end]
    sampled = np.interp(grid, times, np.asarray(values, float))
    return float(np.sum(.5 * (sampled[1:] + sampled[:-1]) * np.diff(grid)))


def _held_integral(times, values, start, end):
    if start < times[0] - 1e-10:
        raise ValueError("No authentic command is available at the start of the analysis window")
    grid = np.r_[start, times[(times > start) & (times < end)], end]
    index = np.searchsorted(times, grid[:-1], side="right") - 1
    if np.any(index < 0):
        raise ValueError("Missing initial held command")
    return float(np.sum(np.asarray(values, float)[index] * np.diff(grid)))


def metrics_from_agent_logs(frames, expected_duration=16.0):
    if not frames:
        raise ValueError("No vehicle logs")
    validated = [_validate_agent(frame, expected_duration) for frame in frames]
    if len({frame.attrs["run_nonce"] for frame in frames}) != 1:
        raise ValueError("Vehicle streams come from different physical attempts")
    if (set(int(frame.attrs["agent_index"]) for frame in frames) != set(range(len(frames))) or
            any(int(frame.attrs.get("num_agents", -1)) != len(frames) for frame in frames)):
        raise ValueError("Vehicle logs do not constitute the declared complete team")
    epochs = [item[4] for item in validated]
    if not np.allclose(epochs, epochs[0], rtol=0, atol=1e-9):
        raise ValueError("Vehicles do not share the same mission epoch")
    state_start = max(0., max(item[2][0] for item in validated))
    state_end = min(expected_duration, min(item[2][-1] for item in validated))
    start = max(state_start, max(item[1][0] for item in validated))
    end = state_end
    duration = end - start
    if duration <= 0:
        raise ValueError("No common observed interval with an authentic held command")
    covered = (duration >= expected_duration - .1 - 1e-12 and
               all(state_t[0] <= .05 and state_t[-1] >= expected_duration - .05 and command_t[0] <= .05
                   for _, command_t, state_t, _, _ in validated))
    total_error = command_effort = applied_effort = 0.
    window_counts = {counter: 0 for counter in EVENT_COUNTERS.values()}
    mission_counts = window_counts.copy()
    iet = []; peaks = []; settling = []; state_counts = []; gaps = []; clock_leads = []
    for commands, (states, command_t, state_t, events, _) in zip(frames, validated):
        total_error += _trapz_supported(state_t, states.err_norm, start, end)
        command_norm2 = np.sum(commands[["ux_cmd", "uy_cmd"]].to_numpy(float) ** 2, axis=1)
        applied_norm2 = np.sum(commands[["ux_applied", "uy_applied"]].to_numpy(float) ** 2, axis=1)
        command_effort += _held_integral(command_t, command_norm2, start, end)
        applied_effort += _held_integral(command_t, applied_norm2, start, end)
        for event_type, counter in EVENT_COUNTERS.items():
            times = events[event_type]
            in_window = times[(times >= start) & (times < end)]
            window_counts[counter] += len(in_window)
            mission_counts[counter] += len(times)
            if event_type == "refresh":
                iet.extend(np.diff(in_window).tolist())
        active = np.r_[np.searchsorted(command_t, start, side="right") - 1,
                       np.where((command_t > start) & (command_t < end))[0]]
        peaks.append(float(np.sqrt(command_norm2[active]).max()))
        grid = np.r_[start, state_t[(state_t > start) & (state_t < end)], end]
        errors = np.interp(grid, state_t, states.err_norm)
        bad = np.flatnonzero(errors > .08)
        settling.append(float(grid[bad[-1]+1]) if len(bad) and bad[-1] < len(grid)-1 else (end if len(bad) else start))
        state_counts.append(len(state_t)); gaps.append(float(np.diff(state_t).max()))
        clock_leads.append(float(np.max(states.state_sample_s.to_numpy(float)-states.clock_receipt_gz_s.to_numpy(float))))
    return {
        "J": total_error / (len(frames) * duration),
        "integral_tracking_error": total_error / len(frames),
        "control_energy": command_effort,
        "actual_control_energy": applied_effort,
        "event_trigger_count": window_counts["measurement_refresh_count"],
        "measurement_refreshes_in_common_window": window_counts["measurement_refresh_count"],
        **mission_counts,
        **{key + "_in_common_window": value for key, value in window_counts.items()},
        "common_window_start_s": start, "common_window_end_s": end,
        "common_window_duration_s": duration, "coverage_fraction": duration / expected_duration,
        "state_only_common_window_start_s": state_start, "state_only_common_window_end_s": state_end,
        "protocol_window_complete": bool(covered), "event_streams_validated": True,
        "settling_time": max(settling), "minimum_inter_event_time": min(iet) if iet else duration,
        "peak_control_input": max(peaks), "state_samples_total": sum(state_counts),
        "maximum_state_sample_gap_s": max(gaps),
        "maximum_state_sample_lead_over_latest_received_clock_s": max(clock_leads),
        "metrics_schema_version": SCHEMA, "error_source": "all_unique_px4_state_estimate_samples",
        "energy_definition": "planar_acceleration_setpoint_squared_ZOH_integral_on_actual_publication_clock",
        "applied_energy_definition": "node_scaled_setpoint_effort; not measured physical acceleration or rotor energy",
        "traffic_counter_scope": "independent_actual_events_within_mission_[0,T)",
    }
