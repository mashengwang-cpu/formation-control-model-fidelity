import json,tarfile,tempfile,unittest
from pathlib import Path
from unittest import mock
import transfer_archive as ta
class TransferTests(unittest.TestCase):
    def test_raw_and_independent_backup_restore_exact_bytes(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);src=root/'attempt_test';src.mkdir();(src/'a').write_bytes(bytes(range(256))*30)
            (src/'nested').mkdir();(src/'nested'/'b').write_text('state timestamp, command\n')
            report=ta.transfer_attempt(src,root/'destination'/'attempt_test')
            self.assertTrue(report['copied_and_backup_hashes_verified'])
            with tarfile.open(report['archive'],'r:gz') as f:
                self.assertEqual(f.extractfile('attempt_test/a').read(),(src/'a').read_bytes())
            self.assertEqual(ta.inventory(root/'destination'/'attempt_test'),[v for v in ta.inventory(src) if v['path']!='verified_transfer.json'])
    def test_corruption_stops_before_cleanup(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);src=root/'attempt_test';src.mkdir();(src/'a').write_bytes(b'original')
            copy=ta.shutil.copytree
            def corrupt(s,d,**kwargs):
                out=copy(s,d,**kwargs);(Path(d)/'a').write_bytes(b'corrupted');return out
            with mock.patch.object(ta.shutil,'copytree',side_effect=corrupt):
                with self.assertRaisesRegex(RuntimeError,'hash mismatch'):ta.transfer_attempt(src,root/'dest',True)
            self.assertEqual((src/'a').read_bytes(),b'original')
    def test_cleanup_outside_new_science_root_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);src=root/'attempt_test';src.mkdir();(src/'a').write_bytes(b'original')
            with self.assertRaises(ValueError):ta.transfer_attempt(src,root/'dest',True)
            self.assertTrue((src/'a').exists())
if __name__=='__main__':unittest.main()
