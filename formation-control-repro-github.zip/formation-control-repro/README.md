# Formation control: actuation models and equal-budget tuning

Reproducibility materials for **Controller rankings and module benefits in heterogeneous formation control: Actuation models and equal-budget tuning**.

Authors: Fuliang Ma, Yuzhen Dang, Yuping Ma, Ying Jiang and Hongbin Ma.

## Scope

This compact distribution contains controller and analysis code, frozen designs,
development and execution-level metric records, and plotting inputs for all
8 main-text and 5 supplementary figures. It supports statistical recomputation,
parameter-selection replay and representative simulation runs.

Full original time-series arrays and PX4 raw logs are not included. They remain
in the separate full archive, whose public deposit is pending. This distribution
does not support re-auditing every original trajectory, physical event or raw-log
hash. No published dataset DOI is claimed.

## Quick start

Use Python 3.12 in a dedicated environment and install `requirements.txt`.
Run commands from this repository directory:

```text
python reproduce.py verify
python reproduce.py results
python reproduce.py selection
python reproduce.py figures
```

The first command checks file hashes. Results are recomputed from retained metric
records; figures are regenerated from frozen plotting inputs. Outputs and caches
are written to `outputs/`. Default PNG output is 150 dpi; use
`python reproduce.py figures --dpi 1000` for publication-resolution PNG. PDF and
SVG remain vector outputs.

`python reproduce.py test` runs implementation checks. `python reproduce.py smoke`
runs 32 representative full-duration conditions. Neither command repeats the
entire experimental campaign. Full rerun instructions and evidence coverage are
in `docs/PAPER_SCOPE.md` and `full_rerun.py`; full runs require substantial time
and disk space. Do not start a full run merely to view the figures.

## Interpretation and provenance

RISE delayed/noisy source-condition reconstruction remains unresolved. PX4 failed
designs and unevaluated hypothesis families are retained. Finite simulation output
does not establish physically feasible flight or hardware validation.

`VALIDATION.md` and `provenance/validation/` document prior checks and their limits.
`provenance/INPUT_MEMBERS.csv.gz` maps retained inputs to source archive members
and SHA-256 hashes. These records support reproducibility; they are not claims
that every experiment has been independently repeated on every platform.

## Licenses

Original code: MIT, see `LICENSE_CODE.txt`. Original data and figures: CC BY 4.0.
Third-party notices remain in their original scope; see `LICENSES.md`.
The manuscript and submission correspondence are not included in this release.
The reference table text retains the licensing boundary documented in the package.
