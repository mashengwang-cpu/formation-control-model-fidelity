# Controller rankings and module benefits in heterogeneous formation control: Actuation models and equal-budget tuning

## Paper identity and provenance

Authors, in manuscript order: Fuliang Ma; Yuzhen Dang; Yuping Ma; Ying Jiang; Hongbin Ma.

- Qinghai University, Xining 810016, Qinghai, China: Fuliang Ma, Yuzhen Dang, Ying Jiang.
- China Mobile Group Qinghai Co., Ltd., Xining 810001, Qinghai, China: Yuping Ma, Hongbin Ma.
- Corresponding author: Yuzhen Dang.

The reference version is the local final-check manuscript dated 2026-09-08 at 13:32:48, prepared for Simulation Modelling Practice and Theory. This identifies a manuscript version; it does not establish submission or publication. Original metadata sources, relative to the delivery workspace:

- `2026-09-08_133248_SMPT_终检交付/03_系统填写与作者待办/Title_Abstract_Keywords.txt`: title line 1, English abstract line 3, keywords line 5.
- `2026-09-08_133248_SMPT_终检交付/03_系统填写与作者待办/Authors_and_affiliations.txt`: lines 1–4.
- `2026-09-08_133248_SMPT_终检交付/02_可编辑源与图件/01_Main_LaTeX/Manuscript.tex`: title/authors/affiliations lines 34–43; abstract lines 45–46.

## English abstract — verbatim supplied text

Simulation-based comparisons of formation controllers depend on actuation-model fidelity, parameter selection and numerical accuracy. We cross model fidelity with parameter-selection strategy under a fixed development budget. Three modular controllers (Minimal, Family and Full with the prescribed-performance transformation disabled) and a sampled distributed robust integral of the sign of the error (RISE) controller are compared across point-mass, command-lag and complete vehicle models on an eight-vehicle aerial–surface team and an independent four-vessel Otter model. Each method receives 2,880 development evaluations per platform; point-selected parameters are transferred unchanged or retuned for each model. Fifty new seed blocks per platform yield twelve paired model interactions with nominal 95% simultaneous bootstrap intervals; separate controller, inner-loop and integrator clocks support qualification against an adaptive reference integrator. Fidelity and tuning interact. On the native platform, transfer shifts the Full-minus-Minimal error contrast by 0.3362 m between the point and complete models and reverses the ranking. After retuning, this interaction is 0.00132 m (-0.00026 to 0.00289 m); on Otter, the retuned interaction persists at 0.4009 m (0.3655 to 0.4363 m). The gain schedule and signed powers become harmful on the complete native model but retain smaller benefits on Otter, and retuned RISE has the lowest complete-model error only on Otter. All 12,150 formal executions have finite endpoints, and the selected conditions pass the declared numerical criteria. These comparisons show that transferred rankings depend on model fidelity and tuning; simulation studies should report both choices and numerical qualification. RISE source-condition reconstruction, legacy stress cases and PX4 hypotheses remain unresolved.

## 中文摘要 — 对上述摘要的忠实翻译

基于仿真的编队控制器比较取决于执行机构模型保真度、参数选择和数值精度。本研究在固定开发预算下，将模型保真度与参数选择策略交叉设置为实验因素。在由八个无人航空与水面平台组成的异构编队和独立的四艘 Otter 船舶模型上，对三种模块化控制器（Minimal、Family，以及关闭预设性能变换的 Full）和一种采样实现的分布式误差符号鲁棒积分（RISE）控制器进行比较，模型层次包括质点模型、指令滞后模型和完整车辆模型。每种方法在每个平台上均获得 2,880 次开发评估；在质点模型上选择的参数直接迁移使用，或针对各模型重新调参。每个平台使用 50 个新种子块，得到 12 个配对模型交互效应及其名义 95% 同时自助法置信区间；控制器、内环和积分器采用独立时钟，以支持相对于自适应参考积分器的数值合格性检验。保真度与调参策略存在交互。在本研究原生平台上，参数直接迁移使 Full 相对 Minimal 的误差差值在质点模型与完整模型之间变化 0.3362 m，并使排序反转。重新调参后，该交互为 0.00132 m（−0.00026 至 0.00289 m）；在 Otter 上，重新调参后的交互仍为 0.4009 m（0.3655 至 0.4363 m）。时变增益调度和带符号幂项在完整原生模型上变得有害，但在 Otter 上仍有较小收益；重新调参后的 RISE 仅在 Otter 完整模型上具有最低误差。全部 12,150 次正式执行均具有有限的终点指标，所选条件也通过了预先声明的数值标准。这些比较表明，迁移得到的排序依赖于模型保真度和调参策略；仿真研究应同时报告这两项选择及数值合格性检验。RISE 源文献条件重构、旧版应力条件和 PX4 假设检验仍有未解决的问题。

## Reproduction scope / 复现范围

The controlled comparison has 23,040 development executions and 12,150 unique formal-test executions serving 16,800 design references. Each method has 2,880 development evaluations per platform. Inference uses 50 independent held-out seed blocks per platform, not 16,800 independent samples. The twelve primary interactions use one nominal simultaneous bootstrap interval family. Secondary intervals are pointwise.

The lightweight package must distinguish: (1) re-rendering figures from frozen plotting inputs; (2) recomputing statistics from frozen execution-level endpoints and design mappings; (3) executing simulations with the supplied models and parameters. Re-rendering is not a statistical refit, and a representative simulation is not a rerun of the full campaign. Full trajectory and original PX4 evidence audits require the separate raw archives. The accompanying table-reference file contains the existing manuscript's tables; its extraction is not a new computation.

精简包应明确区分：冻结输入重绘图件、从逐执行终点指标和设计映射重算统计、使用所附模型与参数重新运行仿真。三者的验证边界不同。代表性仿真通过不等于全部实验已重跑；逐执行指标分析也不等于完整轨迹或原始 PX4 记录审计。附带的表格参考文件只提取当前论文已有排版与数值，不表示本次已经重算这些表。

## Figures: current numbering and original input mapping

The current manuscript has eight main figures and five supplementary figures. Frozen plotted data and provenance are mapped in `2026-09-08_141447_Zenodo归档核查/public_metadata/SOURCE_DATA_MAP.csv`, lines 2–35. The latest independent figure companion regenerates Figure 1–8 and S1–S5 from its frozen inputs. The graphical abstract is separate from these thirteen numbered figures.

| Current output | Subject | Original small-data inputs / entry point |
|---|---|---|
| Figure 1 | Native formation and controller/model architecture; explanatory schematic | `data/figure_sources/rev_fig1_protocol__topology_edges.csv`, `rev_fig1_protocol__models.csv`; publication figure script |
| Figure 2 | New controlled test tracking error and all 50 seed-block values | `data/analysis/paired_seed_blocks.csv`, `secondary_method_summaries.csv`; `enhancement/figures.py` |
| Figure 3 | Twelve primary complete-minus-point interactions | `data/analysis/primary_contrasts.csv`, `primary_family.json`; `enhancement/figures.py` |
| Figure 4 | Legacy matched-core error, species decomposition and effort | `data/statistics/method_means.csv`, `runs_snapshot.csv`, `core_fixed.csv`; `data/envelope/core_species_means.csv` |
| Figure 5 | Legacy local module effects and cross-model interactions | `data/statistics/module_effect.csv`, `cross_fidelity_interaction.csv` |
| Figure 6 | Legacy independent attitude intervention and stress boundary | `data/statistics/method_means.csv`, `runs_snapshot.csv`, `attitude_interaction.csv`; `data/envelope/flight_envelope_summary.csv` |
| Figure 7 | Legacy information interventions | `data/statistics/method_means.csv`, `descriptive_contrasts.csv` |
| Figure 8 | All PX4 design outcomes and conditional complete-record descriptions | Four `data/figure_sources/rev_fig6_px4_pub__*.csv` inputs: group counts, windows, geometry and design outcomes |
| Figure S1 | Selected-parameter numerical qualification | `data/analysis/numerical_plot_values.csv`; numerical design and qualification records |
| Figure S2 | Legacy matched gain sensitivity | `data/statistics/method_means.csv` |
| Figure S3 | Legacy error-refresh threshold sensitivity | `data/statistics/method_means.csv` |
| Figure S4 | Legacy robustness sensitivity | `data/statistics/method_means.csv`, `descriptive_contrasts.csv` |
| Figure S5 | Legacy high-gain stress diagnostic | `data/statistics/method_means.csv`, `runs_snapshot.csv`; `data/envelope/flight_envelope_summary.csv`, `flight_envelope_per_job.csv` |

Legacy source figure numbers differ: new source Figures 7, 8, S5 become current Figures 2, 3, S1. Legacy main Figures 1–6 become current Figures 1, 4, 5, 6, 7, 8; legacy S1–S4 become current S2–S5. Use the current companion's `PUBLICATION_FIGURE_MAPPING.json` for output names.

## Tables: complete current inventory

There is one main table and seventeen supplementary tables. These were counted directly from the final TeX environments. The linked inputs below identify provenance or a suitable recomputation starting point; inclusion in this map does not claim that this packaging run has already recomputed a table. Table S12 is a configuration statement, and Table S16 reports selected diagnostic examples. The frozen reference is `paper_tables_reference.tex`.

| Output | TeX starting line | Subject | Original provenance / starting point |
|---|---:|---|---|
| Main Table 1 | Main 741 | Native core error by UAV/USV species | `data/envelope/core_species_means.csv` |
| Table S1 | Supplement 223 | Equal development counts and measured kernel CPU time | `diagnostics/budget_cpu_audit.csv`; `enhancement/audit_results.py` |
| Table S2 | Supplement 238 | Warmed-up fleet controller-update CPU cost | `data/analysis/controller_computation_cost.json`; `enhancement/computation_cost.py` |
| Table S3 | Supplement 253 | Twelve primary interactions and observed numerical discrepancies | `data/analysis/primary_contrasts.csv`; `enhancement/analysis.py` |
| Table S4 | Supplement 272 | Native point-selected transfer means | `data/analysis/secondary_method_summaries.csv`, native/transfer |
| Table S5 | Supplement 283 | Native model-specific retuned means | `data/analysis/secondary_method_summaries.csv`, native/retuned |
| Table S6 | Supplement 294 | Otter point-selected transfer means | `data/analysis/secondary_method_summaries.csv`, Otter/transfer |
| Table S7 | Supplement 305 | Otter model-specific retuned means | `data/analysis/secondary_method_summaries.csv`, Otter/retuned |
| Table S8 | Supplement 316 | Realized horizontal force-squared effort | `data/analysis/secondary_method_summaries.csv`; not electrical energy |
| Table S9 | Supplement 335 | Native selected parameters | `design/selection.json`; frozen development/selection protocol |
| Table S10 | Supplement 355 | Otter selected parameters | `design/selection.json`; frozen development/selection protocol |
| Table S11 | Supplement 376 | Complete-model physical-event and saturation diagnostics | `diagnostics/physical_diagnostics.csv`; retain per-arm denominators and execution reuse |
| Table S12 | Supplement 414 | Fixed settings for legacy matched models | Supplement configuration text; original frozen configurations/protocol, not an empirical refit |
| Table S13 | Supplement 673 | Legacy matched-core error, commanded effort and refreshes | `data/statistics/method_means.csv` and legacy run endpoints; 20 blocks × 5 scenarios |
| Table S14 | Supplement 696 | Legacy realized horizontal actuator-force effort | Legacy per-run and method summaries, actual-force metric; excludes hover thrust and yaw torque |
| Table S15 | Supplement 731 | Legacy high-gain out-of-envelope outcomes | `data/envelope/flight_envelope_summary.csv`; all 40 tasks per arm retained |
| Table S16 | Supplement 773 | Three selected individual high-gain step-resolution examples | Original separate posthoc 72-record diagnostic set; manuscript names seeds 1003, 1016, 1018; not random or confirmatory samples |
| Table S17 | Supplement 1041 | Complete nine-arm PX4 design/attempt accounting | Frozen 900-row design outcome index and `px4/ATTEMPTS.csv`; 1,291 attempts, all failures retained |

The current public source map explicitly identifies S1–S11. The S12–S17 entries above extend that inventory by reading the final supplementary TeX; frozen plotting inputs are under `figure_reproduction/data/`, and the original per-run, envelope, numerical and PX4 summaries are restored under `outputs/workspace/data/` by `python reproduce.py results`. The compressed member ledger maps their exact original paths to `payloads/*.tar.xz`.

## Scientific boundaries / 科学解释边界

- On the native platform, the Full-minus-Minimal interaction changes from 0.3362 m under transfer to 0.00132 m after retuning, with simultaneous interval [−0.00026, 0.00289] m. This is not an equivalence result. On Otter, the retuned interaction is 0.4009 m [0.3655, 0.4363] m; the benefit narrows without reversing Full's ranking against Minimal.
- The selected numerical checks establish agreement on the specified condition grid, not a global error bound, physical-model validity, safe flight, hardware-in-the-loop validation or real-vehicle performance.
- The RISE source-condition diagnostic retains 94 distinct configurations: 42 reach 30 seconds, 52 stop at the magnitude guard. These are not 94 independent inferential samples. Complete reconstruction of the delayed/noisy source conditions remains unresolved.
- Legacy high-gain stress outcomes retain reference-plane crossing, inversion and nonmonotone step sensitivity. Finite integrals do not establish physical mission completion; no failed or high-error case should be silently removed.
- PX4 preserves 900 planned designs and 1,291 attempts: 824 complete records and 76 failed designs (44 before epoch issue, 32 after). Completeness is not safe flight. Failure of required designs withholds all three planned hypothesis families. Complete-record plots are conditional descriptions, not successful-subset hypothesis tests.
- Recorded kernel/controller CPU measurements are historical measurements under their stated setup. Replaying their frozen tables does not measure speed on the reader's computer.

数值一致性、指标统计重算、图件重绘和软件单次执行应分别报告。精简不应改变种子块数量、共享执行规则、失败记录或负面结果；应明确原始轨迹和 PX4 完整证据的外置范围。

## Raw archive availability — local record only

Status date: 2026-09-08. This statement is based only on the local record `2026-09-08_141447_Zenodo归档核查/上传状态与续传说明.md`, especially lines 9–14 and 22; no fresh online availability check was performed for this scope note.

The local record says the intended Zenodo collection contains 25 files totaling 76,797,790,985 bytes, upload verification is incomplete, and the deposit has not been published. Its draft upload page and reserved DOI must not be used as a public dataset download URL or cited as a published data record. A lightweight package must run its documented included-data modes without that unpublished deposit. Full-archive download instructions can be updated only after publication and independent public-access verification.

截至上述本地记录，Zenodo 归档仍未发布，上传与文件校验未完成。此状态只核对了本地记录，不能声称今天已在线验证网站状态。GitHub 精简包不应将草稿链接或预留 DOI 写成可公开下载的数据集。

## Software and license continuity

The numerical source comes from the current repository code archive `2026-09-08_104022_SMPT_投稿与数据归档/05_数据仓库归档/files/Repository_Code_and_Figures.zip`. Relative to the older 2322 code archive, the common numerical and selection/analysis source members retained the same member sizes and CRC values; the current package additionally contains revised publication graphics, independent source-condition diagnostics and explicit license files. This central-directory comparison is a provenance check, not a new scientific validation or bytewise cryptographic proof of every file.

Retain original `LICENSES.md`, `LICENSE_CODE.txt`, `SOFTWARE_SOURCES.md` and vendor notices. The recorded scope is MIT for original software and CC BY 4.0 for original data and figures, with third-party notices retained. Keep the documented software-assistance disclosure and the independent Otter source attribution.
