# 上传这个精简仓库

本地交付已经包含可上传的仓库文件，不需要先上传原始大数据卷。

1. 将精简 ZIP 解压，在 `formation-control-repro` 内查看 `README_zh-CN.md`。ZIP 是交付包装；为了让 GitHub 显示源码与 README，应上传解压后的内容。
2. 推荐用 GitHub Desktop 新建本地仓库，选择该文件夹，查看待提交清单。应包括源码、README、`payloads/`、许可和哈希清单。
3. 首次提交前确认待提交列表不含 `outputs/`、`.venv/`、缓存及原始大数据卷。使用本包 `.gitignore`。
4. 提交本地文件，再由作者在 GitHub Desktop 选择 Publish repository，设置正确的所有者、仓库名和公开/私有范围。本文包不替作者执行发布。
5. 从 GitHub 重新下载或 clone，运行 `python reproduce.py verify`；有运行环境时再运行 `results` 与 `figures`。保留 `.gitattributes`，不要自动转换科学源码换行符。

GitHub 普通 Git 单文件超过 100 MiB 会被阻止，浏览器上传每文件上限为 25 MiB。本包各文件均在 25 MiB 以内，最终 ZIP 也检查了该上限。网页批量添加通常一次最多 100 文件；本包多于 100 个文件，用 Git 或 GitHub Desktop 更方便。

官方说明：[大文件限制](https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github)、[添加文件](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)。

不应把生成轨迹、环境缓存或验证工作目录提交到 Git；运行结果由命令再生成。如果以后需要托管完整原始证据，另用已发布、可匿名访问的数据仓库并在 README 添加真实链接。不要使用未发布 Zenodo 草稿或预留 DOI 充当公开下载链接。
