# Controller rankings and module benefits in heterogeneous formation control: Actuation models and equal-budget tuning

The controlled experiment compares Minimal, Family, Full (PPT off) and an
equation-complete sampled distributed RISE controller. Each method receives
2,880 development simulations on each of two platforms. A native eight-vehicle
UAV–USV team and an independently developed four-Otter model are analyzed
separately. Point-selected transfer and model-specific retuning share the same
candidate evaluation budget. The formal design uses 50 new seed blocks on
each platform, with three native or nine Otter conditions per block.

The original fixed-gain, event-refresh and PX4 cohorts retain separate data
and inference. Their original results do not become numerical or physical
validation merely because a new controlled cohort passes its checks. Full
source-condition reconstruction of the RISE paper's delayed/noisy simulation
remains unresolved; the implemented equations and their declared sampled
deployment are documented separately. No result is described as a physical
experiment or a hardware-in-the-loop test.

## Files

- `enhancement/`: controllers, common interfaces, independent-clock physics,
  segmented reference integrator, budgeted selection, statistics and figures.
- `vendor/PythonVehicleSimulator/`: pinned original source, hashes and MIT license.
- `design/`: frozen candidates, selected parameters and inference implementation.
- `data/campaign/79b3058645f1/`: full training, validation and formal-test designs,
  job records and raw arrays. Shared executions retain one identifier.
- `data/numerical/`: current default and selected-parameter integration checks,
  plus selected reference-tolerance checks.
- `source_diagnostics/`: independent 94-condition source-model diagnostics with fixed noise clock and nonrounded delays; the delayed reconstruction remains unresolved.
- `data/source_fixture_v2/`: the RISE source-condition reconstruction, including
  finite divergent results.
- `data/analysis/`: paired block tables, the twelve primary interactions,
  secondary results and controller timing.
- `figures/enhancement/`: PDF, editable SVG, 1000 dpi PNG, reading previews and
  exact plotted-data ledgers for the controlled results.
- `DATA_DICTIONARY.md`: array definitions, coordinate frames, units and failures.
- `CONTROL_VALIDATION_PROTOCOL.md`: study choices and their interpretation.
- `SOFTWARE_SOURCES.md`: upstream sources, software attribution and licensing scope.

Separate verification records contain raw-array audits, budget checks, source
parity, regression checks, rendering checks and archive integrity evidence.
The submission directory contains final manuscript files. Build outputs and
verification logs are excluded from upload archives.

## Environment

Use Python 3.12 and a dedicated environment with `requirements.txt`. The
recorded runtime uses Python 3.12.14, NumPy 2.3.5, SciPy 1.18.0, pandas 3.0.1
and Numba 0.66.0. All numerical kernels use float64. First-call JIT compilation
can affect measured simulation time; the separate controller benchmark is
warmed up. PDF figure fonts are embedded. SVG text uses Arial, with DejaVu
Sans as the declared fallback.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

The commands below assume that `python` resolves to that environment and that
the working directory is `Reproduction`. Replays write to `outputs` and do
not overwrite archived data. The number of workers can be reduced for a
smaller machine. Full development and testing require substantial local CPU
time and disk space; GPU or remote paid resources are not required.

## Recompute the archived analysis and figures

```powershell
python -m pytest enhancement -q
python -m enhancement.analysis --campaign data/campaign/79b3058645f1 --numerical data/numerical/selected_dd57944609c8 --output outputs/controlled_analysis
python -m enhancement.figures --analysis outputs/controlled_analysis --numerical data/numerical/selected_dd57944609c8 --output outputs/controlled_figures
python -m enhancement.audit_results --campaign data/campaign/79b3058645f1 --output outputs/controlled_audit --workers 6
```

The analysis starts from the frozen design, preserves missing records and
does not treat duplicated design references as new seed blocks. The primary
family is withheld if a required endpoint is missing or nonfinite. A finite
large error is retained. Secondary intervals are pointwise and are not
substitutes for the primary simultaneous intervals. Numerical discrepancies
and physical-event diagnostics remain separate from bootstrap uncertainty.

## Rerun development and independent tests

The frozen protocol is reused so that candidates, budgets and selection
rules remain identical. Use a fresh output directory for an independent
execution; existing job records otherwise resume after hash verification.

```powershell
python -m enhancement.numerical_campaign --workers 20 --data-root outputs/replay_data
python -m enhancement.campaign develop --workers 20 --data-root outputs/replay_data --numerical-folder outputs/replay_data/numerical/defaults_dd57944609c8
python -m enhancement.numerical_campaign --workers 20 --data-root outputs/replay_data --selection outputs/replay_data/campaign/79b3058645f1/selection.json
python -m enhancement.campaign test --workers 20 --data-root outputs/replay_data --selected-numerical-folder outputs/replay_data/numerical/selected_dd57944609c8
python -m enhancement.reference_tightening --numerical outputs/replay_data/numerical/selected_dd57944609c8 --output outputs/replay_data/numerical/selected_reference_tightening
python -m enhancement.analysis --campaign outputs/replay_data/campaign/79b3058645f1 --numerical outputs/replay_data/numerical/selected_dd57944609c8 --output outputs/replay_analysis
python -m enhancement.computation_cost --selection outputs/replay_data/campaign/79b3058645f1/selection.json --output outputs/controller_computation_cost.json
```

The implementation rejects controller/dynamics or selection-source changes
after protocol freezing. A changed algorithm needs a new cohort and explicit
provenance. Physical integration does not run an extra controller update at
its internal stages. The native outer/inner periods remain 20/1.25 ms and
Otter remains 50/10 ms when the physics step is refined.

The legacy `reproduce.py` entry points remain available for the original
fixed-gain statistics, figures, conditional certificate and PX4 completeness
analysis. PX4 raw evidence resides in its unchanged companion volumes; their
hashes and archive indices identify the required files. The controlled
experiment and its analysis do not require those volumes to run.

## Published figure numbering

The manuscript is supplied through the journal submission, separately from
this data record. The reference metadata identify the sources used in the study.

The original figures keep their original filenames in `figures/` so that
the legacy reproduction entry point remains compatible. Publication numbers
are recorded in `PUBLICATION_FIGURE_MAPPING.json`. New source figures 7, 8
and S5 become publication figures 2, 3 and S1. Legacy whole figures 1–6
become publication figures 1, 4, 5, 6, 7 and 8; legacy S1–S4 become S2–S5.

One legacy graphic contains a printed supplementary-figure reference.
Recreate its publication label without modifying its data or legacy tools:

```powershell
python -m enhancement.relabel_legacy --legacy-root . --output outputs/legacy_publication
```

The generated Figure_4 and panels map to publication Figure_6. The adapter
changes S4 to S5 in the printed references and verifies identical source
hashes, data and axes. `figures/publication_renumbered/` contains the delivered
version and the verification record. Complete publication-numbered artwork is in `publication_artwork/`; it includes the whole figures and independent reading panels.

`diagnostics/` contains the raw-array audit, development budget/CPU summaries,
physical-event tables and complete failure records used in the reported
checks. These are reproducible with `enhancement.audit_results` and remain
separate from the inference dataset. `README_LEGACY.md` and `README_NATIVE.md`
describe only the original cohorts; their figure numbers refer to the
preserved original filenames.

## Archive reconstruction

Extract `Repository_Code_and_Figures.zip` and all ten independent
`Reproduction_Data_01.zip` through `Reproduction_Data_10.zip` into the same
destination. Each archive supplies members beneath `Reproduction/`; they
are ordinary ZIPs and do not require split-archive software. The data
volumes are mutually disjoint. Validate bytes, SHA-256 and member CRC using
the delivery manifest and archive indices before reuse.

The eight unchanged PX4 companion volumes are listed separately in
`PX4_COMPANION_INDEX.json`. They are needed only for replay of the original
PX4 raw evidence. They are not part of the new controlled campaign or a
claim that the PX4 hypotheses have become evaluable.

Source-equation implementation, isolated checks and full source-experiment
reproduction are distinct. The sampled RISE equations and six noiseless
source fixtures pass their checks; the delayed/noisy source reconstruction
remains unresolved and its adverse finite trajectories are retained. The
controlled comparison evaluates the disclosed sampled implementation,
not successful reproduction of every source-paper simulation.

The portable delivery archive index uses paths relative to its root. PX4 companion filenames in `PX4_COMPANION_INDEX.json` are relative to the download directory; `delivery_path` gives each local delivery location. Historical absolute paths inside frozen evidence remain provenance records.
