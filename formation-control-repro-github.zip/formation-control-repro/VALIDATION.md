# Validation / 本次验证记录

Validated locally on 2026-09-08 with Windows Python 3.12.14 and the dependency versions in `provenance/validation/runtime_and_checks.json`.

| Check | Actual result |
|---|---|
| Original input preservation | 43,758 input members / 215,418,946 bytes checked against the original delivery SHA-256 manifest while packaging |
| Frozen implementation / design coverage | 8 source hashes, 16,800 test references, 12,150 unique metric records, 56 arms and 2,800 paired arm/seed blocks passed |
| Numerical-record coverage | All 156 default + 486 selected cases present and bound to exact frozen jobs, parameters and source hashes |
| Controlled reanalysis | Eight CSV outputs, primary-family JSON, summary JSON and the 50 × 12 contrast array exactly match frozen numeric references |
| Legacy reanalysis | All seven statistical tables exactly match frozen references; all 8,820 design references / 7,620 unique executions retained |
| Parameter selection replay | All 23,040 development records retained; shortlisted candidate order, selected IDs, full-precision parameters and test design are exactly equal |
| Aggregate selection roundoff | Original parallel completion order differs from sorted replay; mean error/effort compared with rtol=1e-12, atol=1e-12. Maximum absolute difference 2.3283064365386963e-10 on the original metric scale. No parameter decision changed |
| Actual full-duration simulations | 32/32 representative conditions passed (both platforms, all method/model combinations including deletions); maximum absolute tracking-error difference from archived endpoint = 0.0; force effort and update counts passed rtol=1e-10, atol=1e-10 |
| Existing tests | 26 passed; one Numba array-contiguity performance hint. Independent source-law/history/integration checks also passed (100 equation cases) |
| Figures | All 13 latest publication data/axes/interval/source ledgers match, with PDF/SVG/PNG rendered; Figure 2 visually checked |
| Numerical plot adapter | 486 original cases yield 1,800 comparisons; all values equal the retained CSV with round-trip float parsing |
| PX4 failures | All 900 designs and 1,291 attempts retained in relevant summaries; 76 failed designs remain, and H1/H2/H3 correctly remain blocked |
| Conditional theorem replay | Original certificate and excluded counterexamples regenerated; no-saturation remains an assumption, not a proven global guarantee |
| Controlled result tables | 11 table environments regenerated from recomputed inferential outputs plus preserved timing and event summaries |
| Full rerun entry | Fresh workspace and exact stage plan validated with --prepare-only; the full campaign was not launched |

本次已经实际完成逐记录统计复算、选参重建、32 个完整时长条件运行、26 项既有测试及 13 图重绘。不能将这些检查等同于重新运行数万次实验、从每条原始轨迹重算所有端点、物理实验验证或论文科学结论无条件成立。

The dense raw trajectory arrays and original PX4 environment/logs are intentionally absent. The full 23,040-development / 12,150-formal campaign, raw-array re-audit of all historical runs, independent online dependency installation, and non-Windows execution were not performed in this packaging task. The timing table is historical; new-machine timing is available only through an explicit timing/full-rerun command. The 18 manuscript table environments in `docs/paper_tables_reference.tex` are frozen references, not a claim that all 18 were newly computed.

Machine-readable reports are in `provenance/validation/` and `provenance/FIGURE_SLIM_VALIDATION.json`. Run `python reproduce.py verify` after downloading to check package file bytes. Per-input archive members are checked again when a replay expands them. The SHA manifest excludes itself and generated outputs.
