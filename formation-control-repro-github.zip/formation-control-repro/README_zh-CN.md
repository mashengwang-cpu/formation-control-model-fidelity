# 编队控制精简复现包

作者：Fuliang Ma、Yuzhen Dang、Yuping Ma、Ying Jiang、Hongbin Ma。

本仓库保留控制器与统计代码、冻结设计、开发与逐执行指标，以及正文8图、补充5图的绘图输入。使用方法见 [README](README.md)。

它支持统计复算、选参重建、图件重绘和代表性仿真；不包含完整时序数组及 PX4 原始日志，因此不能仅凭本包重新审计每条原始轨迹。完整原始归档另行保留，公开存储尚待完成。

默认 PNG 为150 dpi；投稿用途运行 `python reproduce.py figures --dpi 1000`，PDF/SVG保持矢量。所有新输出位于 `outputs/`，不要提交缓存、虚拟环境或新生成的大轨迹。

科学来源、哈希和既有验证记录保存在 `provenance/` 与 `VALIDATION.md`。RISE源条件重构、PX4未评估假设及压力条件的适用边界保留不变。许可证见 `LICENSES.md`。
