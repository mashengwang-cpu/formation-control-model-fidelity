"""Strict read-only coverage checks for the compact frozen controlled cohort.

Call check(workspace) after the controlled and numerical payloads are expanded.
This verifies metric-record coverage and provenance, not omitted raw arrays.
"""
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def _read(path):
    def invalid_constant(value):
        raise ValueError("Nonstandard JSON numeric constant: " + value)
    return json.loads(path.read_text(encoding="utf-8"), parse_constant=invalid_constant)


def _require(condition, message):
    if not condition:
        raise ValueError("Frozen input coverage: " + message)


def _body(record, excluded):
    return {key: value for key, value in record.items() if key not in excluded}


def _physical(job):
    return _body(job, {"stage", "candidate"})


def check(workspace):
    """Return a JSON-serializable report or raise ValueError on inconsistency."""
    workspace = Path(workspace).resolve()
    protocol = _read(workspace / "design/protocol.json")
    protocol_hash = protocol["protocol_hash"]
    _require(protocol_hash == _digest(_body(protocol, {"protocol_hash"})), "protocol content hash")
    _require(protocol_hash == "79b3058645f13f3192ff65e597859422cb32bf352007f9812e3a6f82100062e1",
             "unexpected frozen cohort")
    sources = {**protocol["dynamics_sources"], **protocol["selection_sources"]}
    for name, expected in sources.items():
        _require(Path(name).name == name, "invalid source filename")
        actual = hashlib.sha256((workspace / "enhancement" / name).read_bytes()).hexdigest()
        _require(actual == expected, "source changed: " + name)
    source_hash = _digest(protocol["dynamics_sources"])
    campaign = workspace / "data/campaign" / protocol_hash[:12]
    _require(_read(campaign / "protocol.json") == protocol, "campaign protocol differs")
    selection = _read(campaign / "selection.json")
    _require(selection["protocol_hash"] == protocol_hash, "selection protocol")
    _require(selection["selection_hash"] == _digest(_body(selection, {"selection_hash"})),
             "selection content hash")
    _require(_read(workspace / "design/selection.json") == selection, "root/campaign selection differs")
    frozen = _read(campaign / "test_design_frozen.json")
    _require(frozen["selection_hash"] == selection["selection_hash"], "test selection hash")
    _require(frozen["design_hash"] == _digest(_body(frozen, {"design_hash"})), "frozen test design hash")
    formal = _read(campaign / "test/design.json")
    _require(formal["protocol_hash"] == protocol_hash, "formal test protocol")
    rows = formal["rows"]
    _require(len(rows) == 16800, "formal design must contain 16800 references")
    _require([_body(row, {"design_id", "job_id"}) for row in rows] == frozen["rows"],
             "execution references differ from frozen test rows")
    unique = {}
    design_ids = set()
    blocks = defaultdict(list)
    arms = defaultdict(set)
    for reference in rows:
        row = _body(reference, {"design_id", "job_id"})
        _require(reference["design_id"] == _digest(row)[:28], "formal design_id")
        _require(reference["design_id"] not in design_ids, "duplicate formal design_id")
        design_ids.add(reference["design_id"])
        job = row["job"]
        expected_id = _digest({"physical": _physical(job), "parameters": row["parameters"],
                               "protocol": protocol_hash})[:28]
        _require(reference["job_id"] == expected_id, "formal physical execution ID")
        unique.setdefault(expected_id, row)
        platform = job["platform"]
        _require(platform in protocol["seed_groups"], "unknown formal platform")
        _require(job["stage"] == "test", "non-test formal job")
        _require(job["seed"] in protocol["seed_groups"][platform]["test"], "non-test seed")
        arm = (platform, job["method"], row["strategy"], job["model"], _digest(row["parameters"]))
        arms[arm].add(job["seed"])
        blocks[(*arm, job["seed"])].append((job["trajectory"], job["current"]))
    _require(len(unique) == 12150, "formal design must contain 12150 unique executions")
    _require(len(arms) == 56 and len(blocks) == 2800, "formal analysis-arm/block coverage")
    for arm, seeds in arms.items():
        _require(seeds == set(protocol["seed_groups"][arm[0]]["test"]), "seed coverage per arm")
    for block, scenarios in blocks.items():
        expected = {(trajectory, current) for trajectory in protocol["test_trajectories"]
                    for current in protocol["test_currents"][block[0]]}
        _require(len(scenarios) == len(expected) and set(scenarios) == expected,
                 "missing/duplicated scenarios in paired seed block")
    jobs = campaign / "test/jobs"
    actual_ids = {path.stem for path in jobs.glob("*.json")}
    _require(actual_ids == set(unique), "missing or extra formal metric records")
    statuses = Counter()
    for job_id, row in unique.items():
        record = _read(jobs / (job_id + ".json"))
        _require(record["job_id"] == job_id and record["protocol_hash"] == protocol_hash,
                 "record identity/protocol: " + job_id)
        _require(_physical(record["job"]) == _physical(row["job"])
                 and record["parameters"] == row["parameters"], "record physical inputs: " + job_id)
        metrics = record["metrics"]
        _require(isinstance(metrics["complete"], bool), "invalid complete flag: " + job_id)
        _require(record["status"] == ("complete" if metrics["complete"] else "failed_simulation"),
                 "record completion/status mismatch: " + job_id)
        if metrics["complete"]:
            _require(all(isinstance(metrics.get(key), (int, float)) and math.isfinite(metrics[key])
                         for key in ["J_m", "force_effort_N2s"]), "nonfinite complete endpoint: " + job_id)
        statuses[record["status"]] += 1
    summary = _read(campaign / "test/summary.json")
    _require(summary["execution_count"] == len(unique) and summary["reference_count"] == len(rows)
             and summary["statuses"] == dict(statuses), "formal summary/record counts")

    numerical_reports = {}
    for name, expected_count in [("defaults", 156), ("selected", 486)]:
        folder = workspace / "data/numerical" / (name + "_" + source_hash[:12])
        design = _read(folder / "design.json")
        numeric_summary = _read(folder / "summary.json")
        _require(design["source"] == protocol["dynamics_sources"] and design["source_hash"] == source_hash,
                 name + " numerical source identity")
        _require(numeric_summary["source_hash"] == source_hash, name + " numerical summary source")
        cases = {}
        for case in design["cases"]:
            case_id = _digest({"job": case["job"], "parameters": case["parameters"], "source": source_hash})[:24]
            _require(case_id not in cases, name + " duplicate numerical design case")
            cases[case_id] = case
        _require(len(cases) == expected_count, name + " numerical design count")
        actual_cases = {path.stem for path in folder.glob("*.json") if path.name not in {"design.json", "summary.json"}}
        _require(actual_cases == set(cases), name + " missing/extra numerical records")
        evaluated = 0
        errors = 0
        unresolved = []
        for case_id, case in cases.items():
            record = _read(folder / (case_id + ".json"))
            _require(record["case_id"] == case_id and record["source_hash"] == source_hash,
                     name + " numerical record identity/source")
            _require(record["job"] == case["job"] and record["parameters"] == case["parameters"],
                     name + " numerical inputs")
            if record["status"] == "evaluated":
                evaluated += 1
                comparisons = record["comparisons"]
                target = .00125 if case["job"]["platform"] == "native" else .0025
                _require(sum(item["physics_dt"] == target for item in comparisons) == 1,
                         name + " missing/duplicate target-step comparison")
                if not comparisons[-1]["pass"]:
                    unresolved.append(case_id)
            else:
                _require(record["status"] == "implementation_error", name + " unknown numerical status")
                errors += 1
        _require(numeric_summary["cases"] == expected_count and numeric_summary["evaluated"] == evaluated
                 and numeric_summary["implementation_errors"] == errors,
                 name + " numerical summary/record counts")
        _require(set(numeric_summary["unresolved_finest"]) == set(unresolved),
                 name + " unresolved numerical cases omitted or altered")
        numerical_reports[name] = {"designed": expected_count, "present": len(actual_cases),
                                   "evaluated": evaluated, "implementation_errors": errors,
                                   "unresolved_finest": len(unresolved)}
    return {"status": "PASS", "protocol_hash": protocol_hash, "source_hash": source_hash,
            "frozen_source_files": len(sources), "formal_design_references": len(rows),
            "formal_unique_metric_records": len(unique), "formal_analysis_arms": len(arms),
            "paired_seed_blocks": len(blocks), "formal_statuses": dict(statuses),
            "numerical": numerical_reports, "numerical_case_records": 642,
            "raw_trajectory_hashes_rechecked": False,
            "scope": "Exact frozen metric/design/source coverage; numerical limitations and failed outcomes are retained. Omitted NPZ traces are not reaudited."}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    print(json.dumps(check(parser.parse_args().workspace), indent=2))
