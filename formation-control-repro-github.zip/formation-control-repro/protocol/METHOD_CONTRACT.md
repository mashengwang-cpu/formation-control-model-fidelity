# 修订版方法与实验合同

本合同在新测试运行之前制定。旧配置以 LEGACY_CONFIG_REGISTER.csv 为准；本合同不追溯改变旧实验。

## 方法身份

| 新文简称 / arm_id | 实现 method | PPT | 相对背景 |
|---|---|---|---|
| Full, PPT off / full_no_ppt | proposed_no_ppt | off | 主消融背景 |
| Minimal / minimal | proposed_minimal_causal | off | PD、误差采样触发、因果补偿 |
| Family / family | recent_2025_resilient_fixed_time | on | 自建家族比较器，不称原文精确复现 |
| TVG removed / ko_tvg | hifi_ko_tvg | off | 只删除 capped TVG |
| Powers removed / ko_powers | hifi_ko_powers | off | 只删除两项 signed powers |
| Approximation removed / ko_approximator | hifi_ko_approximator | off | 只删除自适应逼近 |
| Error filter removed / ko_observer | hifi_ko_observer | off | 只删除 leaky error filter |
| Efficiency compensation removed / ko_faultcomp | hifi_ko_faultcomp | off | 只删除输入除以有效度的补偿，bias 估计仍在 |
| Topology removed / ko_topology | proposed_no_ppt | off | 仅 gamma 从 0.35 变为 0 |
| PPT added / ppt_added | proposed_full | on | 只打开 PPT |

所有匹配主比较使用 Kp=2.15、Kv=2.05、gamma=0.35、Tp=5 s、同一 trigger，PPT 与模块开关逐任务存档。Family 原生 1.9/1.9 增益不混入主匹配比较，增益敏感性单独完整报告。这里的 full 明确为 PPT-off 背景，不能与历史 proposed_full 混称。

## 事件与信息

事件同时刷新位置与速度误差样本。控制器、PPT 当前边界、TVG、逼近器、leaky filter 与补偿器每 0.02 s 计算；非事件步的命令可以变化。PPT 保存原始误差样本，并以当前边界重新变换。事件计数不代表执行器命令发布数，也不代表无线包数量。

拓扑混合与触发检测可访问当步邻居误差；这是一套集中仿真中的信息可用性假设，未实现事件网络协议。DoS 仅阻止样本刷新。PX4 保留持续 Offboard 心跳与加速度设定值，其消息成本单列。

因果估计器固定 g_rho=0.25、alignment gate=0.8、decay=0.05、projection=[0.30,1.05]；bias gain=0.10、decay=0.35、limit=0.40。此设置是沿用后进行统一的设计选择，不声称由缺档 pilot 优化得到。速度测量未受攻击，初始化时 bias 为零；这是可识别性所依赖的假设。投影保证估计数值有界，不保证无偏或真实故障参数收敛。

causal、oracle（rho 和 bias 均提供）、oracle_efficiency（只提供 rho）、oracle_bias（只提供 bias）分开保存，用于区分信息贡献。

## 新匹配模型

同一主循环下的 matched_point_mass、matched_lagged、mixed_6dof_3dof 均采用 SI 力、质量、相同 XY 初态、全队伍扰动索引和测试种子。matched_drag=True 统一 XY 平移阻尼；完整定义见 MODEL_CONTRACT.md。rigid 不再隐式叠加 planar sway/lag 代理。旧 v1000_canonical 仍仅服务历史数值回放。

mixed 的积分器按实际实现描述；RK4 标签只用于对应点质量平移积分，不能覆盖所有内环更新。UAV 姿态干预仅改变 kR=8*s^2、kOmega=1.25*s；s={0.5,1,2}，UAV-only，内步固定 0.00125 s。它识别的是这一受控带宽参数的影响，不能独自证明全部高保真差异都由姿态产生。

## 指标

新 J 为时间梯形积分的各车平均 XY 误差 / T，单位 m。新 commanded effort 为外环保持区间内 sum ||u_cmd||^2 dt，单位 N^2 s，不称电能。实际平移力 effort 对真实施加的力在物理内步积分；USV yaw torque 与 UAV 推力/饱和诊断单列，不能把 XY force effort 当总能耗。

任务区间为 [0,T) 的控制作用与刷新事件；T 端点只用于状态积分。保存旧算术均值/梯形 commanded effort 为诊断字段，不与新定义混用。

## 独立性与失败

主测试种子 1000--1019；独立稳健性种子 2000--2019。所有选择在结果查看前固定；没有声称足以检出任意微小差异的功效保证。预定任务失败保留，相关推断标记不完整。共享同一次确定性仿真用于多个比较时，使用同一 job_id 引用，独立任务数按唯一 job_id 计算。
