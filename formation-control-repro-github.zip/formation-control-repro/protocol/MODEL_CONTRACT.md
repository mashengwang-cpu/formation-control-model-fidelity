# Revised physical-model and theorem contract

Date: 2026-09-06. All changes are confined to `revision_20260906`; the archived submission and audit remain immutable.

## Objects and interfaces

- Outer controller: planar force command, newtons, sampled every `dt_s`. Events refresh position/velocity error samples; adaptive/filter/estimator states may update at every detection step. This is sample-held feedback, not a zero-order-held compensated command.
- Canonical point mass: archived linear mass/damping RK4 map; unchanged for historical reproduction. Planar proxy: explicitly separate lagged surrogate; unchanged.
- Revised `mixed_6dof_3dof`: Newton-Euler UAV plus underactuated surge-sway-yaw USV. Rigid plants receive the outer force request directly by default. The old implicit planar filter/sway-proxy cascade is removed from this plant, and historical rigid CSVs must not be relabeled as revised results.
- Rigid integration: semi-implicit translation/body-velocity steps and exponential-map UAV attitude updates. `integrator='rk4'` controls only reduced-order paths; it must not be reported as the rigid inner-loop integration order.
- UAV `inner_dt_s` and new `usv_inner_dt_s` are independent upper bounds on inner step length; substeps cover exactly one outer step.

## Independent UAV interventions (SimulationJob fields)

| Field | Default | Meaning |
|---|---:|---|
| `uav_attitude_bandwidth_scale` | 1.0 | UAV kR=8*s^2, kOmega=1.25*s; inertia, outer gains, USV and thrust limits unchanged. This changes the unsaturated linear response rate while preserving its damping ratio. |
| `uav_tilt_limit_rad` | 0.70 | Desired UAV tilt limit only. |
| `uav_thrust_max_frac` | 2.40 | UAV total commanded thrust ceiling as a multiple of mg, retaining per-rotor allocation/clipping. |
| `inner_dt_s` | 0.005 | UAV integration step only. |
| `usv_inner_dt_s` | 0.005 | USV integration step only. |
| `uav_command_lag_s` | 0.0 | Explicit optional first-order world-frame UAV command filter; zero means direct command. |
| `usv_command_lag_s` | 0.0 | Independent optional USV command filter; no artificial sway gain or yaw-coupled planar proxy. |

Bandwidth intervention uses the existing geometric torque law and actuator constraints, so actuator saturation can limit the realized bandwidth. Record saturation and do not label this as an intervention that holds all realized torques constant. For bandwidth comparison s={0.5,1,2}, hold UAV inner step at 0.00125 s and USV inner step fixed. For numerical convergence, vary only UAV inner step with s=1.

## USV corrections

1. The supplied `disturbance_xy` is a world-frame external force in N. Rotate it into the body frame and add to the surge/sway dynamics; position obeys p_dot=R(psi)[u,v]. Stored inertial velocity therefore matches the kinematic velocity used for position integration and estimators.
2. Sway has no actuator. Log only the true applied surge thrust rotated into world xy. No `0.34*f_sway` is synthesized as an actual force.
3. Actuator effectiveness multiplies actual surge/yaw commands. Yaw torque effort is reported separately in N^2 m^2 s; it cannot be added numerically to planar force-squared effort.
4. Rigid force-effort metrics integrate the squared actual actuator force over inner steps. External disturbance and drag are excluded from actuator effort. These effort proxies are not electrical energy or endurance.

## Estimator and evidence boundary

The causal estimator remains a projection-based identifier under a deliberately simplified input/acceleration relationship. Corrected rigid drag passed to it follows the corresponding plant drag; neither projection nor bounded output guarantees true-parameter consistency. Root selects the common causal estimator bandwidth/alignment settings and common controller methods.

Theorem 1 covers only the unsaturated, isolated canonical point-mass minimal-feedback loop with an assumed effectiveness-ratio interval, detection-grid event timing, and no DoS. It does not certify the revised rigid dynamics, the network, or estimator accuracy. The proof will distinguish commanded input from realized actuator input and replace the sampled intersample factor by a conservative continuous-interval upper bound. The invalid S1 fixed-time Lyapunov sketch is withdrawn.

## Matched comparison layers implemented after protocol agreement

New `matched_point_mass` and `matched_lagged` share the `simulate_job` path, initial xy positions/velocities, masses, topology, scenario realization, SI force requests, time grid, and the same semi-implicit translational integration rule and species-specific inner steps. They do not invoke the historical canonical loop. The first is fully actuated in world xy; the second adds only a declared world-frame first-order input filter (default 0.08 s UAV and 0.24 s USV). Positive explicit lag fields override these defaults. A zero lag field on `matched_lagged` selects the layer default, whereas zero on the point-mass/rigid layer means a direct wire.

The filter is implemented as the outer-step map `F_k = exp(-dt/tau)*F_(k-1) + (1-exp(-dt/tau))*u_k`, with the updated `F_k` held through that physical outer interval. It is not an additional continuous lag integrated at every physics substep.

All three new matched campaigns must explicitly set `matched_drag=True`. This gives UAV horizontal drag `(.24+.012*||vxy||)*vxy`, independent of vertical velocity, and USV isotropic horizontal drag `(.36+.065*||vxy||)*vxy`. In the rigid USV the same expression is evaluated in the body frame and rotated, which is physically rotation-equivariant. The matched planar layers require this flag. Native rigid sensitivity runs may use `matched_drag=False`: the original full-3D UAV norm and anisotropic USV hull damping remain available, now with the corrected force/kinematics implementation. This is a declared surrogate-model intervention, not a claim that the isotropic hull is a calibrated vessel.

In the rigid `dynamics_uncertainty=.15` diagnostic, the generated mass and its mass-scaled inertia/thrust quantities vary. The effectiveness estimator receives this realized mass. Generated drag/time constants are not propagated into the rigid fleets; the estimator's drag array is overwritten with fleet-specific rigid drag for every rigid follower (simulator lines 400–408). Thus this condition is parameter variation with known realized mass, not unknown-mass identification or uniform uncertainty in every physical coefficient.

New matched/rigid horizontal external force is computed once per outer step from the full follower index list and held during that step. The UAV/USV masks select from this same array; USV indices are not restarted at one. UAV vertical force is additional, and altitude/attitude/rotor limits and USV heading/underactuation are exactly the physical mechanisms absent from planar counterparts. Native historical CSVs used a different disturbance/integration configuration and are not merged.

`resilience_information_mode='oracle_efficiency'` supplies only true actuator effectiveness while estimating bias causally. `'oracle_bias'` supplies only true sensor bias while estimating effectiveness causally. `'oracle'` supplies both; `'causal'` estimates both. Non-resilient methods do not receive either compensation. The two partial-oracle modes are implemented on the new simulator path; the historical canonical loop is unchanged.

## Logging and verification

- `actual_controls[k]` is the inner-step mean actuator xy force over `[t_k,t_(k+1))` for rigid vehicles. The final row repeats the last interval solely for display. State trajectories are node samples; interval-mean force must not be interpreted as a simultaneous endpoint observation.
- `actual_control_energy`, `actual_uav_force_effort`, and `actual_usv_force_effort` use inner-step sums of squared applied force times step duration, not squared mean force or endpoint trapezoids. `actual_usv_yaw_torque_effort` is separate. Horizontal force effort excludes hover thrust and must not be called battery energy.
- `SimulationOutput.actual_force_interval_effort` has shape `(T,N)` and `usv_yaw_interval_effort` has shape `(T,N_usv)`. Each row stores the corresponding inner-step effort sum over the following outer interval; the last row is zero. Summing all entries reconstructs the corresponding run metric without needing to square the mean-force trace. These arrays are available for the revised rigid and matched-planar layers.
- New diagnostics: `uav_rotor_saturation_fraction`, `uav_tilt_saturation_fraction`, `uav_tracking_error`, and `usv_tracking_error`.
- Focused verification: 15 tests passed, covering USV external-force units and kinematics, absence of fictitious sway force, rho-squared actual effort, rotation-equivalent matched drag, independent attitude intervention, initial-state matching, separate partial oracles, unchanged USV-only trajectories under UAV-only interventions, existing rigid smoke checks, and the historical canonical gold set.
