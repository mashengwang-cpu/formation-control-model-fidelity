# RISE source-condition diagnostics

These diagnostics reconstruct the source model independently of the formal formation-control benchmark. The 94 distinct diagnostic configurations include 42 completed 30 s runs and 52 magnitude-guard stops. Eight repeated pilot configurations are excluded from those counts. The delayed source behavior remains unresolved.

From this directory, run `python code/verify_source.py --help` for run controls. `python code/test_source.py` checks algebra and short-window integration; `python code/check_delayed_reference.py` checks a short delayed trajectory. These checks do not establish full-horizon numerical convergence. The scripts retain their original experiment settings. See the supplementary source-diagnostic subsection and reports for assumptions and limits.
