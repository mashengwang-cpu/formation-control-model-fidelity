"""Source-law parity and independent integration/history contracts."""
import importlib.util
import json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
import verify_source as v

def main():
    old=Path(__file__).resolve().parent/'frozen_controllers.py'
    spec=importlib.util.spec_from_file_location('frozen_controllers',old)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    rng=np.random.default_rng(77401); errors=[]
    A,B=m.ring(8,1.);B[1::2]=0
    for _ in range(100):
        y=rng.normal(size=78); c=rng.uniform(-.5,.5,(8,12));t=rng.uniform(0,30)
        zero=np.zeros((8,3));noise=np.zeros((8,6,3));states=y[None,:]
        virtual,idot=v.command(y,t,.001,0,states,zero,noise,False)
        g=v.input_matrix(t,c);gp=np.array([np.diag(1/x) for x in g])
        q,vel=y[:27].reshape(9,3),y[27:54].reshape(9,3)
        u0,i0,_,_=m.rise_equations.py_func(q[:8],vel[:8],q[8],vel[8],A,B,y[54:].reshape(8,3),np.array(v.GAINS),gp)
        errors.append(max(np.max(np.abs(virtual/g-u0)),np.max(np.abs(idot-i0))))
    assert max(errors)<1e-10
    times=np.arange(11)*.001;array=np.array([2+3*t+np.arange(4) for t in times])
    np.testing.assert_allclose(v.hist(array,.00437,.001,10),2+3*.00437+np.arange(4),atol=1e-14)
    np.testing.assert_array_equal(v.hist(array,-.005,.001,10),array[0])
    # Zero state, zero drift/disturbance and zero noise: leader acceleration is
    # [-1,1,0], so only leader acceleration is nonzero at t=0.
    y=np.zeros(78); states=y[None,:];commands=np.zeros((1,8,3))
    rhs,u=v.derivative(y,0.,.001,0,states,commands,np.zeros((8,12)),np.zeros((8,3)),np.zeros((8,6,3)),False)
    expected=np.zeros(78);expected[51:54]=[-1,1,0]
    np.testing.assert_array_equal(rhs,expected)
    y,c,delay,nz=v.initial_draw(29000,.02);noise=np.zeros_like(nz)
    def rhs(t,y):
        return v.derivative(y,t,.001,0,y[None,:],commands,c,np.zeros((8,3)),np.zeros((8,6,3)),False)[0]
    # Independent DOP853 on a short transient including sign crossings.
    # No fourth-order convergence claim is made for this nonsmooth system.
    ref=solve_ivp(rhs,(0,.02),y,method='DOP853',rtol=2e-12,atol=2e-13,max_step=.0001)
    tight=solve_ivp(rhs,(0,.02),y,method='DOP853',rtol=2e-13,atol=2e-14,max_step=.00005)
    assert ref.success and tight.success
    convergence=[]
    for dt in [.001,.0005,.00025,.000125,.0000625,.00003125,.000015625,.0000078125,.00000390625,.000001953125]:
        ys,_,status=v.simulate(y,c,np.zeros((8,3)),noise,dt,.02,False)
        e=float(np.max(np.abs(ys[-1]-tight.y[:,-1])))
        convergence.append(e);assert status==0
    print("Independent RK4 errors:", convergence, flush=True)
    assert all(b<a for a,b in zip(convergence,convergence[1:]))
    assert convergence[-1]<1e-4
    result={'equation_cases':100,'maximum_equation_error':max(errors),'history_linear_interpolation':True,'constant_negative_history':True,'zero_state_physics':True,'dop853_tolerance_difference':float(np.max(np.abs(ref.y[:,-1]-tight.y[:,-1]))),'rk4_max_state_error_at_20ms':convergence,'pass':True}
    (v.ROOT/'reports/implementation_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))

if __name__=='__main__':main()
