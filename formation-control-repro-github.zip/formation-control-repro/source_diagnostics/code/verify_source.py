"""Independent method-of-steps reconstruction of Nino et al., CSL 2025.

No gain tuning, graph-weight tuning, saturation, or sign smoothing.
State history is constant before t=0; actuator input history is zero.
Positive delays use linear interpolation of stored states/commands.
RK4 integrates physical and integral states together. Noise is constant on
fixed 1 ms intervals across resolutions; RK stages use that interval's noise.
The 1e12 diagnostic stop is recorded as an incomplete trajectory, not a pass.
"""
from pathlib import Path
import argparse, hashlib, json, time
import numpy as np
from numba import njit

ROOT = Path(__file__).resolve().parents[1]
GAINS = (10., 10., 25., 50.)
VARIANTS = {
    'ideal': (False, (0,0,0), False),
    'noise_only': (True, (0,0,0), False),
    'communication_only': (False, (1,0,0), False),
    'actuation_only': (False, (0,1,0), False),
    'target_only': (False, (0,0,1), False),
    'all_delays': (False, (1,1,1), False),
    'all_noise_delays': (True, (1,1,1), False),
    'all_relative_delays': (True, (1,1,1), True),
}

@njit(cache=True)
def hist(array, tau, dt, k):
    x = max(0., tau/dt)
    i = min(int(np.floor(x)), k)
    j = min(i+1, k)
    f = min(max(x-i, 0.), 1.)
    return (1-f)*array[i] + f*array[j]

@njit(cache=True)
def command(y, t, dt, k, states, delays, noise, relative):
    q, v, integ = y[:27].reshape(9,3), y[27:54].reshape(9,3), y[54:].reshape(8,3)
    eta = np.zeros((8,3)); etav = np.zeros((8,3)); e = np.zeros((8,3)); ev = np.zeros((8,3))
    for i in range(8):
        if delays[i,2] > 0:
            past = hist(states,t-delays[i,2],dt,k)
            pq,pv = past[:27].reshape(9,3),past[27:54].reshape(9,3)
        else:
            pq,pv = q,v
        e[i] = pq[8] - (pq[i] if relative else q[i]) + noise[i,0]
        ev[i] = pv[8] - (pv[i] if relative else v[i]) + noise[i,1]
        if i%2==0: eta[i],etav[i]=e[i],ev[i]
        if delays[i,0]>0:
            past=hist(states,t-delays[i,0],dt,k)
            pq,pv=past[:27].reshape(9,3),past[27:54].reshape(9,3)
        else: pq,pv=q,v
        for jn in range(2):
            j=(i-1)%8 if jn==0 else (i+1)%8
            eta[i]+=pq[j]-(pq[i] if relative else q[i])+noise[i,2+jn]
            etav[i]+=pv[j]-(pv[i] if relative else v[i])+noise[i,4+jn]
    virtual=25*etav+501*eta+integ
    for i in range(0,8,2): virtual[i]+=20*ev[i]+101*e[i]
    idot=2535*eta+50*np.sign(etav+10*eta)
    return virtual,idot

@njit(cache=True)
def input_matrix(t,c):
    g=np.empty((8,3))
    g[:,0]=1-c[:,6]*np.cos(t);g[:,1]=1-c[:,7]*np.sin(t)
    g[:,2]=1-c[:,8]*np.cos(t)*np.sin(t)
    return g

@njit(cache=True)
def derivative(y,t,dt,k,states,commands,c,delays,noise,relative):
    virtual,idot=command(y,t,dt,k,states,delays,noise,relative)
    g=input_matrix(t,c); u=virtual/g
    applied=u.copy()
    for i in range(8):
        if delays[i,1]>0:
            tau=t-delays[i,1]
            applied[i]=np.zeros(3) if tau<0 else hist(commands,tau,dt,k)[i]
    q,v=y[:27].reshape(9,3),y[27:54].reshape(9,3)
    acc=np.empty((9,3))
    for i in range(8):
        x,yy,z=q[i];vx,vy,vz=v[i]
        acc[i,0]=c[i,0]*(yy-z)+c[i,1]*np.tanh(vx*t)+g[i,0]*applied[i,0]+c[i,9]*np.cos(t)
        acc[i,1]=c[i,2]*(z-x)+c[i,3]*np.tanh(vy*t)+g[i,1]*applied[i,1]+c[i,10]*np.sin(t)
        acc[i,2]=c[i,4]*(x-yy)+c[i,5]*np.tanh(vz*t)+g[i,2]*applied[i,2]+c[i,11]*np.cos(t)*np.sin(t)
    x,yy,z=q[8];vx,vy,vz=v[8]
    acc[8]=np.array([np.sin(x)-np.cos(yy*vx),np.cos(z*vy)-np.sin(x),-np.sin(yy*vz)-np.sin(z)])
    return np.concatenate((v.ravel(),acc.ravel(),idot.ravel())),u

@njit(cache=True)
def simulate(y0,c,delays,noise,dt,duration,relative):
    steps=round(duration/dt); states=np.empty((steps+1,78));commands=np.zeros((steps+1,8,3))
    states[0]=y0; end=steps; status=0
    for k in range(steps):
        t=k*dt; nz=noise[min(int(round(t/dt))//round(.001/dt),len(noise)-1)]
        y=states[k]
        a,u=derivative(y,t,dt,k,states,commands,c,delays,nz,relative);commands[k]=u
        b,_=derivative(y+.5*dt*a,t+.5*dt,dt,k,states,commands,c,delays,nz,relative)
        cc,_=derivative(y+.5*dt*b,t+.5*dt,dt,k,states,commands,c,delays,nz,relative)
        d,_=derivative(y+dt*cc,t+dt,dt,k,states,commands,c,delays,nz,relative)
        states[k+1]=y+dt/6*(a+2*b+2*cc+d)
        if not np.isfinite(states[k+1]).all(): end=k+1;status=2;break
        if np.max(np.abs(states[k+1]))>1e12: end=k+1;status=1;break
    nz=noise[min(int(end*dt/.001),len(noise)-1)]
    _,commands[end]=derivative(states[end],end*dt,dt,end,states,commands,c,delays,nz,relative)
    return states[:end+1],commands[:end+1],status

def initial_draw(seed,duration=30.):
    rng=np.random.default_rng(seed)
    y=np.zeros(78);y[:27]=rng.uniform(-10,10,(9,3)).ravel();y[51:54]=[1,-1,.5]
    c=rng.uniform(-.5,.5,(8,12));delays=rng.uniform(.001,.02,(8,3))
    noise=rng.normal(0,.001,(round(duration/.001)+1,8,6,3))
    return y,c,delays,noise

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',default='29000,29001,29002');ap.add_argument('--steps',default='.001,.0005,.00025')
    ap.add_argument('--variants',default=','.join(VARIANTS));ap.add_argument('--output',default='campaign');args=ap.parse_args()
    out=ROOT/'results'/args.output;out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for seed in map(int,args.seeds.split(',')):
        y,c,delays,noise=initial_draw(seed)
        for variant in args.variants.split(','):
            noisy,mask,relative=VARIANTS[variant]
            actual_delays=delays*np.array(mask)[None,:];nz=noise if noisy else np.zeros_like(noise)
            for dt in map(float,args.steps.split(',')):
                start=time.perf_counter();ys,us,status=simulate(y,c,actual_delays,nz,dt,30.,relative)
                errors=np.linalg.norm(ys[:,:27].reshape(-1,9,3)[:,:8]-ys[:,:27].reshape(-1,9,3)[:,8,None,:],axis=2)
                tail=errors[-round(5/dt):] if status==0 else None
                name=f'{seed}_{variant}_{int(round(dt*1e6))}us'
                take=np.unique(np.r_[np.arange(0,len(ys),round(.01/dt)),len(ys)-1])
                np.savez_compressed(out/(name+'.npz'),time=take*dt,state=ys[take],command=us[take],coefficients=c,delays=actual_delays,initial=y)
                row=dict(seed=seed,variant=variant,dt=dt,status=['completed','diagnostic_magnitude_stop','nonfinite'][status],end_time=(len(ys)-1)*dt,tail_mean_m=float(tail.mean()) if tail is not None else None,tail_max_m=float(tail.max()) if tail is not None else None,max_error_m=float(errors.max()),max_input=float(np.abs(us).max()),seconds=time.perf_counter()-start,trace=name+'.npz')
                rows.append(row);print(json.dumps(row),flush=True)
                (out/'summary.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    config=dict(gains=GAINS,graph='unit-weight undirected cycle; pinned agents 1,3,5,7',noise_clock_s=.001,output_clock_s=.01,delay_interpolation='linear; exact sampled values',initial_history='constant state; zero pre-start actuator input',integrator='coupled-state RK4 method of steps',stop='absolute state > 1e12 recorded as incomplete; no replacement endpoint',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),arguments=vars(args))
    (out/'protocol.json').write_text(json.dumps(config,indent=2),encoding='utf-8')

if __name__=='__main__': main()
