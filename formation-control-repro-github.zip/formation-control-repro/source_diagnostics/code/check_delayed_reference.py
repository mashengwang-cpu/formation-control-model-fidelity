"""Independent dense-output DOP853 method of steps, actuation delays only.

Uses a matrix form of the control law, independently of verify_source.command.
This is a finite-horizon integration cross-check, not physical validation.
"""
import json
import numpy as np
from scipy.integrate import solve_ivp
import verify_source as v

def run_ref(y0,c,delays,horizon,tol):
    A=np.zeros((8,8))
    for i in range(8): A[i,(i-1)%8]=A[i,(i+1)%8]=1
    B=np.diag([1,0,1,0,1,0,1,0]);H=2*np.eye(8)+B-A
    ends=[];sols=[]
    def controller(y,t):
        q,vel=y[:27].reshape(9,3),y[27:54].reshape(9,3)
        e=q[8]-q[:8];ev=vel[8]-vel[:8];eta=H@e;etav=H@ev
        raw=25*etav+501*eta+20*B@ev+101*B@e+y[54:].reshape(8,3)
        g=np.column_stack((1-c[:,6]*np.cos(t),1-c[:,7]*np.sin(t),1-c[:,8]*np.cos(t)*np.sin(t)))
        return raw/g,2535*eta+50*np.sign(etav+10*eta)
    def rhs(t,y):
        _,idot=controller(y,t);u=np.zeros((8,3))
        for i in range(8):
            lag=t-delays[i]
            if lag>=0:
                past=y0 if lag==0 else sols[min(np.searchsorted(ends,lag,side='left'),len(sols)-1)](lag)
                u[i]=controller(past,lag)[0][i]
        q=y[:27].reshape(9,3);vv=y[27:54].reshape(9,3)
        f=np.column_stack((c[:,0]*(q[:8,1]-q[:8,2])+c[:,1]*np.tanh(vv[:8,0]*t),c[:,2]*(q[:8,2]-q[:8,0])+c[:,3]*np.tanh(vv[:8,1]*t),c[:,4]*(q[:8,0]-q[:8,1])+c[:,5]*np.tanh(vv[:8,2]*t)))
        g=np.column_stack((1-c[:,6]*np.cos(t),1-c[:,7]*np.sin(t),1-c[:,8]*np.cos(t)*np.sin(t)))
        dist=np.column_stack((c[:,9]*np.cos(t),c[:,10]*np.sin(t),c[:,11]*np.cos(t)*np.sin(t)))
        x,yy,z=q[8];vx,vy,vz=vv[8]
        leader=np.array([np.sin(x)-np.cos(yy*vx),np.cos(z*vy)-np.sin(x),-np.sin(yy*vz)-np.sin(z)])
        return np.r_[vv.ravel(),np.vstack((f+g*u+dist,leader)).ravel(),idot.ravel()]
    grid=np.unique(np.r_[np.arange(0,horizon,.001),delays[delays<horizon],horizon]);y=y0
    for begin,end in zip(grid,grid[1:]):
        sol=solve_ivp(rhs,(begin,end),y,method='DOP853',dense_output=True,rtol=tol,atol=tol*.1,max_step=.00025)
        assert sol.success
        y=sol.y[:,-1];ends.append(end);sols.append(sol.sol)
    return y

def main():
    y,c,d,nz=v.initial_draw(29000,.2)
    ref=run_ref(y,c,d[:,1],.2,1e-10);print('First reference complete',flush=True)
    tight=run_ref(y,c,d[:,1],.2,1e-11);print('Tight reference complete',flush=True)
    np.savez_compressed(v.ROOT/'reports/delayed_reference_endpoints.npz',reference=ref,tight=tight)
    errs=[]
    for h in [.0005,.00025,.000125,.0000625,.00003125,.000015625,.0000078125,.00000390625]:
        ys,_,status=v.simulate(y,c,d*np.array([0,1,0])[None,:],np.zeros_like(nz),h,.2,False)
        assert status==0
        errs.append({'step':h,'position_max_error_m':float(np.max(np.abs(ys[-1,:27]-tight[:27]))),'relative_full_state_error':float(np.max(np.abs(ys[-1]-tight)/(1+np.abs(tight))))})
    result={'horizon_s':.2,'seed':29000,'reference_tightening_position_difference_m':float(np.max(np.abs(ref[:27]-tight[:27]))),'fixed_step_comparison':errs,'scope':'actuation-only delay, all agents, dense-output independent matrix control'}
    (v.ROOT/'reports/delayed_reference_check.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result),flush=True)
    assert errs[-1]['position_max_error_m']<.002

if __name__=='__main__':main()
