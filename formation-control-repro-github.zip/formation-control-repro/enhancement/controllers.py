"""Controller equations; the deployment layer applies physical input limits.

RISE: Nino et al., doi:10.1109/LCSYS.2025.3576068, equations (3)--(8).
The other methods reproduce the periodic-refresh path of the frozen modular
controller. Their signed powers retain its 1e-9 numerical offset. RISE uses
the exact componentwise sign function and an unclipped integral state.
"""
import numpy as np
from numba import njit

METHODS = ("minimal", "family", "full", "rise")
PARAM_NAMES = ("kp", "kv", "schedule_gain", "schedule_boundary", "schedule_cap",
               "adaptation_gain", "adaptation_leak", "filter_gain", "filter_leak",
               "finite_gain", "fixed_gain", "k1", "k2", "k3", "k4")
DEFAULT = np.array([2.15, 2.05, .45, .35, 3., .18, .02, .7, .25, .6, .25,
                    10., 10., 25., 50.])
# Method indices: 0 Minimal, 1 Family, 2 Full, 3 RISE; deletions 4--10.
METHOD_INDEX = {name: i for i, name in enumerate(METHODS)}
METHOD_INDEX.update(no_schedule=4, no_powers=5, no_approximation=6,
                    no_filter=7, no_faultcomp=8, no_topology=9, ppt_on=10)


def parameter_indices(method):
    if method == "rise":
        return [11, 12, 13, 14]
    if method == "minimal":
        return [0, 1]
    base = [0, 1, 5, 6, 7, 8, 9, 10]
    return base + ([2, 3, 4] if method == "full" else [])


def ring(n, weight=.35):
    """Undirected cycle, all followers pinned to the leader (b_i=1)."""
    if n < 3:
        raise ValueError("The cycle requires at least three followers")
    adjacency = np.zeros((n, n))
    for i in range(n):
        adjacency[i, (i + 1) % n] = weight
        adjacency[(i + 1) % n, i] = weight
    return adjacency, np.ones(n)


@njit(cache=True)
def rise_equations(q, qdot, leader_q, leader_v, adjacency, pinning, integral,
                   gains, gplus):
    """Return Eq. (7), Eq. (8), e and eta, before any deployment saturation.

    q is the offset-transformed raw position; gplus has shape (N,m,d).
    No pre-mixed or degree-normalized error is accepted by this interface.
    """
    k1, k2, k3, k4 = gains
    e = leader_q - q
    edot = leader_v - qdot
    eta = pinning[:, None] * e
    etadot = pinning[:, None] * edot
    for i in range(q.shape[0]):
        for j in range(q.shape[0]):
            eta[i] += adjacency[i, j] * (q[j] - q[i])
            etadot[i] += adjacency[i, j] * (qdot[j] - qdot[i])
    command = np.zeros((q.shape[0], gplus.shape[1]))
    for i in range(q.shape[0]):
        virtual = (k3 * etadot[i] + ((k1 + k2) * k3 + 1.) * eta[i]
                   + (k1 + k2) * pinning[i] * edot[i]
                   + (1. + k1 * k2) * pinning[i] * e[i] + integral[i])
        command[i] = gplus[i] @ virtual
    derivative = ((k1 + (1. + k1 * k2) * k3) * eta
                  + k4 * np.sign(etadot + k1 * eta))
    return command, derivative, e, eta


@njit(cache=True)
def periodic_control(method, parameters, time, dt, q, velocity, leader_q,
                     leader_v, adjacency, pinning, gplus, weights, error_filter,
                     rise_integral):
    """One outer-clock update. All internal states are logged without clipping.

    Internal RISE integral uses left-endpoint Euler at the controller clock,
    not at a physics substep. This is a sampled implementation of the law.
    """
    n = q.shape[0]
    if method == 3:
        raw, derivative, _, _ = rise_equations(q, velocity, leader_q, leader_v,
            adjacency, pinning, rise_integral, parameters[11:15], gplus)
        rise_integral += dt * derivative
        return raw
    error = q - leader_q
    velocity_error = velocity - leader_v
    network = error.copy()
    if method != 9:
        for i in range(n):
            total = pinning[i] * error[i]
            degree = pinning[i]
            for j in range(n):
                total += adjacency[i, j] * (error[i] - error[j])
                degree += adjacency[i, j]
            # Same error mixture as the frozen source; velocity stays raw.
            network[i] = .65 * error[i] + .35 * total / degree
    transformed = network.copy()
    if method == 1 or method == 10:
        bound = 1. + .6 * np.exp(-3. * min(max(time, 0.), 5.) / 5.)
        z = np.minimum(.98, np.maximum(-.98, network / bound))
        transformed = .5 * np.log((1. + z) / (1. - z))
    scheduled = method >= 2 and method != 4
    gain = parameters[0]
    if scheduled:
        gain *= min(parameters[4], 1. + parameters[2] /
                    (max(5. - time, 0.) + parameters[3]))
    raw = -gain * transformed - parameters[1] * velocity_error
    if method != 0 and method != 5:
        p1, p2 = (.62, 1.42) if method == 1 else (.60, 1.45)
        raw -= parameters[9] * np.sign(transformed) * (np.abs(transformed) + 1e-9)**p1
        raw -= parameters[10] * np.sign(transformed) * (np.abs(transformed) + 1e-9)**p2
    for i in range(n):
        if method != 0 and method != 6:
            basis = np.array([1., transformed[i, 0], transformed[i, 1],
                              velocity_error[i, 0], velocity_error[i, 1],
                              np.sqrt(np.sum(transformed[i]**2)),
                              np.sqrt(np.sum(velocity_error[i]**2))])
            for k in range(7):
                raw[i] -= weights[i, k] * basis[k]
                weights[i, k] += dt * (parameters[5] * basis[k] * transformed[i]
                                        - parameters[6] * weights[i, k])
        if method != 0 and method != 7:
            error_filter[i] += dt * (parameters[7] * transformed[i]
                                    - parameters[8] * error_filter[i])
            raw[i] -= error_filter[i]
    return raw
