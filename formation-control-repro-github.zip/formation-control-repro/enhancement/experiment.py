"""Three-clock experiments. Seeds affect initial conditions, never parameters."""
from dataclasses import dataclass, asdict
import time
import numpy as np
from numba import njit
from .controllers import periodic_control, DEFAULT, METHOD_INDEX, ring
from .physics import (world_observation, inner_commands, rk4_step, rhs,
                      rotation, euler_angles)
from .otter_adapter import make_boat

# Bump when a compiled dependency changes: Numba's disk cache does not track
# changes to imported functions transitively.
ENGINE_REVISION = 2


@dataclass(frozen=True)
class Job:
    platform: str = "native"
    model: str = "point"
    method: str = "minimal"
    seed: int = 39000
    trajectory: str = "straight"
    current: float = 0.
    stage: str = "numerical"
    candidate: int = 0
    outer_dt: float = .02
    inner_dt: float = .00125
    physics_dt: float = .00125
    duration: float = 16.
    response_scale: float = 1.
    disturbance_scale: float = 1.


TRAJECTORIES = ("straight", "arc", "ellipse", "double_sine", "speed_line")


def reference(times, name, platform, phase):
    """Analytic positions and derivatives; phase is a paired seed variable."""
    t = np.asarray(times)
    scale = 1. if platform == "native" else 4.
    speed = .55 if platform == "native" else .65
    if name == "straight":
        p = np.column_stack([speed*t, .12*scale*np.sin(.12*t+phase)])
        v = np.column_stack([np.full(len(t), speed), .0144*scale*np.cos(.12*t+phase)])
    elif name == "arc":
        radius = 12.*scale
        omega = speed/radius
        angle = omega*t + .15*np.sin(phase)
        p = np.column_stack([radius*np.sin(angle), radius*(1-np.cos(angle))])
        v = np.column_stack([speed*np.cos(angle), speed*np.sin(angle)])
    elif name == "ellipse":
        a, b = 8.*scale, 4.*scale
        omega = speed/a
        angle = omega*t + phase
        p = np.column_stack([a*np.sin(angle), b*np.cos(angle)])
        v = np.column_stack([a*omega*np.cos(angle), -b*omega*np.sin(angle)])
    elif name == "double_sine":
        p = np.column_stack([speed*t, scale*(.8*np.sin(.09*t+phase)+.25*np.sin(.23*t+.3*phase))])
        v = np.column_stack([np.full(len(t), speed),
                             scale*(.072*np.cos(.09*t+phase)+.0575*np.cos(.23*t+.3*phase))])
    elif name == "speed_line":
        p = np.column_stack([speed*t+.18/.11*(np.sin(.11*t+phase)-np.sin(phase)), np.zeros(len(t))])
        v = np.column_stack([speed+.18*np.cos(.11*t+phase), np.zeros(len(t))])
    else:
        raise ValueError(name)
    p -= p[0]
    return np.ascontiguousarray(p), np.ascontiguousarray(v)


def prepare(job):
    for interval in [job.outer_dt/job.inner_dt, job.inner_dt/job.physics_dt, job.duration/job.outer_dt]:
        if abs(interval-round(interval)) > 1e-8 or interval < 1:
            raise ValueError("Clocks must have exact integer ratios, with physics <= inner <= outer")
    if job.stage not in {"fixture", "numerical", "train", "validation", "test", "benchmark"}:
        raise ValueError(job.stage)
    platform = 0 if job.platform == "native" else 1
    if job.platform not in {"native", "otter"}:
        raise ValueError(job.platform)
    n = 8 if platform == 0 else 4
    model = ("point", "lag", "rigid").index(job.model)
    original, boat = make_boat(job.current)
    times = np.arange(round(job.duration/job.outer_dt)+1)*job.outer_dt
    rng = np.random.default_rng(job.seed)
    phase = rng.uniform(-np.pi, np.pi)
    lp, lv = reference(times, job.trajectory, job.platform, phase)
    spacing = 1.2 if platform == 0 else 6.
    offsets = np.array([[-spacing*(i//2+1), spacing*(-.5 if i%2==0 else .5)] for i in range(n)])
    state = np.zeros((n, 15))
    state[:, :2] = lp[0]+offsets+rng.normal(0., .25 if platform==0 else .6, (n, 2))
    state[:, 6] = 1.
    masses = np.array([1. if i<4 else 1.35 for i in range(n)]) if platform==0 else np.full(n, original.M[0, 0])
    initial_velocity = lv[0]+rng.normal(0., .05 if platform==0 else .025, (n, 2))
    for i in range(n):
        state[i, 3:5] = initial_velocity[i]
        if platform == 0 and i < 4:
            state[i, 2] = 1.5
        elif model == 2:
            heading = np.arctan2(initial_velocity[i, 1], initial_velocity[i, 0])
            state[i, 6], state[i, 9] = np.cos(heading/2), np.sin(heading/2)
            state[i, 3:6] = rotation(state[i, 6:10]).T@np.array([*initial_velocity[i], 0.])
    # Common physical starting state for every candidate and control method.
    # Otter starts at the upstream eta_z/roll/pitch=0; payload settling is retained.
    adjacency, pinning = ring(n)
    length_scale, time_scale = (1., 1.) if platform==0 else (6., 6.)
    force_scale = 1. if platform==0 else original.M[0, 0]*length_scale/time_scale**2
    gplus = np.zeros((n, 2, 2))
    for i in range(n):
        gplus[i] = np.eye(2)*(masses[i] if platform==0 else 1.)
    return (state, times, lp, lv, offsets, masses, boat, adjacency, pinning,
            gplus, platform, model, phase, length_scale, time_scale, force_scale)


@njit(cache=True)
def run_core(state, times, lp, lv, offsets, masses, boat, adjacency, pinning,
             gplus, platform, model, phase, length_scale, time_scale, force_scale,
             method, parameters, outer_dt, inner_dt, h, response_scale,
             disturbance_scale, detailed):
    samples, n = len(times), len(state)
    errors = np.full((samples, n), np.nan)
    requested = np.full((samples-1, n, 2), np.nan)
    actual_force = np.full_like(requested, np.nan)
    impulse = np.full_like(requested, np.nan)
    effort = np.full((samples-1, n), np.nan)
    moment_effort = np.full_like(effort, np.nan)
    saturation = np.full((samples-1, n, 2), np.nan)
    internal_norm = np.full((samples, n, 3), np.nan)
    internal_state = np.full((samples, n, 18), np.nan)
    states = np.full((samples if detailed else 2, n, 15), np.nan)
    states[0] = state
    weights = np.zeros((n, 7, 2))
    error_filter = np.zeros((n, 2))
    integral = np.zeros((n, 2))
    physical_events = np.zeros((n, 3), np.int64)
    event_previous = np.zeros((n, 3), np.bool_)
    substeps = int(round(outer_dt/h))
    inner_ratio = int(round(inner_dt/h))
    completed = 0
    failure = 0
    controller_cpu_placeholder = 0.
    for k in range(samples):
        position, velocity = world_observation(state, platform, model)
        error = position-lp[k]-offsets
        errors[k] = np.sqrt(np.sum(error*error, axis=1))
        for i in range(n):
            internal_state[k, i, :14] = weights[i].reshape(14)
            internal_state[k, i, 14:16] = error_filter[i]
            internal_state[k, i, 16:18] = integral[i]
            internal_norm[k, i, 0] = np.sqrt(np.sum(weights[i]*weights[i]))
            internal_norm[k, i, 1] = np.sqrt(np.sum(error_filter[i]*error_filter[i]))
            internal_norm[k, i, 2] = np.sqrt(np.sum(integral[i]*integral[i]))
        if detailed:
            states[k] = state
        if k == samples-1:
            break
        raw = periodic_control(method, parameters, times[k]/time_scale, outer_dt/time_scale,
            (position-offsets)/length_scale, velocity*time_scale/length_scale,
            lp[k]/length_scale, lv[k]*time_scale/length_scale, adjacency, pinning,
            gplus, weights, error_filter, integral)*force_scale
        requested[k] = raw
        if not (np.all(np.isfinite(raw)) and np.all(np.isfinite(weights))
                and np.all(np.isfinite(error_filter)) and np.all(np.isfinite(integral))):
            failure = 1
            break
        command = raw.copy()
        outer_sat = np.zeros(n)
        for i in range(n):
            norm = np.sqrt(np.sum(command[i]*command[i]))
            if norm > 8.*force_scale:
                command[i] *= 8.*force_scale/norm
                outer_sat[i] = 1.
        total_effort, total_moment = np.zeros(n), np.zeros(n)
        total_impulse = np.zeros((n, 2))
        allocation_duration = np.zeros(n)
        held, inner_sat = inner_commands(state, command, platform, model, masses, boat, response_scale)
        _, actual_force[k], _ = rhs(state, held, times[k], platform, model, masses, boat, phase, disturbance_scale)
        for substep in range(substeps):
            if substep % inner_ratio == 0 and substep != 0:
                held, inner_sat = inner_commands(state, command, platform, model, masses, boat, response_scale)
            state, e, m, f = rk4_step(state, held, times[k]+substep*h, h,
                platform, model, masses, boat, phase, disturbance_scale)
            total_effort += e
            total_moment += m
            total_impulse += f
            allocation_duration += h*inner_sat
            if not np.all(np.isfinite(state)):
                failure = 2
                break
            if model == 2:
                for i in range(n):
                    flags = np.zeros(3, np.bool_)
                    if platform == 0 and i < 4:
                        flags[0] = state[i, 2] < 0.
                    flags[1] = rotation(state[i, 6:10])[2, 2] < 0.
                    # A diagnostic domain flag, never a replacement endpoint.
                    flags[2] = np.sqrt(np.sum(state[i, 3:6]**2)) > (20. if platform==0 else 6*.5144)
                    for flag in range(3):
                        if flags[flag] and not event_previous[i, flag]:
                            physical_events[i, flag] += 1
                        event_previous[i, flag] = flags[flag]
        if failure:
            break
        effort[k], moment_effort[k], impulse[k] = total_effort, total_moment, total_impulse
        saturation[k, :, 0] = outer_sat*outer_dt
        saturation[k, :, 1] = allocation_duration
        completed = k+1
    if not detailed:
        states[1] = state
    return (errors, requested, actual_force, impulse, effort, moment_effort,
            saturation, internal_norm, states, weights, error_filter, integral,
            physical_events, completed, failure, internal_state)


def run(job, parameters=None, detailed=False):
    parameters = DEFAULT.copy() if parameters is None else np.asarray(parameters, dtype=float)
    if parameters.shape != DEFAULT.shape or not np.all(np.isfinite(parameters)) or np.any(parameters<=0):
        raise ValueError("Invalid positive controller parameters")
    data = prepare(job)
    started_cpu, started_wall = time.process_time(), time.perf_counter()
    result = run_core(*data, METHOD_INDEX[job.method], parameters, job.outer_dt,
                     job.inner_dt, job.physics_dt, job.response_scale,
                     job.disturbance_scale, detailed)
    cpu, wall = time.process_time()-started_cpu, time.perf_counter()-started_wall
    names = ("error_norm", "requested_force", "actual_force_at_outer", "actual_impulse",
             "actual_force_squared_integral", "actual_moment_squared_integral",
             "saturation_duration", "internal_state_norm", "physical_state",
             "final_weights", "final_error_filter", "final_rise_integral", "physical_events")
    arrays = dict(zip(names, result[:13]))
    arrays["internal_state"] = result[15]
    arrays["time"] = data[1]
    completed, failure = int(result[13]), int(result[14])
    full = failure==0 and completed==len(data[1])-1
    j = float(np.trapezoid(np.mean(arrays["error_norm"], axis=1), data[1])/job.duration) if full else None
    metrics = {"J_m": j, "force_effort_N2s": float(np.sum(arrays["actual_force_squared_integral"])) if full else None,
               "moment_effort_N2m2s": float(np.sum(arrays["actual_moment_squared_integral"])) if full else None,
               "completed_intervals": completed, "designed_intervals": len(data[1])-1,
               "failure": ("none", "nonfinite_controller", "nonfinite_physics")[failure],
               "complete": full, "cpu_seconds": cpu, "wall_seconds": wall,
               "outer_updates": completed, "inner_updates": completed*round(job.outer_dt/job.inner_dt),
               "physics_steps": completed*round(job.outer_dt/job.physics_dt),
               "event_counts": arrays["physical_events"].tolist()}
    return metrics, arrays


if __name__ == "__main__":
    import argparse, json
    parser = argparse.ArgumentParser()
    parser.add_argument("--platform", default="native")
    parser.add_argument("--model", default="rigid")
    parser.add_argument("--method", default="minimal")
    parser.add_argument("--duration", type=float, default=1.)
    args = parser.parse_args()
    independent = args.platform == "otter"
    job = Job(platform=args.platform, model=args.model, method=args.method, duration=args.duration,
              outer_dt=.05 if independent else .02, inner_dt=.01 if independent else .00125,
              physics_dt=.0025 if independent else .00125)
    # First invocation includes compilation; a second run measures steady state.
    run(job)
    metrics, _ = run(job)
    print(json.dumps(metrics))
