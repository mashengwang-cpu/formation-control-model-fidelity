"""Replay nine frozen native tasks and compare every stored trajectory array.

The default set is nominal seed 1000, all three main methods and all three
plant models. This is a deterministic representative check, not a rerun of the
complete experiment. Only computation time is excluded from metric equality.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'simulation'))
from run_revision import run_one
from verify_native import equivalent, sha256, TOL
import numpy as np
import pandas as pd


def replay(payload):
    data, output, row = payload
    saved_path = data / 'jobs' / f"{row['job_id']}.json"
    saved = json.loads(saved_path.read_text(encoding='utf-8'))
    replay_row = {'job_id': row['job_id'], 'job': saved['job'], 'simulation_overrides': {}}
    _, status, elapsed = run_one((replay_row, saved['configuration'], str(output), saved['provenance_id']))
    new_path = output / 'jobs' / f"{row['job_id']}.json"
    new = json.loads(new_path.read_text(encoding='utf-8'))
    report = dict(job_id=row['job_id'], arm_id=row['arm_id'], plant_model=row['job']['plant_model'],
                  seed=row['job']['seed'], scenario=row['job']['scenario'], status=status,
                  elapsed_wall_s=elapsed, errors=[], array_checks=[], metric_checks=0)
    if status != 'ok':
        report['errors'].append('Replay execution failed; see saved diagnostic job record')
        return report
    saved_trace = data / saved['trajectory'].replace('\\', '/')
    new_trace = output / new['trajectory'].replace('\\', '/')
    report['reference_trajectory_hash_ok'] = sha256(saved_trace) == saved['trajectory_sha256']
    if not report['reference_trajectory_hash_ok']:
        report['errors'].append('reference_trajectory_hash')
    with np.load(saved_trace, allow_pickle=False) as reference, np.load(new_trace, allow_pickle=False) as actual:
        if set(reference.files) != set(actual.files):
            report['errors'].append('array_inventory')
        for key in sorted(set(reference.files) & set(actual.files)):
            left, right = reference[key], actual[key]
            same_shape = left.shape == right.shape
            numeric_equal = same_shape and np.allclose(left, right, rtol=TOL, atol=TOL)
            difference = float(np.max(np.abs(left.astype(float) - right.astype(float)))) if same_shape and left.size else 0.0
            report['array_checks'].append(dict(array=key, shape=list(left.shape), same_shape=same_shape,
                                               max_abs_difference=difference, pass_tolerance=bool(numeric_equal)))
            if not numeric_equal:
                report['errors'].append('array:' + key)
    for key, value in saved['metrics'].items():
        if key == 'computation_time':
            continue
        report['metric_checks'] += 1
        if key not in new['metrics'] or not equivalent(new['metrics'][key], value):
            report['errors'].append('metric:' + key)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=ROOT / 'data/native')
    parser.add_argument('--output', type=Path, default=ROOT / 'results/native_replay')
    parser.add_argument('--workers', type=int, default=3)
    args = parser.parse_args()
    data = args.data.resolve(strict=True)
    output = args.output.resolve()
    if output.is_relative_to(data) or output == ROOT:
        raise ValueError('Use a separate output directory; evidence is read-only')
    if (output / 'jobs').exists() or (output / 'traces').exists():
        raise FileExistsError('Use a new replay output directory; existing evidence is never replaced')
    for folder in (output, output / 'jobs', output / 'traces'):
        folder.mkdir(parents=True, exist_ok=True)
    design = json.loads((data / 'design.json').read_text(encoding='utf-8'))
    chosen = [row for row in design if row['campaign'] == 'core_fixed'
              and row['job']['seed'] == 1000 and row['job']['scenario'] == 'nominal']
    assert len(chosen) == 9 and len({row['job_id'] for row in chosen}) == 9
    (output / 'selected_design.json').write_text(json.dumps(chosen, indent=2), encoding='utf-8')
    start = time.perf_counter()
    reports = []
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        for report in executor.map(replay, [(data, output, row) for row in chosen]):
            reports.append(report)
            print(report['plant_model'], report['arm_id'], 'PASS' if not report['errors'] else report['errors'], flush=True)
    arrays = [dict(job_id=r['job_id'], plant_model=r['plant_model'], arm_id=r['arm_id'], **item)
              for r in reports for item in r['array_checks']]
    pd.DataFrame(arrays).to_csv(output / 'replay_array_comparison.csv', index=False)
    result = dict(status='PASS' if all(not r['errors'] for r in reports) else 'FAIL',
                  representative_jobs=len(reports), trajectory_arrays_compared=len(arrays),
                  deterministic_metrics_compared=sum(r['metric_checks'] for r in reports),
                  array_max_abs_difference=max(r['max_abs_difference'] for r in arrays),
                  tolerance=dict(relative=TOL, absolute=TOL), excluded_metrics=['computation_time'],
                  full_experiment_rerun=False, elapsed_s=time.perf_counter()-start,
                  runner_sha256=sha256(ROOT / 'simulation/run_revision.py'), jobs=reports)
    (output / 'NATIVE_REPLAY.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({key: value for key, value in result.items() if key != 'jobs'}, indent=2))
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
