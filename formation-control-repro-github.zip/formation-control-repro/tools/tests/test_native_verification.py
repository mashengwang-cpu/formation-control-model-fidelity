"""Failure-injection checks against one packaged native evidence record."""
import copy
import json
from pathlib import Path
import shutil
import sys

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
from verify_native import inspect_job


@pytest.fixture(scope='module')
def reference():
    data = (ROOT / 'data/native').resolve()
    design = json.loads((data / 'design.json').read_text(encoding='utf-8'))[0]
    ledger = pd.read_csv(data / 'runs.csv')
    rows = ledger[ledger.job_id.eq(design['job_id'])].to_dict('records')
    provenance = json.loads((data / 'provenance.json').read_text(encoding='utf-8'))
    return data, design['job_id'], design, rows, provenance


def test_unmodified_reference_record_passes(reference):
    result = inspect_job(reference)
    assert result['errors'] == []
    assert result['ledger_metric_checks'] > 0
    assert result['raw_metric_checks'] >= 14


def test_metric_disagreement_in_expanded_ledger_is_detected(reference):
    data, job_id, design, rows, provenance = reference
    rows = copy.deepcopy(rows)
    rows[-1]['control_energy'] += 1
    result = inspect_job((data, job_id, design, rows, provenance))
    assert 'runs_metric:control_energy' in result['errors']


def copy_record(reference, tmp_path):
    data, job_id, design, rows, provenance = reference
    for folder in ('jobs', 'traces'):
        (tmp_path / folder).mkdir()
    record = json.loads((data / 'jobs' / f'{job_id}.json').read_text(encoding='utf-8'))
    shutil.copy2(data / 'traces' / f'{job_id}.npz', tmp_path / 'traces' / f'{job_id}.npz')
    return job_id, design, copy.deepcopy(rows), provenance, record


def test_shared_record_and_ledger_error_is_caught_by_raw_reconstruction(reference, tmp_path):
    job_id, design, rows, provenance, record = copy_record(reference, tmp_path)
    record['metrics']['formation_tracking_error'] += .01
    for row in rows:
        row['formation_tracking_error'] = record['metrics']['formation_tracking_error']
    (tmp_path / 'jobs' / f'{job_id}.json').write_text(json.dumps(record), encoding='utf-8')
    result = inspect_job((tmp_path.resolve(), job_id, design, rows, provenance))
    assert 'runs_metric:formation_tracking_error' not in result['errors']
    assert 'raw_metric:formation_tracking_error' in result['errors']


def test_valid_but_modified_force_array_is_detected(reference, tmp_path):
    job_id, design, rows, provenance, record = copy_record(reference, tmp_path)
    path = tmp_path / 'traces' / f'{job_id}.npz'
    with np.load(path, allow_pickle=False) as raw:
        arrays = {key: raw[key] for key in raw.files}
    arrays['controls'][5, 0, 0] += 1
    np.savez_compressed(path, **arrays)
    (tmp_path / 'jobs' / f'{job_id}.json').write_text(json.dumps(record), encoding='utf-8')
    result = inspect_job((tmp_path.resolve(), job_id, design, rows, provenance))
    assert 'trajectory_hash' in result['errors']
    assert 'raw_metric:control_energy' in result['errors']
