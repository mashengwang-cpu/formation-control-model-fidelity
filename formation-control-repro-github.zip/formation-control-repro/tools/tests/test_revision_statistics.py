from pathlib import Path
from copy import deepcopy
import importlib.util
import sys
import numpy as np
import pandas as pd
import pytest
from scipy import stats

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'simulation/src'))
sys.path.insert(0,str(ROOT/'tools'))
sys.path.insert(0,str(ROOT/'px4_interface'))
from finite_control_sim.statistics import paired_hodges_lehmann, bca_paired_ratio_ci, wilcoxon_r_from_z
import revision_stats
spec=importlib.util.spec_from_file_location('px4_revised_analysis',ROOT/'px4_interface/analysis.py')
px4=importlib.util.module_from_spec(spec);spec.loader.exec_module(px4)

def test_paired_hodges_lehmann_is_walsh_not_difference_median():
    values=np.array([-3.,-1.,4.,10.])
    assert paired_hodges_lehmann(values)==2.5
    assert paired_hodges_lehmann(values)!=np.median(values)

def test_wilcoxon_signed_r_corrects_tied_absolute_ranks():
    assert wilcoxon_r_from_z(np.array([-1.,-1.,2.,2.]))==pytest.approx(1/np.sqrt(7.25))
    assert wilcoxon_r_from_z(np.array([1.,1.,-2.,-2.]))==pytest.approx(-1/np.sqrt(7.25))

def test_paired_ratio_bca_resamples_denominator():
    x=np.array([.2,.3,.4,.5,.6,.7,.8,.9])
    y=np.array([.1,.1,.2,.2,.3,.3,.8,1.5])
    mean,lo,hi=bca_paired_ratio_ci(x,y,samples=20000,seed=1234)
    expected=stats.bootstrap((x,y),lambda a,b,axis:(np.mean(a,axis=axis)-np.mean(b,axis=axis))/np.mean(b,axis=axis),
                             paired=True,method='BCa',n_resamples=20000,random_state=1234)
    assert mean==pytest.approx((x.mean()-y.mean())/y.mean())
    assert lo==pytest.approx(expected.confidence_interval.low)
    assert hi==pytest.approx(expected.confidence_interval.high)
    with pytest.raises(ValueError): bca_paired_ratio_ci(x,y[:-1])

def synthetic_v21_agent(state_times, command_times, force, refresh, multiplier=1., agent_index=0, num_agents=1):
    """Independent synthetic streams with explicit v2.1 identities and counters."""
    epoch=100.
    state_times=np.asarray(state_times,dtype=float)
    command_times=np.asarray(command_times,dtype=float)
    refresh=np.asarray(refresh,dtype=int)
    n=len(command_times)
    commands=pd.DataFrame(dict(clock_gz_s=epoch+command_times,common_epoch_s=epoch,
                               ux_cmd=force,uy_cmd=0.,ux_applied=force,uy_applied=0.,event=refresh,
                               command_publish_count=np.arange(1,n+1),
                               measurement_refresh_count=np.cumsum(refresh)))
    errors=multiplier*(state_times+1)
    states=pd.DataFrame(dict(t=state_times,state_sample_s=epoch+state_times,
                            state_timestamp_s=epoch+state_times+.005,
                            clock_receipt_gz_s=epoch+state_times+.03,common_epoch_s=epoch,
                            err_x=errors,err_y=0.,err_norm=errors))
    records=[]
    for kind,times in [('command',command_times),('refresh',command_times[refresh==1]),
                       ('heartbeat',command_times),('mission_stop',[16.005])]:
        for count,t in enumerate(times,1):
            records.append(dict(event_type=kind,clock_gz_s=epoch+t,common_epoch_s=epoch,cumulative_count=count))
    events=pd.DataFrame(records).sort_values('clock_gz_s',kind='stable').reset_index(drop=True)
    for stream in [states,events]:
        stream.attrs.update(schema_version='px4-interface-v2.1',run_nonce='synthetic_statistics_fixture',
                            agent_index=agent_index)
    commands.attrs.update(schema_version='px4-interface-v2.1',run_nonce='synthetic_statistics_fixture',
                          agent_index=agent_index,num_agents=num_agents,state_stream=states,event_stream=events,
                          command_stop_gz_s=116.,stop_observed_gz_s=116.005,drain_complete='true',
                          final_command_publish_count=n,final_measurement_refresh_count=int(refresh.sum()),
                          final_offboard_heartbeat_count=n,raw_state_receipts=len(states),duplicate_state_samples=0,
                          out_of_order_state_samples=0,state_receipt_scope='valid_framed_DDS_samples_with_source_in_0_T')
    return commands


def test_v21_irregular_logs_integrate_each_vehicle_in_real_time():
    frames=[]
    for agent_index,(t,multiplier) in enumerate([(np.array([0.,4.,11.,16.]),1.),(np.array([0.,3.,9.,12.,16.]),2.)]):
        n=len(t)
        command_times=t.copy();command_times[-1]=15.99
        # The endpoint is a state observation. The last pre-stop command holds
        # the already sampled error and therefore produces no refresh event.
        refresh=np.ones(n,dtype=int);refresh[-1]=0
        frames.append(synthetic_v21_agent(t,command_times,np.full(n,2.),refresh,
                                          multiplier,agent_index,num_agents=2))
    result=px4.metrics_from_agent_logs(frames)
    assert result['J']==pytest.approx(13.5)
    assert result['control_energy']==pytest.approx(128.)
    assert result['protocol_window_complete']
    assert result['command_publish_count']==9
    assert result['event_trigger_count']==7
    truncated=deepcopy(frames)
    for frame in truncated:
        states=frame.attrs['state_stream']
        frame.attrs['state_stream']=states[states.t<16].copy()
        frame.attrs['raw_state_receipts']=len(frame.attrs['state_stream'])
    assert not px4.metrics_from_agent_logs(truncated)['protocol_window_complete']

def test_v21_command_effort_uses_publication_clock_and_zoh():
    t=np.array([0.,1.,2.,16.]);ct=np.array([.02,1.03,2.03])
    frame=synthetic_v21_agent(t,ct,[0.,2.,0.],[1,1,1])
    metrics=px4.metrics_from_agent_logs([frame])
    assert metrics['control_energy']==pytest.approx(4.)
    assert metrics['common_window_start_s']==pytest.approx(.02)
    assert metrics['event_trigger_count']==3
    # v2.1 rejects publications after the mission stop; it never silently
    # discards them while reporting a complete validated event stream.
    invalid=synthetic_v21_agent(t,[.02,1.03,2.03,16.02],[0.,2.,0.,10.],[1,1,1,1])
    with pytest.raises(ValueError,match='published within'):
        px4.metrics_from_agent_logs([invalid])

def test_missing_scenario_cannot_silently_change_seed_mean():
    rows=pd.DataFrame([dict(seed=s,scenario=q,status='ok',formation_tracking_error=1.)
                       for s in [1,2] for q in ['a','b']])
    with pytest.raises(ValueError):revision_stats.seed_blocks(rows.iloc[:-1],['a','b'],[1,2],'formation_tracking_error')
    failed=rows.copy();failed.loc[0,'status']='error'
    with pytest.raises(ValueError):revision_stats.seed_blocks(failed,['a','b'],[1,2],'formation_tracking_error')

def test_module_contrast_sign_is_on_minus_off_for_ppt_and_knockouts():
    rows=[];seeds=[1,2,3];plants=['matched_point_mass','matched_lagged','mixed_6dof_3dof']
    for i,plant in enumerate(plants):
        effect=-1.+i
        for seed in seeds:
            common=dict(campaign='module_ablation',plant_model=plant,seed=seed,scenario='nominal',status='ok')
            rows.append({**common,'arm_id':'full_no_ppt','module':'none','formation_tracking_error':10.+seed})
            for module in revision_stats.MODULES:
                rows.append({**common,'arm_id':'ppt_added' if module=='ppt' else 'ko_'+module,'module':module,
                             'formation_tracking_error':10.+seed+(effect if module=='ppt' else -effect)})
    plan={'plants':plants,'scenarios':['nominal'],'test_seeds':seeds}
    result=revision_stats.module_differences(pd.DataFrame(rows),plan)
    for module in revision_stats.MODULES:
        assert np.all(result[('matched_point_mass',module)]['effect']==-1.)
        assert np.all(result[('mixed_6dof_3dof',module)]['effect']==1.)


def test_px4_new_protocol_rejects_missing_whole_seed_and_technical_pilot():
    arms=[(px4.H1_REFERENCE,'causal'),(px4.H1_COMPARATOR,'causal')]
    rows=pd.DataFrame([dict(method=method,contract=contract,seed=seed,scenario=scenario,
                            status='ok',backend='px4',metrics_schema_version='px4-interface-v2.1',
                            num_agents=3,protocol_window_complete=True,event_streams_validated=True)
                       for method,contract in arms for seed in range(5000,5020) for scenario in px4.SCENARIOS])
    assert len(px4.require_complete_protocol(rows,arms))==200
    with pytest.raises(ValueError):px4.require_complete_protocol(rows[rows.seed!=5019],arms)
    pilot=rows.copy();pilot['seed']=pilot.seed-100
    with pytest.raises(ValueError):px4.require_complete_protocol(pilot,arms)
    with pytest.raises(ValueError):px4.require_complete_protocol(rows.assign(metrics_schema_version='px4-interface-v2'),arms)


def test_px4_effect_labels_use_walsh_and_signed_absolute_ranks():
    result=px4.paired_effect_labels(np.array([-3.,-1.,4.,10.]))
    assert result['hodges_lehmann_walsh']==2.5
    assert result['median_difference']==1.5
    assert result['paired_rank_biserial']==pytest.approx(.4)
