"""Compare two full publication exports without normalizing away differences."""
import argparse
import hashlib
import json
from pathlib import Path


def compare(first,second):
    def inventory(folder):
        return {p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                for p in folder.rglob('*') if p.is_file() and
                (p.suffix in ['.pdf','.svg','.png'] or p.name.endswith('.plot_data.json'))}
    left,right=inventory(first),inventory(second)
    names=sorted(set(left)|set(right))
    differences=[{'path':name,'first_sha256':left.get(name),'second_sha256':right.get(name)}
                 for name in names if left.get(name)!=right.get(name)]
    images=[n for n in names if not n.endswith('.plot_data.json')]
    ledgers=[n for n in names if n.endswith('.plot_data.json')]
    manifests_equal=(first/'FIGURE_MANIFEST.json').read_bytes()==(second/'FIGURE_MANIFEST.json').read_bytes()
    return {'status':'PASS' if not differences and len(images)==111 and len(ledgers)==37 and manifests_equal else 'ISSUES',
            'comparison':'Byte-for-byte SHA-256 equality; no path, metadata, numeric or graphic field is ignored.',
            'image_format_files':len(images),'numeric_ledgers':len(ledgers),'manifest_bytes_identical':manifests_equal,
            'differences':differences,'files':[{'path':n,'sha256':left.get(n),'identical':left.get(n)==right.get(n)} for n in names]}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--first',type=Path,required=True)
    parser.add_argument('--second',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    if args.output.resolve().is_relative_to((root/'data').resolve()):
        raise ValueError('Write reports outside frozen data.')
    result=compare(args.first,args.second)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='files'},ensure_ascii=False,indent=2))
    raise SystemExit(0 if result['status']=='PASS' else 1)
