"""Audit frozen native arrays, all ledger metrics, design identity, and source hashes.

This reads the evidence without changing it. A finite trajectory is not proof of
flight success; raw altitude and attitude limits are assessed separately.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import zipfile

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TOL = 2e-12


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def equivalent(observed, expected):
    if expected is None:
        return bool(pd.isna(observed))
    if isinstance(expected, bool):
        return observed == expected
    if isinstance(expected, (int, float)):
        return bool(np.isfinite(observed) and np.isclose(observed, expected, rtol=TOL, atol=TOL))
    return observed == expected


def inspect_job(payload):
    data, job_id, design, ledger_rows, provenance = payload
    check = dict(job_id=job_id, status='missing_or_invalid', errors=[],
                 ledger_references=len(ledger_rows), ledger_metric_checks=0,
                 raw_metric_checks=0, raw_max_metric_abs_difference=0.0, array_count=0)
    try:
        path = data / 'jobs' / f'{job_id}.json'
        record = json.loads(path.read_text(encoding='utf-8'))
        check['record_sha256'] = sha256(path)
        check['status'] = record['status']
        if record['status'] != 'ok':
            check['errors'].append('execution_failed')
            return check
        if record['job_id'] != job_id or record['job'] != design['job']:
            check['errors'].append('job_identity')
        if record['provenance_id'] != provenance['provenance_id']:
            check['errors'].append('provenance_identity')
        config = json.loads(json.dumps(provenance['base_config']))
        config['simulation'].update(design['simulation_overrides'])
        if record['configuration'] != config:
            check['errors'].append('configuration_identity')
        for row in ledger_rows:
            for name, value in record['metrics'].items():
                check['ledger_metric_checks'] += 1
                if name not in row or not equivalent(row[name], value):
                    check['errors'].append('runs_metric:' + name)
            for name, value in record['job'].items():
                if name not in row or not equivalent(row[name], value):
                    check['errors'].append('runs_job:' + name)
            if row['status'] != record['status'] or row['provenance_id'] != record['provenance_id']:
                check['errors'].append('runs_status_or_provenance')
        trajectory = (data / record['trajectory'].replace('\\', '/')).resolve(strict=True)
        if not trajectory.is_relative_to(data) or trajectory != (data / 'traces' / f'{job_id}.npz').resolve():
            raise ValueError('Trajectory is outside the expected evidence path')
        check['trajectory_sha256'] = sha256(trajectory)
        if check['trajectory_sha256'] != record['trajectory_sha256']:
            check['errors'].append('trajectory_hash')
        with np.load(trajectory, allow_pickle=False) as raw:
            check['array_count'] = len(raw.files)
            arrays = {key: raw[key] for key in raw.files}
        if any(not np.isfinite(array).all() for array in arrays.values()):
            check['errors'].append('nonfinite_array')
        t = arrays['times']
        dt = np.diff(t)
        if (len(t) != 801 or not np.all(dt > 0) or not np.isclose(t[0], 0)
                or not np.isclose(t[-1], 16) or not np.allclose(dt, .02, rtol=TOL, atol=TOL)):
            check['errors'].append('time_domain')
        n_uav, n_usv = record['job']['uav_count'], record['job']['usv_count']
        n_agents = n_uav + n_usv
        for key in ('controls', 'actual_controls', 'physical_position_errors'):
            if arrays[key].shape != (len(t), n_agents, 2):
                check['errors'].append('array_shape:' + key)
        error = np.linalg.norm(arrays['physical_position_errors'], axis=2)
        if not np.allclose(error, arrays['tracking_errors'], rtol=TOL, atol=TOL):
            check['errors'].append('error_norm')
        mean_error = error.mean(axis=1)
        force = arrays['actual_force_interval_effort']
        yaw = arrays['usv_yaw_interval_effort']
        if (force < 0).any() or (yaw < 0).any():
            check['errors'].append('negative_interval_effort')
        if np.any(force[-1] != 0) or np.any(yaw[-1] != 0):
            check['errors'].append('terminal_interval_effort')
        duration = t[-1] - t[0]
        command_effort = np.sum(np.sum(arrays['controls'][:-1] ** 2, axis=(1, 2)) * dt)
        tracking = np.sum(.5 * (mean_error[:-1] + mean_error[1:]) * dt) / duration
        rebuilt = {
            'formation_tracking_error': tracking,
            'xy_formation_tracking_error': tracking,
            'control_energy': command_effort,
            'control_energy_per_agent_time': command_effort / (duration * n_agents),
            'actual_control_energy': force.sum(),
            'actual_uav_force_effort': force[:, :n_uav].sum(),
            'actual_usv_force_effort': force[:, n_uav:].sum(),
            'actual_usv_yaw_torque_effort': yaw.sum(),
            'event_trigger_count': arrays['trigger_events'][:-1].sum(),
            'command_evaluation_count': len(t) * n_agents,
            'plant_command_intervals': (len(t) - 1) * n_agents,
            'no_event_command_change_count': np.sum(
                (~arrays['trigger_events'][1:-1]) &
                (np.max(np.abs(arrays['controls'][1:-1] - arrays['controls'][:-2]), axis=2) > 1e-12)),
        }
        for name, start, stop in [('uav_tracking_error', 0, n_uav),
                                  ('usv_tracking_error', n_uav, n_agents)]:
            if stop > start:
                series = error[:, start:stop].mean(axis=1)
                rebuilt[name] = np.sum(.5 * (series[:-1] + series[1:]) * dt) / duration
        for name, value in rebuilt.items():
            check[name + '_abs_difference'] = float(abs(value - record['metrics'][name]))
            if not equivalent(value, record['metrics'][name]):
                check['errors'].append('raw_metric:' + name)
        check['raw_metric_checks'] = len(rebuilt)
        check['raw_max_metric_abs_difference'] = max(check[k] for k in check if k.endswith('_abs_difference'))
    except Exception as exc:
        check['errors'].append(f'{type(exc).__name__}: {exc}')
    check['errors'] = sorted(set(check['errors']))
    return check


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=ROOT / 'data/native')
    parser.add_argument('--output', type=Path, default=ROOT / 'results/native_verification')
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    data = args.data.resolve(strict=True)
    output = args.output.resolve()
    if output.is_relative_to(data) or output == ROOT:
        raise ValueError('Use a separate output directory; evidence is read-only')
    output.mkdir(parents=True, exist_ok=True)
    design = json.loads((data / 'design.json').read_text(encoding='utf-8'))
    provenance = json.loads((data / 'provenance.json').read_text(encoding='utf-8'))
    runs = pd.read_csv(data / 'runs.csv')
    plan = pd.read_csv(data / 'planned_jobs.csv')
    design_lookup = {r['design_id']: r for r in design}
    unique = {r['job_id']: r for r in design}
    checks = {}
    checks['expected_design_counts'] = len(design) == 8820 and len(unique) == 7620
    checks['design_hash'] = digest(design) == provenance['design_sha256']
    checks['design_ids_unique'] = len(design_lookup) == len(design)
    checks['job_content_hashes'] = all(digest({'job': r['job'], 'simulation': r['simulation_overrides']})[:24]
                                         == r['job_id'] for r in design)
    checks['runs_design_identity'] = (len(runs) == len(design) and not runs.design_id.duplicated().any()
                                     and set(runs.design_id) == set(design_lookup))
    checks['planned_design_identity'] = (len(plan) == len(design) and not plan.design_id.duplicated().any()
                                        and set(plan.design_id) == set(design_lookup))
    for label, frame in [('runs', runs), ('planned', plan)]:
        checks[label + '_design_metadata'] = all(
            all(equivalent(row.get(key), value) for key, value in design_lookup.get(row['design_id'], {}).items()
                if key not in ('job', 'simulation_overrides'))
            for row in frame.to_dict('records'))
    checks['job_inventory'] = {p.stem for p in (data / 'jobs').glob('*.json')} == set(unique)
    checks['trace_inventory'] = {p.stem for p in (data / 'traces').glob('*.npz')} == set(unique)
    checks['run_job_inventory'] = set(runs.job_id) == set(unique)
    source_checks = []
    with zipfile.ZipFile(data / 'source_snapshot.zip') as archive:
        checks['source_snapshot_inventory'] = set(archive.namelist()) == set(provenance['source'])
        for relative, expected in provenance['source'].items():
            source_path = (ROOT / relative).resolve()
            if not source_path.is_relative_to(ROOT):
                raise ValueError('Source manifest path escapes the package')
            source_checks.append(dict(path=relative, expected_sha256=expected,
                                      snapshot_ok=hashlib.sha256(archive.read(relative)).hexdigest() == expected,
                                      live_ok=source_path.is_file() and sha256(source_path) == expected))
    checks['source_snapshot_hashes'] = all(r['snapshot_ok'] for r in source_checks)
    checks['live_simulation_source_unchanged'] = all(r['live_ok'] for r in source_checks)
    ledger = {job_id: frame.to_dict('records') for job_id, frame in runs.groupby('job_id', sort=False)}
    payloads = [(data, job_id, row, ledger.get(job_id, []), provenance) for job_id, row in unique.items()]
    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        for i, check in enumerate(executor.map(inspect_job, payloads), 1):
            results.append(check)
            if i % 1000 == 0 or i == len(payloads):
                print(f'Inspected {i}/{len(payloads)} unique native trajectories', flush=True)
    frame = pd.DataFrame(results)
    frame['errors'] = frame['errors'].map(lambda value: ';'.join(value))
    frame.to_csv(output / 'native_raw_ledger_verification.csv', index=False)
    pd.DataFrame(source_checks).to_csv(output / 'native_source_verification.csv', index=False)
    checks['raw_and_ledger_checks'] = bool(frame.errors.eq('').all())
    report = dict(status='PASS' if all(checks.values()) else 'FAIL', unique_jobs=len(unique),
                  verification_script_sha256=sha256(Path(__file__).resolve()),
                  design_references=len(design), completed_finite_jobs=int(frame.status.eq('ok').sum()),
                  raw_metric_checks=int(frame.raw_metric_checks.fillna(0).sum()),
                  ledger_metric_checks=int(frame.ledger_metric_checks.sum()),
                  checked_source_files=len(source_checks), checks=checks,
                  raw_max_metric_abs_difference=float(frame.raw_max_metric_abs_difference.max()),
                  tolerance=dict(relative=TOL, absolute=TOL),
                  flight_success_not_implied=True,
                  evidence_hashes={name: sha256(data / name) for name in
                                   ('design.json', 'planned_jobs.csv', 'runs.csv', 'provenance.json', 'source_snapshot.zip')})
    (output / 'NATIVE_VERIFICATION.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
