"""Export the exact plotted estimates and interval endpoints as a reading table."""
from pathlib import Path
import argparse,csv,json
from verify_figure_data import EXPECTED
ROOT=Path(__file__).resolve().parents[1]

def export(folder,output):
    if output.resolve().is_relative_to((ROOT/'data').resolve()):
        raise ValueError('Do not write into frozen input data.')
    rows=[]
    for path in sorted(folder.glob('*.plot_data.json')):
        data=json.loads(path.read_text(encoding='utf-8'))
        for ax in data['axes']:
            for n,r in enumerate(q for q in ax['records'] if q['type']=='estimate_interval'):
                source=r.get('source_row',{})
                rows.append(dict(figure=data['figure'],panel=ax['panel'],estimate_index=n+1,
                    axis='x' if r['horizontal'] else 'y',position=r['position'],
                    mean=r['mean'],bca95_low=r['low'],bca95_high=r['high'],
                    marker_filled=r['solid'],
                    **{k:source.get(k,'') for k in ['metric','campaign','plant_model','condition','plotted_arm','module','contrast']},
                    source_row_json=json.dumps(source,ensure_ascii=False,sort_keys=True)))
    expected=sum(sum(counts) for counts in EXPECTED.values())
    if len(rows)!=expected:raise ValueError(f'Expected all {expected} plotted intervals; found {len(rows)}')
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    with output.open(encoding='utf-8-sig',newline='') as f:back=list(csv.DictReader(f))
    assert all(float(a[k])==b[k] for a,b in zip(back,rows) for k in ['position','mean','bca95_low','bca95_high'])
    print(f'Exported {len(rows)} exact estimates and intervals; numeric CSV round trip verified.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=ROOT/'figures')
    parser.add_argument('--output',type=Path,default=ROOT/'figures/ESTIMATES_AND_INTERVALS.csv')
    args=parser.parse_args();export(args.input,args.output)
