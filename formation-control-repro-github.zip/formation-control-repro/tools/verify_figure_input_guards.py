"""Exercise malformed figure inputs on in-memory copies of frozen records."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import publication_figures as figures
import publication_style as style

ROOT=Path(__file__).resolve().parents[1]


def audit(work):
    checks=[]
    original=figures.RAW
    core=original[original.campaign.eq('core_fixed')]
    row=core.index[0]

    def rejection(name,call):
        try:
            call()
        except (ValueError,KeyError,TypeError) as error:
            checks.append({'check':name,'passed':True,'observed':type(error).__name__+': '+str(error)})
        except Exception as error:
            checks.append({'check':name,'passed':False,'observed':'Unexpected '+type(error).__name__+': '+str(error)})
        else:
            checks.append({'check':name,'passed':False,'observed':'Malformed input was accepted'})
        finally:
            plt.close('all')

    def native(case,mutate):
        altered=mutate(original.copy(deep=True))
        try:
            figures.RAW=altered
            rejection(case,lambda:figures.blocks('core_fixed'))
        finally:
            figures.RAW=original

    def setcell(frame,column,value):
        frame.loc[row,column]=value
        return frame

    for column in [figures.J,figures.E,figures.N]:
        native('native_nan_'+column,lambda d,c=column:setcell(d,c,np.nan))
    for value,label in [(np.inf,'positive_inf'),(-np.inf,'negative_inf')]:
        native('native_'+label,lambda d,v=value:setcell(d,figures.J,v))
    native('native_missing_metric_column',lambda d:d.drop(columns=[figures.J]))
    native('native_missing_seed_identity',lambda d:setcell(d,'seed',np.nan))
    native('native_failed_status',lambda d:setcell(d,'status','failed'))
    native('native_one_missing_scenario',lambda d:d.drop(index=row))
    cell=core.iloc[0]
    keymask=original.campaign.eq('core_fixed')
    for key in ['plant_model','arm_id','condition','seed']:
        keymask &= original[key].eq(cell[key])
    native('native_one_entire_seed_missing',lambda d:d.loc[~keymask].copy())
    native('native_duplicate_scenario',lambda d:pd.concat([d,d.loc[[row]]],ignore_index=True))
    # The unmodified records are a positive control for both plotted campaigns.
    for campaign,count in [('core_fixed',180),('attitude_intervention',360)]:
        grouped=figures.blocks(campaign)
        checks.append({'check':'valid_'+campaign,'passed':len(grouped)==count,
                       'observed':{'seed_blocks':len(grouped)}})

    for value,label in [(np.nan,'nan'),(np.inf,'inf'),(-np.inf,'negative_inf')]:
        def invalid_estimate(v=value):
            fig,ax=plt.subplots();style.interval(ax,0,v,.1,.2)
        rejection('estimate_'+label,invalid_estimate)
        def invalid_point(v=value):
            fig,ax=plt.subplots();figures.points(ax,0,[.1,v], 'minimal')
        rejection('seed_point_'+label,invalid_point)
    def reversed_interval():
        fig,ax=plt.subplots();style.interval(ax,0,.15,.2,.1)
    rejection('reversed_interval',reversed_interval)
    fig,ax=plt.subplots();style.interval(ax,0,4,1,2)
    checks.append({'check':'BCa_estimate_outside_interval_is_legal',
                   'passed':ax._plot_records[0]['mean']==4,'observed':'Estimate and CI drawn independently'})
    plt.close(fig)

    for axis in ['x','y']:
        for value,label in [(0.0,'zero'),(-.1,'negative')]:
            def invalid_log(a=axis,v=value):
                fig,ax=plt.subplots()
                style.register(ax,{'type':'seed_blocks','x':[v,.2] if a=='x' else [.1,.2],
                                   'y':[v,.2] if a=='y' else [.1,.2]})
                getattr(ax,'set_'+a+'scale')('log')
                style.fit_records(ax,a)
            rejection('log_'+axis+'_'+label,invalid_log)

    # Instrument export rather than writing malformed PDFs/PNGs to the package.
    export_calls=[]
    def invalid_before_export():
        fig,ax=plt.subplots();ax.set_xscale('log');ax.set_xlim(.1,1);ax.set_ylim(0,1)
        style.register(ax,{'type':'seed_blocks','x':[0,.2],'y':[.2,.3]})
        fig.savefig=lambda *args,**kwargs:export_calls.append(str(args[0]))
        style.save(fig,'invalid_log_probe',work/'guard_probe',[],'Input validation probe',panels=False)
    rejection('invalid_log_rejected_by_save',invalid_before_export)
    checks.append({'check':'invalid_data_rejected_before_any_export','passed':not export_calls,
                   'observed':{'export_calls':len(export_calls)}})

    src=ROOT/'data/figure_sources'
    geometry=pd.read_csv(src/'rev_fig6_px4_pub__all_attempt_geometry_scope.csv')
    ignored=geometry.loc[~geometry.plotted]
    endpoint_columns=['native_pair_center_distance_min_m','native_max_tilt_deg']
    captured={}
    previous_save=figures.save
    def capture(fig,*args,**kwargs):
        records=[q for ax in fig.axes for q in getattr(ax,'_plot_records',[])]
        rows=[q['row'] for q in records if q['type']=='design_counts']
        captured.update({key:sum(int(row[key]) for row in rows) for key in
                         ['designs','record_complete','failed_before_release','failed_after_release']})
        captured['geometry_points']=sum(q['count'] for q in records if q['type']=='geometry')
        captured['observed_windows']=sum(q['count'] for q in records if q['type']=='ecdf')
        plt.close(fig)
        return captured
    try:
        figures.save=capture
        figures.px4(work)
    finally:
        figures.save=previous_save
    expected={'designs':900,'record_complete':824,'failed_before_release':44,
              'failed_after_release':32,'geometry_points':824,'observed_windows':824}
    checks.append({'check':'PX4_missing_failed_attempt_endpoints_are_legal',
                   'passed':ignored[endpoint_columns].isna().any().any() and captured==expected,
                   'observed':{'captured':captured,'unplotted_attempts':len(ignored),
                               'unplotted_attempts_with_missing_endpoint':int(ignored[endpoint_columns].isna().any(axis=1).sum())}})
    checks.append({'check':'PX4_plotted_endpoints_are_finite',
                   'passed':np.isfinite(geometry.loc[geometry.plotted,endpoint_columns].to_numpy()).all(),
                   'observed':{'complete_geometries':int(geometry.plotted.sum())}})
    for check in checks:check['passed']=bool(check['passed'])
    return {'status':'PASS' if all(c['passed'] for c in checks) else 'ISSUES',
            'scope':'Malformed inputs are memory-only copies; no frozen CSV is changed and no experiment is run.',
            'checks':checks,'failures':[c for c in checks if not c['passed']]}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'outputs/figure_input_guards.json')
    args=parser.parse_args()
    if args.output.resolve().is_relative_to((ROOT/'data').resolve()):
        raise ValueError('Write verification reports outside frozen data.')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    result=audit(args.output.parent)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':result['status'],'checks':len(result['checks']),'failures':result['failures']},ensure_ascii=False,indent=2))
    raise SystemExit(0 if result['status']=='PASS' else 1)
