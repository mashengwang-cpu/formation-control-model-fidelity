"""Descriptive species decomposition and raw flight-envelope diagnostics.

These diagnostics do not alter the frozen primary endpoints, remove trials,
or add inferential tests. A z <= 0 crossing is a reference-plane violation,
not a simulated collision: this free-flight model has no ground contact.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import io
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "simulation/src"))
from finite_control_sim.statistics import bca_mean_ci

SNAPSHOT = ROOT / "data/statistics/runs_snapshot.csv"
OUT = ROOT / "results/native_diagnostics"


def inspect(record):
    path = ROOT / "data/native/traces" / (record["job_id"] + ".npz")
    with np.load(path, allow_pickle=False) as trace:
        z, tilt, t = trace["uav_altitudes"], trace["uav_tilts"], trace["times"]
        below = np.any(z <= 0, axis=1)
        inverted = np.any(tilt >= np.pi / 2, axis=1)
        return {**record, "min_uav_z_m": float(z.min()),
                "max_uav_tilt_rad": float(tilt.max()),
                "any_reference_plane_crossing": bool(below.any()),
                "first_plane_crossing_s": float(t[np.flatnonzero(below)[0]]) if below.any() else None,
                "any_inverted_uav": bool(inverted.any()),
                "trajectory_sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    global OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=OUT)
    args = parser.parse_args()
    OUT = args.output.resolve()
    if OUT.is_relative_to(ROOT / "data") or OUT == ROOT:
        raise ValueError("Use a separate output directory; archived evidence is read-only")
    payload = SNAPSHOT.read_bytes()
    frame = pd.read_csv(io.BytesIO(payload))
    core = frame[frame.campaign.eq("core_fixed")]
    attitude = frame[frame.campaign.eq("attitude_intervention")]
    if len(core) != 900 or len(attitude) != 720:
        raise ValueError("Descriptive diagnostics require complete core and attitude campaigns")
    if not core.status.eq("ok").all() or not attitude.status.eq("ok").all():
        raise ValueError("Do not silently exclude unsuccessful executions")
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "input_runs_snapshot.csv").write_bytes(payload)
    species_rows = []
    for (plant, arm), group in core.groupby(["plant_model", "arm_id"]):
        for species in ["uav", "usv"]:
            blocks = group.groupby("seed")[species + "_tracking_error"].mean()
            if len(blocks) != 20:
                raise ValueError("Incomplete seed blocks")
            mean, lo, hi = bca_mean_ci(blocks.to_numpy(float))
            species_rows.append(dict(plant_model=plant, arm_id=arm, species=species,
                                     mean=mean, bca95_low=lo, bca95_high=hi, n_seeds=20))
    species = pd.DataFrame(species_rows)
    species.to_csv(OUT / "core_species_means.csv", index=False)
    identity = core.formation_tracking_error - .5 * (core.uav_tracking_error + core.usv_tracking_error)
    if not np.allclose(identity, 0, rtol=0, atol=1e-12):
        raise ValueError("Equal-species tracking-error identity failed")

    rigid = frame[(frame.campaign.eq("core_fixed") & frame.plant_model.eq("mixed_6dof_3dof"))
                  | frame.campaign.eq("attitude_intervention")]
    columns = ["job_id", "campaign", "arm_id", "seed", "scenario", "attitude_response_scale",
               "formation_tracking_error", "altitude_rmse", "uav_rotor_saturation_fraction",
               "uav_tilt_saturation_fraction"]
    with ThreadPoolExecutor(max_workers=4) as executor:
        detail = pd.DataFrame(executor.map(inspect, rigid[columns].to_dict("records")))
    detail.to_csv(OUT / "flight_envelope_per_job.csv", index=False)
    groups = ["campaign", "arm_id", "attitude_response_scale"]
    summary = detail.groupby(groups).agg(
        tasks=("job_id", "size"), reference_plane_crossings=("any_reference_plane_crossing", "sum"),
        inverted_tasks=("any_inverted_uav", "sum"), min_z_m=("min_uav_z_m", "min"),
        max_tilt_rad=("max_uav_tilt_rad", "max"), mean_altitude_rmse=("altitude_rmse", "mean"),
        mean_rotor_saturation_fraction=("uav_rotor_saturation_fraction", "mean"),
        mean_tilt_command_limit_fraction=("uav_tilt_saturation_fraction", "mean"))
    summary.to_csv(OUT / "flight_envelope_summary.csv")
    (OUT / "provenance.json").write_text(json.dumps(dict(
        status="completed_descriptive_posthoc_diagnostics",
        source_snapshot=str(SNAPSHOT.relative_to(ROOT)),
        source_snapshot_sha256=hashlib.sha256(payload).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        core_tasks=len(core), attitude_tasks=len(attitude), inspected_rigid_tasks=len(detail),
        species_identity_max_abs=float(np.abs(identity).max()),
        bootstrap_samples=20000, bootstrap_seed=1234,
        excluded_primary_trials=0, inferential_tests=0,
        interpretation="Plane crossings/inversion indicate departure from the tested hover envelope; no ground collision model is present."
    ), indent=2), encoding="utf-8")
    labels = {"minimal": "Minimal", "family": "Family", "full_no_ppt": "Full, PPT off"}
    lines = [r"\begin{table}[t]\centering",
             r"\caption{Tracking error by vehicle type in the mixed rigid-body core comparison. Each species has four followers. Means and pointwise 95\% BCa intervals over 20 five-scenario seed blocks; these are descriptive decompositions of the primary endpoint.}",
             r"\label{tab:species}", r"\small\begin{tabular}{lrr}\toprule",
             r"Controller & UAV $J$ (m) & USV $J$ (m) \\", r"\midrule"]
    for arm in labels:
        values = []
        for kind in ["uav", "usv"]:
            row = species[(species.plant_model == "mixed_6dof_3dof") & (species.arm_id == arm)
                          & (species.species == kind)].iloc[0]
            values.append(f"{row['mean']:.3f} [{row.bca95_low:.3f}, {row.bca95_high:.3f}]")
        lines.append(" & ".join([labels[arm], *values]) + r" \\")
    lines += [r"\bottomrule\end{tabular}\end{table}"]
    (OUT / "species_table.tex").write_text(
        "\n".join(lines) + "\n", encoding="utf-8")
    print(summary.to_string())


if __name__ == "__main__":
    main()
