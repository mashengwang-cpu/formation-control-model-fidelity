"""Numerical verification of Theorem 1 (sampled-data practical stability of the
minimal event-triggered stack, main text) and of Supplementary Note S12.

The theorem covers one follower of the canonical point-mass loop (v1000_canonical
plant: dot p = v, m dot v = rho u + d - c v) under the minimal stack
(sampled-data PD, periodic event detection with held error samples, gated causal
fault compensation u_cmd = sat(u_nom / max(rho_hat, 0.35))), with gamma = 0 topology
mixing, no DoS and no FDI.  This script:

  1. builds the exact inter-event hold maps M_j(g) for hold lengths
     tau = j h, j = 1..Nbar (Nbar h >= max hold 0.55 s), with the multiplicative
     uncertainty theta(t) = rho / max(rho_hat, 0.35) relaxed into the exact
     componentwise kernel box (kernels of the damped double integrator are
     nonnegative, so the box vertices majorize every measurable theta(.));
  2. searches for a common quadratic certificate P > 0 with
     M_j(g)^T P M_j(g) <= gamma^2 P at all box vertices (affine in g, so
     vertex verification is exact, not gridded);
  3. evaluates the explicit ultimate bound of Theorem 1, the admissible
     (saturation-free) initial set, and the excluded worst cases (projection-only
     effectiveness interval, DoS-extended holds);
  4. replays the exact single-agent minimal-stack loop (using the public
     package controller and estimator classes) to measure the realized tracking
     error, the estimator underestimation sup(rho - rho_hat), saturation
     occurrences and event statistics, and reports the conservatism factor of
     the theoretical bound.

Run with:  py -3.12 Reproduction/tools/verify_theorem_conditions.py
Only numpy is required.
"""

from __future__ import annotations

import math
import argparse
import json
import sys
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "simulation" / "src"))

from finite_control_sim.controllers import (  # noqa: E402
    ControllerInput,
    ControllerState,
    ModularController,
    get_method_spec,
)
from finite_control_sim.estimators import OnlineEfficiencyEstimator  # noqa: E402
from finite_control_sim.models import deterministic_disturbance, leader_reference  # noqa: E402

# ----------------------------------------------------------------------------
# Paper parameters (main-text Tables 1 and 2, Section 2).
# ----------------------------------------------------------------------------
H = 0.02                       # detection / sampling period (s)
T_HOLD = 0.55                  # trigger max hold (s)
NBAR = math.ceil(T_HOLD / H)   # 28 detection periods -> max realized hold 0.56 s
KP, KV = 2.15, 2.05            # minimal-stack gains
UBAR = 8.0                     # input saturation
RHO_FLOOR = 0.35               # fault-compensation divisor floor
PROJ_HI = 1.05                 # estimator projection ceiling
RHO_MIN, RHO_MAX = 0.47, 1.0   # canonical LOE 0.55+0.08 sin(1.7 t), else 1
DBAR = np.array([0.035, 0.03])           # per-axis disturbance amplitude (models.py)
V0BAR = np.array([0.55, 1.4 * 0.28])     # per-axis leader velocity bound
A0BAR = np.array([0.0, 1.4 * 0.28 ** 2]) # per-axis leader acceleration bound
PLANTS = {"UAV": (1.0, 0.28), "USV": (1.35, 0.42)}  # (mass, linear damping)
KVEC = np.array([KP, KV])

RHO_TILDE_PAPER = 0.20  # parameterizes the assumed theta interval; NOT a proved estimator bound


def wbar_axes(m: float, c: float) -> np.ndarray:
    """Per-axis bound on the lumped disturbance w = d - c v0 - m a0."""
    return DBAR + c * V0BAR + m * A0BAR


def theta_box(rho_tilde: float) -> tuple[float, float]:
    """theta = rho / max(rho_hat, 0.35) under projection + rho_hat >= rho - rho_tilde."""
    theta_min = RHO_MIN / PROJ_HI
    theta_max = min(RHO_MAX, RHO_FLOOR + rho_tilde) / RHO_FLOOR
    return theta_min, theta_max


def kernel_integrals(tau: float, a: float, m: float) -> tuple[float, float, float]:
    """q1 = int (1-e^{-a r})/a dr / m, q2 = int e^{-a r} dr / m, plus e^{-a tau}."""
    ea = math.exp(-a * tau)
    one_minus_ea = -math.expm1(-a * tau)
    q2 = one_minus_ea / (a * m)
    q1 = (tau / a - one_minus_ea / a ** 2) / m
    return q1, q2, ea


def intersample_upper_bound(p: np.ndarray, a: float, m: float,
                           theta_min: float, theta_max: float,
                           tau_bar: float, mesh_s: float = 0.001) -> dict:
    """Conservative continuous-r enclosure, including r=0.

    e1^T M(r,g) = [1-Kp*g1, b(r)-Kv*g1]. On every closed interval [l,u],
    b(r)=(1-exp(-a*r))/a and q1(r) are increasing. Therefore the row lies in
    the affine image of the rectangle
       b in [b(l), b(u)], g1 in [theta_min*q1(l), theta_max*q1(u)].
    Its squared P-inverse norm is convex, so all continuous r and all box
    gains are bounded by FOUR rectangle vertices, not by sampled r values.
    A small outward guard covers float64 evaluation rounding; this is a
    numerical certificate of an analytic enclosure, not interval-arithmetic
    verification of every floating-point operation.
    """
    if mesh_s <= 0 or tau_bar < 0 or theta_min <= 0 or theta_max < theta_min:
        raise ValueError("Invalid intersample enclosure parameters.")
    inverse = np.linalg.inv(p)
    intervals = max(1, math.ceil(tau_bar / mesh_s))
    nodes = np.linspace(0., tau_bar, intervals + 1)
    guard = 1e-12
    upper_squared = 0.
    for left, right in zip(nodes[:-1], nodes[1:]):
        ql, q2l, _ = kernel_integrals(float(left), a, m)
        qr, q2r, _ = kernel_integrals(float(right), a, m)
        for b in (m * q2l - guard, m * q2r + guard):
            for g1 in (theta_min * ql - guard, theta_max * qr + guard):
                row = np.array([1. - KP * g1, b - KV * g1])
                upper_squared = max(upper_squared, float(row @ inverse @ row))
    upper = math.sqrt(upper_squared) * (1. + 1e-12) + guard
    return dict(upper=float(upper), at_zero=float(math.sqrt(inverse[0, 0])),
                mesh_s=float(tau_bar / intervals), intervals=intervals,
                rectangle_vertices=4 * intervals, outward_guard=guard)


def hold_matrix(tau: float, a: float, g1: float, g2: float) -> np.ndarray:
    ea = math.exp(-a * tau)
    phi = np.array([[1.0, (1.0 - ea) / a], [0.0, ea]])
    return phi - np.outer([g1, g2], KVEC)


def vertex_family(a: float, m: float, theta_min: float, theta_max: float,
                  nbar: int) -> tuple[np.ndarray, np.ndarray]:
    mats, qs = [], []
    for j in range(1, nbar + 1):
        q1, q2, _ = kernel_integrals(j * H, a, m)
        qs.append((q1, q2))
        for g1 in (theta_min * q1, theta_max * q1):
            for g2 in (theta_min * q2, theta_max * q2):
                mats.append(hold_matrix(j * H, a, g1, g2))
    return np.array(mats), np.array(qs)


def make_p(phi: float, log_kappa: float) -> np.ndarray:
    cs, sn = math.cos(phi), math.sin(phi)
    rot = np.array([[cs, -sn], [sn, cs]])
    return rot @ np.diag([1.0, 10.0 ** log_kappa]) @ rot.T


def gamma_all(p: np.ndarray, mats: np.ndarray) -> np.ndarray:
    """P-norm ||T M T^{-1}||_2 for every M (T upper Cholesky factor of P)."""
    t = np.linalg.cholesky(p).T
    ti = np.linalg.inv(t)
    arr = np.einsum("ab,nbc,cd->nad", t, mats, ti)
    return np.linalg.svd(arr, compute_uv=False)[:, 0]


def ratio_objective(p: np.ndarray, mats: np.ndarray, qs: np.ndarray) -> float:
    """Psi = max_j psi_j / (1 - gamma_j); +inf when any gamma_j >= 1.

    This is the constant that multiplies ||wbar|| in the ultimate P-radius,
    so it is the natural search objective for the certificate.
    """
    nbar = qs.shape[0]
    gammas = gamma_all(p, mats).reshape(nbar, 4).max(axis=1)
    if gammas.max() >= 1.0:
        return np.inf
    t = np.linalg.cholesky(p).T
    plus = np.linalg.norm(qs @ t.T, axis=1)
    minus = np.linalg.norm((qs * np.array([1.0, -1.0])) @ t.T, axis=1)
    psi = np.maximum(plus, minus)
    return float((psi / (1.0 - gammas)).max())


def search_p(mats: np.ndarray, qs: np.ndarray | None = None) -> tuple[np.ndarray, float]:
    """Grid + refinement search for P.

    With qs given, minimizes the ultimate-bound ratio Psi (used for the final
    certificate); without qs, minimizes the worst vertex contraction gamma
    (used for feasibility scans).
    """

    def cost(p: np.ndarray) -> float:
        if qs is None:
            return float(gamma_all(p, mats).max())
        return ratio_objective(p, mats, qs)

    best = (None, np.inf)
    for phi in np.linspace(0.0, math.pi, 61):
        for lk in np.linspace(-3.0, 3.0, 61):
            g = cost(make_p(phi, lk))
            if g < best[1]:
                best = ((phi, lk), g)
    (phi0, lk0), _ = best
    span_phi, span_lk = math.pi / 60, 0.1
    for _ in range(4):
        for phi in np.linspace(phi0 - span_phi, phi0 + span_phi, 21):
            for lk in np.linspace(lk0 - span_lk, lk0 + span_lk, 21):
                g = cost(make_p(phi, lk))
                if g < best[1]:
                    best = ((phi, lk), g)
        (phi0, lk0), _ = best
        span_phi *= 0.2
        span_lk *= 0.2
    return make_p(phi0, lk0), best[1]


def certify(plant: str, rho_tilde: float, nbar: int = NBAR, verbose: bool = True):
    """Full Theorem 1 certificate for one plant type. Returns dict or None."""
    m, c = PLANTS[plant]
    a = c / m
    theta_min, theta_max = theta_box(rho_tilde)
    mats, qs = vertex_family(a, m, theta_min, theta_max, nbar)
    p, psi_star = search_p(mats, qs)
    if not np.isfinite(psi_star):
        if verbose:
            print(f"  [{plant}] NOT certifiable at rho_tilde = {rho_tilde}")
        return None
    t = np.linalg.cholesky(p).T
    ti = np.linalg.inv(t)
    gammas = gamma_all(p, mats).reshape(nbar, 4).max(axis=1)
    plus = np.linalg.norm(qs @ t.T, axis=1)
    minus = np.linalg.norm((qs * np.array([1.0, -1.0])) @ t.T, axis=1)
    psi = np.maximum(plus, minus)
    ratio = psi / (1.0 - gammas)
    j_star = int(ratio.argmax()) + 1

    enclosure = intersample_upper_bound(p, a, m, theta_min, theta_max, nbar * H)
    kappa_e = enclosure["upper"]
    q1_end, _, _ = kernel_integrals(nbar * H, a, m)

    wb = wbar_axes(m, c)
    wb2 = float(np.linalg.norm(wb))
    c_bound = kappa_e * psi_star + q1_end
    e_ult = c_bound * wb2                          # ultimate bound on sup ||e(t)||
    r_star_axes = wb * psi_star                    # per-axis ultimate P-norm radius
    r_star_tot = float(np.linalg.norm(r_star_axes))
    k_pinv_k = float(KVEC @ np.linalg.solve(p, KVEC))
    x_adm = RHO_FLOOR * UBAR / math.sqrt(k_pinv_k)  # a-priori saturation-free radius

    out = dict(plant=plant, m=m, c=c, rho_tilde=rho_tilde, theta_min=theta_min,
               theta_max=theta_max, P=p, gamma_max=float(gammas.max()),
               gammas=gammas, psi_star=float(psi_star), j_star=j_star,
               kappa_e=float(kappa_e), kappa_enclosure=enclosure, q1_end=float(q1_end),
               c_bound=float(c_bound), wbar=wb, wbar2=wb2, e_ult=float(e_ult),
               r_star_axes=r_star_axes, r_star_tot=r_star_tot,
               x_adm=float(x_adm), apriori_sat_ok=bool(r_star_tot <= x_adm))
    if verbose:
        print(f"  [{plant}] m={m}, c={c}: theta in [{theta_min:.4f}, {theta_max:.4f}]")
        print(f"    P = [[{p[0,0]:.4f}, {p[0,1]:.4f}], [{p[1,0]:.4f}, {p[1,1]:.4f}]]")
        print(f"    per-hold contraction gamma_j in "
              f"[{gammas.min():.4f}, {gammas.max():.4f}]  (all < 1)")
        print(f"    Psi = sup_j psi_j/(1-gamma_j) = {psi_star:.3f} at j = {j_star} "
              f"(j=1: {ratio[0]:.3f}, j={nbar}: {ratio[-1]:.3f})")
        print(f"    kappa_e = {kappa_e:.3f}, q1(tau_bar) = {q1_end:.4f}, "
              f"C = kappa_e Psi + q1 = {c_bound:.3f}")
        print(f"    continuous-r rectangle enclosure: {enclosure['intervals']} closed intervals, "
              f"r=0 factor {enclosure['at_zero']:.9f}; no sampled-sup substitution")
        print(f"    wbar per axis = ({wb[0]:.4f}, {wb[1]:.4f}), ||wbar|| = {wb2:.4f}")
        print(f"    ULTIMATE BOUND  limsup_t sup ||e(t)|| <= C ||wbar|| = {e_ult:.3f}")
        print(f"    a-priori saturation-free P-radius Xbar = {x_adm:.3f}; "
              f"ultimate P-radius Psi||wbar|| = {r_star_tot:.3f} "
              f"({'sufficient condition met' if out['apriori_sat_ok'] else 'sufficient condition NOT met; no-saturation kept as a checked assumption'})")
    return out


# ----------------------------------------------------------------------------
# Excluded worst cases (Remark material).
# ----------------------------------------------------------------------------

def spectral_counterexamples() -> None:
    print("\n== Excluded worst cases (constant theta, hence realizable) ==")
    for plant, (m, c) in PLANTS.items():
        a = c / m
        # Projection-only effectiveness interval: theta_max = rho_max / 0.35.
        th = RHO_MAX / RHO_FLOOR
        q1, q2, _ = kernel_integrals(NBAR * H, a, m)
        rad = max(abs(np.linalg.eigvals(hold_matrix(NBAR * H, a, th * q1, th * q2))))
        print(f"  [{plant}] projection-only theta = {th:.3f}, hold 0.56 s: "
              f"spectral radius {rad:.2f} (unstable if > 1)")
        # DoS-extended hold at the certified theta_max.
        _, th_max = theta_box(RHO_TILDE_PAPER)
        tau_dos = NBAR * H + 1.12  # max hold + canonical DoS window length
        q1, q2, _ = kernel_integrals(tau_dos, a, m)
        rad = max(abs(np.linalg.eigvals(hold_matrix(tau_dos, a, th_max * q1, th_max * q2))))
        print(f"  [{plant}] DoS-extended hold {tau_dos:.2f} s at theta = {th_max:.3f}: "
              f"spectral radius {rad:.2f}")


def scan_rho_tilde() -> None:
    print("\n== Certificate search over rho_tilde (coarse scan; no infeasibility proof) ==")
    feasible = None
    for rt in np.arange(0.05, 0.61, 0.05):
        ok = True
        for plant in PLANTS:
            m, c = PLANTS[plant]
            theta_min, theta_max = theta_box(rt)
            mats, _ = vertex_family(c / m, m, theta_min, theta_max, NBAR)
            _, g = search_p(mats)
            ok &= g < 1.0
        print(f"  rho_tilde = {rt:.2f}: {'certificate found' if ok else 'not certified by this search'}")
        if ok:
            feasible = rt
    print(f"  -> largest rho_tilde certified by this search: {feasible}")


# ----------------------------------------------------------------------------
# Exact single-agent minimal-stack replay (theorem object), package classes.
# ----------------------------------------------------------------------------

def run_single_agent(plant: str, scenario: str, seed: int, duration: float = 16.0):
    m, c = PLANTS[plant]
    dt = H
    times = np.arange(0.0, duration + 0.5 * dt, dt)
    steps = len(times)
    rng = np.random.default_rng(seed)
    spec = get_method_spec("proposed_minimal_causal")
    controller = ModularController(spec=spec, follower_count=1, dimensions=2,
                                   max_control=UBAR)
    estimator = OnlineEfficiencyEstimator(1)  # defaults: gain 4.0 /s, ungated
    leader_p0, leader_v0 = leader_reference(0.0)
    offset = np.array([[-1.2, -0.6]])
    positions = leader_p0[None, :] + offset + rng.normal(0.0, 0.42, size=(1, 2))
    velocities = np.tile(leader_v0, (1, 1)) * 0.15
    state = ControllerState(
        adaptive_weights=np.zeros((1, controller.basis_size, 2)),
        observer_state=np.zeros((1, 2)),
        trigger_filter=np.zeros(1),
        sampled_error=(positions - leader_p0[None, :] - offset).copy(),
        sampled_velocity_error=(velocities - leader_v0[None, :]).copy(),
    )
    x0 = np.hstack([(positions - leader_p0[None, :] - offset)[0],
                    (velocities - leader_v0[None, :])[0]])

    loe_start = 0.42 * duration
    err_norm = np.zeros(steps)
    under_est = 0.0
    theta_sup = 0.0
    sat_steps = 0
    events = 0
    last_event_t = 0.0
    max_hold = 0.0
    last_event_time = np.zeros(1)
    for step, t in enumerate(times):
        leader_p, leader_v = leader_reference(float(t))
        desired = leader_p[None, :] + offset
        e = positions - desired
        edot = velocities - leader_v[None, :]
        rho = 0.55 + 0.08 * math.sin(1.7 * t) if (
            scenario == "actuator_fault" and t >= loe_start) else 1.0
        eff_hat = estimator.efficiency.copy()
        under_est = max(under_est, rho - float(eff_hat[0]))
        theta_sup = max(theta_sup, rho / max(float(eff_hat[0]), RHO_FLOOR))
        out = controller.step(state, ControllerInput(
            time_s=float(t), dt_s=dt, position_error=e, velocity_error=edot,
            sampled_error=state.sampled_error,
            time_since_event=t - last_event_time,
            communication_available=np.ones(1, dtype=bool),
            actuator_efficiency=eff_hat, predefined_time_s=5.0,
            constraint_radius=1.0, trigger_base_threshold=0.035,
            trigger_max_hold_s=T_HOLD, minimum_inter_event_s=0.0))
        mask = out.triggered.copy()
        if step == 0:
            mask[:] = True
        state = out.next_state
        if mask[0]:
            events += 1
            max_hold = max(max_hold, t - last_event_t)
            last_event_t = t
        last_event_time[mask] = t
        raw_comp = out.raw_control / max(float(eff_hat[0]), RHO_FLOOR)
        if np.linalg.norm(raw_comp) > UBAR + 1e-9:
            sat_steps += 1
        commanded = out.commanded_control
        actual = rho * commanded
        err_norm[step] = np.linalg.norm(e)
        if step == steps - 1:
            break
        prev_vel = velocities.copy()
        dist = deterministic_disturbance(float(t), 1, seed_scale=0.01 * seed)

        def deriv(vel: np.ndarray) -> np.ndarray:
            return (actual + dist - c * vel) / m

        k1a, k1p = deriv(velocities), velocities
        k2a = deriv(velocities + 0.5 * dt * k1a)
        k2p = velocities + 0.5 * dt * k1a
        k3a = deriv(velocities + 0.5 * dt * k2a)
        k3p = velocities + 0.5 * dt * k2a
        k4a = deriv(velocities + dt * k3a)
        k4p = velocities + dt * k3a
        velocities = velocities + (dt / 6.0) * (k1a + 2 * k2a + 2 * k3a + k4a)
        positions = positions + (dt / 6.0) * (k1p + 2 * k2p + 2 * k3p + k4p)
        estimator.update(applied_control=commanded,
                         observed_acceleration=(velocities - prev_vel) / dt,
                         mass=np.array([m]), modelled_drag=c * prev_vel,
                         dt_s=dt)
    tail = times >= 8.0
    return dict(J=float(err_norm.mean()), tail_mean=float(err_norm[tail].mean()),
                tail_sup=float(err_norm[tail].max()), under_est=float(under_est),
                theta_sup=float(theta_sup), sat_steps=sat_steps, events=events,
                max_hold=float(max_hold), x0=x0)


def simulate_all(certs: dict) -> None:
    print("\n== Single-agent minimal-stack replay (20 seeds, causal estimator) ==")
    seeds = range(20)
    total_steps = 0
    total_sat = 0
    for plant in PLANTS:
        cert = certs[plant]
        for scenario in ("nominal", "actuator_fault"):
            runs = [run_single_agent(plant, scenario, s) for s in seeds]
            total_steps += 801 * len(runs)
            j_mean = np.mean([r["J"] for r in runs])
            tail_mean = np.mean([r["tail_mean"] for r in runs])
            tail_sup = np.max([r["tail_sup"] for r in runs])
            under = np.max([r["under_est"] for r in runs])
            th_sup = np.max([r["theta_sup"] for r in runs])
            sat = sum(r["sat_steps"] for r in runs)
            total_sat += sat
            ev = np.mean([r["events"] for r in runs])
            hold = np.max([r["max_hold"] for r in runs])
            cons_sup = cert["e_ult"] / tail_sup
            cons_mean = cert["e_ult"] / tail_mean
            print(f"  [{plant}/{scenario}] J = {j_mean:.4f}, tail mean = "
                  f"{tail_mean:.4f}, tail sup = {tail_sup:.4f}")
            print(f"    sup theta(t) = {th_sup:.3f} vs certified theta_max = "
                  f"{cert['theta_max']:.3f} "
                  f"({'inside box' if th_sup <= cert['theta_max'] else 'OUTSIDE BOX'}); "
                  f"sup(rho - rho_hat) = {under:.3f}")
            print(f"    saturated steps = {sat}, events/run = {ev:.1f}, "
                  f"max realized hold = {hold:.2f} s")
            print(f"    conservatism: bound/tail-sup = {cons_sup:.1f}x, "
                  f"bound/tail-mean = {cons_mean:.1f}x")
    print(f"  saturation across all runs: {total_sat}/{total_steps} steps")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-json', type=Path)
    args = parser.parse_args()
    print("=" * 78)
    print("Theorem 1 certificate: minimal stack, canonical point-mass loop")
    print(f"h = {H}, max hold = {T_HOLD} s (Nbar = {NBAR}), Kp = {KP}, Kv = {KV}, "
          f"ubar = {UBAR}")
    print(f"rho in [{RHO_MIN}, {RHO_MAX}], projection [0.30, {PROJ_HI}], "
          f"floor {RHO_FLOOR}, assumed theta interval parameterized by rho_tilde = {RHO_TILDE_PAPER}")
    print("=" * 78)
    certs = {}
    for plant in PLANTS:
        certs[plant] = certify(plant, RHO_TILDE_PAPER)
    if any(v is None for v in certs.values()):
        raise SystemExit("Certificate not found at the paper parameters.")
    spectral_counterexamples()
    scan_rho_tilde()
    simulate_all(certs)
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(certs, indent=2,
            default=lambda value: value.tolist() if hasattr(value, 'tolist') else float(value)), encoding='utf-8')
    print("\nDone.")


if __name__ == "__main__":
    main()
