"""Verify publication exports, independent-panel parity and frozen numeric data."""
import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
import pdfplumber
from PIL import Image
from pdfminer.pdftypes import resolve1
from verify_figure_data import audit, EXPECTED

ROOT=Path(__file__).resolve().parents[1]

def verify(folder):
    checks=[]
    def check(name,passed,detail=None):
        checks.append({'check':name,'passed':bool(passed),'detail':detail})
    manifest=json.loads((folder/'FIGURE_MANIFEST.json').read_text(encoding='utf-8'))
    check('eleven_expected_full_figures',set(manifest)==set(EXPECTED))
    panel_count=0
    font_count=0
    all_files=[]
    for name,item in manifest.items():
        source_ledger=json.loads((folder/item['plot_data']['path']).read_text(encoding='utf-8'))
        entries=[{'figure':name,'files':item['files'],'plot_data':item['plot_data']}]+item.get('panel_artifacts',[])
        check(name+':one_reading_panel_per_axis',len(entries)-1==(len(source_ledger['axes']) if name not in ['Figure_S3','Figure_S4','Graphical_abstract'] else 0))
        for j,entry in enumerate(entries):
            label=entry['figure'];check(label+':three_formats',set(entry['files'])=={'pdf','svg','png'})
            ledger_path=folder/entry['plot_data']['path']
            check(label+':ledger_sha256',hashlib.sha256(ledger_path.read_bytes()).hexdigest()==entry['plot_data']['sha256'])
            if j:
                panel_count+=1
                ledger=json.loads((folder/entry['plot_data']['path']).read_text(encoding='utf-8'))
                check(label+':same_axis_and_all_records',ledger['axes']==[source_ledger['axes'][j-1]])
                check(label+':dedicated_conditions',bool(ledger.get('reading_layout',{}).get('notes')))
                check(label+':same_frozen_sources',ledger['sources']==source_ledger['sources'])
            for ext,q in entry['files'].items():
                path=folder/q['path'];all_files.append(path)
                check(label+':'+ext+':sha256',path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==q['sha256'])
            pdf=folder/entry['files']['pdf']['path']
            with pdfplumber.open(pdf) as document:
                page=document.pages[0]
                outside=[c['text'] for c in page.chars if c['text'].strip() and (min(c['x0'],c['top'])<-.4 or c['x1']>page.width+.4 or c['bottom']>page.height+.4)]
                check(label+':no_text_outside_page',not outside,outside)
                check(label+':vector_pdf',len(page.images)==0)
                if j:check(label+':180mm_reading_canvas',abs(page.width*25.4/72-180)<.01)
                if name=='Figure_S4':
                    check(label+':180mm_diagnostic_canvas',abs(page.width*25.4/72-180)<.01)
                    expected_labels=Counter(value for axis in source_ledger['axes'] for record in axis['records']
                                            if record.get('type')=='envelope_events' for value in record['labels'].values())
                    actual_labels=Counter(re.sub(r'\s+','',value) for value in
                                          re.findall(r'\b\d+\s*/\s*40\b',page.extract_text() or ''))
                    check(label+':all_12_event_count_labels_in_pdf',sum(expected_labels.values())==12 and
                          actual_labels==expected_labels,dict(actual_labels))
                dimensions=[page.width,page.height]
            embedded=True
            with pdfplumber.open(pdf) as document:
                for page in document.pages:
                    resources=resolve1(page.page_obj.attrs.get('Resources',{}))
                    for ref in resolve1(resources.get('Font',{})).values():
                        font=resolve1(ref)
                        fonts=resolve1(font.get('DescendantFonts',[])) or [font]
                        for item in fonts:
                            ft=resolve1(item);font_count+=1
                            descriptor=resolve1(ft.get('FontDescriptor',{}))
                            embedded &= any(k in descriptor for k in ['FontFile','FontFile2','FontFile3'])
            check(label+':all_pdf_fonts_embedded',embedded)
            svg=(folder/entry['files']['svg']['path']).read_text(encoding='utf-8')
            check(label+':vector_svg','<image' not in svg and '<svg' in svg)
            with Image.open(folder/entry['files']['png']['path']) as png:
                check(label+':1000dpi_png',all(abs(x-1000)<.1 for x in png.info.get('dpi',(0,0))))
                check(label+':png_matches_physical_canvas',all(abs(p-size/72*1000)<=2 for p,size in zip(png.size,dimensions)))
    check('27_independent_reading_panels',panel_count==27,panel_count)
    check('114_unique_format_files',len(set(all_files))==114 and len(all_files)==114,len(set(all_files)))
    numeric=audit(folder,list(EXPECTED))
    check('frozen_numeric_suite',numeric['status']=='PASS',{'checks':len(numeric['checks']),'intervals':numeric['intervals'],'seed_points':numeric['seed_points'],'geometry_points':numeric['geometry_points'],'failures':numeric['failures']})
    return {'status':'PASS' if all(x['passed'] for x in checks) else 'ISSUES','checks':checks,'failures':[x for x in checks if not x['passed']],
            'font_resources_checked':font_count,'full_figures':len(manifest),'independent_panels':panel_count,'format_files':len(set(all_files)),
            'scope':'Format and scientific-record parity, page boundaries and embedded PDF fonts. Does not certify internal visual collisions or colour-vision accessibility.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=ROOT/'figures')
    parser.add_argument('--output',type=Path,default=ROOT/'outputs/artwork_verification.json')
    args=parser.parse_args()
    if args.output.resolve().is_relative_to((ROOT/'data').resolve()):
        raise ValueError('Write verification reports outside frozen input data.')
    report=verify(args.input)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False,indent=2))
    raise SystemExit(0 if report['status']=='PASS' else 1)
