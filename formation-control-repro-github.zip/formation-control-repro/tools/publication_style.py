"""Typography, exact-size vector export and numerical source binding."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.transforms import Bbox
from matplotlib.ticker import ScalarFormatter, MaxNLocator
import pdfplumber

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'
STATS=DATA/'statistics'
CAPTIONS=json.loads((ROOT/'tools/figure_captions.json').read_text(encoding='utf-8'))
MM=1/25.4
ARMS=['minimal','family','full_no_ppt']
LABEL={'minimal':'Minimal','family':'Family comparator','full_no_ppt':'Full (PPT off)',
       'ko_tvg':'No gain schedule','ko_powers':'No signed powers',
       'ko_approximator':'No approximation','ko_observer':'No error filter'}
COLOR={'minimal':'#006C84','family':'#AD5700','full_no_ppt':'#684A98',
       'ko_tvg':'#006E62','ko_powers':'#955D00','ko_approximator':'#A33769','ko_observer':'#50602A'}
MARKER={'minimal':'o','family':'s','full_no_ppt':'^','ko_tvg':'D','ko_powers':'v','ko_approximator':'P','ko_observer':'X'}
LINESTYLE={'minimal':'-','family':(0,(4,2)),'full_no_ppt':(0,(5,2,1,2)),
           'ko_tvg':'-','ko_powers':'--','ko_approximator':'-.','ko_observer':':'}
PLANTS=['matched_point_mass','matched_lagged','mixed_6dof_3dof']
PLABEL=['Point mass','Command lag','Rigid body']
MODULES=['tvg','powers','approximator','observer','faultcomp','ppt','topology']
MLABEL=['Gain schedule','Signed powers','Approximation','Error filter','Effectiveness compensation','PPT','Topology mixing']
INK='#283641'
MUTED='#657581'
LIGHT='#EDF1F3'
PLANT_COLOR=['#697C89','#38858E','#435D80']
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
 'font.size':10,'axes.labelsize':10,'axes.titlesize':10.5,'xtick.labelsize':9.5,'ytick.labelsize':9.5,
 'legend.fontsize':10.5,'axes.linewidth':1.0,'axes.edgecolor':INK,'text.color':INK,'axes.labelcolor':INK,
 'xtick.color':INK,'ytick.color':INK,'axes.spines.top':False,'axes.spines.right':False,
 'legend.frameon':False,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
 'figure.facecolor':'white','savefig.facecolor':'white','axes.facecolor':'white',
 'lines.linewidth':1.25,'mathtext.fontset':'dejavusans','axes.unicode_minus':True,
 'svg.hashsalt':'ast-formation-figure-readability-r3-20260907'})


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def select(df,**terms):
    for k,v in terms.items():df=df[df[k].isin(v) if isinstance(v,(list,tuple,set)) else df[k]==v]
    return df.copy()


def table(name):return pd.read_csv(STATS/f'{name}.csv')


def decorate(ax,letter=None,grid=None,zero=False):
    ax.tick_params(direction='out',length=4,width=.9,pad=4)
    ax.set_axisbelow(True)
    if grid:ax.grid(axis=grid,color='#E5EAEE',lw=.45)
    if zero:ax.axvline(0,color='#6B7784',lw=.85,ls=(0,(3,2)),zorder=0)
    if letter:ax.text(0,1.12,letter,transform=ax.transAxes,ha='left',va='bottom',fontsize=11,weight='bold')


def panel(ax,letter,title='',subtitle=None):
    ax.text(0,1.085,letter,transform=ax.transAxes,ha='left',va='bottom',fontsize=12,weight='bold')
    if title:ax.annotate(title,(0,1.085),xycoords='axes fraction',xytext=(16,0),textcoords='offset points',ha='left',va='bottom',fontsize=10.5,weight='bold')
    if subtitle:ax.text(0,1.015,subtitle,transform=ax.transAxes,ha='left',va='bottom',fontsize=8.6,color=MUTED)


def heading(fig,title,note=None):
    # Whole-figure titles belong in manuscript captions.
    if note:fig.text(.025,.928,note,ha='left',va='top',fontsize=8.6,color=MUTED)


def row_guides(ax,n,offset=0):
    for y in np.arange(n)+offset:
        ax.axhline(y+.5,color=LIGHT,lw=.65,zorder=0)


def register(ax,record):
    if not hasattr(ax,'_plot_records'):ax._plot_records=[]
    ax._plot_records.append(record)


def fit_records(ax,axis='y',pad=.08,zero=False):
    """Include every registered observation and interval on the requested axis."""
    values=[]
    for r in getattr(ax,'_plot_records',[]):
        if r['type']=='estimate_interval':
            if (axis=='x')==r['horizontal']:values.extend([r['mean'],r['low'],r['high']])
        elif r['type']=='seed_blocks':values.extend(r[axis])
    lo,hi=float(min(values)),float(max(values))
    if getattr(ax,f'get_{axis}scale')()=='log':
        if lo<=0:raise ValueError('Nonpositive observation on a logarithmic axis')
        delta=max(np.log10(hi)-np.log10(lo),.1)*pad
        limits=(10**(np.log10(lo)-delta),10**(np.log10(hi)+delta))
    else:
        if zero:lo=min(0,lo);hi=max(0,hi)
        delta=max(hi-lo,1e-8)*pad;limits=(0 if zero and lo==0 else lo-delta,hi+delta)
    getattr(ax,f'set_{axis}lim')(*limits)


def interval(ax,pos,mu,lo,hi,color=INK,marker='o',horizontal=True,solid=True,source=None,size=5.4):
    mu,lo,hi,pos=map(float,[mu,lo,hi,pos])
    if not np.isfinite([mu,lo,hi,pos]).all() or lo>hi:raise ValueError('Invalid plotted interval')
    # Draw the interval independently of the estimate: a BCa interval need not
    # contain its arithmetic point estimate in every possible input table.
    if horizontal:
        ax.plot([lo,hi],[pos,pos],color=INK,lw=1.25,zorder=6,solid_capstyle='round')
        ax.plot([lo,hi],[pos,pos],linestyle='none',marker='|',ms=8,mew=1.1,color=INK,zorder=6)
        ax.plot(mu,pos,marker=marker,ms=size,mfc=color if solid else 'white',mec=INK,mew=.75,ls='none',zorder=7)
    else:
        ax.plot([pos,pos],[lo,hi],color=INK,lw=1.25,zorder=6,solid_capstyle='round')
        ax.plot([pos,pos],[lo,hi],linestyle='none',marker='_',ms=8,mew=1.1,color=INK,zorder=6)
        ax.plot(pos,mu,marker=marker,ms=size,mfc=color if solid else 'white',mec=INK,mew=.75,ls='none',zorder=7)
    register(ax,{'type':'estimate_interval','horizontal':horizontal,'position':pos,'mean':mu,'low':lo,'high':hi,'solid':bool(solid),'source_row':source or {}})


def legend(fig,arms=ARMS,y=.985,ncol=None):
    handles=[Line2D([],[],color=COLOR[a],marker=MARKER[a],mec=INK,mew=.6,ls=LINESTYLE[a],ms=5.4,lw=1.7,label=LABEL[a]) for a in arms]
    return fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,y),ncol=ncol or len(arms),
                      columnspacing=1.4,handlelength=1.4,handletextpad=.5)


def mean_ci(ax,x,rows,arm,horizontal=False,offset=0,solid=True):
    for xx,(_,r) in zip(x,rows.iterrows()):
        mu=float(r['mean'] if 'mean' in r else r['mean_difference'])
        lo=float(r.bca95_low);hi=float(r.bca95_high)
        src=r.to_dict();src['row_index']=str(r.name);src['plotted_arm']=arm
        interval(ax,xx+offset,mu,lo,hi,COLOR[arm],MARKER[arm],horizontal,solid,src)


def log_axis(ax,axis='y'):
    getattr(ax,f'set_{axis}scale')('log')
    ax.minorticks_off()
    getattr(ax,f'{axis}axis').set_major_formatter(ScalarFormatter())


def save(fig,name,out,sources,caption,panels=True):
    out.mkdir(parents=True,exist_ok=True)
    from matplotlib.text import Text
    for text in fig.findobj(match=Text):
        if text.get_fontsize()<8.5:text.set_fontsize(8.5)
    fig.canvas.draw()
    source=[]
    for path in sources:
        p=Path(path);source.append({'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p)})
    # Numeric ledger and visible axis contract travel with each figure.
    axes_data=[];clipped=[];cropped_points=[]
    for i,ax in enumerate(fig.axes):
        rr=getattr(ax,'_plot_records',[])
        ad={'panel':chr(97+i),'xlim':list(map(float,ax.get_xlim())),'ylim':list(map(float,ax.get_ylim())),
            'xscale':ax.get_xscale(),'yscale':ax.get_yscale(),'records':rr}
        for q in rr:
            if q['type']=='estimate_interval':
                limits=sorted(ax.get_xlim() if q['horizontal'] else ax.get_ylim())
                if min(q['mean'],q['low'])<limits[0]-1e-10 or max(q['mean'],q['high'])>limits[1]+1e-10:clipped.append([i,q])
                position_limits=sorted(ax.get_ylim() if q['horizontal'] else ax.get_xlim())
                if not position_limits[0]<=q['position']<=position_limits[1]:clipped.append([i,q])
            elif q['type'] in ['seed_blocks','ecdf','geometry']:
                keys={'seed_blocks':('x','y'),'ecdf':('duration_s','fraction'),'geometry':('separation_m','tilt_deg')}[q['type']]
                for axis,key in zip(['x','y'],keys):
                    values=np.asarray(q[key],dtype=float);limits=sorted(getattr(ax,f'get_{axis}lim')())
                    if not np.isfinite(values).all() or values.min()<limits[0]-1e-10 or values.max()>limits[1]+1e-10:
                        cropped_points.append({'panel':i,'type':q['type'],'axis':axis,'range':[float(values.min()),float(values.max())],'limits':limits})
        axes_data.append(ad)
    if clipped:raise ValueError(f'{name}: interval cropped by visible limits: {clipped}')
    if cropped_points:raise ValueError(f'{name}: observations cropped by visible limits: {cropped_points}')
    # Validate every coordinate before creating any image-format artifact.
    files={}
    for ext,dpi in [('pdf',None),('svg',None),('png',1000)]:
        p=out/f'{name}.{ext}'
        metadata=({'Creator':'Matplotlib','CreationDate':None,'ModDate':None} if ext=='pdf' else {'Date':None} if ext=='svg' else None)
        fig.savefig(p,dpi=dpi,metadata=metadata)
        files[ext]={'path':p.name,'sha256':sha(p),'bytes':p.stat().st_size}
    ledger=out/f'{name}.plot_data.json'
    def clean(v):
        if isinstance(v,np.generic):return clean(v.item())
        if isinstance(v,np.ndarray):return clean(v.tolist())
        if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
        if isinstance(v,(list,tuple)):return [clean(x) for x in v]
        if isinstance(v,float) and not np.isfinite(v):return None
        return v
    ledger.write_text(json.dumps(clean({'figure':name,'sources':source,'axes':axes_data,'clipped_intervals':clipped,'cropped_observations':cropped_points}),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    panel_files=[]
    panel_artifacts=[]
    if panels and len(fig.axes)>1:
        from publication_panels import panel_contract
        import textwrap
        original_size=fig.get_size_inches().copy()
        original_positions=[ax.get_position().frozen() for ax in fig.axes]
        shared_legends=list(fig.legends)
        shared_text=list(fig.texts)
        handles=[h for leg in shared_legends for h in leg.legend_handles]
        labels=[t.get_text() for leg in shared_legends for t in leg.texts]
        for item in shared_legends+shared_text:item.set_visible(False)
        for i,ax in enumerate(fig.axes):
            contract=panel_contract(name,i)
            original_axis_fonts={text:text.get_fontsize() for text in ax.findobj(match=Text)}
            original_marks=[]
            if getattr(ax,'_plot_records',[]):
                for line in ax.lines:
                    marker=line.get_marker()
                    if marker in set(MARKER.values()) | {'|','_'}:
                        original_marks.append((line,line.get_markersize(),line.get_markeredgewidth()))
                        line.set_markersize(9 if marker in {'|','_'} else 6.4)
                        line.set_markeredgewidth(1.15 if marker in {'|','_'} else .85)
            for other in fig.axes:other.set_visible(other is ax)
            fig.set_size_inches(contract['width_mm']*MM,contract['height_mm']*MM)
            ax.set_position(contract['bounds'])
            original_yticklabels=[t.get_text() for t in ax.get_yticklabels()]
            if hasattr(ax,'_standalone_yticklabels'):
                ax.set_yticklabels(ax._standalone_yticklabels)
            ax.xaxis.label.set_fontsize(12)
            ax.yaxis.label.set_fontsize(12)
            for label in ax.get_xticklabels()+ax.get_yticklabels():label.set_fontsize(11.5)
            axis_legend=ax.get_legend()
            if axis_legend:
                for label in axis_legend.get_texts():label.set_fontsize(11.5)
            added=[]
            if handles and not getattr(ax,'_omit_shared_legend',False):
                added.append(fig.legend(handles,labels,ncol=min(3,len(handles)),
                    loc='upper center',bbox_to_anchor=(.54,.235),
                    borderaxespad=0,fontsize=11.5,handlelength=1.7,handletextpad=.5,columnspacing=1.5))
            lines=[line for note in contract['notes'] for line in textwrap.wrap(note,width=113)]
            for j,line in enumerate(lines):
                added.append(fig.text(.065,.181-j*11/(contract['height_mm']*72/25.4),line,
                    fontsize=8.5,va='top',ha='left',color=INK))
            fig.canvas.draw()
            panel_name=f'{name}{chr(97+i)}'
            dest_dir=out/'panels';dest_dir.mkdir(exist_ok=True)
            formats={}
            for ext,dpi in [('pdf',None),('svg',None),('png',1000)]:
                dest=dest_dir/f'{panel_name}.{ext}'
                metadata=({'Creator':'Matplotlib','CreationDate':None,'ModDate':None} if ext=='pdf' else {'Date':None} if ext=='svg' else None)
                fig.savefig(dest,dpi=dpi,metadata=metadata)
                formats[ext]={'path':dest.relative_to(out).as_posix(),'sha256':sha(dest),'bytes':dest.stat().st_size}
            panel_ledger=dest_dir/f'{panel_name}.plot_data.json'
            panel_ledger.write_text(json.dumps(clean({'figure':panel_name,'sources':source,
                'axes':[axes_data[i]],'clipped_intervals':[],'cropped_observations':[],
                'reading_layout':contract}),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
            with pdfplumber.open(dest_dir/f'{panel_name}.pdf') as doc:
                page=doc.pages[0]
                outside=[c['text'] for c in page.chars if c['text'].strip() and
                    (min(c['x0'],c['top'])<-.4 or c['x1']>page.width+.4 or c['bottom']>page.height+.4)]
                if outside:raise ValueError(f'{panel_name}: text outside reading canvas: {outside}')
            panel_files.append(formats['pdf'])
            panel_artifacts.append({'figure':panel_name,'files':formats,
                'plot_data':{'path':panel_ledger.relative_to(out).as_posix(),'sha256':sha(panel_ledger)},
                'width_mm':contract['width_mm'],'height_mm':contract['height_mm'],'notes':contract['notes']})
            for item in added:item.remove()
            if hasattr(ax,'_standalone_yticklabels'):ax.set_yticklabels(original_yticklabels)
            for text,size in original_axis_fonts.items():text.set_fontsize(size)
            for line,size,edge in original_marks:line.set_markersize(size);line.set_markeredgewidth(edge)
        fig.set_size_inches(original_size)
        for ax,position in zip(fig.axes,original_positions):ax.set_position(position);ax.set_visible(True)
        for item in shared_legends+shared_text:item.set_visible(True)
    with pdfplumber.open(out/f'{name}.pdf') as doc:
        page=doc.pages[0]; chars=[c for c in page.chars if c['text'].strip()]
        outside=[c['text'] for c in chars if min(c['x0'],c['top'])<-.4 or c['x1']>page.width+.4 or c['bottom']>page.height+.4]
        sizes=[c['size'] if c['upright'] else c['width'] for c in chars]
        qa={'width_mm':page.width*25.4/72,'height_mm':page.height*25.4/72,
            'minimum_font_pt':min(sizes),'outside_text':outside,'raster_images_in_pdf':len(page.images)}
    plt.close(fig)
    generator=[{'path':'tools/'+n,'sha256':sha(ROOT/'tools'/n)} for n in
               ['publication_style.py','publication_figures.py','publication_schematics.py','publication_panels.py','figure_captions.json']]
    qa['clipped_intervals']=0
    qa['cropped_observations']=0
    qa['interval_count']=sum(q['type']=='estimate_interval' for a in axes_data for q in a['records'])
    return {'files':files,'panel_files':panel_files,'panel_artifacts':panel_artifacts,'plot_data':{'path':ledger.name,'sha256':sha(ledger)},'sources':source,'generator':generator,'caption':caption,'qa':qa}
