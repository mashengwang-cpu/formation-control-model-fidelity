"""Analyse the frozen prospective design without changing execution inputs.

See evidence/REVISION_STATISTICAL_ANALYSIS_PLAN.json. A design reference is
identified by design_id; a physical execution by job_id. Shared references
are never counted as new runs. Incomplete families are blocked, not repaired
by removing failed seeds or averaging partial scenario blocks.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "simulation/src"))
from finite_control_sim.statistics import (
    bca_mean_ci, bca_paired_ratio_ci, holm_adjust, matched_pairs_rank_biserial,
    paired_hodges_lehmann, wilcoxon_r_from_z,
)

PLAN = ROOT.parent / "evidence/REVISION_STATISTICAL_ANALYSIS_PLAN.json"
METRICS = ["formation_tracking_error", "control_energy", "event_trigger_count"]
MODULES = ["tvg", "powers", "approximator", "observer", "faultcomp", "ppt", "topology"]
ATTITUDE_ARMS = ["full_no_ppt", "minimal", "ko_tvg", "ko_powers", "ko_approximator", "ko_observer"]


def load_manifest(path: Path) -> pd.DataFrame:
    if path.suffix.lower() != ".json":
        return pd.read_csv(path)
    rows = []
    for item in json.loads(path.read_text(encoding="utf-8")):
        row = {k: v for k, v in item.items() if k not in {"job", "simulation_overrides"}}
        job = item["job"]; sim = item["simulation_overrides"]
        row.update(job)
        row.update(gamma=job["topology_feedback_gain"],
                   information_mode=job["resilience_information_mode"],
                   attitude_response_scale=job["uav_attitude_bandwidth_scale"],
                   efficiency_gain=sim["resilience_efficiency_gain"],
                   efficiency_alignment_min=sim["resilience_efficiency_alignment_min"],
                   trigger_base_threshold=sim.get("event_trigger_threshold", 0.035))
        rows.append(row)
    return pd.DataFrame(rows)


def validate_reference_integrity(frame: pd.DataFrame, manifest: pd.DataFrame,
                                 plan: dict) -> list[str]:
    errors = []
    required = set(plan["required_input_columns"])
    missing = sorted(required - set(frame.columns))
    if missing:
        return [f"Missing required result columns: {missing}"]
    for label, table in [("results", frame), ("manifest", manifest)]:
        if table.design_id.duplicated().any():
            errors.append(f"Duplicate design_id in {label}")
    extra = set(frame.design_id) - set(manifest.design_id)
    if extra:
        errors.append(f"{len(extra)} unregistered design references present")
    if errors:
        return errors
    common = [c for c in manifest.columns if c in frame.columns
              and c not in {*METRICS, "actual_control_energy", "status"}]
    left = frame.set_index("design_id")
    right = manifest.set_index("design_id").reindex(left.index)
    for col in common:
        if col == "design_id":
            continue
        a, b = left[col], right[col]
        if pd.api.types.is_numeric_dtype(a) and pd.api.types.is_numeric_dtype(b):
            equal = np.isclose(a.to_numpy(float), b.to_numpy(float), rtol=1e-12, atol=1e-12, equal_nan=True)
        else:
            equal = a.fillna("<NA>").astype(str).str.lower().to_numpy() == b.fillna("<NA>").astype(str).str.lower().to_numpy()
        if not bool(np.all(equal)):
            errors.append(f"Manifest/result configuration mismatch: {col} ({int(np.sum(~equal))} rows)")
    # Repeated physical jobs must contain identical metrics and outcomes.
    for col in [*METRICS, "actual_control_energy", "status"]:
        if (frame.groupby("job_id")[col].nunique(dropna=False) > 1).any():
            errors.append(f"Shared physical job_id has conflicting {col}")
    if not frame.status.isin(["ok", "error"]).all():
        errors.append("Only explicit status=ok/error is supported")
    if not (frame.replicate_split == "test").all():
        errors.append("Non-test data cannot enter this frozen analysis")
    return errors


def seed_blocks(rows: pd.DataFrame, scenarios: list[str], seeds: list[int],
                metric: str) -> pd.Series:
    if rows.empty:
        raise ValueError("Required design arm is absent")
    if not (rows.status == "ok").all():
        raise ValueError("Failed physical executions present; no seed replacement or deletion")
    if rows.duplicated(["seed", "scenario"]).any():
        raise ValueError("More than one design reference within a seed/scenario arm")
    actual = set(zip(rows.seed.astype(int), rows.scenario.astype(str)))
    expected = {(int(seed), scenario) for seed in seeds for scenario in scenarios}
    if actual != expected:
        raise ValueError(f"Incomplete or extra seed/scenario blocks: missing={len(expected-actual)}, extra={len(actual-expected)}")
    if not np.isfinite(rows[metric].to_numpy(float)).all():
        raise ValueError(f"Nonfinite endpoint {metric}; no complete-case filtering")
    return rows.groupby("seed", sort=True)[metric].mean().reindex(seeds)


def choose(frame: pd.DataFrame, **conditions) -> pd.DataFrame:
    selected = frame
    for key, value in conditions.items():
        if isinstance(value, float):
            selected = selected[np.isclose(selected[key].to_numpy(float), value, rtol=0, atol=1e-12)]
        else:
            selected = selected[selected[key] == value]
    return selected


def difference_record(diff: np.ndarray, *, inferential: bool = True,
                      x: np.ndarray | None = None, y: np.ndarray | None = None,
                      **identifiers) -> dict:
    diff = np.asarray(diff, float)
    if not np.isfinite(diff).all() or len(diff) < 2:
        raise ValueError("At least two finite paired blocks are required")
    estimate, lo, hi = bca_mean_ci(diff)
    row = {**identifiers, "n_paired_seeds": len(diff), "mean_difference": estimate,
           "bca95_low": lo, "bca95_high": hi, "median_difference": float(np.median(diff)),
           "hodges_lehmann": paired_hodges_lehmann(diff),
           "paired_rank_biserial": matched_pairs_rank_biserial(diff),
           "signed_wilcoxon_r": wilcoxon_r_from_z(diff),
           "fraction_negative": float(np.mean(diff < 0)), "fraction_positive": float(np.mean(diff > 0)),
           "interval_method": "pointwise_BCa_seed_block_mean_difference",
           "bootstrap_samples": 20000, "bootstrap_seed": 1234,
            "evidence_status": "new_locally_frozen_design_results"}
    if x is not None and y is not None:
        row["arm_mean"] = float(np.mean(x)); row["reference_mean"] = float(np.mean(y))
        if np.all(np.asarray(y) > 0):
            if np.array_equal(np.asarray(x), np.asarray(y)):
                ratio = rlo = rhi = 0.0
            else:
                ratio, rlo, rhi = bca_paired_ratio_ci(x, y)
            row.update(relative_mean_change=ratio, relative_change_bca95_low=rlo,
                       relative_change_bca95_high=rhi,
                       ratio_definition="(mean_arm-mean_reference)/mean_reference; paired denominator resampled")
    if inferential:
        row["p_value"] = 1.0 if np.all(diff == 0) else float(stats.wilcoxon(diff, zero_method="wilcox", alternative="two-sided").pvalue)
    return row


def finish_family(rows: list[dict], expected_count: int, family: str) -> pd.DataFrame:
    if len(rows) != expected_count:
        raise ValueError(f"Family {family}: expected {expected_count} hypotheses, found {len(rows)}")
    table = pd.DataFrame(rows)
    table["holm_family"] = family
    table["holm_family_size"] = expected_count
    table["holm_adjusted_p"] = holm_adjust(table.p_value.to_numpy(float))
    table["reject_at_0_05"] = table.holm_adjusted_p < .05
    return table


def analyse_core(frame: pd.DataFrame, plan: dict) -> pd.DataFrame:
    out=[]
    for plant in plan["plants"]:
        scope=choose(frame,campaign="core_fixed",plant_model=plant)
        for arm in ["minimal","full_no_ppt"]:
            for metric in METRICS:
                x=seed_blocks(choose(scope,arm_id=arm),plan["scenarios"],plan["test_seeds"],metric).to_numpy()
                y=seed_blocks(choose(scope,arm_id="family"),plan["scenarios"],plan["test_seeds"],metric).to_numpy()
                out.append(difference_record(x-y,x=x,y=y,plant_model=plant,arm_id=arm,
                                             reference_arm_id="family",metric=metric,
                                             contrast="arm_minus_family"))
    return finish_family(out,18,"core_fixed")


def module_differences(frame: pd.DataFrame, plan: dict) -> dict:
    result={}
    for plant in plan["plants"]:
        scope=choose(frame,campaign="module_ablation",plant_model=plant)
        base=seed_blocks(choose(scope,arm_id="full_no_ppt"),plan["scenarios"],plan["test_seeds"],METRICS[0]).to_numpy()
        for module in MODULES:
            arm=choose(scope,module=module)
            if arm.arm_id.nunique()!=1:
                raise ValueError(f"Expected one registered intervention arm for {plant}/{module}")
            current=seed_blocks(arm,plan["scenarios"],plan["test_seeds"],METRICS[0]).to_numpy()
            # PPT is added to the no-PPT reference; all other arms remove one
            # module from it. Positive module effect always means harmful.
            effect=current-base if module=="ppt" else base-current
            result[(plant,module)]={"effect":effect,"current":current,"base":base,
                                    "arm_id":str(arm.arm_id.iloc[0]),
                                    "module_on_arm_id":str(arm.arm_id.iloc[0]) if module=="ppt" else "full_no_ppt",
                                    "module_off_arm_id":"full_no_ppt" if module=="ppt" else str(arm.arm_id.iloc[0])}
    return result


def analyse_modules(frame: pd.DataFrame, plan: dict) -> pd.DataFrame:
    out=[]
    for (plant,module),value in module_differences(frame,plan).items():
        on=value["current"] if module=="ppt" else value["base"]
        off=value["base"] if module=="ppt" else value["current"]
        out.append(difference_record(value["effect"],plant_model=plant,module=module,
                                     arm_id=value["arm_id"],module_on_arm_id=value["module_on_arm_id"],
                                     module_off_arm_id=value["module_off_arm_id"],
                                     module_on_mean=float(on.mean()),module_off_mean=float(off.mean()),
                                     arm_minus_reference_mean=float((value["current"]-value["base"]).mean()),
                                     metric=METRICS[0],contrast="J_module_on_minus_J_module_off"))
    return finish_family(out,21,"module_effect")


def analyse_crossfidelity(frame: pd.DataFrame, plan: dict) -> pd.DataFrame:
    effects=module_differences(frame,plan);out=[]
    for high,low in plan["families"]["cross_fidelity_interaction"]["comparisons"]:
        for module in MODULES:
            a=effects[(high,module)]["effect"];b=effects[(low,module)]["effect"]
            out.append(difference_record(a-b,high_plant=high,reference_plant=low,module=module,
                                         high_module_effect=float(a.mean()),reference_module_effect=float(b.mean()),
                                         metric=METRICS[0],contrast="module_effect_high_minus_point_mass"))
    return finish_family(out,14,"cross_fidelity_interaction")


def attitude_differences(frame: pd.DataFrame, plan: dict) -> dict:
    scope=choose(frame,campaign="attitude_intervention",plant_model="mixed_6dof_3dof")
    if len(scope) and (not (scope.uav_count==4).all() or not (scope.usv_count==0).all()):
        raise ValueError("Attitude intervention must be UAV-only (4 UAV, 0 USV)")
    result={};scenarios=plan["families"]["attitude_scale_effect"]["scenarios"]
    for arm in ATTITUDE_ARMS:
        base=seed_blocks(choose(scope,arm_id=arm,attitude_response_scale=1.0),scenarios,plan["test_seeds"],METRICS[0]).to_numpy()
        for scale in [.5,2.0]:
            current=seed_blocks(choose(scope,arm_id=arm,attitude_response_scale=scale),scenarios,plan["test_seeds"],METRICS[0]).to_numpy()
            result[(arm,scale)]={"effect":current-base,"current":current,"base":base}
    return result


def analyse_attitude(frame: pd.DataFrame,plan:dict) -> pd.DataFrame:
    out=[]
    for (arm,scale),value in attitude_differences(frame,plan).items():
        out.append(difference_record(value["effect"],arm_id=arm,attitude_response_scale=scale,
                                     reference_scale=1.0,metric=METRICS[0],
                                     current_mean=float(value["current"].mean()),reference_mean=float(value["base"].mean()),
                                     contrast="J_scale_s_minus_J_scale_1"))
    return finish_family(out,12,"attitude_scale_effect")


def analyse_attitude_interaction(frame: pd.DataFrame,plan:dict) -> pd.DataFrame:
    effects=attitude_differences(frame,plan);out=[]
    for arm in [a for a in ATTITUDE_ARMS if a!="minimal"]:
        for scale in [.5,2.0]:
            a=effects[(arm,scale)]["effect"];b=effects[("minimal",scale)]["effect"]
            out.append(difference_record(a-b,arm_id=arm,reference_arm_id="minimal",
                                         attitude_response_scale=scale,reference_scale=1.0,metric=METRICS[0],
                                         contrast="[J_arm_s-J_arm_1]-[J_minimal_s-J_minimal_1]"))
    return finish_family(out,10,"attitude_interaction")


def descriptive_outputs(frame:pd.DataFrame,plan:dict) -> tuple[pd.DataFrame,pd.DataFrame]:
    means=[];contrasts=[]
    for campaign in ["core_fixed","module_ablation","attitude_intervention",*plan["descriptive_campaigns"]]:
        scope=choose(frame,campaign=campaign)
        if scope.empty:continue
        seeds=plan["robustness_seeds"] if campaign=="robustness" else plan["test_seeds"]
        scenarios=plan["families"]["attitude_scale_effect"]["scenarios"] if campaign=="attitude_intervention" else plan["scenarios"]
        for (plant,arm,condition),group in scope.groupby(["plant_model","arm_id","condition"],dropna=False):
            for metric in [*METRICS,"actual_control_energy"]:
                identity=dict(campaign=campaign,plant_model=plant,arm_id=arm,condition=condition,metric=metric)
                try:
                    values=seed_blocks(group,scenarios,seeds,metric).to_numpy()
                    mean,lo,hi=bca_mean_ci(values)
                    means.append({**identity,"status":"complete","n_seeds":len(values),"mean":mean,
                                  "bca95_low":lo,"bca95_high":hi,"interval_method":"pointwise_BCa_seed_block_mean",
                                  "bootstrap_samples":20000,"bootstrap_seed":1234})
                except ValueError as exc:
                    means.append({**identity,"status":"blocked","reason":str(exc),"registered_seeds":len(seeds)})
        if campaign not in plan["descriptive_campaigns"]:continue
        # Paired method contrasts at each condition. Baselines are explicit
        # design references inside the same campaign; no implicit reuse.
        for (plant,condition),group in scope.groupby(["plant_model","condition"],dropna=False):
            for arm in ["minimal","full_no_ppt"]:
                for metric in METRICS:
                    identity=dict(campaign=campaign,plant_model=plant,condition=condition,
                                  arm_id=arm,reference_arm_id="family",metric=metric,contrast="arm_minus_family_descriptive")
                    try:
                        x=seed_blocks(choose(group,arm_id=arm),scenarios,seeds,metric).to_numpy()
                        y=seed_blocks(choose(group,arm_id="family"),scenarios,seeds,metric).to_numpy()
                        contrasts.append({"status":"complete",**difference_record(x-y,inferential=False,x=x,y=y,**identity)})
                    except ValueError as exc:
                        contrasts.append({**identity,"status":"blocked","reason":str(exc)})
        # Within-method condition changes isolate information / perturbation /
        # budget changes. They are descriptive, regardless of CI sign.
        reference_condition={"gain_sensitivity":"gains_2.15_2.05","refresh_tradeoff":"threshold_0.035",
                             "robustness":"baseline","information_contract":"causal"}[campaign]
        for (plant,arm,condition),group in scope.groupby(["plant_model","arm_id","condition"],dropna=False):
            if condition==reference_condition:continue
            for metric in METRICS:
                identity=dict(campaign=campaign,plant_model=plant,arm_id=arm,condition=condition,
                              reference_condition=reference_condition,metric=metric,contrast="condition_minus_registered_reference_descriptive")
                try:
                    x=seed_blocks(group,scenarios,seeds,metric).to_numpy()
                    y=seed_blocks(choose(scope,plant_model=plant,arm_id=arm,condition=reference_condition),scenarios,seeds,metric).to_numpy()
                    contrasts.append({"status":"complete",**difference_record(x-y,inferential=False,x=x,y=y,**identity)})
                except ValueError as exc:
                    contrasts.append({**identity,"status":"blocked","reason":str(exc)})
    return pd.DataFrame(means),pd.DataFrame(contrasts)


def run_analysis(frame:pd.DataFrame,manifest:pd.DataFrame,plan:dict,out:Path) -> dict:
    out.mkdir(parents=True,exist_ok=True)
    failures=frame[frame.status!="ok"] if "status" in frame else frame
    failures.to_csv(out/"failure_rows.csv",index=False)
    integrity=validate_reference_integrity(frame,manifest,plan)
    missing=manifest[~manifest.design_id.isin(frame.design_id)] if "design_id" in frame else manifest
    missing.to_csv(out/"missing_design_references.csv",index=False)
    status={"analysis_plan_version":plan["version"],"integrity_errors":integrity,
            "registered_design_references":len(manifest),"observed_design_references":len(frame),
            "registered_unique_physical_jobs":int(manifest.job_id.nunique()),
            "observed_unique_physical_jobs":int(frame.job_id.nunique()) if "job_id" in frame else 0,
            "failed_unique_physical_jobs":int(failures.job_id.nunique()) if "job_id" in failures else None,
            "missing_design_references":len(missing),"families":{},
            "intervals":"Pointwise BCa, not simultaneous. Mean CIs and signed-rank tests have different estimands."}
    functions={"core_fixed":analyse_core,"module_effect":analyse_modules,
               "cross_fidelity_interaction":analyse_crossfidelity,
               "attitude_scale_effect":analyse_attitude,"attitude_interaction":analyse_attitude_interaction}
    for name,func in functions.items():
        try:
            if integrity:raise ValueError("Input/manifest integrity validation failed")
            table=func(frame,plan)
            table.to_csv(out/f"{name}.csv",index=False)
            status["families"][name]={"status":"complete","hypotheses":len(table)}
        except (ValueError,KeyError) as exc:
            # Overwrite any prior output of this analysis directory with an
            # explicit blocked marker; never leave a stale success table.
            pd.DataFrame([{"status":"blocked","reason":str(exc)}]).to_csv(out/f"{name}.csv",index=False)
            status["families"][name]={"status":"blocked","reason":str(exc)}
    if not integrity:
        means,contrasts=descriptive_outputs(frame,plan)
        means.to_csv(out/"method_means.csv",index=False)
        contrasts.to_csv(out/"descriptive_contrasts.csv",index=False)
    status["status"]="complete" if not integrity and not len(missing) and not len(failures) and all(v["status"]=="complete" for v in status["families"].values()) else "incomplete_or_blocked"
    (out/"analysis_status.json").write_text(json.dumps(status,indent=2),encoding="utf-8")
    return status


def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",type=Path,default=ROOT/"data/revision/runs.csv")
    parser.add_argument("--manifest",type=Path,default=ROOT/"data/revision/planned_jobs.csv")
    parser.add_argument("--plan",type=Path,default=PLAN)
    parser.add_argument("--output",type=Path,default=ROOT/"data/revision_statistics/new_experiments")
    args=parser.parse_args()
    if args.output.resolve().is_relative_to((ROOT/"data").resolve()) and not args.output.resolve().is_relative_to((ROOT/"data/revision_statistics").resolve()):
        raise ValueError("Analysis outputs under data/ must stay within data/revision_statistics/")
    # The execution ledger can grow while this analysis runs. Parse, archive,
    # and hash the same immutable byte string, never re-read the live file.
    input_bytes=args.input.read_bytes()
    frame=pd.read_csv(io.BytesIO(input_bytes))
    args.output.mkdir(parents=True,exist_ok=True)
    snapshot=args.output/"runs_snapshot.csv"
    snapshot.write_bytes(input_bytes)
    manifest_bytes=args.manifest.read_bytes();plan_bytes=args.plan.read_bytes()
    manifest_snapshot=args.output/("manifest_snapshot"+args.manifest.suffix.lower())
    plan_snapshot=args.output/"plan_snapshot.json"
    manifest_snapshot.write_bytes(manifest_bytes);plan_snapshot.write_bytes(plan_bytes)
    analysis_bytes=Path(__file__).read_bytes()
    analysis_snapshot=args.output/"analysis_script_snapshot.py"
    analysis_snapshot.write_bytes(analysis_bytes)
    manifest=load_manifest(manifest_snapshot)
    plan=json.loads(plan_bytes.decode("utf-8"))
    status=run_analysis(frame,manifest,plan,args.output)
    provenance={"input_sha256":hashlib.sha256(input_bytes).hexdigest(),
                "input_snapshot_path":str(snapshot.resolve()),
                "input_source_path":str(args.input.resolve()),
                "manifest_sha256":hashlib.sha256(manifest_bytes).hexdigest(),
                "manifest_snapshot_path":str(manifest_snapshot.resolve()),
                "manifest_source_path":str(args.manifest.resolve()),
                "plan_sha256":hashlib.sha256(plan_bytes).hexdigest(),
                "plan_snapshot_path":str(plan_snapshot.resolve()),
                "plan_source_path":str(args.plan.resolve()),
                "analysis_script_sha256":hashlib.sha256(analysis_bytes).hexdigest(),
                "analysis_script_snapshot_path":str(analysis_snapshot.resolve()),
                "analysis_script_source_path":str(Path(__file__).resolve()),
                "numpy":np.__version__,"pandas":pd.__version__,"python":sys.version}
    (args.output/"analysis_provenance.json").write_text(json.dumps(provenance,indent=2),encoding="utf-8")
    print(json.dumps(status,indent=2))
    return 0 if status["status"]=="complete" else 2


if __name__=="__main__":
    raise SystemExit(main())
