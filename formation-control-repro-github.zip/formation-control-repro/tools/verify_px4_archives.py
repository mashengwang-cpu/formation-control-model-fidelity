"""Verify the eight PX4 evidence ZIPs in place without extracting any file.

Default: ZIP CRC, uncompressed member byte counts/SHA-256, receipt bindings,
frozen source identity, and complete design/attempt coverage. --deep additionally
streams every compressed attempt's tar members against its transfer receipt.
It never creates or follows the archived external dependency symbolic links.
Scientific failures remain failures; archive integrity is not flight validity.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PREFIX = 'px4_evidence/'
EXPECTED_BUNDLES = [f'PX4_Evidence_{n:02d}.zip' for n in range(1, 9)]


def safe_name(name):
    path = PurePosixPath(name)
    if not name or path.is_absolute() or '\\' in name or ':' in name or any(p in ('', '.', '..') for p in name.split('/')):
        raise ValueError(f'Unsafe archive member name: {name!r}')
    if path.as_posix() != name:
        raise ValueError(f'Noncanonical archive member name: {name!r}')
    return path


def digest_stream(stream):
    digest = hashlib.sha256()
    count = 0
    for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
        count += len(block)
        digest.update(block)
    return count, digest.hexdigest()


def csv_rows(data):
    return list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))


def verify_tar(stream, receipt, attempt_name):
    """Read tar member bytes and links as metadata; never materialize paths."""
    expected = {}
    for item in receipt['files']:
        safe_name(item['path'])
        if item['path'] in expected:
            raise ValueError('Duplicate receipt member: ' + item['path'])
        expected[item['path']] = item
    checked = set()
    regular_files = regular_bytes = symbolic_links = 0
    with tarfile.open(fileobj=stream, mode='r|gz') as archive:
        for member in archive:
            name = member.name.rstrip('/')
            path = safe_name(name)
            if path.parts[0] != attempt_name:
                raise ValueError('Tar entry has an unexpected attempt root: ' + name)
            relative = '/'.join(path.parts[1:])
            if member.isdir():
                continue
            if not relative or relative not in expected or relative in checked:
                raise ValueError('Unexpected or duplicate tar member: ' + name)
            item = expected[relative]
            if member.issym():
                if item.get('symlink') != member.linkname:
                    raise ValueError('Tar symbolic-link metadata differs: ' + relative)
                symbolic_links += 1
            elif member.isfile():
                if 'symlink' in item or member.size != int(item['bytes']):
                    raise ValueError('Tar file type or size differs: ' + relative)
                file_stream = archive.extractfile(member)
                if file_stream is None:
                    raise ValueError('Cannot read regular tar member: ' + relative)
                size, digest = digest_stream(file_stream)
                if size != int(item['bytes']) or digest != item['sha256']:
                    raise ValueError('Tar regular file hash differs: ' + relative)
                regular_files += 1
                regular_bytes += size
            else:
                raise ValueError('Unsupported tar member type: ' + relative)
            checked.add(relative)
    if checked != set(expected):
        raise ValueError('Tar member set differs from the transfer receipt')
    return dict(regular_files=regular_files, regular_bytes=regular_bytes, symbolic_links=symbolic_links)


def validate_cohort(metadata, attempts):
    manifest_name = PREFIX + 'FROZEN_900_JOBS.csv'
    freeze = json.loads(metadata[PREFIX + 'FREEZE.json'])
    manifest_bytes = metadata[manifest_name]
    if hashlib.sha256(manifest_bytes).hexdigest() != freeze['manifest_sha256']:
        raise ValueError('Frozen design manifest differs from FREEZE.json')
    planned = csv_rows(manifest_bytes)
    plan = {(r['campaign'], r['run_id']): r for r in planned}
    if len(planned) != 900 or len(plan) != 900 or set(int(r['seed']) for r in planned) != set(range(5000, 5020)):
        raise ValueError('Expected exactly 900 unique fixed design rows and seeds 5000–5019')
    if Counter(r['campaign'] for r in planned) != Counter(h1=200, h2=500, h3=200):
        raise ValueError('Frozen campaign sizes differ')
    for name, digest in freeze['source_sha256'].items():
        value = metadata[PREFIX + 'source_frozen/' + name]
        if hashlib.sha256(value).hexdigest() != digest:
            raise ValueError('Frozen source identity differs: ' + name)
    protocol = metadata[PREFIX + 'source_frozen/PROTOCOL_V21.md']
    if hashlib.sha256(protocol).hexdigest() != freeze['protocol_sha256']:
        raise ValueError('Frozen protocol identity differs')
    indexed = []
    for shard in range(8):
        for campaign in ('h1', 'h2', 'h3'):
            rel = PREFIX + f'shard_{shard}/{campaign}_px4/runs_index_{shard}_of_8.csv'
            for row in csv_rows(metadata[rel]):
                indexed.append(dict(row, shard=str(shard), campaign=campaign))
    actual = {(r['campaign'], r['run_id']): r for r in indexed}
    if len(indexed) != 900 or len(actual) != 900 or set(actual) != set(plan):
        raise ValueError('Indexes do not represent the exact 900-design manifest')
    expected_attempts = 0
    for key, row in actual.items():
        for field in ('shard', 'method', 'scenario', 'seed', 'contract'):
            if row[field] != plan[key][field]:
                raise ValueError(f'Index/manifest mismatch: {key}/{field}')
        count = int(row['attempt_count'])
        if not 1 <= count <= 3:
            raise ValueError('Attempt count violates the frozen retry bound')
        expected_attempts += count
        names = sorted(attempts.get((row['shard'], row['campaign'], row['run_id']), []))
        if len(names) != count or [int(n.split('_')[1]) for n in names] != list(range(count)):
            raise ValueError('Archives do not contain every indexed attempt: ' + str(key))
    if expected_attempts != 1291 or sum(map(len, attempts.values())) != 1291:
        raise ValueError('Expected exactly 1291 archived attempts')
    statuses = Counter(row['status'] for row in indexed)
    if statuses != Counter(ok=824, interface_or_simulator_failure=76):
        raise ValueError('Observed design failure accounting differs from the frozen cohort')
    manager = json.loads(metadata[PREFIX + 'campaign_status.json'])
    if manager['active'] or manager['pending_count'] != 0:
        raise ValueError('Archived manager is not terminal')
    return dict(designs=900, attempts=1291, design_statuses=dict(statuses),
                frozen_source_files=len(freeze['source_sha256']), hypotheses='All three remain blocked by failed required designs')


def verify(archives_dir, manifest_path, deep=False, bundle_hashes_path=None):
    started = time.monotonic()
    expected_rows = csv_rows(manifest_path.read_bytes())
    expected = {}
    for row in expected_rows:
        safe_name(row['member'])
        if not row['member'].startswith(PREFIX) or row['archive'] not in EXPECTED_BUNDLES:
            raise ValueError('Unexpected manifest bundle or root')
        key = row['archive'], row['member']
        if key in expected:
            raise ValueError('Duplicate release-manifest row')
        expected[key] = row
    if {r['archive'] for r in expected_rows} != set(EXPECTED_BUNDLES):
        raise ValueError('Release manifest must describe all eight evidence ZIPs')
    bundle_hashes = {}
    if bundle_hashes_path:
        for row in csv_rows(bundle_hashes_path.read_bytes()):
            if row['archive'] in bundle_hashes:
                raise ValueError('Duplicate outer ZIP hash row')
            bundle_hashes[row['archive']] = row
        if set(bundle_hashes) != set(EXPECTED_BUNDLES):
            raise ValueError('Outer ZIP hash table must describe exactly eight bundles')
    metadata, attempts, receipts, tar_records = {}, {}, {}, {}
    checked_members = checked_bytes = deep_files = deep_bytes = deep_links = 0
    bundles = []
    for bundle_name in EXPECTED_BUNDLES:
        path = archives_dir / bundle_name
        wanted = {member: row for (archive, member), row in expected.items() if archive == bundle_name}
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)) or set(names) != set(wanted):
                raise ValueError('ZIP member set differs from release manifest: ' + bundle_name)
            for info in archive.infolist():
                safe_name(info.filename)
                if info.is_dir() or stat.S_ISLNK(info.external_attr >> 16) or info.flag_bits & 1:
                    raise ValueError('Directory, link or encrypted ZIP member is not permitted')
                row = wanted[info.filename]
                if info.file_size != int(row['bytes']):
                    raise ValueError('ZIP member byte count differs: ' + info.filename)
                # Reading ZipExtFile to EOF also verifies its ZIP CRC-32.
                with archive.open(info) as stream:
                    size, digest = digest_stream(stream)
                if size != int(row['bytes']) or digest != row['sha256']:
                    raise ValueError('ZIP member SHA-256 differs: ' + info.filename)
                checked_members += 1
                checked_bytes += size
                if info.filename.endswith('.tar.gz'):
                    rel = PurePosixPath(info.filename.removeprefix(PREFIX))
                    if len(rel.parts) != 5 or rel.parts[2] != 'logs':
                        raise ValueError('Unexpected attempt archive location')
                    shard = str(int(rel.parts[0].removeprefix('shard_')))
                    campaign = rel.parts[1].removesuffix('_px4')
                    name = rel.name.removesuffix('.tar.gz')
                    attempts.setdefault((shard, campaign, rel.parts[3]), []).append(name)
                    tar_records[info.filename] = dict(archive=bundle_name, bytes=size, sha256=digest, attempt_name=name)
                else:
                    if size > 16 * 1024 * 1024:
                        raise ValueError('Unexpectedly large non-tar metadata member')
                    content = archive.read(info)
                    metadata[info.filename] = content
                    if info.filename.endswith('.transfer.json'):
                        receipts[info.filename.removesuffix('.transfer.json') + '.tar.gz'] = json.loads(content)
            if deep:
                for member, record in tar_records.items():
                    if record['archive'] != bundle_name:
                        continue
                    if member not in receipts:
                        raise ValueError('Compressed attempt lacks its transfer receipt')
                    with archive.open(member) as stream:
                        detail = verify_tar(stream, receipts[member], record['attempt_name'])
                    deep_files += detail['regular_files']
                    deep_bytes += detail['regular_bytes']
                    deep_links += detail['symbolic_links']
        measured_hash = None
        if bundle_name in bundle_hashes:
            with path.open('rb') as stream:
                size, measured_hash = digest_stream(stream)
            expected_bundle = bundle_hashes[bundle_name]
            if size != int(expected_bundle['bytes']) or measured_hash != expected_bundle['sha256']:
                raise ValueError('Outer ZIP hash differs: ' + bundle_name)
        bundles.append(dict(archive=bundle_name, bytes=path.stat().st_size, members=len(wanted), sha256=measured_hash))
        print(json.dumps(dict(verified_bundle=bundle_name, verified_members=checked_members,
                              checked_member_bytes=checked_bytes, deep=deep)), flush=True)
    if set(receipts) != set(tar_records):
        raise ValueError('Compressed attempts and transfer receipts are not one-to-one')
    regular_files = regular_bytes = symbolic_links = 0
    for member, record in tar_records.items():
        receipt = receipts[member]
        if receipt.get('copied_and_backup_hashes_verified') is not True or receipt['archive_bytes'] != record['bytes'] or receipt['archive_sha256'] != record['sha256']:
            raise ValueError('Compressed attempt differs from frozen transfer receipt: ' + member)
        seen = set()
        for item in receipt['files']:
            safe_name(item['path'])
            if item['path'] in seen:
                raise ValueError('Duplicate transfer-receipt member')
            seen.add(item['path'])
            if 'symlink' in item:
                symbolic_links += 1
            else:
                regular_files += 1
                regular_bytes += int(item['bytes'])
    cohort = validate_cohort(metadata, attempts)
    if deep and (deep_files, deep_bytes, deep_links) != (regular_files, regular_bytes, symbolic_links):
        raise ValueError('Deep tar member totals differ from receipts')
    bag_name = PREFIX + 'audits/scientific_bag/FINAL_BAG_CORROBORATION.json'
    bag = json.loads(metadata[bag_name])
    if bag['state'] != 'COMPLETE' or bag['counts'] != {'PASS': 824, 'NOT_ELIGIBLE_FAILED_DESIGN': 76} or bag['manifest_issues']:
        raise ValueError('Preserved bag corroboration accounting differs')
    return dict(status='PASS', verified_utc=datetime.now(timezone.utc).isoformat(), elapsed_s=time.monotonic()-started,
                bundles=bundles, member_files=checked_members, member_bytes=checked_bytes,
                zip_crc_and_member_sha256_verified=True, outer_zip_sha256_verified=len(bundle_hashes)==8,
                compressed_attempt_sha256_verified=True, cohort=cohort,
                receipt_regular_files=regular_files, receipt_regular_bytes=regular_bytes, receipt_symbolic_links=symbolic_links,
                deep_tar_content_verified=deep, deep_regular_files=deep_files, deep_regular_bytes=deep_bytes,
                qualification='File integrity and frozen design/attempt coverage only. No extraction, symbolic-link traversal, PX4 execution, new metric reconstruction, or scientific acceptance test. Deep tar content hashes are checked only with --deep.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archives-dir', type=Path, default=ROOT.parent)
    parser.add_argument('--manifest', type=Path, default=ROOT/'px4/PACKAGE_CONTENTS.csv')
    parser.add_argument('--bundle-hashes', type=Path, default=ROOT/'px4/ARCHIVE_SHA256.csv')
    parser.add_argument('--deep', action='store_true', help='Also decompress and hash every raw tar member without extraction (~108 GB of streamed content).')
    parser.add_argument('--report', type=Path, help='Optional new JSON report path; existing reports are not overwritten.')
    args = parser.parse_args()
    if args.report and args.report.exists():
        parser.error('Report already exists; choose a new report filename.')
    result = verify(args.archives_dir, args.manifest, args.deep, args.bundle_hashes)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        with args.report.open('x', encoding='utf-8') as stream:
            json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
