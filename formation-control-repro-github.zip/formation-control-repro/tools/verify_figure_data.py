"""Verify publication plotting records against frozen experimental tables.

Reads all eleven plot-data ledgers, checks estimates and seed blocks against the
archived evidence, verifies the declared decision/axis mappings, and writes a
machine-readable report. No experiments are run and no inputs are modified.
"""
from pathlib import Path
import argparse, json, hashlib, sys
import numpy as np
import pandas as pd
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
STATS=ROOT/'data/statistics'
J,E,N='formation_tracking_error','control_energy','event_trigger_count'
ARMS=['minimal','family','full_no_ppt']
PLANTS=['matched_point_mass','matched_lagged','mixed_6dof_3dof']
MODULES=['tvg','powers','approximator','observer','faultcomp','ppt','topology']
STRESS_ARMS=['minimal','full_no_ppt','ko_tvg','ko_powers','ko_approximator','ko_observer']
STRESS_SOURCES={'data/statistics/method_means.csv','data/statistics/runs_snapshot.csv',
                'data/envelope/flight_envelope_summary.csv','data/envelope/flight_envelope_per_job.csv'}
EXPECTED={'Figure_1':[0,0,0,0],'Figure_2':[9,6,9,9],'Figure_3':[7,7,7,7,7],'Figure_4':[12,6,5,5],'Figure_5':[9,12],'Figure_6':[0,0,0],'Figure_S1':[12,12],'Figure_S2':[12,12,12],'Figure_S3':[9],'Figure_S4':[6],'Graphical_abstract':[9,6]}
EXPECTED_SEEDS={'Figure_2':[180,0,180,180],'Figure_4':[240,0,0,0],'Figure_S4':[120]}
RECORD_TYPES={'estimate_interval','seed_blocks','ecdf','geometry','design_counts','envelope_events'}
TABLES={x:pd.read_csv(STATS/(x+'.csv')) for x in ['method_means','module_effect','cross_fidelity_interaction','attitude_interaction','descriptive_contrasts']}
TABLES['species']=pd.read_csv(ROOT/'data/envelope/core_species_means.csv')
RAW=pd.read_csv(STATS/'runs_snapshot.csv')
checks=[]
def check(name,value,detail=None):checks.append({'name':name,'passed':bool(value),'detail':detail})
def sub(df,**conditions):
    for k,v in conditions.items():
        df=df[np.isclose(df[k].to_numpy(float),v,rtol=0,atol=1e-12)] if isinstance(v,float) else df[df[k].eq(v)]
    return df
def match(name,panel,q):
    s=q['source_row'].copy()
    if name=='Figure_3':
        module=s.get('module',MODULES[int(round(q['position']))])
        if panel<3:return sub(TABLES['module_effect'],plant_model=PLANTS[panel],module=module)
        return sub(TABLES['cross_fidelity_interaction'],high_plant=PLANTS[panel-2],module=module)
    if name in ['Figure_2','Graphical_abstract'] and panel==1:
        return sub(TABLES['species'],plant_model=PLANTS[2],arm_id=s['arm_id'],species=s.get('species',s['row_index']))
    if name=='Figure_4' and panel>=2:
        return sub(TABLES['attitude_interaction'],arm_id=s['arm_id'],attitude_response_scale=float(s['attitude_response_scale']))
    if name=='Figure_S3' or (name=='Figure_5' and panel==0):
        return sub(TABLES['descriptive_contrasts'],campaign=s['campaign'],plant_model=s['plant_model'],arm_id=s['arm_id'],condition=s.get('condition',s.get('row_index')),metric=s['metric'],contrast=s['contrast'])
    campaign={'Figure_2':'core_fixed','Figure_4':'attitude_intervention','Figure_5':'information_contract','Figure_S1':'gain_sensitivity','Figure_S2':'refresh_tradeoff','Figure_S4':'attitude_intervention','Graphical_abstract':'core_fixed'}[name]
    plant=s.get('plant_model',s.get('row_index') if name in ['Figure_2','Graphical_abstract'] else PLANTS[2])
    condition=s.get('condition',s.get('row_index'))
    return sub(TABLES['method_means'],campaign=campaign,plant_model=plant,arm_id=s['arm_id'],condition=condition,metric=s['metric'])
def inbounds(axis,x,y):
    x=np.asarray(x,float);y=np.asarray(y,float); xl=sorted(axis['xlim']);yl=sorted(axis['ylim'])
    return np.isfinite(x).all() and np.isfinite(y).all() and (x>=xl[0]-1e-10).all() and (x<=xl[1]+1e-10).all() and (y>=yl[0]-1e-10).all() and (y<=yl[1]+1e-10).all()
def frozen_hash_matches(relative_path, expected_hash):
    candidate=(ROOT/relative_path).resolve()
    return (candidate.is_relative_to(ROOT.resolve()) and candidate.is_file()
            and hashlib.sha256(candidate.read_bytes()).hexdigest()==expected_hash)

def display_input_path(folder):
    resolved=folder.resolve()
    return resolved.relative_to(ROOT.resolve()).as_posix() if resolved.is_relative_to(ROOT.resolve()) else '<external figure directory>'

def allowed_record_types(name,panel):
    if name=='Figure_1':return set()
    if name=='Figure_6':return [{'design_counts'},{'ecdf'},{'geometry'}][panel]
    allowed={'estimate_interval'}
    if EXPECTED_SEEDS.get(name,[0]*len(EXPECTED[name]))[panel]:allowed.add('seed_blocks')
    if name=='Figure_S4':allowed.add('envelope_events')
    return allowed

def integer(value):
    return (not isinstance(value,(bool,np.bool_)) and isinstance(value,(int,float,np.number))
            and np.isfinite(value) and value==np.floor(value))

def audit_envelope_events(records,axis):
    """Check task-level event annotations separately from the logarithmic metric."""
    summary=pd.read_csv(ROOT/'data/envelope/flight_envelope_summary.csv')
    detail=pd.read_csv(ROOT/'data/envelope/flight_envelope_per_job.csv')
    rows=[q for q in records if q.get('type')=='envelope_events']
    check('Figure_S4:events:six_unique_methods',len(rows)==6 and
          {q.get('arm') for q in rows}==set(STRESS_ARMS))
    for n,q in enumerate(rows):
        key=f'Figure_S4:events:{n}'
        required={'arm','campaign','scale','tasks','crossings','inversions','labels','row','columns'}
        complete=required.issubset(q)
        check(key+':complete_record',complete)
        if not complete:continue
        identity=(q['arm'] in STRESS_ARMS and q['campaign']=='attitude_intervention'
                  and integer(q['scale']) and q['scale']==2)
        check(key+':scale_2_identity',identity)
        valid_counts=all(integer(q[k]) for k in ['tasks','crossings','inversions'])
        check(key+':integer_counts',valid_counts)
        if not identity or not valid_counts:continue
        check(key+':40_task_denominator_and_event_ranges',q['tasks']==40 and
              all(0<=q[k]<=q['tasks'] for k in ['crossings','inversions']))
        labels=q['labels']
        check(key+':exact_display_labels',isinstance(labels,dict) and
              labels=={k:f"{int(q[k])}/{int(q['tasks'])}" for k in ['crossings','inversions']})
        columns=q['columns']
        check(key+':annotation_column_mapping',isinstance(columns,dict) and
              set(columns)=={'crossings','inversions'} and
              all(isinstance(columns[k],(int,float)) and not isinstance(columns[k],bool)
                  and np.isfinite(columns[k]) for k in columns) and
              columns.get('crossings')==1.10 and columns.get('inversions')==1.43)
        check(key+':method_row_mapping',integer(q['row']) and q['row']==STRESS_ARMS.index(q['arm']) and
              min(axis['ylim'])<=q['row']<=max(axis['ylim']))
        chosen=sub(detail,campaign='attitude_intervention',arm_id=q['arm'],attitude_response_scale=2.0)
        group=sub(summary,campaign='attitude_intervention',arm_id=q['arm'],attitude_response_scale=2.0)
        snapshot=sub(RAW,campaign='attitude_intervention',arm_id=q['arm'],condition='bandwidth_2',plant_model=PLANTS[2])
        unit=['seed','scenario']
        complete_units=(len(chosen)==40 and chosen.job_id.nunique()==40 and
                        not chosen[unit].isna().any().any() and not chosen.duplicated(unit).any() and
                        chosen.seed.nunique()==20 and
                        chosen.groupby('seed').scenario.agg(set).map(
                            lambda x:x=={'nominal','combined_attack_fault'}).all())
        check(key+':20_complete_seed_pairs',complete_units)
        check(key+':same_jobs_as_frozen_snapshot',len(snapshot)==40 and snapshot.status.eq('ok').all() and
              set(chosen.job_id)==set(snapshot.job_id) and
              set(map(tuple,chosen[unit].to_numpy()))==set(map(tuple,snapshot[unit].to_numpy())))
        booleans=chosen[['any_reference_plane_crossing','any_inverted_uav']]
        boolean_values=all(isinstance(x,(bool,np.bool_)) for x in booleans.to_numpy().ravel())
        check(key+':complete_boolean_event_flags',boolean_values)
        if not boolean_values:continue
        crossings=chosen.any_reference_plane_crossing.to_numpy(bool)
        inversions=chosen.any_inverted_uav.to_numpy(bool)
        finite_bounds=np.isfinite(chosen[['min_uav_z_m','max_uav_tilt_rad']].to_numpy(float)).all()
        check(key+':trace_summary_event_definitions',finite_bounds and
              np.array_equal(crossings,chosen.min_uav_z_m.to_numpy(float)<=0) and
              np.array_equal(inversions,chosen.max_uav_tilt_rad.to_numpy(float)>=np.pi/2))
        counts={'tasks':len(chosen),'crossings':int(crossings.sum()),'inversions':int(inversions.sum())}
        check(key+':counts_from_all_per_job_rows',all(q[k]==v for k,v in counts.items()))
        check(key+':unique_summary_and_exact_counts',len(group)==1 and
              all(q[k]==group.iloc[0][col] for k,col in
                  [('tasks','tasks'),('crossings','reference_plane_crossings'),('inversions','inverted_tasks')]))
        # Events can co-occur in one task: neither category removes the other.
        check(key+':overlapping_events_retained',int((crossings & inversions).sum())>0,
              {'both_events':int((crossings & inversions).sum()),'events_are_mutually_exclusive':False})
    totals_valid=all(all(integer(q.get(k)) for k in ['tasks','crossings','inversions']) for q in rows)
    check('Figure_S4:events:all_240_tasks_163_crossings_200_inversions',totals_valid and
          tuple(sum(q[k] for q in rows) for k in ['tasks','crossings','inversions'])==(240,163,200))

def audit(folder,expected_names):
    checks.clear()
    total_intervals=total_seed_points=total_geometry_points=total_event_records=0
    figures=[]
    initial=json.loads((ROOT/'data/figure_sources/figure_input_hashes.json').read_text(encoding='utf-8'))['source_hashes']
    for path,h in initial.items():check('frozen_source:'+path,frozen_hash_matches(path,h))
    for name in expected_names:
        path=folder/(name+'.plot_data.json')
        check(name+':ledger_present',path.is_file())
        if not path.exists():continue
        data=json.loads(path.read_text(encoding='utf-8'))
        check(name+':ledger_identity',data.get('figure')==name)
        check(name+':axis_count',len(data['axes'])==len(EXPECTED[name]))
        if len(data['axes'])!=len(EXPECTED[name]):continue
        for source in data['sources']:
            check(name+':source_hash:'+source['path'],frozen_hash_matches(source['path'],source['sha256']))
        if name=='Figure_S4':
            bound={q['path'] for q in data['sources']}
            check(name+':all_four_frozen_sources_bound',STRESS_SOURCES.issubset(bound) and
                  len(bound)==len(data['sources']))
        summary={'figure':name,'plot_data_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'intervals':0,'seed_points':0,'geometry_points':0,'axes':[]}
        for i,axis in enumerate(data['axes']):
            original_records=axis['records'];records=[]
            for j,q in enumerate(original_records):
                typ=q.get('type')
                known=typ in RECORD_TYPES
                allowed=known and typ in allowed_record_types(name,i)
                check(f'{name}:{i}:record:{j}:known_record_type',known,typ)
                check(f'{name}:{i}:record:{j}:type_belongs_to_panel',allowed,typ)
                if allowed:records.append(q)
            intervals=[q for q in records if q['type']=='estimate_interval']
            check(f'{name}:{i}:interval_count',len(intervals)==EXPECTED[name][i],{'actual':len(intervals),'expected':EXPECTED[name][i]})
            source_identities=[]
            for j,q in enumerate(intervals):
                key=f'{name}:{i}:interval:{j}'
                rows=match(name,i,q)
                check(key+':unique_source_row',len(rows)==1)
                if len(rows)!=1:continue
                r=rows.iloc[0];mu=r['mean'] if 'mean' in r else r['mean_difference']
                if name=='Figure_S4' or (name=='Figure_4' and i==1):
                    check(key+':stress_scale_2_and_rigid_body',r.campaign=='attitude_intervention' and
                          r.condition=='bandwidth_2' and r.plant_model==PLANTS[2] and r.arm_id in STRESS_ARMS)
                source_identities.append(r.to_json())
                expected_metric=([J,None,E,N][i] if name=='Figure_2' else [J,E][i] if name=='Figure_S1' else [J,E,N][i] if name=='Figure_S2' else None if name=='Graphical_abstract' and i==1 else J)
                if expected_metric is not None:check(key+':metric_matches_panel',r.get('metric')==expected_metric)
                check(key+':exact_frozen_estimate',np.allclose([q['mean'],q['low'],q['high']],[mu,r.bca95_low,r.bca95_high],rtol=1e-13,atol=1e-13))
                coords=([q['low'],q['mean'],q['high']],[q['position']]*3) if q['horizontal'] else ([q['position']]*3,[q['low'],q['mean'],q['high']])
                check(key+':all_coordinates_visible',inbounds(axis,*coords))
                if name=='Figure_3':check(key+':Holm_fill_from_frozen_decision',q['solid']==bool(r.reject_at_0_05))
                if name=='Figure_4' and i==0:check(key+':fill_encodes_scale_only',q['solid']==(r.condition=='bandwidth_1'))
                if name=='Figure_S2':
                    threshold=float(r.condition.split('_')[1])
                    check(key+':actual_threshold_position',np.isclose(q['position'],threshold,rtol=0,atol=1e-14) and threshold in [.015,.035,.07,.14])
                    check(key+':logarithmic_threshold_axis',axis['xscale']=='log')
            check(f'{name}:{i}:distinct_source_rows',len(set(source_identities))==len(intervals))
            if name=='Figure_S4' or (name=='Figure_4' and i==1):
                check(f'{name}:{i}:all_six_stress_methods',len(intervals)==6 and
                      {q['source_row'].get('arm_id') for q in intervals}==set(STRESS_ARMS))
            total_intervals+=len(intervals);summary['intervals']+=len(intervals)
            pointcount=0
            for j,q in enumerate(records):
                if q['type']=='seed_blocks':
                    identity=q['identity'];camp='core_fixed' if name=='Figure_2' else 'attitude_intervention'
                    plant=identity.get('plant',PLANTS[2]);cond=identity.get('condition','baseline');metric=identity['metric']
                    rows=sub(RAW,campaign=camp,plant_model=plant,arm_id=q['arm'],condition=cond)
                    expected=rows.groupby('seed')[metric].mean().to_numpy(float)
                    values=q['y'] if name=='Figure_2' else q['x']
                    if name=='Figure_S4':
                        check(f'{name}:{i}:seed:{j}:stress_source_identity',plant==PLANTS[2] and
                              cond=='bandwidth_2' and metric==J and q['arm'] in STRESS_ARMS)
                    check(f'{name}:{i}:seed:{j}:all_20_frozen_blocks',q['count']==20 and len(values)==20 and np.allclose(values,expected,rtol=1e-13,atol=1e-13))
                    check(f'{name}:{i}:seed:{j}:no_point_cropped',inbounds(axis,q['x'],q['y']))
                    pointcount+=len(values)
                elif q['type']=='ecdf':
                    windows=pd.read_csv(ROOT/'data/figure_sources/rev_fig6_px4_pub__complete_record_windows.csv')
                    duration=np.sort(windows.common_window_duration_s.to_numpy());fraction=np.arange(1,825)/824
                    check('Figure_6:ecdf:all_824_observed_windows',q['count']==824 and np.allclose(q['duration_s'],duration,rtol=0,atol=1e-12) and np.array_equal(q['fraction'],fraction))
                    check('Figure_6:ecdf:no_coordinate_cropped',inbounds(axis,q['duration_s'],q['fraction']))
                elif q['type']=='geometry':
                    geo=pd.read_csv(ROOT/'data/figure_sources/rev_fig6_px4_pub__all_attempt_geometry_scope.csv');geo=geo[geo.plotted]
                    chosen=geo[geo.native_max_tilt_deg.ge(90)] if q['tilt_at_least_90'] else geo[geo.native_max_tilt_deg.lt(90)]
                    check(f'Figure_6:geometry:{j}:threshold_class',q['count']==len(chosen) and np.allclose(q['separation_m'],chosen.native_pair_center_distance_min_m,rtol=0,atol=1e-12) and np.allclose(q['tilt_deg'],chosen.native_max_tilt_deg,rtol=0,atol=1e-12))
                    check(f'Figure_6:geometry:{j}:no_coordinate_cropped',inbounds(axis,q['separation_m'],q['tilt_deg']))
                    total_geometry_points+=q['count'];summary['geometry_points']+=q['count']
                elif q['type']=='design_counts':
                    r=q['row'];groups=pd.read_csv(ROOT/'data/figure_sources/rev_fig6_px4_pub__group_counts.csv')
                    rr=sub(groups,campaign=r['campaign'],method=r['method'],contract=r['contract'])
                    check(f'Figure_6:counts:{j}',len(rr)==1 and all(int(r[k])==int(rr.iloc[0][k]) for k in ['designs','record_complete','failed_before_release','failed_after_release']))
            check(f'{name}:{i}:complete_seed_point_count',pointcount==EXPECTED_SEEDS.get(name,[0]*len(data['axes']))[i])
            if name=='Figure_S4':
                seeds=[q for q in records if q['type']=='seed_blocks']
                check('Figure_S4:all_six_seed_block_methods',len(seeds)==6 and
                      {q['arm'] for q in seeds}==set(STRESS_ARMS))
                check('Figure_S4:logarithmic_tracking_error_axis',axis['xscale']=='log')
                audit_envelope_events(records,axis)
                total_event_records+=sum(q['type']=='envelope_events' for q in records)
            if name=='Figure_6':
                typ=['design_counts','ecdf','geometry'][i]
                expected_records=[9,1,2][i]
                check(f'Figure_6:{i}:complete_record_type_count',sum(q['type']==typ for q in records)==expected_records)
                if i==0:
                    ids={(q['row']['campaign'],q['row']['method'],q['row']['contract']) for q in records if q['type']=='design_counts'}
                    groups=pd.read_csv(ROOT/'data/figure_sources/rev_fig6_px4_pub__group_counts.csv')
                    check('Figure_6:all_9_group_identities',ids==set(zip(groups.campaign,groups.method,groups.contract)))
                if i==2:check('Figure_6:all_824_geometry_points',sum(q['count'] for q in records if q['type']=='geometry')==824)
            total_seed_points+=pointcount;summary['seed_points']+=pointcount
            summary['axes'].append(dict(panel=axis['panel'],intervals=len(intervals),seed_points=pointcount,xlim=axis['xlim'],ylim=axis['ylim'],xscale=axis['xscale'],yscale=axis['yscale']))
        figures.append(summary)
    return dict(status='PASS' if all(q['passed'] for q in checks) else 'ISSUES',scope='Every registered record has a known type and a declared panel. Estimates and observations match frozen sources and visible metric bounds. S4 event annotations match all 240 task records and preserve overlapping events; their page placement is checked by the artwork verifier. No new simulations are run.',input_directory=display_input_path(folder),figures=figures,intervals=total_intervals,seed_points=total_seed_points,geometry_points=total_geometry_points,envelope_event_records=total_event_records,checks=list(checks),failures=[q for q in checks if not q['passed']],metadata={'new_experiments':0,'source_hash_reference':'data/figure_sources/figure_input_hashes.json','expected_figures':expected_names,'complete_figure_suite':set(expected_names)==set(EXPECTED)})
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=ROOT/'figures',help='Directory containing the eleven *.plot_data.json files.')
    parser.add_argument('--only',nargs='+',choices=list(EXPECTED),help='Verify an explicitly limited subset; the report records this scope.')
    parser.add_argument('--output',type=Path,default=ROOT/'outputs/figure_verification.json',help='Report path; parent directories are created if needed.')
    args=parser.parse_args()
    output=args.output.resolve()
    if output.is_relative_to((ROOT/'data').resolve()) or output==ROOT.resolve():
        raise ValueError('Write verification reports outside the frozen data directory.')
    report=audit(args.input,args.only or list(EXPECTED))
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ['checks','figures','metadata']},ensure_ascii=False,indent=2,allow_nan=False))
    raise SystemExit(0 if report['status']=='PASS' else 1)
