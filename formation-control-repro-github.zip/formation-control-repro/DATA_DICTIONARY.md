# Controlled-comparison data

`design/protocol.json` fixes the controller and dynamics hashes, candidate
vectors, search bounds, seed groups, budgets and primary inference rule.
`design/selection.json` stores parameters selected from validation records.
`design/inference.json` identifies the statistical implementation before formal
testing. The full protocol hash identifies the directory under `data/campaign`.

Each campaign stage has a `design.json` and separate `jobs` and `traces`
directories. A design row names an analysis arm; `job_id` identifies a physical
execution. Identical point-model executions shared by transfer and retuning
keep one job identifier. Their reuse does not add independent observations.
Every job record contains the resolved settings, parameter vector, completion
and failure status, measured CPU/wall time, trace path and trace SHA-256.

| Array | Shape | Meaning and units |
|---|---|---|
| `time` | K+1 | Outer sample time, seconds |
| `error_norm` | (K+1,N) | Each follower's planar Euclidean error, metres |
| `requested_force` | (K,N,2) | World-planar request before the common norm limiter, N |
| `actual_force_at_outer` | (K,N,2) | Realized world-planar actuator force at the start of the interval, N |
| `actual_impulse` | (K,N,2) | Integral of realized planar force over the outer interval, N s |
| `actual_force_squared_integral` | (K,N) | Integral of squared realized planar actuator-force norm, N² s |
| `actual_moment_squared_integral` | (K,N) | Integral of squared actuator-moment norm, N² m² s |
| `saturation_duration` | (K,N,2) | Outer-request and inner-allocation saturation durations, seconds |
| `physical_state` | (K+1,N,15) or (2,N,15) | Complete formal-test state history, or development initial/final state |
| `internal_state` | (K+1,N,18) | Fourteen approximation weights, two leaky-filter states and two RISE integral states |
| `internal_state_norm` | (K+1,N,3) | Norms of the approximation, filter and RISE states |
| `physical_events` | (N,3) | Counts of entering the below-reference-plane, inversion and speed-diagnostic states |
| `final_weights`, `final_error_filter`, `final_rise_integral` | Method-specific | Final controller states, with inactive modules retained as zeros |

Here N is eight on the native platform and four on Otter; K is 800 and
1,200 respectively. A numerically failed run retains its allocated arrays and
failure category. Unexecuted entries are nonfinite and cannot be treated as
zero, complete observations or usable final states.

Physical-state columns are: inertial position 0–2 (m); velocity 3–5 (m/s);
quaternion 6–9 (scalar first); body angular velocity 10–12 (rad/s); and two
lag/propeller states 13–14. Velocity is inertial for native UAVs and ideal
layers, and body-fixed for complete vessels. Columns 13–14 are force states
(N) in the lag model and propeller shaft speeds (rad/s, as in the upstream
Otter implementation) in the complete Otter model. These are not revolutions
per minute. Inactive state columns have no physical endpoint interpretation.

Tracking error is the trapezoidal integral of the sampled mean follower error
divided by mission duration. Force and moment effort sum the corresponding
per-interval integrals over all agents. They are not electrical energy or
fuel consumption. The outer sampled actual-force array alone cannot recover
the force-squared integral when attitude or propeller state changes within an
interval; the archived quadrature integrals are required.

Numerical records keep the job, parameters, reference tolerances and every
tested physical step. RK4 and segmented DOP853 use the same physical RHS and
the same controller clocks. `J_bound_m` is an observed absolute difference
from that reference, not a proved uniform error bound. The primary analysis
sums observed per-arm discrepancies and reports its checked scope.

Analysis tables preserve the complete test design. `paired_seed_blocks.csv`
contains equal-weight scenario aggregates. `primary_contrasts.csv` contains
the twelve mean interactions and simultaneous intervals. Files prefixed
`secondary_` contain pointwise descriptive analyses; their intervals are
not simultaneous. The two independent platform cohorts each have 50 blocks.

`source_fixture_v2` is the source-condition reconstruction for RISE. It includes
unsuccessful finite trajectories. Its noisy/delayed cases do not establish
reproduction of the source figures. The main controlled comparison uses a
separate graph and common periodic information without these delays.
